#!/usr/bin/env julia

const PROJECT_ROOT = normpath(joinpath(@__DIR__, "..", ".."))

if !isdefined(Main, :ScanOptions)
    include(joinpath(PROJECT_ROOT, "scripts", "relaxtime", "run_gap_transport_scan.jl"))
end

include(joinpath(PROJECT_ROOT, "scripts", "relaxtime", "phase_guided_transport_scan_cli.jl"))
include(joinpath(PROJECT_ROOT, "scripts", "relaxtime", "phase_guided_transport_scan_plan.jl"))
include(joinpath(PROJECT_ROOT, "scripts", "relaxtime", "phase_guided_transport_scan_assets.jl"))

const PhaseGuidedCLI = PhaseGuidedTransportScanCLI
const PhaseGuidedPlan = PhaseGuidedTransportScanPlan
const PhaseGuidedAssets = PhaseGuidedTransportScanAssets

function _default_output_paths(opts::PhaseGuidedCLI.PhaseGuidedScanOptions)
    result_csv = joinpath(opts.outdir, "phase_guided_transport_scan.csv")
    plan_csv = joinpath(opts.outdir, "sampling_plan.csv")
    readme = joinpath(opts.outdir, "README.md")
    effective_config = joinpath(opts.outdir, "effective_config.json")
    failed_points = joinpath(opts.outdir, "failed_points.csv")
    channel_diagnostics = joinpath(opts.outdir, "channel_diagnostics.csv")
    return (; result_csv, plan_csv, readme, effective_config, failed_points, channel_diagnostics)
end

function _default_figure_dir(opts::PhaseGuidedCLI.PhaseGuidedScanOptions)
    mode_dir = opts.mode == :mode_a_fixed_muB_phase_scaled ? "mode_a_fixed_muB_phase_scaled" : "mode_b_fixed_T_sparse_muB"
    return joinpath(PROJECT_ROOT, "data", "outputs", "figures", "relaxtime", "transport", "phase_guided", mode_dir, opts.case_name)
end

function _build_runtime_scan_opts(result_csv::String, opts::PhaseGuidedCLI.PhaseGuidedScanOptions)
    base_args = String[
        "--output", result_csv,
        "--provenance-dir", opts.outdir,
        "--failed-points-output", joinpath(opts.outdir, "failed_points.csv"),
        "--propagator-xi-policy", String(opts.propagator_xi_policy),
        "--sigma-cache-policy", String(opts.sigma_cache_policy),
        "--p-num", string(opts.p_num),
        "--t-num", string(opts.t_num),
    ]
    opts.tau_p_nodes !== nothing && append!(base_args, ["--tau-p-nodes", string(opts.tau_p_nodes)])
    opts.tau_angle_nodes !== nothing && append!(base_args, ["--tau-angle-nodes", string(opts.tau_angle_nodes)])
    opts.tau_phi_nodes !== nothing && append!(base_args, ["--tau-phi-nodes", string(opts.tau_phi_nodes)])
    opts.tau_n_sigma_points !== nothing && append!(base_args, ["--tau-n-sigma", string(opts.tau_n_sigma_points)])
    opts.sigma_grid_n !== nothing && append!(base_args, ["--sigma-grid-n", string(opts.sigma_grid_n)])
    opts.channel_diagnostics && append!(base_args, ["--channel-diagnostics-output", joinpath(opts.outdir, "channel_diagnostics.csv")])
    !opts.compute_bulk && push!(base_args, "--no-compute-bulk")
    opts.overwrite && push!(base_args, "--overwrite")
    opts.resume && push!(base_args, "--resume")
    return Main.parse_args(base_args)
end

function _point_meta(point)
    return (
        mode=point.mode,
        phase_reference_kind=point.phase_reference_kind,
        scan_group=point.scan_group,
        group_label=point.group_label,
        plot_panel=point.plot_panel,
        plot_panel_label=point.plot_panel_label,
        plot_series=point.plot_series,
        plot_series_label=point.plot_series_label,
        T_phase_base_MeV=point.T_phase_base_MeV,
        alpha_T=point.alpha_T,
        phase_anchor_method=point.phase_anchor_method,
        coexistence_side=point.coexistence_side,
        coexistence_certified=point.coexistence_certified,
        coexistence_delta_xi=point.coexistence_delta_xi,
    )
end

function run_phase_guided_scan(opts::PhaseGuidedCLI.PhaseGuidedScanOptions, ctx;
    phase_reference=nothing,
    phase_reference_mode::Symbol=:runtime,
)
    paths = _default_output_paths(opts)
    figure_dir = _default_figure_dir(opts)
    mkpath(opts.outdir)

    if opts.overwrite
        for path in (paths.result_csv, paths.plan_csv, paths.readme, paths.effective_config, paths.failed_points, paths.channel_diagnostics)
            isfile(path) && rm(path)
        end
    end

    plan = PhaseGuidedPlan.build_plan(
        opts;
        phase_reference=phase_reference,
        phase_reference_mode=phase_reference_mode,
    )
    PhaseGuidedAssets.write_plan_csv(paths.plan_csv, plan)
    PhaseGuidedAssets.write_readme(paths.readme, opts, plan; result_csv_name=basename(paths.result_csv), figure_dir=replace(figure_dir, '\\' => '/'), phase_reference=phase_reference)
    PhaseGuidedAssets.write_effective_config(paths.effective_config, PhaseGuidedAssets.build_effective_config(opts, paths.result_csv, paths.plan_csv; figure_dir=replace(figure_dir, '\\' => '/'), phase_reference=phase_reference))

    if opts.dry_run
        Main.ProvenanceMetadata.write_run_sidecars(
            opts.outdir;
            ctx=ctx,
            effective_config=PhaseGuidedAssets.build_effective_config(opts, paths.result_csv, paths.plan_csv; figure_dir=replace(figure_dir, '\\' => '/'), phase_reference=phase_reference),
            artifacts=[paths.plan_csv, paths.readme, paths.effective_config],
            summary=Dict{String,Any}("points_total" => plan.total, "dry_run" => true),
        )
        println("Phase-guided transport plan prepared (dry-run). Output: $(opts.outdir)")
        return plan
    end

    scan_opts = _build_runtime_scan_opts(paths.result_csv, opts)
    runtime = Main.build_scan_runtime(scan_opts)
    existing = scan_opts.resume && isfile(paths.result_csv) && !scan_opts.overwrite ?
        Main.read_existing_keys(paths.result_csv) :
        Set{Tuple{Float64,Float64,Float64}}()

    if scan_opts.overwrite && isfile(paths.result_csv)
        rm(paths.result_csv)
    end

    io = open(paths.result_csv, "a")
    failed_io = open(paths.failed_points, "a")
    channel_io = opts.channel_diagnostics ? open(paths.channel_diagnostics, "a") : nothing
    # Bind the result before the try/finally block; the provenance summary is
    # written after streams are closed and must remain a function-local value.
    stats = nothing
    try
        if filesize(paths.result_csv) == 0
            Main.ScanCSV.write_metadata(io, Dict(
                "schema" => "scan_csv_v1",
                "title" => "phase_guided_transport_scan",
                "script" => "scripts/relaxtime/run_phase_guided_transport_scan.jl",
                "git_commit" => Main.current_git_commit(),
            ))
            Main.write_header_if_needed(io)
        end
        if filesize(paths.failed_points) == 0
            Main.write_failed_points_header_if_needed(failed_io)
        end
        if channel_io !== nothing && filesize(paths.channel_diagnostics) == 0
            Main.ScanCSV.write_metadata(channel_io, Dict(
                "schema" => "scan_csv_v1",
                "title" => "phase_guided_transport_scan_channel_diagnostics",
                "script" => "scripts/relaxtime/run_phase_guided_transport_scan.jl",
                "git_commit" => Main.current_git_commit(),
                "source_csv" => paths.result_csv,
                "propagator_xi_policy" => string(opts.propagator_xi_policy),
                "sigma_cache_policy" => string(opts.sigma_cache_policy),
            ))
            Main.write_channel_diagnostics_header_if_needed(channel_io)
        end

        stats = PhaseGuidedPlan.execute_plan!(
            (point, previous_solution, previous_phase) ->
                Main.execute_gap_transport_scan_point!(
                    io,
                    channel_io,
                    failed_io,
                    point.T_MeV,
                    point.muB_MeV,
                    point.xi,
                    scan_opts,
                    ctx,
                    runtime;
                    previous_solution=previous_solution,
                    previous_phase=previous_phase,
                    phase_reference=phase_reference,
                    phase_reference_mode=phase_reference_mode,
                    point_meta=_point_meta(point),
                ),
            opts,
            plan,
            existing,
        )

    finally
        close(io)
        close(failed_io)
        channel_io !== nothing && close(channel_io)
    end

    # Hashes must be taken only after all producer streams have been flushed and
    # closed.  In particular, a header-only failed_points.csv is a valid zero-row
    # artifact and must not be hashed as an empty file.
    Main.ProvenanceMetadata.write_run_sidecars(
        opts.outdir;
        ctx=ctx,
        effective_config=PhaseGuidedAssets.build_effective_config(opts, paths.result_csv, paths.plan_csv; figure_dir=replace(figure_dir, '\\' => '/'), phase_reference=phase_reference),
        artifacts=opts.channel_diagnostics ?
            [paths.result_csv, paths.plan_csv, paths.readme, paths.effective_config, paths.failed_points, paths.channel_diagnostics] :
            [paths.result_csv, paths.plan_csv, paths.readme, paths.effective_config, paths.failed_points],
        summary=Dict{String,Any}(
            "points_total" => stats.total,
            "success_count" => stats.success,
            "error_count" => stats.error,
            "skipped_count" => stats.skipped,
        ),
    )

    println("Phase-guided transport scan finished. Output: $(paths.result_csv)")
    return plan
end

function main()
    opts = PhaseGuidedCLI.parse_args(copy(ARGS))
    ctx = Main.ProvenanceMetadata.new_run_context("scripts/relaxtime/run_phase_guided_transport_scan.jl", copy(ARGS))
    phase_reference = Main._load_runtime_phase_reference(opts)
    run_phase_guided_scan(opts, ctx;
        phase_reference=phase_reference,
        phase_reference_mode=opts.phase_reference_mode,
    )
end

if abspath(PROGRAM_FILE) == @__FILE__
    main()
end
