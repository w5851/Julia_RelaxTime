"""q=0 invariant-extrapolation counterpart of the charged GBU muB probe.

This analysis-only script reuses the same upstream FixedMuBConservedCharges
background perturbations as ``scan_charged_gbu_mub_sensitivity.jl`` and changes
only the meson-density kernel route to ``q0_lambda_reference``.  It is kept in
the isolated sensitivity worktree and never writes a production baseline.
"""
module ChargedGBUMuBQ0Sensitivity

using CSV
using Dates
using JSON3
using SHA
using TOML

const ROOT = normpath(joinpath(@__DIR__, "..", "..", ".."))
isdefined(Main, :Models) || Base.include(Main, joinpath(ROOT, "src", "models", "Models.jl"))
isdefined(Main, :ChargedGBUResearchWorkflow) || Base.include(
    Main, joinpath(ROOT, "src", "models", "workflow_apps", "ChargedGBUResearchWorkflow.jl"))
isdefined(Main, :ChargedGBUMuBSensitivity) || Base.include(
    Main, joinpath(ROOT, "scripts", "analysis", "relaxtime", "scan_charged_gbu_mub_sensitivity.jl"))
isdefined(Main, :CausalGBUResearch) || Base.include(
    Main, joinpath(ROOT, "scripts", "analysis", "relaxtime", "causal_gbu_research_utils.jl"))

const Models = Main.Models
const W = Main.ChargedGBUResearchWorkflow
const S = Main.ChargedGBUMuBSensitivity
const Q0 = Main.CausalGBUResearch

const DEFAULT_CONFIG = W.DEFAULT_CONFIG
const DEFAULT_BASELINE = S.DEFAULT_BASELINE
const DEFAULT_OUTPUT = joinpath(ROOT, "data", "outputs", "results", "relaxtime", "analysis",
    "charged_rpa_phase_backend", "muB_sensitivity_q0_20260913_v1")
const DEFAULT_ENERGIES = [3.0, 5.0, 7.7]
const DEFAULT_OFFSETS = [-50.0, 0.0, 50.0]

Base.@kwdef struct Q0Settings
    mesh::Int = 512
    np::Int = 128
    nx::Int = 64
    ne::Int = 128
    nw::Int = 4800
    nr::Int = 128
    nq::Int = 24
    qmax::Float64 = 8.0
    thermal::Float64 = 24.0
    lower::Float64 = 1e-5
    upper::Float64 = 56.0
    phase_tol::Float64 = 0.005
end

function q0_density(bg, channel::Symbol, settings::Q0Settings)
    s = Q0.Settings(mesh=settings.mesh, np=settings.np, nx=settings.nx, ne=settings.ne,
        nw=settings.nw, nr=settings.nr, nq=settings.nq, qmax=settings.qmax,
        thermal=settings.thermal, lower=settings.lower, upper=settings.upper,
        phase_tol=settings.phase_tol)
    return Q0.density(bg, channel, s; reference=true)
end

function ratio_from_channels(results)
    p = results["pi_plus"]
    k = results["K_plus"]
    ok = p.passed && k.passed && isfinite(p.density) && isfinite(k.density) &&
        p.density > 0.0 && k.density >= 0.0
    return ok ? k.density / p.density : NaN, ok
end

function run_scan(; output=DEFAULT_OUTPUT, baseline_output=DEFAULT_BASELINE,
    config=DEFAULT_CONFIG, energies=DEFAULT_ENERGIES, offsets=DEFAULT_OFFSETS,
    settings=Q0Settings())
    grids = S.validate_grids(energies, offsets)
    output = abspath(output)
    ispath(output) && error("refusing to overwrite existing output: $(output)")
    mkpath(output)
    c = TOML.parsefile(config)
    profile = Models.load_freezeout_profile(profile=String(c["freezeout_profile"]))
    points = S.probe_points(grids.energies, grids.offsets; profile=profile)
    model = Models.create_model(:PNJL)
    backgrounds = NamedTuple[]
    ratios = NamedTuple[]
    densities = NamedTuple[]
    failures = NamedTuple[]
    baseline_cache = Dict{Float64,Any}()
    for point in points
        base = get!(baseline_cache, point.sqrt_s_NN_GeV) do
            S.read_baseline_point(baseline_output, point)
        end
        solved = nothing
        source = "new_bqs_solve"
        seed_reused = false
        if point.delta_muB_MeV == 0.0 && base !== nothing
            solved = base
            source = base.source
            seed_reused = true
        else
            seed = base === nothing ? nothing : base.seed
            try
                solved = W.background(model,
                    (T_MeV=point.T_MeV, muB_MeV=point.muB_MeV), c; seed=seed)
            catch err
                push!(failures, (sqrt_s_NN_GeV=point.sqrt_s_NN_GeV,
                    delta_muB_MeV=point.delta_muB_MeV, stage="background",
                    reason=sprint(showerror, err), production_authorized=false))
                continue
            end
        end
        bg = solved.bg
        push!(backgrounds, S.background_row(point, bg; source=source, seed_reused=seed_reused))
        result_map = Dict{String,Any}()
        for channel in (:pi_plus, :K_plus)
            result = try
                q0_density(bg, channel, settings)
            catch err
                push!(failures, (sqrt_s_NN_GeV=point.sqrt_s_NN_GeV,
                    delta_muB_MeV=point.delta_muB_MeV, stage=String(channel),
                    reason=sprint(showerror, err), production_authorized=false))
                nothing
            end
            result === nothing && continue
            result_map[String(channel)] = result
            push!(densities, (sqrt_s_NN_GeV=point.sqrt_s_NN_GeV,
                T_MeV=point.T_MeV, baseline_muB_MeV=point.baseline_muB_MeV,
                delta_muB_MeV=point.delta_muB_MeV, muB_MeV=point.muB_MeV,
                channel=String(channel), density_inv_fm3=result.density,
                passed=result.passed, production_authorized=false))
        end
        ratio, passed = ratio_from_channels(result_map)
        push!(ratios, (sqrt_s_NN_GeV=point.sqrt_s_NN_GeV, T_MeV=point.T_MeV,
            baseline_muB_MeV=point.baseline_muB_MeV,
            delta_muB_MeV=point.delta_muB_MeV, muB_MeV=point.muB_MeV,
            ratio=ratio, ratio_passed=passed, source=source,
            route="q0_lambda_reference", production_authorized=false))
        CSV.write(joinpath(output, "backgrounds.csv"), backgrounds)
        CSV.write(joinpath(output, "densities.csv"), densities)
        CSV.write(joinpath(output, "ratios.csv"), ratios)
        CSV.write(joinpath(output, "failures.csv"), failures)
        println("[mub-q0] sqrt_s=$(point.sqrt_s_NN_GeV) delta=$(point.delta_muB_MeV) ratio=$(ratio) pass=$(passed)")
        flush(stdout)
    end
    derivatives = S.sensitivity_rows(
        [merge(r, (ratio=r.ratio,)) for r in ratios if r.ratio_passed];
        delta_muB_MeV=minimum(filter(>(0.0), grids.offsets)))
    CSV.write(joinpath(output, "derivatives.csv"), derivatives)
    manifest = Dict{String,Any}(
        "schema" => "charged_gbu_mub_q0_sensitivity_v1",
        "status" => isempty(failures) ? "diagnostic_completed" : "diagnostic_completed_with_failures",
        "background" => "FixedMuBConservedCharges quark-only BQS; rhoQ/rhoB=0.4; rhoS=0",
        "scan_axis" => "muB at fixed baseline freezeout T",
        "route" => "q0_lambda_reference",
        "q0_mapping" => "lambda=k0+mu1-mu2; k0_0=sqrt(lambda^2-q^2)-(mu1-mu2); lambda>=q",
        "settings" => settings,
        "energies_GeV" => grids.energies,
        "muB_offsets_MeV" => grids.offsets,
        "point_count" => length(points), "ratio_count" => length(ratios),
        "failure_count" => length(failures), "derivative_count" => length(derivatives),
        "production_authorized" => false, "complete_curve_authorized" => false,
        "generated_at_utc" => string(Dates.now(Dates.UTC)),
        "source_git_head" => readchomp(`git -C $ROOT rev-parse HEAD`))
    open(joinpath(output, "manifest.json"), "w") do io
        JSON3.write(io, manifest)
    end
    return (output=output, ratios=length(ratios), failures=length(failures))
end

function main(args=ARGS)
    result = run_scan()
    println(result)
end

abspath(PROGRAM_FILE) == abspath(@__FILE__) && main()

end # module ChargedGBUMuBQ0Sensitivity
