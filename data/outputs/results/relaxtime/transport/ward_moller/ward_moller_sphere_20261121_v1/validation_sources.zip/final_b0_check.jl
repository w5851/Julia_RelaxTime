include(joinpath(@__DIR__, "loops.jl"))

function main_final_b0()
    out = abspath(ARGS[2]); mkpath(out)
    profile = SP.load_profile("ward_moller_sphere_v1")
    sampled = Dict(String(r.point_id)=>r for r in CSV.File(joinpath(CASE,"final_checks_grid.csv")))
    wanted = ["a0203","a0303","a0607","a0653","a0654","a0776","a0777","a0839"]
    # Include both ends of the intermediate high-density band from the frozen grid.
    append!(wanted,[id for (id,r) in sampled if r.muB_MeV==900.0 && r.alpha_T==1.1 && abs(r.xi)==0.5])
    unique!(wanted)
    output = NamedTuple[]
    for id in wanted
        haskey(sampled,id) || continue
        row = sampled[id]; qp,tp = background(row)
        st0 = SP.fixed_point_state(profile,qp,tp)
        st = (qp=st0.quark_params,tp=st0.thermo_params,K=st0.K_coeffs)
        for meson in (:pi,:K)
            seed=(MM.default_meson_mass_guess(meson,st.qp),0.0)
            linear=reliable_pole(meson,st,seed;kind=:linear,nr=192,na=24)
            isfinite(linear.mass) || error("linear pole failed at $id/$meson")
            full=reliable_pole(meson,st,(linear.mass,linear.gamma);kind=:full,nr=192,na=24)
            fullfine=reliable_pole(meson,st,(full.mass,full.gamma);kind=:full,nr=256,na=32)
            linearfine=reliable_pole(meson,st,(linear.mass,linear.gamma);kind=:linear,nr=256,na=32)
            all(isfinite,(full.mass,full.gamma,fullfine.mass,fullfine.gamma,linearfine.mass,linearfine.gamma)) ||
                error("nonfinite final B0 pole at $id/$meson")
            native=MM.meson_mass_equation(meson,linearfine.mass,linearfine.gamma,0.0,st.qp,st.tp,st.K)
            push!(output,(point_id=id,T_MeV=row.T_MeV,muB_MeV=row.muB_MeV,xi=row.xi,
                meson=String(meson),a_prescription="ward_matched",b0_direction="sphere_average",
                linear_mass_MeV=HC*linearfine.mass,linear_width_MeV=HC*linearfine.gamma,
                full_mass_MeV=HC*fullfine.mass,full_width_MeV=HC*fullfine.gamma,
                mass_shift_MeV=HC*(fullfine.mass-linearfine.mass),
                width_shift_MeV=HC*(fullfine.gamma-linearfine.gamma),
                mass_refinement_MeV=HC*max(abs(fullfine.mass-full.mass),abs(linearfine.mass-linear.mass)),
                width_refinement_MeV=HC*max(abs(fullfine.gamma-full.gamma),abs(linearfine.gamma-linear.gamma)),
                native_linear_pole_residual=abs(native),full_pole_residual=fullfine.residual,
                soft_pion_residual=soft_residual(st)))
        end
        converged_result("final_b0_poles",output,out)
        println("DONE_FINAL_B0 ",id);flush(stdout)
    end
end
main_final_b0()
