# Reuse the independently checked angular-blocking integrator with final Ward/sphere inputs.
const original_driver=joinpath(@__DIR__,"transport.jl")
const final_driver=replace(read(original_driver,String),
    "state=loop_state(qp,tp,scheme)"=>
    "base_state=loop_state(qp,tp,scheme); state=merge(base_state,(tp=merge(base_state.tp,(b0_direction=:sphere_average,)),))")
include_string(Main,final_driver,original_driver)
