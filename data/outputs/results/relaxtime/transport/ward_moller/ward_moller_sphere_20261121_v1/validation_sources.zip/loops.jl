# Independent real-axis loop integrals; only the occupation is deformed.
include(joinpath(@__DIR__, "common.jl"))

const QUAD = Dict{Int,Tuple{Vector{Float64},Vector{Float64}}}()
quad(n) = get!(QUAD, n) do
    GL.gauleg(-1.0, 1.0, n)
end

function bisect(f, a, b; tol=1e-9)
    fa, fb = f(a), f(b)
    fa == 0 && return a
    fb == 0 && return b
    isfinite(fa) && isfinite(fb) && signbit(fa) != signbit(fb) ||
        error("root does not bracket: $a $b ($fa $fb)")
    while b-a > tol
        x = (a+b)/2
        fx = f(x)
        isfinite(fx) || error("nonfinite value at $x")
        fx == 0 && return x
        if signbit(fx) == signbit(fa)
            a, fa = x, fx
        else
            b = x
        end
    end
    return (a+b)/2
end

function thermal_occ(kind, sign, p, m, mu, tp, x, beta, nphi)
    E = hypot(p, m)
    if kind === :full && tp.ξ != 0.0
        if beta == 0.0
            return DA.distribution_aniso(sign, p, m, mu, tp.T, tp.Φ, tp.Φbar, tp.ξ, x)
        end
        cz = x*cos(beta)
        sz = sqrt(max(0.0, 1-x*x))*sin(beta)
        return sum(DA.distribution_aniso(sign, p, m, mu, tp.T, tp.Φ, tp.Φbar,
            tp.ξ, cz+sz*cospi(2j/nphi)) for j in 0:nphi-1)/nphi
    end
    f = OL.distribution_value(:pnjl, sign===:quark ? :plus : :minus, E, mu, tp.T, tp.Φ, tp.Φbar)
    kind === :linear || return f
    c = DA.correction_cos_theta_coefficient(sign, p, m, mu, tp.T, tp.Φ, tp.Φbar, tp.ξ)
    return f+c*(x^2*cos(beta)^2+(1-x^2)*sin(beta)^2/2)
end

function occupation_average(kind, sign, p, m, mu, tp, na)
    kind === :iso && return thermal_occ(:iso, sign, p, m, mu, tp, 0.0, 0.0, na)
    kind === :linear && return thermal_occ(:linear, sign, p, m, mu, tp, inv(sqrt(3.0)), 0.0, na)
    xs, ws = quad(na)
    # The occupation is even in the polar cosine. Map the rule to [0,1].
    return sum((w/2)*thermal_occ(:full, sign, p, m, mu, tp, (x+1)/2, 0.0, na)
        for (x,w) in zip(xs,ws))
end

function tilde_at_rest(kind, sign, lambda, m, m2, mu, tp, nr, na)
    xs, ws = quad(nr)
    lim = CUT
    e0 = -(lambda^2+m^2-m2^2)/(2lambda)
    function F(p)
        f = occupation_average(kind, sign, p, m, mu, tp, na)
        return sign===:quark ? f : 1-f
    end
    if !(0<=e0<hypot(lim,m))
        val=sum((w*lim/2)*(p=(x+1)*lim/2; e=hypot(p,m); p*p*F(p)/(e*(e-e0)))
            for (x,w) in zip(xs,ws))
        return complex(2val/lambda,0.0)
    end
    G(p) = (1+e0/hypot(p,m))*F(p)
    q2=(e0-m)*(e0+m)
    q=sqrt(abs(q2))
    cq=G(q2>0 ? q : 0.0)
    smooth=0.0
    for (x,w) in zip(xs,ws)
        p=(x+1)*lim/2
        d=p*p-q2
        divided=if abs(d)<1e-12
            h=1e-6*max(p,1.0)
            (G(p+h)-G(max(0.0,p-h)))/((p+h)^2-max(0.0,p-h)^2)
        else
            (G(p)-cq)/d
        end
        smooth+=(w*lim/2)*p*p*divided
    end
    integral=q2>0 ? lim+(q/2)*log((lim-q)/(lim+q)) : (q2<0 ? lim-q*atan(lim/q) : lim)
    imagpart=q2>0 ? 2pi*q*F(q)/lambda : 0.0
    return complex(2*(smooth+cq*integral)/lambda, imagpart)
end

function tilde_at_momentum(kind, sign, lambda, k, m, m2, mu, tp, beta, nr, na)
    emin, emax = m, hypot(CUT,m)
    r = COR.find_roots_AB(lambda,k,m,m2,emin,emax)
    ends = sort!(unique!([emin; [e for e in r if emin<e<emax]; emax]))
    xs, ws = quad(na)
    ys, vs = quad(nr)
    result=0.0im
    for j in 1:length(ends)-1
        lo, hi=ends[j], ends[j+1]
        for (y,v) in zip(ys,vs)
            angle=pi*(y+1)/2
            e=lo+(hi-lo)*sin(angle/2)^2
            jac=(hi-lo)*pi*sin(angle)/4
            p=sqrt(max(0.0,(e-m)*(e+m)))
            p>0 || continue
            a=2p*k
            b=lambda^2+2lambda*e+m^2-m2^2-k^2
            x0=-b/a
            function F(x)
                f=thermal_occ(kind, sign, p, m, mu, tp, x, beta, na)
                return sign===:quark ? f : 1-f
            end
            fc=F(clamp(x0,-1.0,1.0))
            principal=fc*(log(abs(1-x0))-log(abs(1+x0)))
            for (x,w) in zip(xs,ws)
                d=x-x0
                fx=if abs(d)<1e-10
                    h=1e-6
                    (F(x+h)-F(x-h))/(2h)
                else
                    (F(x)-fc)/d
                end
                principal+=w*fx
            end
            residue=abs(x0)<1 ? pi*Base.sign(lambda)*fc : 0.0
            result+=v*jac*complex(principal,residue)/k
        end
    end
    return result
end

function b0_quad(kind, lambda, k, pp, tp; beta=0.0, nr=128, na=20)
    function tilde(kind, s, l, m, m2, mu)
        return k==0 ? tilde_at_rest(kind,s,l,m,m2,mu,tp,nr,na) :
            tilde_at_momentum(kind,s,l,k,m,m2,mu,tp,beta,nr,na)
    end
    return tilde(kind,:quark,-lambda,pp.m1,pp.m2,pp.μ1)-
           tilde(kind,:antiquark,lambda,pp.m1,pp.m2,pp.μ1)+
           tilde(kind,:quark,lambda,pp.m2,pp.m1,pp.μ2)-
           tilde(kind,:antiquark,-lambda,pp.m2,pp.m1,pp.μ2)
end

function b0_native(kind, lambda, k, pp, tp)
    val=complex(OL.B0(lambda,k,pp.m1,pp.μ1,pp.m2,pp.μ2,tp.T; Φ=tp.Φ,Φbar=tp.Φbar)...)
    if kind===:linear && tp.ξ!=0
        val+=complex(COR.B0_correction(lambda,k,pp.m1,pp.m2,pp.μ1,pp.μ2,tp.T,tp.Φ,tp.Φbar,tp.ξ)...)
    end
    return val
end

function mass_inverse(meson, state, mass; gamma=0.0, k=0.0, kind=:linear, nr=128, na=20, beta=0.0, native=false)
    pp=MM._meson_polarization_params(meson,state.qp)
    coupling=MM._meson_coupling(meson,state.K)
    tp=state.tp
    lambda=mass+pp.μ1-pp.μ2
    b0(l)=native ? b0_native(kind,l,k,pp,tp) : b0_quad(kind,l,k,pp,tp;beta=beta,nr=nr,na=na)
    b=b0(lambda)
    if pp.num_s_quark==1
        b=(b+b0(-mass+pp.μ1-pp.μ2))/2
    end
    delta=pp.channel===:P ? pp.m1-pp.m2 : pp.m1+pp.m2
    return 1+(coupling*C.N_color/(2pi^2))*(pp.A1+pp.A2+(delta^2+k^2-(lambda-im*gamma/2)^2)*b)
end

function reliable_pole(meson, state, seed, previous=nothing; kind=:linear, nr=96, na=16, native=false,
    check_threshold=nothing)
    qp,tp=state.qp,state.tp
    thr=MT.mott_threshold_mass(meson,qp)
    f(m,w)=native ? MM.meson_mass_equation(meson,m,w,0.0,qp,tp,state.K) :
        mass_inverse(meson,state,m;gamma=w,kind=kind,nr=nr,na=na)
    low=0.003
    high=thr
    # These positive masses have no lower pseudo-threshold cut for the light
    # equal-mass channel. For K, stay above |m_s-m_u|.
    if meson===:K
        low=max(low,abs(qp.m.s-qp.m.u)+0.002)
    end
    if !native && low<high
        a, b = real(f(low,0.0)), check_threshold===nothing ? real(f(high,0.0)) : check_threshold
        if abs(b)<2e-10
            return (mass=high,gamma=0.0,residual=abs(f(high,0.0)),status="threshold")
        elseif isfinite(a) && isfinite(b) && signbit(a)!=signbit(b)
            root=bisect(m->real(f(m,0.0)),low,high;tol=4e-11)
            error_norm=abs(f(root,0.0))
            if error_norm<2e-7
                return (mass=root,gamma=0.0,residual=error_norm,status="bound")
            end
        end
    end
    guesses=Tuple{Float64,Float64}[seed]
    previous===nothing || push!(guesses,(previous.mass,previous.gamma))
    default=MM.default_meson_mass_guess(meson,qp)
    append!(guesses,[(default,0.0),(max(thr*1.03,seed[1]),max(0.02,seed[2])),
        (max(thr*1.10,seed[1]),max(0.07,seed[2]))])
    for guess in guesses
        try
            result=nlsolve((y,x)->begin
                out=f(x[1],x[2])
                y[1],y[2]=reim(out)
                nothing
            end,collect(guess);iterations=55,ftol=8e-11,xtol=1e-11)
            m,w=result.zero
            err=abs(f(m,w))
            if m>low && w>=-1e-8 && err<=2e-7
                return (mass=m,gamma=max(0.0,w),residual=err,status=m<thr ? "bound" : "resonance")
            end
        catch e
            e isa InterruptException && rethrow()
        end
    end
    return (mass=NaN,gamma=NaN,residual=NaN,status="no_root")
end

