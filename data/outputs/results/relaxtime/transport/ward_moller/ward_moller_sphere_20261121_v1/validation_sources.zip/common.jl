using CSV, JSON3, SHA, Dates, LinearAlgebra, StaticArrays, NLsolve

const SRC = abspath(ARGS[1])
const CASE = @__DIR__
include(joinpath(SRC,"src","models","Models.jl"))
const RT = Main.RelaxTime
const AS = RT.AverageScatteringRate
const TS = AS.ThermalWeightedSampling
const RTA = RT.RelaxationTime
const CS = RT.TotalCrossSection
const TC = RT.TransportCoefficients
const EC = RT.EffectiveCouplings
const MM = RT.MesonMass
const MT = RT.MottTransition
const OL = RT.OneLoopIntegrals
const COR = Main.OneLoopIntegralsCorrection
const DA = Main.PNJLQuarkDistributions_Aniso
const GL = RT.GaussLegendre
const C = Main.Constants_PNJL
const HC = C.ħc_MeV_fm
const CUT = C.Λ_inv_fm
const SP = Models.TransportSamplingProfiles
const PROFILE = SP.load_profile("thermal_weighted_v1")
const GRID = collect(CSV.File(joinpath(CASE,"backgrounds.csv")))
const SPECIES = (:u,:d,:s,:ubar,:dbar,:sbar)
const CHANNELS = RTA.REQUIRED_RATE_KEYS_FOR_TAU
BLAS.set_num_threads(1)

function converged_result(name, rows, dir)
    isempty(rows) && return
    CSV.write(joinpath(dir,name * ".writing"),rows)
    mv(joinpath(dir,name * ".writing"),joinpath(dir,name * ".csv");force=true)
end

function background(row)
    mass = (u=Float64(row.m_u),d=Float64(row.m_d),s=Float64(row.m_s))
    mu = (u=Float64(row.muq_fm),d=Float64(row.muq_fm),s=Float64(row.muq_fm))
    thermo = (T=Float64(row.T_fm),Φ=Float64(row.Phi),Φbar=Float64(row.Phibar),ξ=Float64(row.xi))
    return (m=mass,μ=mu), thermo
end

function ward_A(m,mu,tp,p,w,cos_nodes)
    c,cw = GL.gauleg(-1.0,1.0,cos_nodes)
    thermal = 0.0
    for j in eachindex(c,cw), i in eachindex(p,w)
        energy = sqrt(m*m + p[i]^2 * (1+tp.ξ*c[j]^2))
        sumf = OL.distribution_value(:pnjl,:plus,energy,mu,tp.T,tp.Φ,tp.Φbar) +
               OL.distribution_value(:pnjl,:minus,energy,mu,tp.T,tp.Φ,tp.Φbar)
        thermal += w[i]*cw[j]*p[i]^2/energy*sumf
    end
    return 2thermal - 4OL.const_integral_term_A(m)
end

function loop_state(qp,tp,scheme; p_nodes=PROFILE.a_integral.p_nodes,
    cos_nodes=PROFILE.a_integral.cos_nodes, p_max=Inf)
    p,w = isinf(p_max) ? AS._cached_semi_infinite_momentum_grid(p_nodes,PROFILE.a_integral.scale_inv_fm) :
        GL.gauleg(0.0,Float64(p_max),p_nodes)
    if scheme===:stock || tp.ξ==0.0
        values=RT.AFieldBuilder.build_A_triplet(qp,tp,p,w;cos_nodes=cos_nodes,use_aniso=true)
    elseif scheme===:ward
        values=NamedTuple{(:u,:d,:s)}(Tuple(ward_A(qp.m[f],qp.μ[f],tp,p,w,cos_nodes) for f in (:u,:d,:s)))
    else
        error("unknown scheme: $scheme")
    end
    K = EC.calculate_effective_couplings(C.G_fm2,C.K_fm5,
        EC.calculate_G_from_A(values.u,qp.m.u), EC.calculate_G_from_A(values.s,qp.m.s))
    return (qp=merge(qp,(A=values,)),tp=tp,K=K)
end

function soft_residual(state)
    pp = MM._meson_polarization_params(:pi,state.qp)
    K = MM._meson_coupling(:pi,state.K)
    return 1 + C.N_color/(2pi^2)*K*(pp.A1+pp.A2) - C.m_ud0_inv_fm/pp.m1
end

function cfg_options(ngr,tgr,mode)
    q=PROFILE.tau_integral
    sample = AS.ThermalSamplingConfig(;merge(AS._thermal_sampling_identity(PROFILE.sampling),
        (relative_velocity=mode,))...)
    p,pw = AS._cached_semi_infinite_momentum_grid(ngr[1],q.scale_inv_fm)
    c,cw = AS._cached_interval_grid(-1.0,1.0,ngr[2])
    z,zw = AS._cached_interval_grid(0.0,2pi,ngr[3])
    return (p_nodes=ngr[1],angle_nodes=ngr[2],phi_nodes=ngr[3],n_sigma_points=tgr,
        p_grid=p,p_w=pw,cos_grid=c,cos_w=cw,phi_grid=z,phi_w=zw,sigma_cutoff=CUT,
        sampling_config=sample)
end

function terminal_config()
    a=PROFILE.terminal_integral
    p,pw = AS._cached_semi_infinite_momentum_grid(a.p_nodes,a.scale_inv_fm)
    c,cw = AS._cached_interval_grid(-1.0,1.0,a.cos_nodes)
    return TC.TransportIntegrationConfig(p_grid=p,p_w=pw,cos_grid=c,cos_w=cw)
end
