include(joinpath("D:/CodexCompute/pnjl-gemini-20261121-v1","loops.jl"))
using ForwardDiff

function solved_zero_background(T_MeV,xi)
    model=SP.profile_model(PROFILE)
    T=T_MeV/HC;mu=SVector(0.0,0.0,0.0)
    expand(x)=SVector(x[1],x[1],x[2],x[3],x[3])
    potential(x)=Models.omega(model,expand(x),T,mu;xi,p_num=96,t_num=24)
    candidates=NamedTuple[]
    for seed in (Models.HADRON_SEED_5[[1,3,4]],Models.QUARK_SEED_5[[1,3,4]])
        r=nlsolve((out,x)->(out .= ForwardDiff.gradient(potential,x);nothing),copy(seed);
            iterations=60,ftol=2e-11,xtol=1e-11)
        x=expand(r.zero);m=Models.calculate_mass_vec(model,SVector(x[1],x[2],x[3]))
        residual=maximum(abs,Models.gap_residual(model,x,T,mu;xi,p_num=96,t_num=24))
        if residual<1e-8 && all(>(0),m) && max(x[1],x[3])<1e-6 && -1e-7<x[4]<1.0
            push!(candidates,(x=x,m=m,residual=residual,omega=potential(r.zero)))
        end
    end
    isempty(candidates) && error("Mott background failed")
    bg=first(sort!(candidates;by=b->b.omega))
    qp=(m=(u=bg.m[1],d=bg.m[2],s=bg.m[3]),μ=(u=0.0,d=0.0,s=0.0))
    tp=(T=T,Φ=bg.x[4],Φbar=bg.x[5],ξ=xi)
    return loop_state(qp,tp,:ward),bg.residual
end

out=abspath(ARGS[2]);mkpath(out)
roots=NamedTuple[]
for (xi,piT,KT) in ((-.3,195.346577167511,194.88318967819214),
    (-.15,201.7778763771057,201.1733889579773),(0.,207.40314149856567,206.65485525131226),
    (.15,212.42873525619507,211.5356068611145),(.3,216.98875665664673,215.95083475112915))
    for (meson,seed) in ((:pi,piT),(:K,KT))
        function f(T)
            st,_=solved_zero_background(T,xi)
            return real(mass_inverse(meson,st,MT.mott_threshold_mass(meson,st.qp);nr=256,na=32))
        end
        T=bisect(f,seed-.02,seed+.02;tol=1e-6)
        st,residual=solved_zero_background(T,xi)
        threshold=MT.mott_threshold_mass(meson,st.qp)
        push!(roots,(xi=xi,meson=String(meson),T_Mott_MeV=T,threshold_MeV=threshold*HC,
            soft_pion_residual=soft_residual(st),background_residual=residual,threshold_residual=f(T)))
        println("MOTT_DIRECT ",xi," ",meson," ",T);flush(stdout)
    end
end
converged_result("mott_temperatures",roots,out)

checks=NamedTuple[]
for row in GRID
    row.probe_id in ("warm_pos","dense_edge","dense138_200") || continue
    qp,tp=background(row);st=loop_state(qp,tp,:ward)
    for meson in (:pi,:K)
        pp=MM._meson_polarization_params(meson,st.qp)
        proc,channel=meson===:pi ? (:dubar_to_dubar,:t) : (:us_to_us,:u)
        ctx=CS.prepare_scattering_context(proc,qp)
        s=(ctx.m1+ctx.m2+180/HC)^2
        tb=CS.calculate_t_bounds(s,ctx.m1,ctx.m2,ctx.m3,ctx.m4)
        for fraction in (.25,.5,.75)
            t=muladd(fraction,tb.t_max-tb.t_min,tb.t_min)
            kinematics=RT.TotalPropagator.calculate_cms_momentum(proc,s,t,channel,qp)
            k0,k=kinematics.k0,kinematics.k
            function value(fun)
                z=fun(k0)
                return pp.num_s_quark==1 ? (z+fun(-k0))/2 : z
            end
            reference=value(l->(b0_quad(:linear,l,k,pp,tp;beta=0.,nr=256,na=32)+
                2b0_quad(:linear,l,k,pp,tp;beta=pi/2,nr=256,na=32))/3)
            production=value(l->complex(OL.B0(l,k,pp.m1,pp.μ1,pp.m2,pp.μ2,tp.T;
                Φ=tp.Φ,Φbar=tp.Φbar)...)+complex(COR.B0_correction(l,k,pp.m1,pp.m2,
                pp.μ1,pp.μ2,tp.T,tp.Φ,tp.Φbar,tp.ξ;b0_direction=:sphere_average)...))
            push!(checks,(point=row.probe_id,meson=String(meson),fraction=fraction,
                k0_MeV=k0*HC,k_MeV=k*HC,production_real=real(production),production_imag=imag(production),
                reference_real=real(reference),reference_imag=imag(reference),
                relative_error=abs(production-reference)/max(abs(reference),1e-12)))
        end
    end
end
converged_result("direction_oracle",checks,out)
println("DIRECTION_ORACLE_MAX ",maximum(c.relative_error for c in checks));flush(stdout)
