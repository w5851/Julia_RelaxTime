include(joinpath(@__DIR__,"common.jl"))

function angle_averaged_section(process,s,q,t,K,n_points; angle_nodes=16)
    ctx = CS.prepare_scattering_context(process,q)
    i,j,c,d = ctx.m1,ctx.m2,ctx.m3,ctx.m4
    limits = CS.calculate_t_bounds(s,i,j,c,d)
    lo = ctx.particle_c == ctx.particle_d ? limits.t_min/2 : limits.t_min
    hi = limits.t_max
    (hi-lo)>CS.EPS_KINEMATIC || return 0.0
    ec,ed=CS.calculate_final_state_energies(s,c,d)
    muc=CS.get_chemical_potential(ctx.particle_c,q)
    mud=CS.get_chemical_potential(ctx.particle_d,q)
    xs,ws=GL.standard_nodes_weights(angle_nodes)
    blocking=0.5*sum(w*CS.combined_final_state_factor(ctx.particle_c,ctx.particle_d,
        ec,ed,c,d,muc,mud,t.T,t.Φ,t.Φbar,t.ξ,x) for (x,w) in zip(xs,ws))
    xs,ws=GL.standard_nodes_weights(n_points)
    scale=(hi-lo)/2
    mid=(hi+lo)/2
    splus=s-(i+j)^2
    sminus=s-(i-j)^2
    int=0.0
    for (x,w) in zip(xs,ws)
        mat = CS.scattering_amplitude_squared_prepared(ctx,s,muladd(scale,x,mid),q,t,K)
        isfinite(mat) && mat>0 || continue
        ds = CS.differential_cross_section(splus,sminus,mat)
        isfinite(ds) && ds>0 && (int+=w*ds)
    end
    return scale*blocking*int
end

function rate_pairs(process,state,scheme,block,modes,ngr,tgr)
    qp,tp,K = state.qp,state.tp,state.K
    RT.PolarizationCache.reset_cache!()
    opts = cfg_options(ngr,tgr,first(modes))
    problem = AS._prepare_thermal_cache_problem(process,qp,tp,K;opts...)
    ctx,cfg = problem.context,problem.sampling
    positive_thresholds = [4qp.m.u^2,4qp.m.d^2,4qp.m.s^2,(qp.m.u+qp.m.s)^2]
    s0=first(ctx.bounds)
    all_eval=Dict{Float64,Float64}()
    function direct(s)
        return get!(all_eval,s) do
            if block===:stock
                CS.total_cross_section(process,s,ctx.quark_params,ctx.thermo_params,ctx.K_coeffs;n_points=tgr)
            elseif block===:avg
                angle_averaged_section(process,s,ctx.quark_params,ctx.thermo_params,ctx.K_coeffs,tgr)
            else
                error("unknown blocking prescription")
            end
        end
    end
    out=NamedTuple[]
    for mode in modes
        el = @elapsed begin
            measure=TS.thermal_measure(problem.plan,ctx.bounds;max_events=cfg.max_events,relative_velocity=mode)
            feature_state = (quark_params=ctx.quark_params,thermo_params=ctx.thermo_params,K_coeffs=ctx.K_coeffs)
            features=TS.scattering_feature_seeds(process,feature_state,measure,s0)
            built=TS.build_thermal_weighted_table(direct,measure,s0;rtol=cfg.rtol,atol=cfg.atol,
                weighted_window=cfg.weighted_window,thresholds=positive_thresholds,
                seed_order=cfg.seed_order,extra_seeds=features.seeds,max_evaluations=cfg.max_evaluations,
                max_nodes=cfg.max_nodes,max_rounds=cfg.max_rounds)
        end
        built.converged || error("$(process)/$(scheme)/$(block)/$(mode) $(built.reason)")
        push!(out,(channel=String(process),scheme=String(scheme),blocking=String(block),velocity=String(mode),
            rate=built.rate,error=built.estimated_error,relative_cache_error=built.estimated_error/built.rate,
            evals=built.evaluations,shared_sigma_evals=length(all_eval),events=measure.events,seconds=el))
    end
    return out
end

function emit_point(row,scheme,blocking,velocities,ngr,tgr,dir)
    tag=String(row.probe_id)
    qp,tp=background(row)
    state=loop_state(qp,tp,scheme)
    rates=NamedTuple[]
    for process in CHANNELS
        let part=rate_pairs(process,state,scheme,blocking,velocities,ngr,tgr)
            for item in part
                push!(rates,merge((probe_id=tag,),item))
            end
        end
        converged_result("rates",rates,dir)
        println("RATE ",tag," ",scheme," ",blocking," ",process," ",
            [(x.velocity,round(x.rate;sigdigits=6)) for x in rates[end-length(velocities)+1:end]])
        flush(stdout)
        GC.gc(false)
    end
    n=NamedTuple{SPECIES}(Tuple(Float64(getproperty(row,Symbol("n_",s))) for s in SPECIES))
    config=terminal_config()
    terminal=NamedTuple[]
    for mode in velocities
        rr=Dict(Symbol(r.channel)=>r.rate for r in rates if r.velocity==String(mode))
        inverse=RTA.relaxation_rates(n,rr)
        tau=map(inv,inverse)
        eta=TC.shear_viscosity(qp,tp;tau=tau,config=config)
        sigma=TC.electric_conductivity(qp,tp;tau=tau,config=config)
        old_tau=NamedTuple{SPECIES}(Tuple(Float64(getproperty(row,Symbol("tau_",s))) for s in SPECIES))
        J=NamedTuple{SPECIES}(Tuple(TC.electric_conductivity(qp,tp;
            tau=NamedTuple{SPECIES}(Tuple(f==s ? 1.0 : 0.0 for f in SPECIES)),config=config)/tp.T for s in SPECIES))
        sigma_check=sum(tau[f]*J[f] for f in SPECIES)
        abs(sigma_check/(sigma/tp.T)-1)<1e-11 || error("conductivity decomposition mismatch")
        old_eta=TC.shear_viscosity(qp,tp;tau=old_tau,config=config)
        old_sigma=TC.electric_conductivity(qp,tp;tau=old_tau,config=config)
        abs(old_sigma/Float64(row.sigma)-1)<1e-9 && abs(old_eta/Float64(row.eta)-1)<1e-9 ||
            error("terminal replay mismatch at $tag")
        # At fixed thermodynamic background zeta is linear in the species tau. Reuse the
        # standard isentropic kernel with background derivative data from the same model.
        zeta=NaN
        zeta_replay=NaN
        if hasproperty(row,:zeta) && isfinite(Float64(row.zeta))
            try
                bc=fixed_bulk(row)
                zeta=TC.bulk_viscosity_isentropic(qp,tp;bulk_coeffs_isentropic=bc,tau=tau,config=config)
                z0=TC.bulk_viscosity_isentropic(qp,tp;bulk_coeffs_isentropic=bc,tau=old_tau,config=config)
                zeta_replay=z0/Float64(row.zeta)-1
                if !isfinite(zeta_replay) || abs(zeta_replay)>1e-6
                    zeta=NaN
                    println("BULK REPLAY DRIFT ",tag," ",zeta_replay)
                end
            catch e
                println("BULK unavailable ",tag," ",sprint(showerror,e))
            end
        end
        tau_fields=NamedTuple{Tuple(Symbol("tau_",s) for s in SPECIES)}(Tuple(tau))
        kernels=NamedTuple{Tuple(Symbol("J_",s) for s in SPECIES)}(Tuple(J))
        push!(terminal,merge((probe_id=tag,scheme=String(scheme),blocking=String(blocking),velocity=String(mode),
            T_MeV=Float64(row.T_MeV),muB_MeV=Float64(row.muB_MeV),xi=Float64(row.xi),
            p_nodes=ngr[1],cos_nodes=ngr[2],phi_nodes=ngr[3],t_nodes=tgr,
            eta_over_s=eta/Float64(row.s_fm3inv),sigma_over_T=sigma/tp.T,zeta_over_s=zeta/Float64(row.s_fm3inv),
            tauinv_ubar=inverse.ubar,dubar_inverse_contribution=n.u*rr[:dubar_to_dubar],
            su_sd_fraction=2n.u*rr[:us_to_us]/inverse.s,ward_residual=soft_residual(state),
            fixed_background_zeta_replay_error=zeta_replay,
            relative_eta_s_to_v15=eta/Float64(row.eta)-1,relative_sigma_T_to_v15=sigma/Float64(row.sigma)-1),
            tau_fields,kernels))
    end
    converged_result("transport",terminal,dir)
end

function fixed_bulk(row)
    qp,tp=background(row)
    model=SP.profile_model(PROFILE)
    target=SVector(qp.m.u,qp.m.d,qp.m.s)
    f(x)=Vector(Models.calculate_mass_vec(model,SVector{3}(x))-target)
    root=nlsolve(f,[-.9,-.9,-1.9];ftol=1e-12,xtol=1e-12)
    maximum(abs,f(root.zero))<1e-10 || error("mass inversion")
    state=SVector(root.zero...,tp.Φ,tp.Φbar)
    return bulk_from_state(model,state,tp,qp.μ.u)
end

function bulk_from_state(model,state,tp,mu)
    dir=Models.ThermoDerivatives
    return dir.bulk_viscosity_coefficients(tp.T,mu;model=model,xi=tp.ξ,p_num=96,t_num=24,
        base_state=state,base_masses=Models.calculate_mass_vec(model,SVector(state[1],state[2],state[3])),
        base_mu_vec=SVector(mu,mu,mu),base_state_source=:workflow_equilibrium,allow_local_polish=false)
end

function main()
    length(ARGS) in (6,8) || error("SOURCE OUTPUT STOCK_OR_WARD STOCK_OR_AVG VELOCITIES POINTS [p,cos,phi t]")
    out=abspath(ARGS[2])
    scheme,block=Symbol.(ARGS[3:4])
    modes=Tuple(Symbol.(split(ARGS[5],',')))
    wanted=split(ARGS[6],',')
    q=PROFILE.tau_integral
    ngr=length(ARGS)==8 ? Tuple(parse.(Int,split(ARGS[7],','))) : (q.p_nodes,q.cos_nodes,q.phi_nodes)
    tgr=length(ARGS)==8 ? parse(Int,ARGS[8]) : q.t_nodes
    println("HOST ",get(ENV,"COMPUTERNAME","?")," JULIA ",VERSION," ",scheme," ",block," ",ngr," ",tgr)
    if block===:avg
        row=first(r for r in GRID if r.probe_id=="warm_iso")
        qp,tp=background(row)
        st=loop_state(qp,tp,:stock)
        proc=:dubar_to_dubar
        s=(2st.qp.m.u+0.65)^2
        checked=angle_averaged_section(proc,s,st.qp,st.tp,st.K,24)
        native=CS.total_cross_section(proc,s,st.qp,st.tp,st.K;n_points=24)
        isapprox(checked,native;rtol=2e-11,atol=1e-13) || error("angle-averaged xi=0 control failed")
        println("isotropic angle average check ",checked," ",native)
    end
    for tag in wanted
        dir=joinpath(out,tag)
        isfile(joinpath(dir,"transport.csv")) && continue
        mkpath(dir)
        try
            emit_point(only(r for r in GRID if r.probe_id==tag),scheme,block,modes,ngr,tgr,dir)
        catch e
            msg=sprint(showerror,e,catch_backtrace())
            write(joinpath(dir,"error.txt"),msg)
            println(stderr,"POINT FAILED ",tag," ",msg)
        end
    end
    all(tag->isfile(joinpath(out,tag,"transport.csv")),wanted) || error("one or more points failed")
end
main()
