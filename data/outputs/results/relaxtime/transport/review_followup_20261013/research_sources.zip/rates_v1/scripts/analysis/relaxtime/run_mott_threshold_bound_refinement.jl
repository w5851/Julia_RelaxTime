#!/usr/bin/env julia
include(joinpath(@__DIR__,"MottThresholdProbe.jl"))
using .TransportReviewCommon, .MottThresholdProbe, CSV

function main(input,outdir)
    isfile(joinpath(outdir,"manifest.json")) && error("use a new output directory")
    write_json(joinpath(outdir,"manifest.json"),run_metadata(@__FILE__,
        (scope="closer bound-side points and absorptive threshold coefficient",input=input,
         offsets=(1e-6,3e-6,1e-5,3e-5),coefficient="-Im denominator/sqrt(x), x/s0=1e-9")))
    results=NamedTuple[]
    for critical in CSV.File(input)
        family=Symbol(critical.family);seed=selected_row(family===:pi ? -0.2 : 0.37)
        for dx in (1e-6,3e-6,1e-5,3e-5)
            loc=local_state(seed,Float64(critical.xi)+dx);st=loc.state
            th=threshold_data(st,family);h=th.s0*1e-9
            getden(x)=begin
                r=response(st,th.s0+x)
                family===:pi ? r.pi_den : r.mixed_den
            end
            c=-imag(getden(h))/sqrt(h)
            predicted=-(th.delta/c)^2
            l=4predicted;u=0.0
            real(getden(l))*th.delta<0 || error("bound root not bracketed")
            for _ in 1:60
                mid=(l+u)/2
                if signbit(real(getden(mid)))==signbit(real(getden(l)));l=mid;else;u=mid;end
            end
            xb=(l+u)/2;dh=abs(xb)*1e-3
            derivative=(real(getden(xb+dh))-real(getden(xb-dh)))/(2dh)
            rr=response(st,th.s0+xb-dh)
            numerator=family===:pi ? 2st.K_coeffs.K123_plus : real(rr.mixed_numerator)
            push!(results,(family=String(family),xi=Float64(critical.xi)+dx,xi_offset=dx,
                delta=th.delta,c=c,binding_s=-xb,predicted_binding_s=-predicted,
                binding_relative_error=xb/predicted-1,residue_abs=abs(numerator/derivative),
                residue_prediction=abs(2numerator*th.delta/c^2),gap_residual=loc.base.residual_norm))
        end
    end
    write_rows(joinpath(outdir,"bound_poles.csv"),results)
    write_json(joinpath(outdir,"status.json"),(complete=true,rows=length(results)))
    println("COMPLETE ",outdir)
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && main(abspath(ARGS[1]),abspath(ARGS[2]))
