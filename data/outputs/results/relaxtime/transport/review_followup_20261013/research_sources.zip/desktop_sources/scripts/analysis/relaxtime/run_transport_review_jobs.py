"""Run an explicit local Julia review job list with durable logs and exit codes."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import time


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec", type=Path)
    args = parser.parse_args()
    spec_path = args.spec.resolve()
    spec = json.loads(spec_path.read_text(encoding="utf-8-sig"))
    output = spec_path.parent
    state_path = output / "jobs_status.json"
    if state_path.exists():
        raise SystemExit(f"Refusing to overwrite an earlier scheduler state: {state_path}")
    pending = list(spec["jobs"])
    if len({job['id'] for job in pending}) != len(pending):
        raise SystemExit("Job ids must be unique")
    running = {}
    state = {"created_utc": utc_now(), "complete": False, "jobs": {}}
    env = dict(os.environ, JULIA_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1")

    def save():
        tmp = state_path.with_suffix(".json.writing")
        tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        tmp.replace(state_path)

    while pending or running:
        while pending and len(running) < spec.get("max_workers", 3):
            job = pending.pop(0)
            job_id = job["id"]
            stdout_path = output / f"{job_id}.stdout.log"
            stderr_path = output / f"{job_id}.stderr.log"
            stdout = stdout_path.open("xb")
            stderr = stderr_path.open("xb")
            try:
                proc = subprocess.Popen(job["command"], cwd=spec["cwd"], env=env,
                                        stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
            except Exception:
                stdout.close()
                stderr.close()
                raise
            state["jobs"][job_id] = {"command": job["command"], "pid": proc.pid,
                                      "started_utc": utc_now(), "exit_code": None,
                                      "stdout": str(stdout_path), "stderr": str(stderr_path)}
            running[job_id] = (proc, stdout, stderr)
            save()
        for job_id, (proc, stdout, stderr) in list(running.items()):
            code = proc.poll()
            if code is not None:
                stdout.close()
                stderr.close()
                state["jobs"][job_id].update(exit_code=code, finished_utc=utc_now())
                del running[job_id]
                save()
        if pending or running:
            time.sleep(2)
    state.update(complete=True, finished_utc=utc_now(),
                 successful=all(job["exit_code"] == 0 for job in state["jobs"].values()))
    save()
    return 0 if state["successful"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
