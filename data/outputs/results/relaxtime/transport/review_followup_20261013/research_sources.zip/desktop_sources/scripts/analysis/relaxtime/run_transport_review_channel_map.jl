#!/usr/bin/env julia
# Export the actual exchange routing for the retained P4 channel plan.
using CSV, JSON, SHA
const ROOT = normpath(joinpath(@__DIR__, "..", "..", ".."))
include(joinpath(ROOT, "src", "constants", "TransportConstants.jl"))

function main()
    runroot = abspath(only(ARGS))
    source = joinpath(ROOT, "src", "constants", "TransportConstants.jl")
    plan = joinpath(dirname(runroot), "channel_plan.csv")
    output = joinpath(runroot, "channel_exchange_map.json")
    isfile(output) && error("channel map output already exists")
    channels = sort!(unique(String(r.channel) for r in CSV.File(plan)))
    routing = Dict{String,Any}()
    for channel in channels
        config = TransportConstants.SCATTERING_MESON_MAP[Symbol(channel)]
        routing[channel] = Dict(
            "type" => String(config[:type]),
            "legs" => Dict(String(leg) => Dict(
                "simple" => String.(values[:simple]),
                "mixed_P" => values[:mixed_P], "mixed_S" => values[:mixed_S])
                for (leg, values) in config[:channels]))
    end
    artifact = Dict("status" => "analysis_only", "routing" => routing,
        "source" => relpath(source, ROOT), "source_sha256" => bytes2hex(sha256(read(source))),
        "plan_sha256" => bytes2hex(sha256(read(plan))),
        "script_sha256" => bytes2hex(sha256(read(@__FILE__))),
        "scope" => "exchange routing only; no named mixed pole or mechanism attribution")
    open(output, "w") do io
        JSON.print(io, artifact, 2)
        println(io)
    end
    println("Exported ", length(channels), " selected-channel routes")
end

abspath(PROGRAM_FILE) == abspath(@__FILE__) && main()
