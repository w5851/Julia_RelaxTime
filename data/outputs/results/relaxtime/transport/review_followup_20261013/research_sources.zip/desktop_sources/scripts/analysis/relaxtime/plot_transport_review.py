"""Static diagnostic figures for the retained-state transport review."""
from __future__ import annotations
import argparse
from collections import defaultdict
import csv
import hashlib
import json
import os
from pathlib import Path


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--components", nargs="+", choices=("tail", "meson", "channels"), default=["tail", "meson", "channels"])
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", str(args.run / "plot_cache"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    plt.rcParams.update({"font.size": 11, "axes.spines.top": False, "axes.spines.right": False,
                         "savefig.dpi": 170, "pdf.fonttype": 42, "axes.grid": True, "grid.alpha": .2})

    def save(fig, name, sources):
        outputs = []
        for suffix in ("png", "pdf"):
            path = args.output / f"{name}.{suffix}"
            fig.savefig(path, bbox_inches="tight")
            outputs.append({"path": str(path.resolve()), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
        plt.close(fig)
        manifest = {"status": "analysis_only", "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    "inputs": [{"path": str(p.resolve()), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources],
                    "outputs": outputs, "production_or_manuscript_modified": False}
        (args.output / f"{name}_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    if "tail" in args.components:
        source = args.run / "transport_tail/transport_tail.csv"
        groups = defaultdict(dict)
        for r in read(source):
            groups[r["point_id"]][r["configuration"]] = r
        fig, axes = plt.subplots(1, 3, figsize=(12.5, 4.1), constrained_layout=True)
        for ax, field, label in zip(axes, ("eta_over_s", "zeta_over_s", "sigma_over_T"), (r"$\eta/s$", r"$\zeta/s$", r"$\sigma/T$")):
            limits = [8, 20, 30, 40, 60]
            names = ["production", "p20", "p30", "p40", "p60"]
            errors = [max(abs(float(g[n][field]) / float(g["infinite512"][field]) - 1) * 100 for g in groups.values()) for n in names]
            ax.semilogy(limits, np.maximum(errors, 1e-12), "o-", color="#176b8d", lw=1.8)
            ax.set(title=label, xlabel=r"Momentum upper limit (fm$^{-1}$)", xlim=(5, 63), ylim=(1e-12, 1e2))
            ax.annotate(f"{errors[0]:.2f}%", (8, errors[0]), xytext=(8, -19), textcoords="offset points", fontsize=10)
            ax.set_xticks(limits)
        axes[0].set_ylabel("Largest difference from reference (%)")
        fig.suptitle("Transport momentum tails: 32 retained backgrounds, fixed relaxation times", fontsize=12)
        save(fig, "transport_tail_sensitivity", [source])

    if "meson" in args.components:
        source = args.run / "meson_v2/meson_poles.csv"
        allrows = [r for r in read(source) if r["mode"] == "mode_a" and r["plot_panel"] == "muB0.0" and r["meson"] == "pi"]
        fig, axes = plt.subplots(1, 3, figsize=(13, 4.2), constrained_layout=True)
        for ax, series, color in zip(axes[:2], ("alpha1.0", "alpha1.1"), ("#176b8d", "#ad563b")):
            linear = sorted([r for r in allrows if r["plot_series"] == series and r["scheme"] == "linear"], key=lambda r: float(r["xi"]))
            full = sorted([r for r in allrows if r["plot_series"] == series and r["scheme"] == "full_rs"], key=lambda r: float(r["xi"]))
            ax.plot([float(r["xi"]) for r in linear], [float(r["mass_MeV"]) for r in linear], color=color, lw=1.6, label="Linear B0")
            ax.plot([float(r["xi"]) for r in full], [float(r["mass_MeV"]) for r in full], "o", color=color, ms=3, mfc="white", label="Full RS B0")
            ax.plot([float(r["xi"]) for r in linear], [float(r["threshold_MeV"]) for r in linear], "--", color="#555555", label=r"$2m_u$")
            ax.set(xlabel=r"$\xi$", ylabel="Mass / threshold (MeV)", title=rf"$\mu_B=0$, $\alpha_T={series[5:]}$")
            ax.legend(frameon=False, fontsize=9)
            axes[2].plot([float(r["xi"]) for r in full], [100 * float(r["mass_rel_to_linear"]) for r in full], "o-", color=color, ms=3, label=rf"$\alpha_T={series[5:]}$")
        axes[2].set(xlabel=r"$\xi$", ylabel="Full RS / linear mass change (%)", title=r"Only the $k=0$ occupation correction changes")
        axes[2].legend(frameon=False, fontsize=9)
        axes[2].axhline(0, color="black", lw=.6)
        fig.suptitle("Pion pole diagnostics on transport backgrounds; retained real-axis width convention", fontsize=12)
        save(fig, "full_rs_k0_pi", [source])

    if "channels" in args.components:
        source = args.run / "tables/channel_window_summary.csv"
        rows = read(source)
        labels = []
        for r in rows:
            if r["mode"] == "mode_a":
                label = f"A: {r['plot_panel'].replace('muB', 'muB=')}, {r['plot_series'].replace('alpha', 'a=')}"
            else:
                label = f"B: {r['plot_panel'].replace('T', 'T=')}, {r['plot_series'].replace('muB', 'muB=')}"
            labels.append(label + f", xi={float(r['xi']):+.2f}")
        y = np.arange(len(rows))
        fig, axes = plt.subplots(1, 2, figsize=(12.5, 5.5), sharey=True, constrained_layout=True)
        for ax, field, title in zip(axes, ("max_channel_change_in_window", "max_weighted_change_in_window"),
                                    ("Largest selected-channel change", "Weighted selected-rate change")):
            values = np.array([float(r[field]) * 100 for r in rows])
            ax.barh(y, np.maximum(values, 1e-8), color=["#ad563b" if v >= 1 else "#176b8d" for v in values], height=.65)
            ax.set(xscale="log", xlabel="48 / 1120 to 96 / 2240 change (%)", title=title)
            ax.axvline(1, ls="--", lw=1, color="#555555", label="1% diagnostic threshold")
            ax.legend(frameon=False, fontsize=9, loc="lower right")
        axes[0].set_yticks(y, labels)
        axes[0].invert_yaxis()
        fig.suptitle("Selected-channel refinement; unchanged channels prevent full tau certification", fontsize=12)
        save(fig, "channel_refinement", [source])


if __name__ == "__main__":
    main()
