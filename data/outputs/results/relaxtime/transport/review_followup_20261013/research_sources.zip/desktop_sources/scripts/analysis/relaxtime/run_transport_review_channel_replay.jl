#!/usr/bin/env julia
# Reject mismatched production context before costly local channel refinement.
include(joinpath(@__DIR__,"TransportReviewCommon.jl"))
using .TransportReviewCommon, CSV

function main()
    outdir=abspath(only(ARGS))
    isfile(joinpath(outdir,"manifest.json")) && error("replay output exists")
    points=Dict(point_id(r)=>r for r in read_points())
    plan=collect(CSV.File(joinpath(INPUT,"channel_plan.csv")))
    chosen=String["mode_a_muB0p0_alpha1p0_xi0p37", "mode_a_muB450p0_alpha1p0_xi0p26",
        "mode_b_T200p0_muB450p0_xi0p31", "mode_a_muB0p0_alpha1p2_xim0p47"]
    config=merge(tau_config(:p128),(sigma_cutoff=Main.Constants_PNJL.Λ_inv_fm,))
    write_json(joinpath(outdir,"manifest.json"),run_metadata(@__FILE__,(points=chosen,config=config,tolerance=1e-10)))
    rows=NamedTuple[]
    for pid in chosen
        row=points[pid];job=first(r for r in plan if String(r.point_id)==pid)
        state=state_from_row(row);channel=Symbol(job.channel)
        println("REPLAY ",pid," ",channel);flush(stdout)
        timed=@timed Main.RelaxTime.AverageScatteringRate.average_scattering_rate(
            channel,state.quark_params,state.thermo_params,state.K_coeffs;config...)
        difference=relative_change(timed.value,Float64(job.source_rate))
        out=merge(point_fields(row),(channel=String(channel),rate=timed.value,source_rate=Float64(job.source_rate),
            relative_error=difference,seconds=timed.time))
        push!(rows,out);checkpoint(outdir,pid,(summary=out,config=config))
        write_rows(joinpath(outdir,"replay.csv"),rows)
        abs(difference)<1e-10 || error("production channel replay mismatch: $pid $channel $difference")
    end
    write_json(joinpath(outdir,"status.json"),(complete=true,rows=length(rows),failures=NamedTuple[]))
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && main()
