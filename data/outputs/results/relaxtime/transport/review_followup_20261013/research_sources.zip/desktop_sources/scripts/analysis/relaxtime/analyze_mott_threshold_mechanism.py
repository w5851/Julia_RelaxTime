"""Summarize completed Mott probes; preserve source CSVs and production inputs."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import shutil
import zipfile

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def read_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_rows(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def slope(rows, field, xfield="x"):
    x = np.array([abs(float(r[xfield])) for r in rows])
    y = np.array([abs(float(r[field])) for r in rows])
    return float(np.polyfit(np.log(x), np.log(y), 1)[0])


def savefig(fig, path):
    fig.savefig(path.with_suffix(".png"), dpi=180)
    fig.savefig(path.with_suffix(".pdf"))
    plt.close(fig)


def main(base, out):
    out.mkdir(parents=True, exist_ok=True)
    jobs = ["run_v2", "cache_v1", "rates_v1", "bound_v2"]
    integrity = {}
    for name in jobs:
        folder = base / name
        status = json.loads((folder / "status.json").read_text(encoding="utf-8"))
        execution = json.loads((folder / "execution.json").read_text(encoding="utf-8"))
        assert status["complete"] and execution["exitcode"] == 0, name
        entries = json.loads((folder / "source_manifest.json").read_text(encoding="utf-8"))["files"]
        with zipfile.ZipFile(folder / "source_snapshot.zip") as archive:
            mismatches = [r["path"] for r in entries if hashlib.sha256(archive.read(r["path"])).hexdigest() != r["sha256"]]
        assert not mismatches, (name, mismatches)
        integrity[name] = dict(complete=True, exitcode=0, archived_source_files=len(entries), hash_mismatches=mismatches)

    profiles = read_rows(base / "run_v2/profiles.csv")
    response_fields = ["den_re", "den_im", "D_abs2", "piP_re", "piP_im", "piS_re", "piS_im"]
    nonfinite_profiles = []
    for r in profiles:
        invalid = [k for k in response_fields if not math.isfinite(float(r[k]))]
        if invalid:
            assert r["scheme"] == "production" and float(r["x"]) < 0, (r["case_id"], r["scheme"], r["epsilon"], invalid)
            nonfinite_profiles.append(dict(case_id=r["case_id"], scheme=r["scheme"],
                epsilon=r["epsilon"], nonfinite_fields=";".join(invalid)))
    if nonfinite_profiles:
        write_rows(out / "production_nonfinite_profiles.csv", nonfinite_profiles)
    profile_health = dict(total=len(profiles), production_total=sum(r["scheme"] == "production" for r in profiles),
        production_nonfinite_below_threshold=len(nonfinite_profiles), paired_pv_nonfinite=0,
        tested_fields=response_fields, nonfinite_values_not_replaced=True)
    endpoints = {r["case_id"]: r for r in read_rows(base / "run_v2/endpoint_checks.csv")}
    critical = read_rows(base / "run_v2/critical_states.csv")
    states = {r["id"]: r["state"] for r in json.loads((base / "run_v2/states.json").read_text(encoding="utf-8"))}
    bounds = read_rows(base / "bound_v2/bound_poles.csv")
    broad_bounds = read_rows(base / "run_v2/bound_poles.csv")
    integrals = read_rows(base / "run_v2/threshold_integrals.csv")
    cache_profiles = read_rows(base / "cache_v1/sigma_profiles.csv")
    cache_integrals = read_rows(base / "cache_v1/weighted_integrals.csv")
    rates = read_rows(base / "rates_v1/rates.csv")
    bands = read_rows(base / "rates_v1/rate_bands.csv")

    fit_rows = []
    drift = []
    production_loop_comparison = []
    for cid, endpoint in endpoints.items():
        fine = [r for r in profiles if r["case_id"] == cid and r["scheme"] == "paired_pv" and r["n"] == "256"]
        positive = [r for r in fine if 1e-8 <= float(r["epsilon"]) <= 1e-5]
        smallest = [r for r in fine if 1e-10 <= float(r["epsilon"]) <= 1e-7]
        c_imag = float(np.mean([-float(r["den_im"]) / math.sqrt(float(r["x"])) for r in smallest]))
        s0, delta, f0 = (float(endpoint[k]) for k in ["s0", "delta", "F0"])
        x_delta = (delta / c_imag) ** 2
        theory_p = 3 * s0 * f0 / (16 * math.pi)
        coeff_error = max(abs(float(r["piP_im"]) / math.sqrt(float(r["x"])) / theory_p - 1) for r in positive)
        fit_rows.append(dict(case_id=cid,piP_exponent=slope(positive,"piP_im"),piS_exponent=slope(positive,"piS_im"),
            D_abs2_exponent=slope(positive,"D_abs2"),c_imag=c_imag,delta=delta,x_delta_fm2inv=x_delta,
            energy_scale_MeV=x_delta/(2*math.sqrt(s0))*197.3269804,coefficient_max_relative_error=coeff_error,
            fit_epsilon_min=1e-8,fit_epsilon_max=1e-5))
        coarse = {r["epsilon"]:r for r in profiles if r["case_id"]==cid and r["scheme"]=="paired_pv" and r["n"]=="128"}
        drift.extend(abs(float(r["D_abs2"])/float(coarse[r["epsilon"]]["D_abs2"])-1) for r in fine)
        reference = {r["epsilon"]: r for r in fine}
        production = [r for r in profiles if r["case_id"] == cid and r["scheme"] == "production"]
        for lo, hi in [(1e-10, 1e-8), (1e-8, 1e-6), (1e-6, 1e-3), (1e-3, 0.1)]:
            window = [r for r in production if lo <= float(r["epsilon"]) <= hi]
            production_loop_comparison.append(dict(case_id=cid, epsilon_min=lo, epsilon_max=hi,
                max_D_abs2_relative_error=max(abs(float(r["D_abs2"]) / float(reference[r["epsilon"]]["D_abs2"]) - 1) for r in window)))
    write_rows(out / "power_fits.csv", fit_rows)
    write_rows(out / "production_loop_comparison.csv", production_loop_comparison)

    critical_coefficients = []
    for r in critical:
        cid = "critical_" + r["family"]
        endpoint = endpoints[cid]
        h_p = 3 * float(endpoint["s0"]) * float(endpoint["F0"]) / (16 * math.pi)
        numerator = float(r["numerator_abs"]) if r["family"] == "mixed" else 2 * states[cid]["K_coeffs"]["K123_plus"]
        prediction = abs(2 * numerator * h_p)
        measured = abs(next(f["c_imag"] for f in fit_rows if f["case_id"] == cid))
        critical_coefficients.append(dict(family=r["family"], numerator_abs=abs(numerator), h_p=h_p,
            predicted_c_abs=prediction, measured_c_abs=measured, relative_difference=measured / prediction - 1))
    write_rows(out / "critical_coefficients.csv", critical_coefficients)

    bound_fits = []
    for family in ["mixed", "pi"]:
        selected = sorted([r for r in bounds if r["family"]==family], key=lambda r: float(r["xi_offset"]))
        near = [r for r in selected if float(r["xi_offset"])<=1e-5]
        bound_fits.append(dict(family=family,binding_exponent=slope(near,"binding_s","delta"),
            residue_exponent=slope(near,"residue_abs","delta"),
            nearest_binding_error=float(near[0]["binding_relative_error"]),
            nearest_residue_error=float(near[0]["residue_abs"])/float(near[0]["residue_prediction"])-1,
            max_derivative_step_change=max(abs(float(r["residue_derivative_relative"])) for r in selected),
            max_binding_error=max(abs(float(r["binding_relative_error"])) for r in selected)))
    write_rows(out / "bound_fits.csv", bound_fits)

    weighted_checks = []
    for r in critical:
        cid="critical_"+r["family"]
        endpoint=endpoints[cid]
        fit=next(f for f in fit_rows if f["case_id"]==cid)
        entries=[x for x in integrals if x["case_id"]==cid and x["nq"]=="128" and float(x["cutoff_fraction"])==0]
        e=min(entries,key=lambda x:float(x["X"]))
        other=next(x for x in integrals if x["case_id"]==cid and x["nq"]=="64" and x["X"]==e["X"] and x["cutoff_fraction"]==e["cutoff_fraction"])
        losses=[]
        for fraction in [1e-4,1e-2]:
            t=next(x for x in integrals if x["case_id"]==cid and x["nq"]=="128" and x["X"]==e["X"] and float(x["cutoff_fraction"])==fraction)
            losses.append(dict(cutoff_fraction=fraction,removed_integral_fraction=1-float(t["integral"])/float(e["integral"])))
        weighted_checks.append(dict(family=r["family"],X=float(e["X"]),integral=float(e["integral"]),
            q64_to_q128_relative=float(e["integral"])/float(other["integral"])-1,cutoff_checks=losses,c_imag=fit["c_imag"]))

    cache_comparisons=[]
    for r in cache_integrals:
        if r["nq"]!="128":continue
        lo=next(x for x in cache_integrals if x["xi"]==r["xi"] and x["X"]==r["X"] and x["nq"]=="64")
        direct=float(r["direct48"])
        cache_comparisons.append(dict(xi=float(r["xi"]),X=float(r["X"]),direct=direct,
            cache560=float(r["cache560"]),cache1120=float(r["cache1120"]),
            cache560_relative=float(r["cache560"])/direct-1,cache1120_relative=float(r["cache1120"])/direct-1,
            direct_q_drift=direct/float(lo["direct48"])-1,cache560_q_drift=float(r["cache560"])/float(lo["cache560"])-1,
            direct_t_drift=direct/float(r["direct24"])-1))
    write_rows(out / "cache_integral_comparison.csv",cache_comparisons)

    partial=[]
    for xi in [0.36,0.37,0.38]:
        source=[r for r in rates if float(r["xi"])==xi and r["method"]=="stock"]
        total=float(source[0]["source_total"])
        for method in ["stock","dense96","dense192"]:
            changes=[r for r in rates if float(r["xi"])==xi and r["method"]==method]
            modified=total+sum(float(r["source_contribution"])*(float(r["rate"])/float(r["source_rate"])-1) for r in changes)
            partial.append(dict(xi=xi,method=method,rate=modified,tau=1/modified,source_tau=1/total,
                coverage=sum(float(r["source_contribution"]) for r in source)/total))
    residuals={}
    for method in ["stock","dense96","dense192"]:
        values=[r for r in partial if r["method"]==method]
        residuals[method]=values[1]["tau"]/((values[0]["tau"]+values[2]["tau"])/2)-1
    write_rows(out / "partial_tau.csv",partial)
    replay=max(abs(float(r["rate"])/float(r["source_rate"])-1) for r in rates if r["method"]=="stock")
    dense_drift=max(abs(float(r["rate"])/float(next(x for x in rates if x["xi"]==r["xi"] and x["channel"]==r["channel"] and x["method"]=="dense96")["rate"])-1) for r in rates if r["method"]=="dense192")
    threshold_attribution=[]
    for xi in [0.36,0.37,0.38]:
        total_change=0.0
        low_change=0.0
        for channel in ["uubar_to_uubar","uubar_to_ddbar"]:
            stock=next(r for r in rates if float(r["xi"])==xi and r["channel"]==channel and r["method"]=="stock")
            dense=next(r for r in rates if float(r["xi"])==xi and r["channel"]==channel and r["method"]=="dense192")
            factor=float(stock["source_contribution"])/float(stock["source_rate"])
            total_change+=factor*(float(dense["rate"])-float(stock["rate"]))
            for method,sign in [("stock",-1),("dense192",1)]:
                low_change+=sign*factor*sum(float(b["rate_in_band"]) for b in bands if float(b["xi"])==xi and b["channel"]==channel and b["method"]==method and float(b["right"])<=0.6)
        threshold_attribution.append(dict(xi=xi,delta_inverse_tau=total_change,delta_below_x06=low_change,fraction_below_x06=low_change/total_change))
    summary=dict(status="analysis_only",integrity=integrity,power_fits=fit_rows,bound_fits=bound_fits,
        profile_health=profile_health,
        weighted_integral_checks=weighted_checks,critical_states=critical,
        critical_coefficients=critical_coefficients,
        production_loop_comparison=production_loop_comparison,
        endpoint_max_difference=max(float(r["endpoint_difference"]) for r in endpoints.values()),
        loop_n128_n256_max_D_relative=max(drift),production_replay_max_relative=replay,
        dense96_dense192_max_rate_relative=dense_drift,partial_tau=partial,local_tau_residuals=residuals,
        threshold_band_attribution=threshold_attribution,
        limitations=["two channels replaced; other rates and outer p128/angle20/phi36 fixed", "mixed soft pole unnamed", "no full complex-energy continuation", "no formal production replacement"])
    (out/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")

    plt.rcParams.update({"font.size":10,"axes.grid":True,"grid.alpha":0.2,"pdf.fonttype":42})
    fig,axes=plt.subplots(2,2,figsize=(10,7.4),layout="constrained")
    p=[r for r in profiles if r["case_id"]=="critical_mixed" and r["scheme"]=="paired_pv" and r["n"]=="256" and float(r["x"])>0]
    eps=np.array([float(r["epsilon"]) for r in p])
    axes[0,0].loglog(eps,[abs(float(r["piP_im"])) for r in p],label="P channel: exponent 1/2")
    axes[0,0].loglog(eps,[abs(float(r["piS_im"])) for r in p],label="S channel: exponent 3/2")
    axes[0,0].set(xlabel=r"$x/s_0$",ylabel=r"$|\mathrm{Im}\,\Pi|$ [fm$^{-2}$]",title="Pair-cut onset")
    axes[0,0].legend()
    for cid,label in [("retained_mixed_0.36",r"$\xi=0.36$"),("retained_mixed_0.37",r"$\xi=0.37$"),("retained_mixed_0.38",r"$\xi=0.38$"),("critical_mixed","Mott soft mode")]:
        r=[x for x in profiles if x["case_id"]==cid and x["scheme"]=="paired_pv" and x["n"]=="256" and float(x["x"])>0]
        xs=np.array([float(x["epsilon"]) for x in r]); ds=np.array([float(x["D_abs2"]) for x in r])
        axes[0,1].loglog(xs,ds,label=label)
        axes[1,1].loglog(xs,[float(x["x"])*float(x["D_abs2"]) for x in r],label=label)
    axes[0,1].set(xlabel=r"$x/s_0$",ylabel=r"$|D_{\rm mixed,P}|^2$ [fm$^4$]",title="Finite plateau to $1/x$")
    axes[0,1].legend()
    for family,marker in [("mixed","o"),("pi","s")]:
        r=sorted([x for x in bounds+broad_bounds if x["family"]==family],key=lambda x:float(x["xi_offset"]))
        axes[1,0].semilogx([float(x["xi_offset"]) for x in r],[float(x["binding_s"])/float(x["predicted_binding_s"]) for x in r],marker=marker,label=family)
    axes[1,0].axhline(1,color="black",ls="--",lw=1)
    axes[1,0].set(xlabel=r"$\xi-\xi_M$ (bound side)",ylabel=r"$|x_b|/(\delta/c)^2$",title="Quadratic binding law")
    axes[1,0].legend()
    axes[1,1].set(xlabel=r"$x/s_0$",ylabel=r"$x|D|^2$ [fm$^2$]",title="Phase-space weighted singularity is finite")
    savefig(fig,out/"threshold_structure")

    fig,axes=plt.subplots(1,2,figsize=(10,4),layout="constrained")
    r=[x for x in cache_profiles if float(x["xi"])==0.37]
    for field,label in [("sigma_direct48","Direct, t48"),("sigma_cache560","Stock cache, N560"),("sigma_cache1120","Stock cache, N1120")]:
        keep=[x for x in r if float(x[field])>0]
        axes[0].loglog([float(x["x"]) for x in keep],[float(x[field]) for x in keep],label=label)
    axes[0].set(xlabel=r"$x=\hat s-4m_u^2$ [fm$^{-2}$]",ylabel=r"$\sigma_{u\bar u\to u\bar u}$ [fm$^2$]",title=r"$\xi=0.37$: cache versus direct")
    axes[0].legend()
    r=sorted([x for x in cache_comparisons if x["X"]==0.6],key=lambda x:x["xi"])
    for field,label in [("direct","Direct"),("cache560","Cache N560"),("cache1120","Cache N1120")]:
        axes[1].plot([x["xi"] for x in r],[x[field] for x in r],"o-",label=label)
    axes[1].set(xlabel=r"$\xi$",ylabel=r"$J=\int_0^{0.6}x\sigma(x)\,dx$ [fm$^{-2}$]",title="Local weighted integral (not full rate)")
    axes[1].set_xticks([0.36, 0.37, 0.38])
    axes[1].legend()
    savefig(fig,out/"cache_threshold_bias")

    fig,ax=plt.subplots(figsize=(7.2,4.8),layout="constrained")
    for method,label in [("stock","Retained production"),("dense96","Two channels, dense96"),("dense192","Two channels, dense192")]:
        r=[x for x in partial if x["method"]==method]
        ax.plot([x["xi"] for x in r],[x["tau"] for x in r],"o-",label=label)
    mixed_critical = next(r for r in critical if r["family"] == "mixed")
    ax.axvline(float(mixed_critical["xi"]),color="gray",ls=":",label="Mixed P threshold")
    ax.set(xlabel=r"$\xi$",ylabel=r"$\tau_u=\tau_{\bar u}$ [fm]",title="Same background and outer quadrature; two channels replaced")
    ax.set_xticks([0.36, 0.37, 0.38])
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.17), ncol=2, fontsize=9)
    savefig(fig,out/"partial_tau_countercheck")

    shutil.copy2(Path(__file__),out/Path(__file__).name)
    inputs={str(p.relative_to(base)).replace("\\","/"):hashlib.sha256(p.read_bytes()).hexdigest() for job in jobs for p in (base/job).glob("*.csv")}
    inputs["run_v2/states.json"] = hashlib.sha256((base / "run_v2/states.json").read_bytes()).hexdigest()
    (out/"analysis_inputs.json").write_text(json.dumps(inputs,indent=2),encoding="utf-8")
    print(json.dumps({k:summary[k] for k in ["bound_fits","weighted_integral_checks","production_replay_max_relative","dense96_dense192_max_rate_relative","partial_tau","local_tau_residuals"]},indent=2))


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("base",type=Path)
    parser.add_argument("out",type=Path)
    args=parser.parse_args()
    main(args.base,args.out)
