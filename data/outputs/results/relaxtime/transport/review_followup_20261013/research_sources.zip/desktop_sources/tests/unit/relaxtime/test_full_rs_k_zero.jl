using Test

if !isdefined(Main, :RelaxTime)
    include(joinpath(@__DIR__, "..", "..", "..", "src", "relaxtime", "RelaxTime.jl"))
end
if !isdefined(Main, :FullRSKZero)
    include(joinpath(@__DIR__, "..", "..", "..", "scripts", "analysis", "relaxtime", "FullRSKZero.jl"))
end

@testset "Full RS k=0 occupation correction" begin
    b0 = Main.RelaxTime.OneLoopIntegrals.B0
    corr = Main.RelaxTime.OneLoopIntegralsCorrection.B0_correction
    rs = Main.FullRSKZero.B0_rs_k0
    delta = Main.FullRSKZero.delta_B0_rs_k0
    tilde = Main.FullRSKZero.delta_tilde_rs_k0
    for (m1, m2, λ, μ) in ((0.6, 0.6, 0.8, 0.0), (0.4, 1.8, 3.0, 0.3), (0.6, 0.6, 1.6, 0.0))
        args = (λ, m1, μ, m2, μ, 1.0)
        @test rs(args...; Φ=.6, Φbar=.5, ξ=0.) == b0(λ, 0., m1, μ, m2, μ, 1.; Φ=.6, Φbar=.5)
        for ξ in (-.5, -.15, .15, .5)
            v = delta(args..., .6, .5, ξ)
            refined = delta(args..., .6, .5, ξ; energy_nodes=256, angle_nodes=64)
            @test all(isfinite, v)
            @test isapprox(collect(v), collect(refined); rtol=2e-5, atol=2e-8)
        end
        # The second-order remainder decreases quadratically, using matched
        # quadrature for the linear and resummed occupation corrections.
        remainder(ξ) = collect(delta(args..., .6, .5, ξ)) - collect(delta(args..., .6, .5, ξ; linear=true))
        r1, r2 = remainder(.02), remainder(.01)
        @test isapprox(sqrt(sum(abs2, r1))/sqrt(sum(abs2, r2)), 4.; rtol=.08)
        # Independent production O(xi) implementation agrees with the leading
        # coefficient; its fixed 32-node energy quadrature limits this check.
        linear = delta(args..., .6, .5, .001; linear=true)
        old = corr(λ, 0., m1, m2, μ, μ, 1., .6, .5, .001)
        @test isapprox(collect(linear), collect(old); rtol=5e-3, atol=2e-7)
    end
    # No residue below threshold; nonzero above it; exact lower endpoint finite.
    @test delta(.8, .6, 0., .6, 0., 1., .6, .6, .5)[2] == 0
    @test abs(delta(1.6, .6, 0., .6, 0., 1., .6, .6, .5)[2]) > 0
    @test all(isfinite, delta(1.2, .6, 0., .6, 0., 1., .6, .6, .5))
    # An independently evaluated residue verifies its normalization and sign.
    m, λ, ξ = .6, -1.6, .5
    E0 = -λ/2
    p0 = sqrt(E0^2-m^2)
    nodes, weights = Main.RelaxTime.GaussLegendre.gauleg(-1., 1., 96)
    f = Main.PNJLQuarkDistributions_Aniso.distribution_aniso
    avg = sum(w*(f(:quark,p0,m,0.,1.,.6,.6,ξ,x)-f(:quark,p0,m,0.,1.,.6,.6,0.,x)) for (x,w) in zip(nodes,weights))/2
    @test isapprox(tilde(:quark,λ,m,m,0.,1.,.6,.6,ξ)[2], 2π*p0*avg/λ; rtol=1e-10)
    @test_throws ArgumentError rs(.8,.6,0.,.6,0.,1.; ξ=-1.)
    @test_throws ArgumentError rs(0.,.6,0.,.6,0.,1.)
    @test_throws ArgumentError rs(.8,.6,0.,.6,0.,0.)
    # The new polarization retains the production width and flavor symmetry
    # conventions exactly in the isotropic limit.
    pol = Main.FullRSKZero.polarization_rs_k0
    oldpol = Main.RelaxTime.PolarizationAniso.polarization_with_width
    for channel in (:P,:S), ns in (0,1), width in (0.,.25)
        args=(channel,2.8,width,.4,1.8,.2,.2,1.,.6,.5,0.,-8.,-6.,ns)
        want=oldpol(channel,2.8,width,0.,.4,1.8,.2,.2,1.,.6,.5,0.,-8.,-6.,ns)
        @test isapprox(collect(pol(args...)),collect(want);rtol=2e-14,atol=2e-14)
    end
    upper=Main.RelaxTime.OneLoopIntegrals.energy_cutoff(.6)
    @test_throws DomainError tilde(:quark,-2upper,.6,.6,0.,1.,.6,.6,.5)
    threshold=Main.FullRSKZero.B0_pair_threshold_rs
    cutoff=Main.Constants_PNJL.Λ_inv_fm
    # Independent vacuum formula verifies both the equal-mass normalization
    # and the unequal-mass +/- energy symmetrization.
    for (a,b) in ((.6,.6),(.4,1.8))
        want=2/(a+b)*(a*asinh(cutoff/a)+b*asinh(cutoff/b))
        @test isapprox(threshold(a,b,0.,1e-5,.6,.5,0.),want;rtol=2e-12)
        for xi in (-.5,0.,.5), linear in (false,true)
            low=threshold(a,b,.2,1.,.6,.5,xi;linear=linear)
            high=threshold(a,b,.2,1.,.6,.5,xi;linear=linear,energy_nodes=256,angle_nodes=64)
            @test isapprox(low,high;rtol=2e-12,atol=2e-12)
        end
    end
end
