#!/usr/bin/env julia
# P4: selected channel gate, fixed outer p128 grid, refined sigma(s) and t grids.
include(joinpath(@__DIR__, "TransportReviewCommon.jl"))
include(joinpath(@__DIR__, "TransportReviewCheckpoints.jl"))
using .TransportReviewCommon
using .TransportReviewCheckpoints
using CSV, SHA

function main()
    length(ARGS)>=1 || error("expected OUTDIR [PART PARTS]")
    outdir=abspath(ARGS[1]);part=length(ARGS)>=2 ? parse(Int,ARGS[2]) : 1
    parts=length(ARGS)>=3 ? parse(Int,ARGS[3]) : 1
    1<=part<=parts || error("invalid partition")
    resume_from=length(ARGS)>=4 ? abspath(ARGS[4]) : nothing
    resume_from==outdir && error("resume into a new directory to preserve the earlier run")
    isfile(joinpath(outdir,"manifest_part$(part).json")) && error("output partition already exists")
    validate_resume(resume_from,joinpath(@__DIR__,"TransportReviewCommon.jl"),joinpath(INPUT,"review_points.csv"))
    points=Dict(point_id(r)=>r for r in read_points())
    plan=collect(CSV.File(joinpath(INPUT,"channel_plan.csv")))
    ids=sort(unique(String(r.point_id) for r in plan))[part:parts:end]
    write_json(joinpath(outdir,"manifest_part$(part).json"),run_metadata(@__FILE__,
        (part=part,parts=parts,points=length(ids),resume_from=resume_from,outer_grid=(128,20,36),
        sigma_cutoff_inv_fm=Main.Constants_PNJL.Λ_inv_fm,
        channel_plan_sha256=bytes2hex(sha256(read(joinpath(INPUT,"channel_plan.csv")))),
        sigma_grids=((48,1120),(96,2240)),scope="selected channels; unchanged channels remain production inputs")))
    rows=NamedTuple[];failures=NamedTuple[]
    for pid in ids
        row=points[pid];state=nothing
        jobs=[r for r in plan if String(r.point_id)==pid]
        for (level,ns,ng) in (("sigma48",48,1120),("sigma96",96,2240)), job in jobs
            channel=Symbol(job.channel)
            name=pid*"_"*String(channel)*"_"*level
            println("START ",name);flush(stdout)
            try
                cfg=merge(tau_config(:p128),(n_sigma_points=ns,sigma_grid_n=ng,
                    sigma_cutoff=Main.Constants_PNJL.Λ_inv_fm))
                restored=restored_checkpoint(resume_from,name,
                    (point_id=pid,channel=String(channel),resolution=level,source_rate=Float64(job.source_rate)),cfg)
                if restored!==nothing
                    push!(rows,canonical_summary(restored["summary"]))
                    checkpoint(outdir,name,restored)
                    continue
                end
                state===nothing && (state=state_from_row(row))
                timed=@timed Main.RelaxTime.AverageScatteringRate.average_scattering_rate(
                    channel,state.quark_params,state.thermo_params,state.K_coeffs;cfg...)
                rate=timed.value
                isfinite(rate)&&rate>=0 || error("nonfinite/negative channel rate: $rate")
                out=merge(point_fields(row),(window_ids=String(job.window_ids),role=String(job.role),
                    primary_species=String(job.primary_species),channel=String(channel),resolution=level,
                    seconds=timed.time,rate=rate,source_rate=Float64(job.source_rate),
                    relative_change=relative_change(rate,Float64(job.source_rate)),
                    source_contribution=Float64(job.source_contribution),source_total=Float64(job.source_total),
                    target_selected_coverage=Float64(job.target_selected_coverage)))
                out=canonical_summary(out)
                push!(rows,out);checkpoint(outdir,name,(summary=out,config=cfg))
            catch err
                detail=sprint(showerror,err,catch_backtrace())
                push!(failures,(job=name,error=detail));checkpoint(outdir,name*"_failure",last(failures))
            end
            write_rows(joinpath(outdir,"channels_part$(part).csv"),rows)
            write_json(joinpath(outdir,"status_part$(part).json"),(complete=false,rows=length(rows),failures=failures))
        end
    end
    write_rows(joinpath(outdir,"channels_part$(part).csv"),rows)
    write_json(joinpath(outdir,"status_part$(part).json"),(complete=true,rows=length(rows),failures=failures))
    isempty(failures) || error("channel gate failed; diagnostics retained")
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && main()
