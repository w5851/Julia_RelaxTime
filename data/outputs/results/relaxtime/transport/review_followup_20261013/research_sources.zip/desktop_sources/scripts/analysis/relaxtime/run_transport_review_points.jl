#!/usr/bin/env julia
#= P1 ablation and P4 local refinement on exactly retained production states.

Usage: julia --project=. .../run_transport_review_points.jl MODE OUTDIR [PART PARTS RESUME_FROM]
MODE: ablation | ablation_check | refinement | smoke. Each point is checkpointed independently.
The ablation is a p64 diagnostic; ablation_check uses p96 at endpoint anchors.
=#
include(joinpath(@__DIR__, "TransportReviewCommon.jl"))
include(joinpath(@__DIR__, "TransportReviewCheckpoints.jl"))
using .TransportReviewCommon
using .TransportReviewCheckpoints
using JSON

function run_point(row, mode, outdir; resume_from=nothing)
    println("PREPARE ",point_id(row));flush(stdout)
    state = nothing
    bulk = nothing
    tau0 = production_tau(row)
    trans0 = nothing
    result_rows = NamedTuple[]
    configs = mode === "refinement" ? ((:p128,:match_thermo), (:sigma_refined,:match_thermo), (:p160,:match_thermo)) :
        mode === "smoke" ? ((:p128,:match_thermo),) :
        mode === "ablation_check" ? ((:p96,:match_thermo), (:p96,:isotropic)) :
        ((:p64,:match_thermo), (:p64,:isotropic))
    for (level, policy) in configs
        name=point_id(row)*"_"*String(level)*"_"*String(policy)
        restored=restored_checkpoint(resume_from,name,
            (point_id=point_id(row),resolution=String(level),policy=String(policy)),tau_config(level))
        if restored!==nothing
            push!(result_rows,canonical_summary(restored["summary"]))
            checkpoint(outdir,name,restored)
            continue
        end
        if state===nothing
            state=state_from_row(row)
            bulk=bulk_for_base(row,base_from_row(row))
            trans0=transport_for_tau(state,tau0,bulk)
        end
        println("START ", point_id(row), " ", level, " ", policy); flush(stdout)
        iso_qp = if policy === :isotropic
            av = Main.RelaxTime.AFieldBuilder.build_A_triplet(state.quark_params,
                merge(state.thermo_params,(ξ=0.0,)); p_nodes=16,p_max=20.0,cos_nodes=4,use_aniso=true)
            merge(state.quark_params,(A=av,))
        else
            nothing
        end
        timed = @timed Main.RelaxTime.RelaxationTime.relaxation_times(
            state.quark_params, state.thermo_params, state.K_coeffs;
            densities=densities_from_row(row), tau_config(level)...,
            propagator_xi_policy=policy, propagator_quark_params=iso_qp)
        result = timed.value
        tr = transport_for_tau(state, result.tau, bulk)
        out = merge(point_fields(row), (resolution=String(level), policy=String(policy),
            seconds=timed.time, tau_u=result.tau.u, tau_s=result.tau.s,
            tau_ubar=result.tau.ubar, tau_sbar=result.tau.sbar,
            eta_over_s=tr.eta/row.s_fm3inv, zeta_over_s=tr.zeta/row.s_fm3inv,
            sigma_over_T=tr.sigma/row.T_fm,
            tau_u_rel_to_production=relative_change(result.tau.u,tau0.u),
            tau_s_rel_to_production=relative_change(result.tau.s,tau0.s),
            eta_rel_to_same_kernel=relative_change(tr.eta,trans0.eta),
            zeta_rel_to_same_kernel=relative_change(tr.zeta,trans0.zeta),
            sigma_rel_to_same_kernel=relative_change(tr.sigma,trans0.sigma),
            replay_eta_rel_to_production=relative_change(trans0.eta,Float64(row.eta)),
            replay_zeta_rel_to_production=relative_change(trans0.zeta,Float64(row.zeta)),
            replay_sigma_rel_to_production=relative_change(trans0.sigma,Float64(row.sigma))))
        out=canonical_summary(out)
        push!(result_rows, out)
        checkpoint(outdir, name,
            (summary=out, rates=result.rates, tau=result.tau, config=tau_config(level)))
    end
    result_rows
end

function main()
    length(ARGS) >= 2 || error("expected MODE OUTDIR [PART PARTS]")
    mode,outdir = ARGS[1],abspath(ARGS[2])
    mode in ("smoke","ablation","ablation_check","refinement") || error("invalid MODE")
    part = length(ARGS)>=3 ? parse(Int,ARGS[3]) : 1
    parts = length(ARGS)>=4 ? parse(Int,ARGS[4]) : 1
    resume_from=length(ARGS)>=5 ? abspath(ARGS[5]) : nothing
    resume_from==outdir && error("resume into a new directory to preserve the earlier run")
    isfile(joinpath(outdir,"manifest_part$(part).json")) && error("output partition already exists")
    validate_resume(resume_from,joinpath(@__DIR__,"TransportReviewCommon.jl"),joinpath(INPUT,"review_points.csv"))
    1 <= part <= parts || error("invalid partition")
    selected = [r for r in read_points() if mode=="refinement" ? r.p4 : r.p1]
    mode=="ablation_check" && (selected=[r for r in selected if r.alpha_T==1.0 && abs(r.xi)==.5])
    mode=="smoke" && (selected=selected[1:1])
    selected=selected[part:parts:end]
    write_json(joinpath(outdir,"manifest_part$(part).json"), run_metadata(@__FILE__,
        (mode=mode,part=part,parts=parts,points=length(selected),resume_from=resume_from,
        thermo_quadrature=(24,8),transport_radial_quadrature=(24,8.0),
        state_policy="retained masses, Phi, densities, T and mu; branch locked bulk",
        ablation_scope="entire sigma(s) context including RS A, B0 and final state Pauli factors; K fixed")))
    allrows = NamedTuple[]
    failures = NamedTuple[]
    for row in selected
        try
            append!(allrows, run_point(row,mode,outdir;resume_from=resume_from))
        catch err
            detail = sprint(showerror,err,catch_backtrace())
            push!(failures,(point_id=point_id(row),error=detail))
            checkpoint(outdir,point_id(row)*"_failure",last(failures))
            println(stderr, detail); flush(stderr)
        end
        write_rows(joinpath(outdir,"summary_part$(part).csv"),allrows)
        write_json(joinpath(outdir,"status_part$(part).json"),
            (complete=false,rows=length(allrows),failures=failures,expected_points=length(selected)))
    end
    write_json(joinpath(outdir,"status_part$(part).json"),
        (complete=true,rows=length(allrows),failures=failures,expected_points=length(selected)))
    isempty(failures) || error("$(length(failures)) point(s) failed; see retained diagnostics")
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && main()
