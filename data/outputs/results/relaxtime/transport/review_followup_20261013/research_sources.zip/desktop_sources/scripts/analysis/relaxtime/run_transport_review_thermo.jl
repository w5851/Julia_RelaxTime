#!/usr/bin/env julia
# P5: background and bulk-derivative quadrature sensitivity at fixed tau.
include(joinpath(@__DIR__, "TransportReviewCommon.jl"))
using .TransportReviewCommon

function main()
    length(ARGS)>=1 || error("expected OUTDIR [LIMIT]")
    outdir=abspath(ARGS[1]);limit=length(ARGS)>=2 ? parse(Int,ARGS[2]) : 0
    selected=[r for r in read_points() if r.p1]
    limit>0 && (selected=selected[1:min(limit,length(selected))])
    resolutions=((12,6),(24,8),(48,16),(96,24))
    write_json(joinpath(outdir,"manifest.json"),run_metadata(@__FILE__,
        (points=length(selected),resolutions=resolutions,tau_policy="fixed_retained_production_tau",
        equilibrium_policy="seed each resolution with retained branch; report mass drift",
        transport_quadrature="production p24, default angular grid, pmax=8 fm^-1; tail sensitivity separate")))
    rows=NamedTuple[];kernelrows=NamedTuple[];failures=NamedTuple[]
    for row in selected
        original=base_from_row(row);tau=production_tau(row)
        for (np,nt) in resolutions
            println("START ",point_id(row)," thermo ",np,"/",nt);flush(stdout)
            try
                timed=@timed begin
                    base=Main.Models.solve(MODEL,Main.Models.FixedMu(),Float64(row.T_fm),Float64(row.muq_fm);
                        seed_guess=original.x_state,xi=Float64(row.xi),p_num=np,t_num=nt,residual_norm_max=1e-7)
                    base.converged || error("equilibrium did not converge")
                    state=state_from_base(base,row)
                    bulk=bulk_for_base(row,base;p_num=np,t_num=nt)
                    tr=transport_for_tau(state,tau,bulk)
                    (base=base,bulk=bulk,transport=tr)
                end
                v=timed.value;b=v.base;t=v.transport
                out=merge(point_fields(row),(p_num=np,t_num=nt,seconds=timed.time,
                    m_u_MeV=b.masses[1]*HC,m_s_MeV=b.masses[3]*HC,Phi=b.x_state[4],Phibar=b.x_state[5],
                    entropy=b.entropy,pressure=b.pressure,v_n_sq=v.bulk.v_n_sq,
                    eta_over_s=t.eta/b.entropy,zeta_over_s=t.zeta/b.entropy,sigma_over_T=t.sigma/row.T_fm,
                    residual_norm=b.residual_norm,branch_locked=v.bulk.branch_locked,
                    mass_u_rel_to_retained=relative_change(b.masses[1],Float64(row.m_u))))
                push!(rows,out)
                checkpoint(outdir,point_id(row)*"_p$(np)t$(nt)",(summary=out,))
                if np==24 && nt==8
                    state=state_from_base(b,row)
                    default_cos=length(Main.RelaxTime.GaussLegendre.DEFAULT_COSΘ_NODES)
                    for (nk,na,pmax) in ((24,default_cos,8.),(64,16,8.),(128,32,8.),
                        (128,32,12.),(192,48,16.),(256,64,20.))
                        kt=transport_for_tau(state,tau,v.bulk;p_nodes=nk,cos_nodes=na,p_max=pmax)
                        push!(kernelrows,merge(point_fields(row),(p_nodes=nk,cos_nodes=na,p_max_inv_fm=pmax,
                            eta_over_s=kt.eta/b.entropy,zeta_over_s=kt.zeta/b.entropy,sigma_over_T=kt.sigma/row.T_fm,
                            eta_rel_to_retained=relative_change(kt.eta,Float64(row.eta)),
                            zeta_rel_to_retained=relative_change(kt.zeta,Float64(row.zeta)),
                            sigma_rel_to_retained=relative_change(kt.sigma,Float64(row.sigma)))))
                    end
                    write_rows(joinpath(outdir,"transport_quadrature.csv"),kernelrows)
                end
            catch err
                detail=sprint(showerror,err,catch_backtrace())
                push!(failures,(point_id=point_id(row),p_num=np,t_num=nt,error=detail))
                checkpoint(outdir,point_id(row)*"_p$(np)t$(nt)_failure",last(failures))
                println(stderr,detail);flush(stderr)
            end
            write_rows(joinpath(outdir,"thermo_sensitivity.csv"),rows)
        end
        write_json(joinpath(outdir,"status.json"),(complete=false,rows=length(rows),failures=failures))
    end
    write_json(joinpath(outdir,"status.json"),(complete=true,rows=length(rows),kernel_rows=length(kernelrows),failures=failures))
    isempty(failures) || error("thermodynamic points failed; see status.json")
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && main()
