! Analysis driver for the retained Fortran kernels. No model parameters change.
! The eta integral is copied from coefficients_tmu; bulk-only derivatives are
! omitted so that the requested muB=0 points can be evaluated exactly.
program legacy_eta_reference_probe
    use nrtype, only: dp
    use constant, only: hc, pi, N_c
    use integral, only: npoint1, y1, w1
    use variable
    use type_state, only: state
    use nr, only: newt
    use PNJL, only: funcv_tmu, quantity, coefficients_tmu
    use quark_fun, only: f1f, f1fb
    use meson_function, only: relaxation_time
    use, intrinsic :: ieee_arithmetic, only: ieee_is_finite
    implicit none
    character(len=128) :: argument, mode
    real(dp) :: target_T_MeV, target_muB_MeV, current_T_MeV
    real(dp) :: x(5), residual(5), max_residual, p, eta_value
    real(dp) :: tau_values(2,3), eta_parts(2,3), energies(3), ff(2,3)
    type(state) :: phy
    logical :: check
    integer :: i, j, k, unit

    if (command_argument_count() /= 3) error stop 'usage: T_MeV muB_MeV eta|legacy_control'
    call get_command_argument(1, argument)
    read(argument,*) target_T_MeV
    call get_command_argument(2, argument)
    read(argument,*) target_muB_MeV
    call get_command_argument(3, mode)
    if (target_T_MeV < 50.0_dp) error stop 'probe starts at 50 MeV'
    call set_integral
    mu_B = target_muB_MeV/hc
    arrMu(:) = mu_B/3.0_dp
    x = [-1.8_dp, -1.8_dp, -2.2_dp, 0.01_dp, 0.01_dp]
    current_T_MeV = 50.0_dp
    max_residual = 0.0_dp
    do
        T = current_T_MeV/hc
        call newt(x, check, funcv_tmu)
        residual = funcv_tmu(x)
        if (.not.all(ieee_is_finite(x)) .or. .not.all(ieee_is_finite(residual))) error stop 'nonfinite equilibrium'
        if (check .or. maxval(abs(residual)) > 1.e-7_dp) error stop 'equilibrium did not converge'
        max_residual = max(max_residual, maxval(abs(residual)))
        if (current_T_MeV >= target_T_MeV) exit
        current_T_MeV = min(target_T_MeV, current_T_MeV + 1.0_dp)
    end do
    phy%T = T
    phy%mu_B = mu_B
    phy%arrMu = arrMu
    phy%arrPhi = x
    call quantity(phy)
    phi_u = x(1); phi_d = x(2); phi_s = x(3)
    Phi1 = x(4); Phi2 = x(5)
    arrMass = phy%arrMass
    arrN = phy%arrN
    arrA = phy%arrA
    arrG = phy%arrG
    n_B = phy%n_B; n_charge = phy%n_charge; n_strange = phy%n_strange
    s = phy%s; pressure = phy%pressure; energy = phy%energy; rho_mass = phy%rho_mass
    if (.not.ieee_is_finite(s) .or. s <= 0.0_dp .or. any(arrMass <= 0.0_dp)) error stop 'invalid thermodynamics'
    write(*,*) 'EQUILIBRIUM', target_T_MeV, target_muB_MeV, arrMass*hc, max_residual
    flush(6)
    call relaxation_time(tau_values)
    if (.not.all(ieee_is_finite(tau_values)) .or. any(tau_values <= 0.0_dp)) error stop 'invalid tau'
    eta_parts = 0.0_dp
    do i = 1, npoint1
        p = y1(i)
        energies = sqrt(arrMass**2+p**2)
        do k = 1, 3
            ff(1,k) = f1f(energies(k)-arrMu(k), T, Phi1, Phi2)
            ff(2,k) = f1fb(energies(k)+arrMu(k), T, Phi1, Phi2)
            do j = 1, 2
                eta_parts(j,k) = eta_parts(j,k) + w1(i)*p**6/energies(k)**2*ff(j,k)
            end do
        end do
    end do
    eta_parts = eta_parts*tau_values*N_c/(15.0_dp*pi**2*T)
    eta_value = sum(eta_parts)
    if (.not.ieee_is_finite(eta_value) .or. eta_value <= 0.0_dp) error stop 'invalid eta'
    open(newunit=unit,file='point.csv',status='replace',action='write')
    write(unit,'(a)') 'T_MeV,muB_MeV,eta_over_s,eta_fm3inv,entropy_fm3inv,m_u_MeV,m_d_MeV,m_s_MeV,Phi,Phibar,tau_u_fm,tau_ubar_fm,tau_s_fm,tau_sbar_fm,max_gap_residual'
    write(unit,'(*(g0,:,","))') target_T_MeV,target_muB_MeV,eta_value/s,eta_value,s,arrMass*hc, &
        Phi1,Phi2,tau_values(1,1),tau_values(2,1),tau_values(1,3),tau_values(2,3),max_residual
    close(unit)
    write(*,*) 'ETA_OVER_S', eta_value/s
    flush(6)
    if (trim(mode) == 'legacy_control') then
        if (abs(target_muB_MeV) < 1.e-8_dp) error stop 'full legacy bulk routine requires nonzero muB'
        call coefficients_tmu(phy)
    else if (trim(mode) /= 'eta') then
        error stop 'unknown mode'
    end if
end program legacy_eta_reference_probe
