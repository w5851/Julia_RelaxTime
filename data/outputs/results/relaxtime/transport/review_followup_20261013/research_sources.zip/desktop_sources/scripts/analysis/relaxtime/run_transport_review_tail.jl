#!/usr/bin/env julia
# Fixed-state, fixed-tau momentum-tail diagnostics; no formal data changes.
include(joinpath(@__DIR__,"TransportReviewCommon.jl"))
using .TransportReviewCommon

function infinite_grid(n,scale)
    nodes,weights=Main.RelaxTime.GaussLegendre.gauleg(0.0,1.0,n)
    scale.*nodes./(1 .-nodes), scale.*weights./(1 .-nodes).^2
end

function main()
    length(ARGS)==1 || error("expected a new OUTDIR")
    outdir=abspath(ARGS[1])
    isfile(joinpath(outdir,"manifest.json")) && error("output already exists")
    selected=[r for r in read_points() if r.p1 || Float64(r.xi)==0.0]
    configs=[(label="production",kind="finite",n=24,na=8,pmax=8.,scale=0.),
        (label="p20",kind="finite",n=256,na=64,pmax=20.,scale=0.),
        (label="p30",kind="finite",n=256,na=64,pmax=30.,scale=0.),
        (label="p40",kind="finite",n=256,na=64,pmax=40.,scale=0.),
        (label="p60",kind="finite",n=512,na=96,pmax=60.,scale=0.),
        (label="infinite128",kind="infinite",n=128,na=64,pmax=0.,scale=2.),
        (label="infinite256",kind="infinite",n=256,na=64,pmax=0.,scale=2.),
        (label="infinite512",kind="infinite",n=512,na=96,pmax=0.,scale=2.),
        (label="infinite_scale5",kind="infinite",n=256,na=96,pmax=0.,scale=5.)]
    checks=NamedTuple[]
    for scale in (2.,5.), a in (.6,1.,2.)
        p,w=infinite_grid(256,scale)
        value=sum(w.*p.^6 .* exp.(-a.*p))
        relative_error=abs(value/(720/a^7)-1)
        relative_error<1e-11 || error("semi-infinite quadrature failed its analytic moment check")
        push!(checks,(scale=scale,a=a,relative_error=relative_error))
    end
    write_json(joinpath(outdir,"manifest.json"),run_metadata(@__FILE__,
        (points=length(selected),configs=configs,state_policy="retained exact background and tau",
        thermo_quadrature=(24,8),mapping="p=scale*x/(1-x), x in [0,1]",analytic_moment_checks=checks)))
    rows=NamedTuple[];failures=NamedTuple[]
    for row in selected
        println("START ",point_id(row));flush(stdout)
        try
            state=state_from_row(row);tau=production_tau(row);bulk=bulk_for_base(row,base_from_row(row))
            localrows=NamedTuple[]
            for c in configs
                tr=if c.kind=="finite"
                    transport_for_tau(state,tau,bulk;p_nodes=c.n,cos_nodes=c.na,p_max=c.pmax)
                else
                    p,w=infinite_grid(c.n,c.scale)
                    Main.RelaxTime.TransportCoefficients.transport_coefficients(state.quark_params,state.thermo_params;
                        tau=tau,bulk_coeffs=bulk,config=Main.RelaxTime.TransportCoefficients.TransportIntegrationConfig(
                            p_nodes=c.n,p_grid=p,p_w=w,cos_nodes=c.na,p_max=60.))
                end
                all(isfinite,(tr.eta,tr.zeta,tr.sigma)) || error("nonfinite transport tail")
                push!(localrows,merge(point_fields(row),(configuration=c.label,kind=c.kind,p_nodes=c.n,
                    cos_nodes=c.na,p_max_inv_fm=c.pmax,mapping_scale=c.scale,
                    eta_over_s=tr.eta/row.s_fm3inv,zeta_over_s=tr.zeta/row.s_fm3inv,sigma_over_T=tr.sigma/row.T_fm,
                    eta_rel_to_retained=relative_change(tr.eta,Float64(row.eta)),
                    zeta_rel_to_retained=relative_change(tr.zeta,Float64(row.zeta)),
                    sigma_rel_to_retained=relative_change(tr.sigma,Float64(row.sigma)))))
            end
            append!(rows,localrows)
            checkpoint(outdir,point_id(row),(rows=localrows,))
        catch err
            detail=sprint(showerror,err,catch_backtrace())
            push!(failures,(point_id=point_id(row),error=detail))
            checkpoint(outdir,point_id(row)*"_failure",last(failures))
            println(stderr,detail);flush(stderr)
        end
        write_rows(joinpath(outdir,"transport_tail.csv"),rows)
        write_json(joinpath(outdir,"status.json"),(complete=false,rows=length(rows),failures=failures))
    end
    write_json(joinpath(outdir,"status.json"),(complete=true,rows=length(rows),expected_rows=length(selected)*length(configs),failures=failures))
    isempty(failures) || error("transport tail points failed")
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && main()
