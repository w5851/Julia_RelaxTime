#!/usr/bin/env julia
# Bounded analysis using a frozen source workspace; no production replacement.
length(ARGS) == 4 || error("usage: FROZEN_ROOT OUTDIR REPO_ROOT tail|validation")
const FROZEN_ROOT = abspath(ARGS[1])
const OUTDIR = abspath(ARGS[2])
const REPO_ROOT = abspath(ARGS[3])
const STAGE = ARGS[4]
include(joinpath(FROZEN_ROOT, "scripts", "analysis", "relaxtime", "TransportReviewCommon.jl"))
using .TransportReviewCommon
using CSV, SHA, Dates
const TC = Main.RelaxTime.TransportCoefficients
if STAGE == "validation"
    include(joinpath(FROZEN_ROOT, "tests/validation/relaxtime/literature_validation_helpers.jl"))
end

function integration_config(label)
    if startswith(label, "infinite")
        n = parse(Int, replace(label, "infinite" => ""))
        x, w = Main.RelaxTime.GaussLegendre.gauleg(0., 1., n)
        return TC.TransportIntegrationConfig(p_nodes=n, p_grid=2 .* x ./ (1 .- x),
            p_w=2 .* w ./ (1 .- x).^2, cos_nodes=n == 512 ? 96 : 64, p_max=60.)
    end
    pmax, n, na = label == "production8" ? (8., 24, 8) :
        label == "p15_n24" ? (15., 24, 8) :
        label == "p15_n128" ? (15., 128, 32) :
        label == "p15_n256" ? (15., 256, 64) :
        label == "p15_n512" ? (15., 512, 96) : error("unknown configuration")
    TC.TransportIntegrationConfig(p_nodes=n, p_max=pmax, cos_nodes=na)
end

function evaluate(state, tau, bulk, entropy, label)
    tr = TC.transport_coefficients(state.quark_params, state.thermo_params;
        tau=tau, bulk_coeffs=bulk, config=integration_config(label))
    (eta_over_s=tr.eta/entropy, zeta_over_s=tr.zeta/entropy,
        sigma_t=tr.sigma/state.thermo_params.T)
end

function tail_check()
    selected = [r for r in read_points() if r.p1 || Float64(r.xi) == 0.]
    labels = ("production8", "p15_n24", "p15_n128", "p15_n256", "p15_n512", "infinite256", "infinite512")
    rows = NamedTuple[]
    oldpath = joinpath(FROZEN_ROOT, "data/outputs/results/relaxtime/transport/review_followup_20261013/run_20261014/tables/transport_tail_comparison.csv")
    old = Dict(String(r.point_id) => r for r in CSV.File(oldpath))
    controls = NamedTuple[]
    for row in selected
        println("START TAIL ", point_id(row)); flush(stdout)
        state = state_from_row(row)
        tau = production_tau(row)
        bulk = bulk_for_base(row, base_from_row(row))
        for label in labels
            vals = evaluate(state, tau, bulk, Float64(row.s_fm3inv), label)
            all(isfinite, values(vals)) || error("nonfinite tail result")
            push!(rows, merge(point_fields(row), (configuration=label,), vals))
            expected = label == "production8" ?
                (Float64(row.eta_over_s), Float64(row.zeta_over_s), Float64(row.sigma_over_T)) :
                label == "infinite512" ?
                (old[point_id(row)].infinite_eta_over_s, old[point_id(row)].infinite_zeta_over_s, old[point_id(row)].infinite_sigma_over_T) : nothing
            if expected !== nothing
                err = maximum(abs(relative_change(a,b)) for (a,b) in zip(values(vals), expected))
                err < 1e-8 || error("frozen-source replay differs from retained results: $err")
                push!(controls, (point_id=point_id(row), configuration=label, max_relative_error=err))
            end
        end
        write_rows(joinpath(OUTDIR, "tail.csv"), rows)
        write_rows(joinpath(OUTDIR, "replay_controls.csv"), controls)
        println("DONE TAIL ", point_id(row)); flush(stdout)
    end
    length(rows) == 32*length(labels) || error("unexpected tail point count")
    write_json(joinpath(OUTDIR, "tail_status.json"), (complete=true, points=length(selected), rows=length(rows)))
end

function validation_check()
    targets = NamedTuple[]
    targetroot = joinpath(FROZEN_ROOT, "tests/validation/data/targets/relaxtime")
    for (field, filename) in ((:eta_over_s,"eta_over_s"), (:zeta_over_s,"zeta_over_s"), (:sigma_t,"sigma_t"))
        path = joinpath(targetroot, "legacy/transport/relaxtime_$(filename)_legacy_targets_v1.csv")
        for r in CSV.File(path)
            push!(targets, (family="legacy_fortran", T_MeV=Float64(r.T_MeV), muB_MeV=Float64(r.muB_MeV),
                field=field, expected=Float64(r.expected_value), rtol=Float64(r.rtol), source=String(r.source)))
        end
    end
    path = joinpath(targetroot, "literature/eta_over_s/relaxtime_eta_over_s_literature_targets_v1.csv")
    for r in CSV.File(path; comment="#")
        push!(targets, (family="literature_eta", T_MeV=Float64(r.T_MeV), muB_MeV=Float64(r.muB_MeV),
            field=:eta_over_s, expected=Float64(r.expected_eta_over_s), rtol=Float64(r.rtol), source=String(r.source)))
    end
    pairs = unique((r.T_MeV,r.muB_MeV) for r in targets)
    rows = NamedTuple[]
    for (T, muB) in pairs
        println("START VALIDATION T=", T, " muB=", muB); flush(stdout)
        localtargets = [r for r in targets if r.T_MeV == T && r.muB_MeV == muB]
        Tf, muf = T/HC, muB/(3HC)
        eq = Main._solve_relaxtime_literature_validation_equilibrium(Tf,muf,0.)
        Bool(eq.converged) || error("validation background failed")
        masses = (u=Float64(eq.masses[1]), d=Float64(eq.masses[2]), s=Float64(eq.masses[3]))
        kc = Main._build_relaxtime_literature_validation_K_coeffs(Tf,muf,masses,Float64(eq.x_state[4]),Float64(eq.x_state[5]))
        want_bulk = any(r.field == :zeta_over_s for r in localtargets)
        res = Main.RELAXTIME_LITERATURE_VALIDATION_TRANSPORT_WORKFLOW.solve_gap_and_transport(Tf,muf;
            xi=0., equilibrium=eq, compute_tau=true, K_coeffs=kc.K_coeffs, compute_bulk=want_bulk,
            p_num=12, t_num=6, seed_state=Vector(eq.x_state), solver_kwargs=(iterations=40,),
            transport_config=integration_config("p15_n256"))
        _,_,entropy,_ = Models.model_thermo(MODEL,eq.x_state,eq.mu_vec,Tf;p_num=12,t_num=6,xi=0.)
        state = (quark_params=res.quark_params, thermo_params=res.thermo_params)
        for label in ("production8", "p15_n24", "p15_n128", "p15_n256", "infinite256")
            vals = evaluate(state,res.tau,res.bulk_coeffs,Float64(entropy),label)
            for target in localtargets
                actual = getproperty(vals,target.field)
                isfinite(actual) || error("nonfinite validation observable")
                push!(rows, merge(target,(field=String(target.field), configuration=label,actual=actual,
                    relative_error=relative_change(actual,target.expected),
                    passes_target_tolerance=isapprox(actual,target.expected;rtol=target.rtol,atol=0.))))
            end
        end
        write_rows(joinpath(OUTDIR,"validation.csv"),rows)
        checkpoint(OUTDIR,"validation_T$(T)_muB$(muB)",(T_MeV=T,muB_MeV=muB,xi=0.,
            masses=masses,x_state=eq.x_state,tau=res.tau,bulk_coeffs=res.bulk_coeffs,entropy=entropy))
    end
    length(rows) == 65 || error("unexpected validation target count")
    write_json(joinpath(OUTDIR,"validation_status.json"),(complete=true,points=length(pairs),targets=length(targets),rows=length(rows)))
end

mkpath(OUTDIR)
write_json(joinpath(OUTDIR,"$(STAGE)_run.json"),(created_utc=string(now(UTC)),julia=string(VERSION),
    source_workspace=FROZEN_ROOT,script_sha256=bytes2hex(sha256(read(@__FILE__))),
    stage=STAGE,status="analysis_only",formal_data_modified=false,manuscript_eligible=false))
STAGE == "tail" ? tail_check() : STAGE == "validation" ? validation_check() : error("unknown stage")
