"""Summarize the bounded cutoff check and distinguish display edits from rapid rises."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math


def read_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(line for line in stream if line.strip() and not line.lstrip().startswith("#")))


def write_rows(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def plot_curves(repo, out):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    source = repo / "docs/analysis/relaxtime/phase_guided_transport/phase_guided_transport_publication_clean_v5/tables/publication_clean_points.csv"
    points = read_rows(source)
    specs = [
        ("muB0.0", "alpha1.0", "tau_u", -.30, -.12, -.22, -.21, r"$\pi$ threshold"),
        ("muB450.0", "alpha1.0", "tau_ubar", .20, .32, .26, .27, "mixed P candidate"),
        ("muB0.0", "alpha1.1", "tau_u", .35, .50, .47, .48, r"$\pi$ threshold"),
        ("muB450.0", "alpha1.1", "tau_ubar", .25, .43, .34, .35, r"$\pi$ threshold"),
    ]
    figure, axes = plt.subplots(2, 2, figsize=(10.4, 7.2), layout="constrained")
    selected, summary = [], []
    for ax, (panel, series, obs, lo, hi, left, right, label) in zip(axes.flat, specs):
        rows = sorted((r for r in points if r["mode_key"] == "mode_a" and r["plot_panel"] == panel
                       and r["plot_series"] == series and r["observable"] == obs
                       and lo <= float(r["xi"]) <= hi), key=lambda r: float(r["xi"]))
        assert len(rows) >= 3
        x = [float(r["xi"]) for r in rows]
        raw = [float(r["raw_value"]) for r in rows]
        display = [float(r["clean_value"]) for r in rows]
        ax.axvspan(left, right, color="#c57b36", alpha=.18, label=label)
        ax.plot(x, raw, "o--", color="#777777", markersize=4, markerfacecolor="white", linewidth=1, label="Raw")
        ax.plot(x, display, color="#165d9c", linewidth=1.7, label="Display")
        ax.set_title(rf"$\mu_B={panel[3:]}$ MeV, $\alpha_T={series[5:]}$", fontsize=11)
        ax.set_xlabel(r"$\xi$")
        ax.set_ylabel(r"$\tau_u$ (fm)" if obs == "tau_u" else r"$\tau_{\bar u}$ (fm)")
        ax.grid(alpha=.18)
        ax.legend(fontsize=8, frameon=False)
        ax.set_xlim(lo, hi)
        changes = [abs(b-a)/max(abs(a), 1e-300) for a, b in zip(raw, display)]
        summary.append(dict(panel=panel, series=series, observable=obs, points=len(rows),
                            changed_points=sum(a != b for a, b in zip(raw, display)),
                            max_relative_display_change=max(changes), threshold_left=left, threshold_right=right))
        selected.extend({k:r[k] for k in ("mode_key", "plot_panel", "plot_series", "observable", "xi",
                                         "raw_value", "v2_clean_value", "clean_value", "display_status", "smoothing_window")} for r in rows)
    figure.suptitle("Raw and display curves with same-background threshold brackets", fontsize=13)
    figure.savefig(out / "raw_display_mott_comparison.png", dpi=180)
    figure.savefig(out / "raw_display_mott_comparison.pdf")
    plt.close(figure)
    write_rows(out / "curve_point_comparison.csv", selected)
    write_rows(out / "curve_window_summary.csv", summary)
    threshold_paths = [out.parent / "run_20261014/tables" / name for name in
                       ("refined_pi_mott_brackets.csv", "channel_threshold_evidence.csv")]
    (out / "curve_source.json").write_text(json.dumps(dict(path=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        threshold_sources=[dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in threshold_paths],
        status="analysis_only",causal_attribution=False), indent=2),encoding="utf-8")
    print(json.dumps(summary, indent=2))


def summarize(out):
    for stage in ("tail", "validation"):
        assert json.loads((out / f"{stage}_status.json").read_text())["complete"]
    rows = read_rows(out / "tail.csv")
    assert len(rows) == 224
    groups = {}
    for row in rows:
        group = groups.setdefault(row["point_id"], {})
        assert row["configuration"] not in group
        group[row["configuration"]] = row
    quantities = ("eta_over_s", "zeta_over_s", "sigma_t")
    comparison = []
    for pid, group in groups.items():
        assert len(group) == 7
        ref, p15 = group["infinite512"], group["p15_n512"]
        item = {k:ref[k] for k in ("point_id", "mode", "plot_panel", "plot_series", "T_MeV", "muB_MeV", "xi")}
        for q in quantities:
            infinity, finite = float(ref[q]), float(p15[q])
            assert math.isfinite(infinity) and math.isfinite(finite) and min(infinity, finite) > 0
            item[q + "_p15"] = finite
            item[q + "_infinite"] = infinity
            item[q + "_tail_fraction"] = (infinity-finite)/abs(infinity)
            item[q + "_n128_relative_change"] = abs(float(group["p15_n128"][q])-finite)/abs(finite)
            item[q + "_n256_relative_change"] = abs(float(group["p15_n256"][q])-finite)/abs(finite)
            item[q + "_n24_relative_change"] = abs(float(group["p15_n24"][q])-finite)/abs(finite)
            item[q + "_infinite_refinement"] = abs(float(group["infinite256"][q])-infinity)/abs(infinity)
            item[q + "_production8_tail_fraction"] = (infinity-float(group["production8"][q]))/abs(infinity)
        comparison.append(item)
    write_rows(out / "cutoff15_comparison.csv", comparison)
    report = {"tail_points":len(groups), "isotropic_points":sum(float(r["xi"]) == 0 for r in comparison)}
    controls = read_rows(out / "replay_controls.csv")
    assert len(controls) == 64
    report["replay_controls"] = dict(count=len(controls), max_relative_error=max(float(r["max_relative_error"]) for r in controls))
    assert report["replay_controls"]["max_relative_error"] < 1e-8
    for scope, subset in (("all", comparison), ("xi0", [r for r in comparison if float(r["xi"]) == 0])):
        report[scope] = {}
        for q in quantities:
            worst = max(subset, key=lambda r:abs(r[q + "_tail_fraction"]))
            report[scope][q] = {"max_tail_fraction":worst[q + "_tail_fraction"], "point_id":worst["point_id"],
                "T_MeV":float(worst["T_MeV"]), "muB_MeV":float(worst["muB_MeV"]), "xi":float(worst["xi"]),
                "max_n128_relative_change":max(r[q + "_n128_relative_change"] for r in subset),
                "max_n256_relative_change":max(r[q + "_n256_relative_change"] for r in subset),
                "max_n24_relative_change":max(r[q + "_n24_relative_change"] for r in subset),
                "max_infinite_refinement":max(r[q + "_infinite_refinement"] for r in subset),
                "max_production8_tail_fraction":max(r[q + "_production8_tail_fraction"] for r in subset)}
    validation = read_rows(out / "validation.csv")
    assert len(validation) == 65
    validation_groups = {}
    for row in validation:
        key = (row["family"], float(row["T_MeV"]), float(row["muB_MeV"]), row["field"])
        group = validation_groups.setdefault(key, {})
        assert row["configuration"] not in group
        group[row["configuration"]] = row
    validation_comparison = []
    for key, group in validation_groups.items():
        assert len(group) == 5
        finite = float(group["p15_n256"]["actual"])
        infinity = float(group["infinite256"]["actual"])
        original = float(group["production8"]["actual"])
        validation_comparison.append(dict(family=key[0], T_MeV=key[1], muB_MeV=key[2], xi=0., field=key[3],
            p15=finite, infinite256=infinity, tail_fraction=(infinity-finite)/abs(infinity),
            p8_to_p15_relative_change=(finite-original)/abs(original),
            p15_n128_relative_change=abs(float(group["p15_n128"]["actual"])-finite)/abs(finite),
            p15_n24_relative_change=abs(float(group["p15_n24"]["actual"])-finite)/abs(finite),
            original8_target_relative_error=float(group["production8"]["relative_error"]),
            p15_target_relative_error=float(group["p15_n256"]["relative_error"]),
            infinite_target_relative_error=float(group["infinite256"]["relative_error"])))
    write_rows(out / "validation_cutoff_comparison.csv", validation_comparison)
    report["validation_cutoff_comparison"] = validation_comparison
    selected = [r for r in validation if r["configuration"] == "p15_n256"]
    for row in selected:
        for field in ("T_MeV", "muB_MeV", "expected", "rtol", "actual", "relative_error"):
            row[field] = float(row[field])
            assert math.isfinite(row[field])
        row["passes_target_tolerance"] = row["passes_target_tolerance"].lower() == "true"
    report["validation_p15"] = selected
    report["validation_summary"] = {}
    for family in ("legacy_fortran", "literature_eta"):
        subset = [r for r in selected if r["family"] == family]
        report["validation_summary"][family] = dict(targets=len(subset),
            passed=sum(r["passes_target_tolerance"] for r in subset),
            max_absolute_relative_error=max(abs(r["relative_error"]) for r in subset))
    report["status"] = "analysis_only"
    report["full_production_tau_certified"] = False
    (out / "summary.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report,indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("stage",choices=("curves", "results"))
    parser.add_argument("outdir",type=Path)
    args = parser.parse_args()
    repository = Path(__file__).resolve().parents[3]
    if args.stage == "curves":
        plot_curves(repository,args.outdir)
    else:
        summarize(args.outdir)
