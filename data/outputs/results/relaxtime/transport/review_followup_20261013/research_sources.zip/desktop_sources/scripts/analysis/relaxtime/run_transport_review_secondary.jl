#!/usr/bin/env julia
# Adaptive p96 paired checks, followed by mixed threshold diagnostics.
include(joinpath(@__DIR__,"run_transport_review_points.jl"))
include(joinpath(@__DIR__,"run_transport_review_threshold_matrix.jl"))
using CSV, SHA

function refine_pi_threshold(runroot)
    source=joinpath(ROOT,"data","outputs","results","relaxtime","transport","phase_guided",
        "mode_a_fixed_muB_phase_scaled",CASE,"phase_guided_transport_scan.csv")
    selected=[merge(NamedTuple(r),(review_mode="mode_a",)) for r in CSV.File(source;comment="#",strict=true) if
        Float64(r.muB_MeV)==0. && Float64(r.alpha_T)==1. && Float64(r.xi) in (-.25,-.24,-.23,-.22,-.21,-.20)]
    length(selected)==6 || error("expected six retained production points near the negative-xi pi threshold")
    rows=NamedTuple[]
    for row in selected
        state=state_from_row(row);qp,tp,kc=state.quark_params,state.thermo_params,state.K_coeffs
        m=qp.m.u
        for linear in (true,false)
            b=B0_pair_threshold_rs(m,m,qp.μ.u,tp.T,tp.Φ,tp.Φbar,tp.ξ;
                energy_nodes=256,angle_nodes=64,linear=linear)
            pol=-Main.Constants_PNJL.N_color/(8π^2)*(2qp.A.u-4m^2*b)
            push!(rows,merge(point_fields(row),(scheme=linear ? "linear" : "full_rs",
                threshold_MeV=2m*HC,threshold_den_re=1-4kc.K123_plus*pol)))
        end
    end
    outdir=joinpath(runroot,"pi_threshold_refinement")
    write_json(joinpath(outdir,"manifest.json"),run_metadata(@__FILE__,
        (points=6,source=source,source_sha256=bytes2hex(sha256(read(source))),
        scope="exact threshold on existing production xi grid; no background interpolation")))
    write_rows(joinpath(outdir,"pi_thresholds.csv"),rows)
    write_json(joinpath(outdir,"status.json"),(complete=true,rows=length(rows),failures=NamedTuple[]))
end

function run_secondary(runroot)
    source=joinpath(runroot,"ablation_resumed","summary_part1.csv")
    status=JSON.parsefile(joinpath(runroot,"ablation_resumed","status_part1.json"))
    status["complete"] && isempty(status["failures"]) && status["rows"]==48 ||
        error("adaptive check requires the completed 24-point paired p64 diagnostic")
    baseline=collect(CSV.File(source));points=[r for r in read_points() if r.p1]
    scores=Dict{String,Float64}();drifts=Dict{String,Float64}()
    ids=Set(point_id(r) for r in points if Float64(r.alpha_T)==1.0 && abs(Float64(r.xi))==.5)
    for row in points
        pid=point_id(row)
        same=only(r for r in baseline if r.point_id==pid && r.policy=="match_thermo")
        iso=only(r for r in baseline if r.point_id==pid && r.policy=="isotropic")
        drifts[pid]=maximum(abs(relative_change(getproperty(same,f),getproperty(row,f))) for f in (:tau_u,:tau_s,:tau_ubar,:tau_sbar))
        scores[pid]=maximum(abs(relative_change(getproperty(iso,f),getproperty(same,f))) for f in (:tau_u,:tau_s,:tau_ubar,:tau_sbar,:eta_over_s,:zeta_over_s,:sigma_over_T))
        drifts[pid]>.005 && push!(ids,pid)
    end
    for pid in sort!(collect(keys(scores)),by=p->scores[p],rev=true)[1:2]
        push!(ids,pid)
    end
    selected=[r for r in points if point_id(r) in ids]
    outdir=joinpath(runroot,"ablation_p96")
    isfile(joinpath(outdir,"manifest_part1.json")) && error("adaptive output already exists")
    write_json(joinpath(outdir,"manifest_part1.json"),run_metadata(@__FILE__,
        (points=length(selected),selected_ids=sort!(collect(ids)),source=source,
        source_sha256=bytes2hex(sha256(read(source))),
        selection="six alpha=1 endpoints plus all baseline tau drifts >0.5% plus two largest paired effects",
        baseline_drifts=drifts,paired_effect_scores=scores,
        config=tau_config(:p96),scope="outer-grid sensitivity at unchanged t/sigma grid")))
    rows=NamedTuple[];failures=NamedTuple[]
    for row in selected
        try
            append!(rows,run_point(row,"ablation_check",outdir))
        catch err
            detail=sprint(showerror,err,catch_backtrace())
            push!(failures,(point_id=point_id(row),error=detail))
            checkpoint(outdir,point_id(row)*"_failure",last(failures))
            println(stderr,detail);flush(stderr)
        end
        write_rows(joinpath(outdir,"summary_part1.csv"),rows)
        write_json(joinpath(outdir,"status_part1.json"),(complete=false,rows=length(rows),expected_points=length(selected),failures=failures))
    end
    write_json(joinpath(outdir,"status_part1.json"),(complete=true,rows=length(rows),expected_points=length(selected),failures=failures))
    run_threshold_matrix(joinpath(runroot,"mixed_thresholds"))
    refine_pi_threshold(runroot)
    isempty(failures) || error("adaptive ablation points failed")
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && run_secondary(only(ARGS))
