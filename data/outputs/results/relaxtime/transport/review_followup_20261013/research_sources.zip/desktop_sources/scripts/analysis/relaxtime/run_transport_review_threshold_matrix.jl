#!/usr/bin/env julia
# Mixed-sector threshold determinants with transport K. No root relabeling.
if !isdefined(Main,:TransportReviewCommon)
    include(joinpath(@__DIR__,"TransportReviewCommon.jl"))
end
include(joinpath(@__DIR__,"FullRSKZero.jl"))
using .TransportReviewCommon, .FullRSKZero

function threshold_polarization(channel,k0,flavor,state;energy_nodes=256)
    qp,tp=state.quark_params,state.thermo_params
    m=getproperty(qp.m,flavor);mu=getproperty(qp.μ,flavor);a=getproperty(qp.A,flavor)
    if k0==2m
        b=B0_pair_threshold_rs(m,m,mu,tp.T,tp.Φ,tp.Φbar,tp.ξ;
            energy_nodes=energy_nodes,angle_nodes=64,linear=true)
        pref=channel===:P ? -k0^2 : 4m^2-k0^2
        return complex(-Main.Constants_PNJL.N_color/(8π^2)*(2a+pref*b),0.)
    end
    complex(Main.RelaxTime.PolarizationAniso.polarization_with_width(
        channel,k0,0.,0.,m,m,mu,mu,tp.T,tp.Φ,tp.Φbar,tp.ξ,a,a,0)...)
end

function run_threshold_matrix(outdir)
    outdir=abspath(outdir)
    isfile(joinpath(outdir,"manifest.json")) && error("output already exists")
    selected=[r for r in read_points() if r.p7]
    write_json(joinpath(outdir,"manifest.json"),run_metadata(@__FILE__,
        (points=length(selected),couplings="retained transport isotropic A couplings",
        formula="det(M)/det(K), entire P or S mixed sector; no named mixed pole assigned",
        endpoint="analytic pair formula; other flavor uses production linear B0",
        caveat="a complex determinant needs both real and imaginary parts to vanish")))
    rows=NamedTuple[];failures=NamedTuple[]
    for row in selected
        try
            state=state_from_row(row);qp=state.quark_params;kc=state.K_coeffs
            for flavor in (:u,:s), channel in (:P,:S)
                k0=2getproperty(qp.m,flavor)
                function at(n)
                    pu=threshold_polarization(channel,k0,:u,state;energy_nodes=n)
                    ps=threshold_polarization(channel,k0,:s,state;energy_nodes=n)
                    mm=Main.RelaxTime.EffectiveCouplings.mixing_matrix_elements(pu,ps,kc,channel)
                    kk=Main.RelaxTime.EffectiveCouplings.mixing_matrix_elements(0.0+0.0im,0.0+0.0im,kc,channel)
                    (mm.M00*mm.M88-mm.M08^2)/(kk.M00*kk.M88-kk.M08^2)
                end
                low=at(128);high=at(256)
                all(isfinite,(real(high),imag(high))) || error("nonfinite mixed threshold determinant")
                push!(rows,merge(point_fields(row),(threshold_flavor=String(flavor),sector=String(channel),
                    threshold_MeV=k0*HC,det_normalized_re=real(high),det_normalized_im=imag(high),
                    det_normalized_abs=abs(high),endpoint_quadrature_change=abs(high-low))))
            end
        catch err
            detail=sprint(showerror,err,catch_backtrace())
            push!(failures,(point_id=point_id(row),error=detail))
            println(stderr,detail);flush(stderr)
        end
        write_rows(joinpath(outdir,"mixed_thresholds.csv"),rows)
    end
    write_json(joinpath(outdir,"status.json"),(complete=true,rows=length(rows),expected_rows=4length(selected),failures=failures))
    isempty(failures) || error("mixed threshold evaluation failed")
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && run_threshold_matrix(only(ARGS))
