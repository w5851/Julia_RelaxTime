"""Summarize completed analysis batches without replacing production inputs."""
from __future__ import annotations

import argparse
from collections import defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
INPUT = ROOT / "data/outputs/results/relaxtime/transport/review_followup_20261013"
OBS = ("tau_u", "tau_s", "tau_ubar", "tau_sbar", "eta_over_s", "zeta_over_s", "sigma_over_T")


def read(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(line for line in stream if not line.startswith("#")))


def write(path, rows):
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def num(row, key):
    value = float(row[key])
    if not math.isfinite(value):
        raise ValueError(f"nonfinite {key}: {row}")
    return value


def rel(a, b):
    return (a - b) / max(abs(b), 1e-300)


def pid(row):
    return f"{row['review_mode']}_{row['plot_panel']}_{row['plot_series']}_xi{float(row['xi'])}".replace(".", "p").replace("-", "m")


def context(row):
    return {key: row[key] for key in ("point_id", "mode", "plot_panel", "plot_series", "T_MeV", "muB_MeV", "xi")}


def checked_batch(directory, pattern, expected=None):
    statuses = sorted(directory.glob("status*.json"))
    if not statuses:
        raise ValueError(f"no status in {directory}")
    for path in statuses:
        state = json.loads(path.read_text())
        if not state["complete"] or state.get("failures") or state.get("failed_roots"):
            raise ValueError(f"batch not successful: {path}: {state}")
    rows = [r for p in sorted(directory.glob(pattern)) for r in read(p)]
    if expected is not None and len(rows) != expected:
        raise ValueError(f"row count {directory}: {len(rows)} != {expected}")
    return rows


def pair_ablation(rows):
    byid = defaultdict(dict)
    for row in rows:
        key = row["point_id"]
        if row["policy"] in byid[key]:
            raise ValueError(f"duplicate paired policy: {key}")
        byid[key][row["policy"]] = row
    output = []
    for key, policies in sorted(byid.items()):
        a, b = policies["match_thermo"], policies["isotropic"]
        result = dict(context(a), resolution=a["resolution"])
        for field in OBS:
            result[f"match_{field}"] = num(a, field)
            result[f"isotropic_{field}"] = num(b, field)
            result[f"effect_{field}"] = rel(num(b, field), num(a, field))
        for field in ("tau_u_rel_to_production", "tau_s_rel_to_production",
                      "replay_eta_rel_to_production", "replay_zeta_rel_to_production", "replay_sigma_rel_to_production"):
            result[f"baseline_{field}"] = num(a, field)
        output.append(result)
    return output


def ablation_summary(run, tables):
    low = pair_ablation(checked_batch(run / "ablation_resumed", "summary_part*.csv", 48))
    high = pair_ablation(checked_batch(run / "ablation_p96", "summary_part*.csv", 18))
    write(tables / "ablation_p64_pairs.csv", low)
    write(tables / "ablation_p96_pairs.csv", high)
    lowmap = {r["point_id"]: r for r in low}
    check = []
    for row in high:
        old = lowmap[row["point_id"]]
        result = context(row)
        for field in OBS:
            result[f"p64_effect_{field}"] = old[f"effect_{field}"]
            result[f"p96_effect_{field}"] = row[f"effect_{field}"]
            result[f"effect_change_pp_{field}"] = 100 * (row[f"effect_{field}"] - old[f"effect_{field}"])
        check.append(result)
    write(tables / "ablation_resolution_comparison.csv", check)
    anchors = checked_batch(run / "ablation_p128_anchor", "anchor.csv", 1)
    preferred = {r["point_id"]: dict(r) for r in low}
    preferred.update({r["point_id"]: dict(r) for r in high})
    for anchor in anchors:
        row = preferred[anchor["point_id"]]
        row["resolution"] = "p128"
        for field in OBS:
            row[f"match_{field}"] = num(anchor, f"p128_match_{field}")
            row[f"isotropic_{field}"] = num(anchor, f"p128_isotropic_{field}")
            row[f"effect_{field}"] = num(anchor, f"p128_effect_{field}")
        for key in tuple(row):
            if key.startswith("baseline_"):
                row[key] = num(anchor, key)
    write(tables / "ablation_preferred_pairs.csv", list(preferred.values()))
    return {"p64_points": len(low), "p96_points": len(high),
            "p128_anchors": anchors,
            "preferred_resolution_counts": {level: sum(r["resolution"] == level for r in preferred.values()) for level in ("p64", "p96", "p128")},
            "preferred_max_absolute_effect": {f: max(preferred.values(), key=lambda r: abs(r[f"effect_{f}"])) for f in OBS},
            "p64_max_absolute_effect": {f: max(low, key=lambda r: abs(r[f"effect_{f}"])) for f in OBS},
            "max_effect_change_percentage_points": {f: max(abs(r[f"effect_change_pp_{f}"]) for r in check) for f in OBS},
            "p128_effect_change_percentage_points": {f: max(abs(num(r, f"effect_change_pp_{f}")) for r in anchors) for f in OBS},
            "scope": "entire cross-section context; paired isotropic/match at same resolution; not an O(xi^2) bound"}


def channel_summary(run, tables, points):
    data = checked_batch(run / "channel_refinement_fixed_cutoff", "channels_part*.csv", 174)
    plan = read(INPUT / "channel_plan.csv")
    rates = {}
    for row in data:
        key = (row["point_id"], row["channel"], row["resolution"])
        if key in rates:
            raise ValueError(f"duplicate channel result {key}")
        rates[key] = row
    bypoint = defaultdict(list)
    details = []
    for job in plan:
        key = job["point_id"], job["channel"]
        a, b = rates[(*key, "sigma48")], rates[(*key, "sigma96")]
        source = float(job["source_rate"])
        assert num(a, "source_rate") == source == num(b, "source_rate")
        details.append(dict(context(a), channel=key[1], role=job["role"],
                            source_rate=source, sigma48_rate=num(a, "rate"), sigma96_rate=num(b, "rate"),
                            high_low_relative_change=rel(num(b, "rate"), num(a, "rate")),
                            high_source_relative_change=rel(num(b, "rate"), source)))
        bypoint[key[0]].append((job, a, b))
    write(tables / "channel_resolution_comparison.csv", details)
    partial = []
    for key, jobs in sorted(bypoint.items()):
        job, a, b = jobs[0]
        species = job["primary_species"]
        total = float(job["source_total"])
        original_tau = float(points[key][f"tau_{species}"])
        assert abs(rel(1 / total, original_tau)) < 1e-10
        omega48 = total
        omega96 = total
        difference_bound = 0.0
        source_selected = 0.0
        for job, a, b in jobs:
            assert float(job["source_total"]) == total
            weight = float(job["source_contribution"]) / float(job["source_rate"])
            omega48 += weight * (num(a, "rate") - float(job["source_rate"]))
            omega96 += weight * (num(b, "rate") - float(job["source_rate"]))
            difference_bound += weight * abs(num(b, "rate") - num(a, "rate"))
            source_selected += float(job["source_contribution"])
        assert omega48 > 0 and omega96 > 0
        partial.append(dict(context(a), role=job["role"], primary_species=species,
                            selected_channels=len(jobs), source_coverage=source_selected / total,
                            source_tau=original_tau, partial_tau_sigma48=1 / omega48,
                            partial_tau_sigma96=1 / omega96,
                            tau_high_low_relative_change=rel(1 / omega96, 1 / omega48),
                            tau_high_source_relative_change=rel(1 / omega96, original_tau),
                            weighted_selected_rate_change=difference_bound / omega96,
                            max_channel_high_low_change=max(abs(rel(num(b, "rate"), num(a, "rate"))) for _, a, b in jobs),
                            window_ids=job["window_ids"]))
    write(tables / "partial_channel_tau.csv", partial)
    replacements = read(INPUT / "display_replacements.csv")
    windows = []
    for win in read(INPUT / "channel_windows.csv"):
        local = [r for r in partial if r["window_ids"] == win["window_ids"]]
        assert len(local) == 3
        role = {r["role"]: r for r in local}
        target, left, right = role["target"], role["left"], role["right"]
        t = (float(target["xi"]) - float(left["xi"])) / (float(right["xi"]) - float(left["xi"]))
        def spike(field):
            return rel(target[field], left[field] * (1 - t) + right[field] * t)
        display = [r for r in replacements if r["mode_key"] == target["mode"] and r["plot_panel"] == target["plot_panel"]
                   and r["plot_series"] == target["plot_series"] and abs(float(r["xi"]) - float(target["xi"])) < 1e-9
                   and r["observable"] == f"tau_{target['primary_species']}"]
        max_change = max(r["max_channel_high_low_change"] for r in local)
        windows.append(dict(context(target), primary_species=target["primary_species"], channels=win["channels"],
                            source_coverage=target["source_coverage"],
                            max_channel_change_in_window=max_change,
                            max_weighted_change_in_window=max(r["weighted_selected_rate_change"] for r in local),
                            target_partial_tau_change=target["tau_high_low_relative_change"],
                            source_local_tau_residual=spike("source_tau"),
                            high_local_partial_tau_residual=spike("partial_tau_sigma96"),
                            target_partial_tau_sigma96=target["partial_tau_sigma96"],
                            display_primary_tau=float(display[0]["derived_display_value"]) if display else "",
                            verdict="selected_channels_stable_at_1pct_between_two_levels" if max_change < .01 else "selected_channels_not_stable_at_1pct",
                            full_tau_or_display_certified=False, window_ids=win["window_ids"]))
    write(tables / "channel_window_summary.csv", windows)
    return {"rows": len(data), "selected_channel_points": len(details), "background_points": len(partial),
            "windows": windows, "diagnostic_threshold": .01, "unselected_channels": "unchanged production values"}


def meson_summary(run, tables, points):
    data = checked_batch(run / "meson_v2", "meson_poles.csv", 908)
    old = {(r["point_id"], r["meson"], r["scheme"]): r for r in read(run / "meson/meson_poles.csv")}
    groups = defaultdict(list)
    for row in data:
        assert row["converged"] == "true"
        for field in ("mass_MeV", "gamma_MeV", "gap_MeV", "threshold_den_re", "threshold_den_im", "threshold_endpoint_change"):
            num(row, field)
        groups[(row["mode"], row["plot_panel"], row["plot_series"], row["meson"], row["scheme"])].append(row)
    brackets = []
    for key, local in sorted(groups.items()):
        local.sort(key=lambda r: float(r["xi"]))
        for a, b in zip(local, local[1:]):
            if num(a, "threshold_den_re") * num(b, "threshold_den_re") > 0:
                continue
            branch_switch = key[:3] == ("mode_a", "muB900.0", "alpha1.0") and num(a, "xi") < 0 < num(b, "xi")
            brackets.append(dict(mode=key[0], plot_panel=key[1], plot_series=key[2], meson=key[3], scheme=key[4],
                                 xi_left=num(a, "xi"), xi_right=num(b, "xi"),
                                 denominator_left=num(a, "threshold_den_re"), denominator_right=num(b, "threshold_den_re"),
                                 gap_left_MeV=num(a, "gap_MeV"), gap_right_MeV=num(b, "gap_MeV"),
                                 branch_switch=branch_switch,
                                 interpretation="phase_branch_jump_not_continuous_mott_bracket" if branch_switch else "pair_threshold_sign_bracket_on_retained_grid"))
    write(tables / "simple_mott_brackets.csv", brackets)
    linear = {(r["point_id"], r["meson"]): r for r in data if r["scheme"] == "linear"}
    full = []
    for r in data:
        if r["scheme"] != "full_rs":
            continue
        other = linear[r["point_id"], r["meson"]]
        width = num(other, "gamma_MeV")
        full.append(dict(r, gamma_linear_MeV=width, gamma_change_MeV=num(r, "gamma_MeV") - width,
                         gamma_relative_if_linear_over_1_MeV=rel(num(r, "gamma_MeV"), width) if width > 1 else ""))
    write(tables / "full_rs_pi_comparison.csv", full)
    max_mass_difference = max(abs(num(r, "mass_MeV") - num(old[(r["point_id"], r["meson"], r["scheme"])], "mass_MeV")) for r in data)
    return {"points": len({r['point_id'] for r in data}), "rows": len(data), "full_rs_pi_points": len(full),
            "nonfinite_thresholds": 0, "max_mass_change_from_threshold_fix_MeV": max_mass_difference,
            "max_full_rs_mass_relative_change": max(full, key=lambda r: abs(num(r, "mass_rel_to_linear"))),
            "max_full_rs_width_absolute_change_MeV": max(abs(r["gamma_change_MeV"]) for r in full),
            "max_full_rs_width_relative_change_for_linear_width_over_1_MeV": max(abs(r["gamma_relative_if_linear_over_1_MeV"]) for r in full if r["gamma_relative_if_linear_over_1_MeV"] != ""),
            "negative_width_beyond_1e_minus_6_MeV": sum(num(r, "gamma_MeV") < -1e-6 for r in data),
            "max_refined_full_rs_residual": max(num(r, "refined_residual") for r in full),
            "max_endpoint_node_change": max(num(r, "threshold_endpoint_change") for r in data),
            "brackets": brackets, "width_convention": "retained real-axis B0 with width prefactor"}


def refined_pi_summary(run, tables):
    data = checked_batch(run / "pi_threshold_refinement", "pi_thresholds.csv", 12)
    output = []
    for scheme in ("linear", "full_rs"):
        local = sorted([r for r in data if r["scheme"] == scheme], key=lambda r: num(r, "xi"))
        for a, b in zip(local, local[1:]):
            if num(a, "threshold_den_re") * num(b, "threshold_den_re") <= 0:
                output.append(dict(mode="mode_a", plot_panel="muB0.0", plot_series="alpha1.0", scheme=scheme,
                                   xi_left=num(a, "xi"), xi_right=num(b, "xi"),
                                   denominator_left=num(a, "threshold_den_re"), denominator_right=num(b, "threshold_den_re")))
    write(tables / "refined_pi_mott_brackets.csv", output)
    return {"rows": len(data), "brackets": output}


def mixed_summary(run, tables):
    data = checked_batch(run / "mixed_thresholds", "mixed_thresholds.csv", 860)
    groups = defaultdict(list)
    for row in data:
        for field in ("threshold_MeV", "det_normalized_re", "det_normalized_im",
                      "det_normalized_abs", "endpoint_quadrature_change"):
            num(row, field)
        groups[(row["mode"], row["plot_panel"], row["plot_series"], row["threshold_flavor"], row["sector"])].append(row)
    brackets = []
    for key, local in sorted(groups.items()):
        local.sort(key=lambda r: float(r["xi"]))
        for a, b in zip(local, local[1:]):
            if num(a, "det_normalized_re") * num(b, "det_normalized_re") > 0:
                continue
            complex_det = max(abs(num(a, "det_normalized_im")), abs(num(b, "det_normalized_im"))) > 1e-10
            branch = key[:3] == ("mode_a", "muB900.0", "alpha1.0") and num(a, "xi") < 0 < num(b, "xi")
            brackets.append(dict(mode=key[0], plot_panel=key[1], plot_series=key[2], threshold_flavor=key[3], sector=key[4],
                                 xi_left=num(a, "xi"), xi_right=num(b, "xi"), det_left=num(a, "det_normalized_re"),
                                 det_right=num(b, "det_normalized_re"),
                                 det_im_left=num(a, "det_normalized_im"), det_im_right=num(b, "det_normalized_im"),
                                 complex_determinant=complex_det, branch_switch=branch,
                                 interpretation="not_a_mott_bracket" if complex_det or branch else "mixed_sector_threshold_candidate_no_named_pole_assigned"))
    write(tables / "mixed_threshold_brackets.csv", brackets)
    return {"rows": len(data), "brackets": brackets,
            "max_endpoint_quadrature_change": max(num(r, "endpoint_quadrature_change") for r in data),
            "named_mixed_poles": "not assigned; identity governance unchanged"}


def mechanism_summary(run, tables, channels, meson, mixed):
    routing_source = json.loads((run / "channel_exchange_map.json").read_text(encoding="utf-8"))
    assert routing_source["source_sha256"] == sha(ROOT / routing_source["source"])
    assert routing_source["plan_sha256"] == sha(INPUT / "channel_plan.csv")
    routing = routing_source["routing"]
    exchange_rows = []
    for channel, info in sorted(routing.items()):
        for leg, config in sorted(info["legs"].items()):
            exchange_rows.append(dict(channel=channel, scattering_type=info["type"], leg=leg,
                                      simple_mesons="|".join(config["simple"]),
                                      mixed_P=config["mixed_P"], mixed_S=config["mixed_S"],
                                      threshold_scope="k_zero_s_channel" if leg == "s" else "finite_k_not_certified"))
    write(tables / "channel_exchange_map.csv", exchange_rows)
    partial = read(tables / "partial_channel_tau.csv")
    output = []
    for window in channels["windows"]:
        local = [r for r in partial if r["window_ids"] == window["window_ids"]]
        assert len(local) == 3
        xmin, xmax = min(num(r, "xi") for r in local), max(num(r, "xi") for r in local)
        selected = window["channels"].split("|")
        simple_s, mixed_s = set(), set()
        for channel in selected:
            config = routing[channel]["legs"].get("s", {})
            simple_s.update(config.get("simple", []))
            mixed_s.update(sector for sector in ("P", "S") if config.get(f"mixed_{sector}", False))

        def inside_local(bracket):
            return (all(bracket[k] == window[k] for k in ("mode", "plot_panel", "plot_series"))
                    and bracket["xi_left"] >= xmin - 1e-10 and bracket["xi_right"] <= xmax + 1e-10)

        # A coarse bracket that merely overlaps this window does not localize a crossing here.
        simple_local = [dict(r, present_in_selected_s_channel=r["meson"] in simple_s)
                        for r in meson["brackets"] if r["scheme"] == "linear" and inside_local(r)]
        mixed_local = [dict(r, present_in_selected_s_channel=r["sector"] in mixed_s)
                       for r in mixed["brackets"] if inside_local(r)]
        evidence = []
        if any(r["present_in_selected_s_channel"] and not r["branch_switch"] for r in simple_local):
            evidence.append("simple_pair_threshold_bracket")
        if any(r["present_in_selected_s_channel"] and not r["branch_switch"] and not r["complex_determinant"] for r in mixed_local):
            evidence.append("real_mixed_sector_threshold_candidate")
        if any(r["present_in_selected_s_channel"] and r["complex_determinant"] for r in mixed_local):
            evidence.append("mixed_real_part_sign_only_nonzero_imaginary_part")
        output.append(dict(context(window), xi_window_left=xmin, xi_window_right=xmax,
                           primary_species=window["primary_species"], channels=window["channels"],
                           source_coverage=window["source_coverage"],
                           max_channel_change_in_window=window["max_channel_change_in_window"],
                           high_local_partial_tau_residual=window["high_local_partial_tau_residual"],
                           s_channel_simple_mesons="|".join(sorted(simple_s)),
                           s_channel_mixed_sectors="|".join(sorted(mixed_s)),
                           local_simple_brackets=json.dumps(simple_local, sort_keys=True),
                           local_mixed_brackets=json.dumps(mixed_local, sort_keys=True),
                           evidence="|".join(evidence) if evidence else "no_local_threshold_localized",
                           causal_attribution=False, full_tau_certified=False))
    write(tables / "channel_threshold_evidence.csv", output)
    return {"windows": len(output), "exchange_rows": len(exchange_rows),
            "table": "tables/channel_threshold_evidence.csv", "exchange_table": "tables/channel_exchange_map.csv",
            "scope": "same-background local threshold association; no named mixed root, finite-k or causal certification"}


def thermo_summary(run, tables):
    data = checked_batch(run / "thermo", "thermo_sensitivity.csv", 96)
    groups = defaultdict(dict)
    for row in data:
        groups[row["point_id"]][int(row["p_num"])] = row
    comparisons = []
    for key, local in sorted(groups.items()):
        for n in (12, 24, 48):
            a, b = local[n], local[96]
            comparisons.append(dict(context(a), p_num=n, **{f"relative_{f}": rel(num(a, f), num(b, f)) for f in ("m_u_MeV", "entropy", "eta_over_s", "zeta_over_s", "sigma_over_T")}))
    write(tables / "thermo_reference_comparison.csv", comparisons)
    return {str(n): {f: max(abs(r[f"relative_{f}"]) for r in comparisons if r["p_num"] == n)
                     for f in ("m_u_MeV", "entropy", "eta_over_s", "zeta_over_s", "sigma_over_T")} for n in (12, 24, 48)}


def tail_summary(run, tables):
    data = checked_batch(run / "transport_tail", "transport_tail.csv", 288)
    groups = defaultdict(dict)
    for row in data:
        groups[row["point_id"]][row["configuration"]] = row
    output = []
    for key, local in sorted(groups.items()):
        reference = local["infinite512"]
        row = context(reference)
        for field in ("eta_over_s", "zeta_over_s", "sigma_over_T"):
            row[f"infinite_{field}"] = num(reference, field)
            row[f"increase_from_production_{field}"] = rel(num(reference, field), num(local["production"], field))
            row[f"increase_from_p20_{field}"] = rel(num(reference, field), num(local["p20"], field))
            row[f"max_reference_disagreement_{field}"] = max(abs(rel(num(local[c], field), num(reference, field))) for c in ("p60", "infinite256", "infinite_scale5"))
        output.append(row)
    write(tables / "transport_tail_comparison.csv", output)
    return {"points": len(output), "configurations_per_point": 9,
            "max_increase_from_production": {f: max(output, key=lambda r: r[f"increase_from_production_{f}"]) for f in ("eta_over_s", "zeta_over_s", "sigma_over_T")},
            "max_reference_disagreement": {f: max(r[f"max_reference_disagreement_{f}"] for r in output) for f in ("eta_over_s", "zeta_over_s", "sigma_over_T")},
            "max_remaining_tail_at_p20": {f: max(r[f"increase_from_p20_{f}"] for r in output) for f in ("eta_over_s", "zeta_over_s", "sigma_over_T")},
            "production_replay_error": {f: max(abs(num(r, f)) for r in data if r["configuration"] == "production") for f in ("eta_rel_to_retained", "zeta_rel_to_retained", "sigma_rel_to_retained")}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    args = parser.parse_args()
    run = args.run.resolve()
    tables = run / "tables"
    points = {pid(r): r for r in read(INPUT / "review_points.csv")}
    report = {"status": "analysis_only", "created_utc": datetime.now(timezone.utc).isoformat(),
              "ablation": ablation_summary(run, tables), "channels": channel_summary(run, tables, points),
              "meson": meson_summary(run, tables, points), "mixed_thresholds": mixed_summary(run, tables),
              "pi_threshold_refinement": refined_pi_summary(run, tables),
              "thermo": thermo_summary(run, tables), "transport_tail": tail_summary(run, tables),
              "convergence_archive": json.loads((run / "provenance/current_convergence_audit.json").read_text())["convergence"],
              "formal_data_modified": False, "manuscript_eligible": False}
    report["mechanism"] = mechanism_summary(run, tables, report["channels"], report["meson"], report["mixed_thresholds"])
    replay = checked_batch(run / "channel_production_replay", "replay.csv", 4)
    report["production_channel_replay"] = {"points": len(replay), "max_relative_error": max(abs(num(r, "relative_error")) for r in replay)}
    report["excluded_batches"] = json.loads((run / "channel_cutoff_correction.json").read_text())
    report["sources"] = [{"path": str(p.relative_to(ROOT)), "sha256": sha(p)} for p in sorted(run.glob("*/*.csv")) if p.parent.name != "tables"]
    report["script_sha256"] = sha(__file__)
    (run / "review_summary.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"ablation_points": report["ablation"]["p64_points"], "channel_rows": report["channels"]["rows"],
                      "meson_rows": report["meson"]["rows"], "tail_points": report["transport_tail"]["points"]}))


if __name__ == "__main__":
    main()
