"""Bounded, isolated comparison of retained Fortran eta/s with four targets."""
from pathlib import Path
import argparse
import concurrent.futures
import csv
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import time


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")


def read_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def prepare(repo, source, out, compiler):
    out.mkdir(parents=True, exist_ok=False)
    snapshot = out / "source_snapshot"
    files = []
    for path in sorted((source / "codes").rglob("*")):
        if path.suffix.lower() != ".f90":
            continue
        relative = path.relative_to(source)
        target = snapshot / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        files.append(dict(path=relative.as_posix(), sha256=digest(target)))
    for name in ("legacy_eta_reference_probe.f90", "run_fortran_reference_probe.py"):
        shutil.copy2(repo / "scripts/analysis/relaxtime" / name, out / name)
    target_source = repo / "tests/validation/data/targets/relaxtime/literature/eta_over_s/relaxtime_eta_over_s_literature_targets_v1.csv"
    shutil.copy2(target_source, out / "targets.csv")
    for name, args in (("source_git_status.txt", ["status", "--short", "--branch"]),
                       ("source_worktree.diff", ["diff", "--", "codes"])):
        result = subprocess.run(["git", "-C", str(source), *args], capture_output=True, check=True)
        (out / name).write_bytes(result.stdout)
    head = subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip()
    version = subprocess.check_output([str(compiler), "--version"], text=True)
    save_json(out / "input_manifest.json", dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        source=str(source), source_head=head, actual_source="retained working tree snapshot with computed tau enabled",
        compiler=str(compiler), compiler_sha256=digest(compiler), compiler_version=version,
        targets_source=str(target_source), targets_sha256=digest(target_source), source_files=files,
        parameters=dict(transport_p_max_inv_fm=15, thermo_and_transport_nodes=128,
                        tau_momentum_nodes=64, tau_angle_nodes=64, sigma_grid_nodes=128, sigma_t_nodes=64,
                        equilibrium_temperature_continuation_step_MeV=1, omp_threads=1),
        status="analysis_only", production_modified=False))


def build(out, compiler):
    root = out / "source_snapshot"
    folder = out / "build"
    folder.mkdir(exist_ok=False)
    pending = []
    for path in sorted((root / "codes").rglob("*")):
        if path.suffix.lower() != ".f90" or path.name in ("solve_point.f90", "scan_config.f90"):
            continue
        source = path.read_bytes().decode("latin1")
        if re.search(r"^\s*program\s+", source, re.M | re.I):
            continue
        modules = set(m.lower() for m in re.findall(r"^\s*module\s+(?!procedure\b)(\w+)", source, re.M | re.I))
        uses = set(m.lower() for m in re.findall(r"^\s*use\s+(\w+)", source, re.M | re.I))
        pending.append((path, modules, uses))
    available = {"omp_lib"}
    ordered = []
    while pending:
        ready = [item for item in pending if item[2] <= available | item[1]]
        if not ready:
            raise RuntimeError(f"unresolved module dependencies: {pending}")
        for item in ready:
            pending.remove(item)
            ordered.append(item[0])
            available.update(item[1])
    ordered.append(out / "legacy_eta_reference_probe.f90")
    flags = ["-O2", "-fopenmp", "-ffree-line-length-none", "-std=legacy"]
    commands, objects = [], []
    with (out / "build.log").open("wb") as log:
        for index, source in enumerate(ordered):
            obj = folder / f"source_{index:02d}.o"
            command = [str(compiler), *flags, "-I", str(folder), "-J", str(folder), "-c", str(source), "-o", str(obj)]
            commands.append(command)
            result = subprocess.run(command, cwd=folder, stdout=log, stderr=log)
            if result.returncode:
                save_json(out / "build_commands.json", commands)
                raise RuntimeError(f"compile failed for {source}; see build.log")
            objects.append(obj)
        command = [str(compiler), *flags, *map(str, objects), "-o", str(folder / "eta_probe.exe")]
        commands.append(command)
        subprocess.run(command, cwd=folder, stdout=log, stderr=log, check=True)
    save_json(out / "build_commands.json", commands)
    print("BUILT", len(ordered), "translation units", flush=True)


def run(out):
    targets = read_rows(out / "targets.csv")
    jobs = [dict(id=r["target_id"], T=float(r["T_MeV"]), muB=float(r["muB_MeV"]), mode="eta", family="target") for r in targets]
    jobs.extend(dict(id=r["target_id"] + "_legacy_mu2", T=float(r["T_MeV"]), muB=2., mode="eta", family="legacy_mu_floor")
                for r in targets if float(r["muB_MeV"]) == 0)
    jobs.append(dict(id="legacy_formula_control_T50_muB5", T=50., muB=5., mode="legacy_control", family="formula_control"))
    environment = dict(os.environ, OMP_NUM_THREADS="1", GFORTRAN_UNBUFFERED_ALL="y")
    compiler_dir = str(Path(json.loads((out / "input_manifest.json").read_text(encoding="utf-8"))["compiler"]).parent)
    environment["PATH"] = compiler_dir + os.pathsep + environment.get("PATH", "")

    def execute(job):
        folder = out / "points" / job["id"]
        (folder / "results").mkdir(parents=True, exist_ok=False)
        command = [str(out / "build/eta_probe.exe"), repr(job["T"]), repr(job["muB"]), job["mode"]]
        start = time.monotonic()
        print("START", job["id"], flush=True)
        with (folder / "stdout.log").open("wb") as stdout, (folder / "stderr.log").open("wb") as stderr:
            try:
                result = subprocess.run(command, cwd=folder, env=environment, stdin=subprocess.DEVNULL,
                                        stdout=stdout, stderr=stderr, timeout=1200)
                status = dict(job, command=command, exitcode=result.returncode, elapsed_seconds=time.monotonic()-start)
            except subprocess.TimeoutExpired:
                status = dict(job, command=command, exitcode=None, timeout=True, elapsed_seconds=time.monotonic()-start)
        save_json(folder / "status.json", status)
        print("DONE", job["id"], status["exitcode"], flush=True)
        return status

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        statuses = list(executor.map(execute, jobs))
    save_json(out / "run_status.json", dict(complete=all(r["exitcode"] == 0 for r in statuses), jobs=statuses))
    if not all(r["exitcode"] == 0 for r in statuses):
        raise RuntimeError("some points failed; see point status and logs")


def summarize(out):
    status = json.loads((out / "run_status.json").read_text(encoding="utf-8"))
    assert status["complete"]
    rows = []
    for target in read_rows(out / "targets.csv"):
        actual = read_rows(out / "points" / target["target_id"] / "point.csv")[0]
        expected = float(target["expected_eta_over_s"])
        error = (float(actual["eta_over_s"])-expected)/expected
        rows.append(dict(target_id=target["target_id"], T_MeV=float(target["T_MeV"]), muB_MeV=float(target["muB_MeV"]),
                         expected_eta_over_s=expected, fortran_eta_over_s=float(actual["eta_over_s"]),
                         relative_error=error, passes_5pct=abs(error) <= .05))
    with (out / "comparison.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    control_folder = out / "points/legacy_formula_control_T50_muB5"
    direct = float(read_rows(control_folder / "point.csv")[0]["eta_over_s"])
    legacy = float((control_folder / "results/eta and sigma.dat").read_text().split()[5])
    control_error = abs(direct-legacy)/abs(legacy)
    assert control_error < 1e-9, control_error
    floor_checks = []
    for row in rows:
        if row["muB_MeV"] != 0:
            continue
        other = float(read_rows(out / "points" / (row["target_id"] + "_legacy_mu2") / "point.csv")[0]["eta_over_s"])
        floor_checks.append(dict(target_id=row["target_id"], eta_muB2=other,
                                 relative_to_muB0=(other-row["fortran_eta_over_s"])/row["fortran_eta_over_s"]))
    report = dict(comparison=rows, passed_5pct=sum(row["passes_5pct"] for row in rows),
                  legacy_formula_control_relative_error=control_error, legacy_mu_floor_checks=floor_checks,
                  status="analysis_only", production_modified=False)
    save_json(out / "summary.json", report)
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("prepare", "build", "run", "summarize"))
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--source", type=Path, default=Path(r"D:\Desktop\Relaxtime_fortran"))
    parser.add_argument("--compiler", type=Path, default=Path(r"D:\mingw64\bin\gfortran.exe"))
    args = parser.parse_args()
    repository = Path(__file__).resolve().parents[3]
    output = args.outdir.resolve()
    if args.stage == "prepare":
        prepare(repository, args.source.resolve(), output, args.compiler.resolve())
    elif args.stage == "build":
        build(output, args.compiler.resolve())
    elif args.stage == "run":
        run(output)
    else:
        summarize(output)
