using Test, JSON, SHA
include(joinpath(@__DIR__,"..","..","..","scripts","analysis","relaxtime","TransportReviewCheckpoints.jl"))
using .TransportReviewCheckpoints

@testset "Review checkpoint identity and numerical contract" begin
    mktempdir() do dir
        mkpath(joinpath(dir,"points"))
        common=joinpath(dir,"common.jl");write(common,"implementation")
        input=joinpath(dir,"input.csv");write(input,"retained input")
        meta=Dict("common_sha256"=>bytes2hex(sha256(read(common))),"input_sha256"=>bytes2hex(sha256(read(input))))
        open(io->JSON.print(io,meta),joinpath(dir,"manifest_part1.json"),"w")
        @test validate_resume(dir,common,input)===nothing
        record=Dict("summary"=>Dict("point_id"=>"p1","rate"=>2.0),"config"=>Dict("n"=>64,"policy"=>"linear"))
        path=joinpath(dir,"points","p1.json")
        open(io->JSON.print(io,record),path,"w")
        saved=read(path)
        result=restored_checkpoint(dir,"p1",(point_id="p1",),(n=64,policy=:linear))
        @test result["summary"]["rate"]==2.0
        @test result["reused_sha256"]==bytes2hex(sha256(saved))
        @test read(path)==saved
        @test restored_checkpoint(dir,"missing",(point_id="missing",),(n=64,))===nothing
        @test_throws ErrorException restored_checkpoint(dir,"p1",(point_id="other",),(n=64,))
        @test_throws ErrorException restored_checkpoint(dir,"p1",(point_id="p1",),(n=128,))
        @test_throws ErrorException restored_checkpoint(dir,"p1",(point_id="p1",),(n=64,sigma_cutoff=3.0))
        record["summary"]["rate"]=nothing
        open(io->JSON.print(io,record),path,"w")
        @test_throws ErrorException restored_checkpoint(dir,"p1",(point_id="p1",),(n=64,))
        write(input,"different input")
        @test_throws ErrorException validate_resume(dir,common,input)
        @test canonical_summary((b=2,a=1))===canonical_summary(Dict("a"=>1,"b"=>2))
    end
end
