#!/usr/bin/env julia
# One higher-order anchor for an observed p64 -> p96 ablation drift.
include(joinpath(@__DIR__,"TransportReviewCommon.jl"))
using .TransportReviewCommon, JSON

function main()
    runroot=abspath(only(ARGS));outdir=joinpath(runroot,"ablation_p128_anchor")
    isfile(joinpath(outdir,"manifest.json")) && error("anchor output exists")
    pid="mode_a_muB0p0_alpha1p0_xim0p5"
    row=only(r for r in read_points() if point_id(r)==pid)
    tau0=production_tau(row)
    replay=JSON.parsefile(joinpath(runroot,"smoke_r2","points",pid*"_p128_match_thermo.json"))
    all(abs(relative_change(replay["tau"][String(s)],getproperty(tau0,s)))<1e-12 for s in SPECIES) ||
        error("this anchor requires an already verified p128 production tau replay")
    low=JSON.parsefile(joinpath(runroot,"ablation_p96","points",pid*"_p96_match_thermo.json"))["summary"]
    iso=JSON.parsefile(joinpath(runroot,"ablation_p96","points",pid*"_p96_isotropic.json"))["summary"]
    write_json(joinpath(outdir,"manifest.json"),run_metadata(@__FILE__,
        (point_id=pid,config=tau_config(:p128),policy="isotropic",
        baseline="retained p128 tau; independently matched by smoke_r2; recomputed same transport kernel",
        selection="observed p64 to p96 paired tau effect drift of about 1.6 percentage points")))
    state=state_from_row(row);bulk=bulk_for_base(row,base_from_row(row))
    av=Main.RelaxTime.AFieldBuilder.build_A_triplet(state.quark_params,
        merge(state.thermo_params,(ξ=0.0,));p_nodes=16,p_max=20.0,cos_nodes=4,use_aniso=true)
    println("START ",pid," p128 isotropic");flush(stdout)
    timed=@timed Main.RelaxTime.RelaxationTime.relaxation_times(
        state.quark_params,state.thermo_params,state.K_coeffs;
        densities=densities_from_row(row),tau_config(:p128)...,
        propagator_xi_policy=:isotropic,propagator_quark_params=merge(state.quark_params,(A=av,)))
    result=timed.value
    tr=transport_for_tau(state,result.tau,bulk);base=transport_for_tau(state,tau0,bulk)
    highvalues=(tau_u=result.tau.u,tau_s=result.tau.s,tau_ubar=result.tau.ubar,tau_sbar=result.tau.sbar,
        eta_over_s=tr.eta/row.s_fm3inv,zeta_over_s=tr.zeta/row.s_fm3inv,sigma_over_T=tr.sigma/row.T_fm)
    original=(tau_u=tau0.u,tau_s=tau0.s,tau_ubar=tau0.ubar,tau_sbar=tau0.sbar,
        eta_over_s=base.eta/row.s_fm3inv,zeta_over_s=base.zeta/row.s_fm3inv,sigma_over_T=base.sigma/row.T_fm)
    fields=Dict{String,Any}(String(k)=>v for (k,v) in pairs(point_fields(row)))
    fields["seconds"]=timed.time
    fields["baseline_tau_u_rel_to_production"]=0.0
    fields["baseline_tau_s_rel_to_production"]=0.0
    fields["baseline_replay_eta_rel_to_production"]=relative_change(base.eta,Float64(row.eta))
    fields["baseline_replay_zeta_rel_to_production"]=relative_change(base.zeta,Float64(row.zeta))
    fields["baseline_replay_sigma_rel_to_production"]=relative_change(base.sigma,Float64(row.sigma))
    for field in keys(highvalues)
        name=String(field)
        effect=relative_change(getproperty(highvalues,field),getproperty(original,field))
        previous=relative_change(iso[name],low[name])
        fields["p128_isotropic_"*name]=getproperty(highvalues,field)
        fields["p128_match_"*name]=getproperty(original,field)
        fields["p128_effect_"*name]=effect
        fields["p96_effect_"*name]=previous
        fields["effect_change_pp_"*name]=100(effect-previous)
    end
    summary=(; (Symbol(k)=>fields[k] for k in sort!(collect(keys(fields))))...)
    checkpoint(outdir,pid,(summary=summary,rates=result.rates,tau=result.tau,config=tau_config(:p128)))
    write_rows(joinpath(outdir,"anchor.csv"),[summary])
    write_json(joinpath(outdir,"status.json"),(complete=true,rows=1,failures=NamedTuple[]))
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && main()
