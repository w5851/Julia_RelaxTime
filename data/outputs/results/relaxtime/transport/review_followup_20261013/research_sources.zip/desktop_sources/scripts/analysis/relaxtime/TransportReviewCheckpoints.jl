"""Checkpoint validation for the retained-state transport review only."""
module TransportReviewCheckpoints

using JSON, SHA

export validate_resume, restored_checkpoint, canonical_summary

canonical_summary(x::NamedTuple) = canonical_summary(Dict(string(k)=>v for (k,v) in pairs(x)))
canonical_summary(x::AbstractDict) = (; (Symbol(k)=>x[k] for k in sort!(collect(keys(x))))...)

function validate_resume(directory, common_path, input_path)
    directory === nothing && return
    isdir(directory) || error("resume directory does not exist: $directory")
    manifests = filter(n->startswith(n,"manifest") && endswith(n,".json"),readdir(directory))
    isempty(manifests) && error("resume directory has no manifest")
    for name in manifests
        meta=JSON.parsefile(joinpath(directory,name))
        get(meta,"common_sha256",nothing)==bytes2hex(sha256(read(common_path))) ||
            error("resume common implementation differs: $name")
        get(meta,"input_sha256",nothing)==bytes2hex(sha256(read(input_path))) ||
            error("resume retained input differs: $name")
    end
end

function finite_values(x)
    x === nothing && return false
    x isa AbstractFloat && return isfinite(x)
    x isa AbstractDict && return all(finite_values,values(x))
    x isa AbstractVector && return all(finite_values,x)
    true
end

function restored_checkpoint(directory, name, expected_summary, expected_config)
    directory === nothing && return nothing
    path=joinpath(directory,"points",name*".json")
    isfile(path) || return nothing
    record=JSON.parsefile(path)
    haskey(record,"summary") && haskey(record,"config") || error("incomplete checkpoint: $path")
    summary=record["summary"]
    for (key,value) in pairs(expected_summary)
        get(summary,string(key),nothing)==value || error("checkpoint identity mismatch: $path ($key)")
    end
    # Compare every numerical option, rather than accepting a filename alone.
    for (key,value) in pairs(expected_config)
        want=value isa Symbol ? string(value) : value
        get(record["config"],string(key),nothing)==want || error("checkpoint config mismatch: $path ($key)")
    end
    finite_values(summary) || error("nonfinite checkpoint summary: $path")
    haskey(record,"rates") && !finite_values(record["rates"]) && error("nonfinite checkpoint rates: $path")
    record["reused_from"]=abspath(path)
    record["reused_sha256"]=bytes2hex(sha256(read(path)))
    record
end

end
