"""Choose P4 channel gates from retained inverse-relaxation-time contributions.

The 11 display recipes refer to 10 unique points. Select the same channels at
the target and its two actual neighbors, stopping at 70% of the target species
rate or four channels. Persist coverage instead of calling this a full rerun.
"""
from __future__ import annotations
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
INPUT = ROOT / "data/outputs/results/relaxtime/transport/review_followup_20261013"
CASE = "first_canonical_v2_p128_xi001_onshellkernel_validated_anchored_prod_v2"
MODES = {"mode_a": "mode_a_fixed_muB_phase_scaled", "mode_b": "mode_b_fixed_T_sparse_muB"}


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(line for line in f if not line.startswith("#")))


def write(path, rows):
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def key(r):
    return (round(float(r["T_MeV"]), 6), round(float(r["muB_MeV"]), 6), round(float(r["xi"]), 8))


def point_id(r):
    return f"{r['review_mode']}_{r['plot_panel']}_{r['plot_series']}_xi{float(r['xi'])}".replace(".", "p").replace("-", "m")


def main():
    points = read(INPUT / "review_points.csv")
    recipes = read(INPUT / "display_replacements.csv")
    target_map = defaultdict(list)
    for r in recipes:
        target_map[(r["mode_key"], r["plot_panel"], r["plot_series"], round(float(r["xi"]),8))].append(r)
    channels = {}
    sources = []
    for mode, dirname in MODES.items():
        path = ROOT / "data/outputs/results/relaxtime/transport/phase_guided" / dirname / CASE / "channel_diagnostics.csv"
        bypoint = defaultdict(list)
        for r in read(path):
            bypoint[key(r)].append(r)
        channels[mode] = bypoint
        sources.append({"path":str(path),"sha256":hashlib.sha256(path.read_bytes()).hexdigest()})
    selected, inventories, windows = [], [], []
    for (mode, panel, series, xi), rr in sorted(target_map.items()):
        target = next(p for p in points if p["review_mode"]==mode and p["plot_panel"]==panel and p["plot_series"]==series and round(float(p["xi"]),8)==xi)
        left_xi, right_xi = float(rr[0]["left_xi"]), float(rr[0]["right_xi"])
        local = [next(p for p in points if p["review_mode"]==mode and p["plot_panel"]==panel and p["plot_series"]==series and abs(float(p["xi"])-x)<1e-9) for x in (left_xi,xi,right_xi)]
        species = max(("u","s","ubar","sbar"), key=lambda sp: abs(float(target["tau_"+sp])/(.5*(float(local[0]["tau_"+sp])+float(local[2]["tau_"+sp])))-1))
        cmaps = [{r["channel"]:r for r in channels[mode][key(p)] if r["species"]==species} for p in local]
        assert cmaps[1], (mode,panel,series,xi,species)
        ranked = sorted(cmaps[1], key=lambda c: abs(float(cmaps[1][c]["contribution"]))+abs(float(cmaps[1][c]["contribution"])-.5*(float(cmaps[0][c]["contribution"])+float(cmaps[2][c]["contribution"]))), reverse=True)
        chosen, coverage = [], 0.0
        for ch in ranked:
            chosen.append(ch)
            coverage += float(cmaps[1][ch]["contribution"])/float(cmaps[1][ch]["total"])
            if coverage>=.7 or len(chosen)>=4:
                break
        win = "|".join(sorted({r["window_id"] for r in rr}))
        windows.append({"window_ids":win,"target_id":point_id(target),"primary_species":species,"channels":"|".join(chosen),"target_coverage":coverage})
        for role,p,cmap in zip(("left","target","right"),local,cmaps):
            rates = {}
            for r in channels[mode][key(p)]:
                ch,rate=r["channel"],float(r["rate"])
                if ch in rates:
                    assert abs(rates[ch]-rate)<=1e-10*max(abs(rate),1), (point_id(p),ch)
                rates[ch]=rate
            inventories.extend({"point_id":point_id(p),"channel":ch,"rate":rate} for ch,rate in sorted(rates.items()))
            for ch in chosen:
                c=cmap[ch]
                selected.append({"window_ids":win,"point_id":point_id(p),"role":role,
                    "primary_species":species,"channel":ch,"source_rate":float(c["rate"]),
                    "source_contribution":float(c["contribution"]),"source_total":float(c["total"]),
                    "target_selected_coverage":coverage})
    write(INPUT/"channel_plan.csv",selected)
    write(INPUT/"channel_source_rates.csv",inventories)
    write(INPUT/"channel_windows.csv",windows)
    report={"status":"analysis_only","selection":"inverse-tau anomaly, then contribution plus local change; 70% target or four channels",
        "unique_targets":len(windows),"channel_points":len(selected),"sources":sources,
        "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"windows":windows}
    (INPUT/"channel_plan_manifest.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({"targets":len(windows),"channel_points":len(selected),"windows":windows},indent=2))


if __name__=="__main__":
    main()
