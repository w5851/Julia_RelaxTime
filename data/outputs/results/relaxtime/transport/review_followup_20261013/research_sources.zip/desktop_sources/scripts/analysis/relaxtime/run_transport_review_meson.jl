#!/usr/bin/env julia
# P2/P7: k=0 poles and thresholds on exact transport production backgrounds.
include(joinpath(@__DIR__, "TransportReviewCommon.jl"))
include(joinpath(@__DIR__, "FullRSKZero.jl"))
using .TransportReviewCommon, .FullRSKZero
using NLsolve, JSON

const MM = Main.RelaxTime.MesonMass

function meson_equation(meson, mass, gamma, state, scheme; energy_nodes=128,angle_nodes=32)
    qp,tp,kc=state.quark_params,state.thermo_params,state.K_coeffs
    if scheme === :linear
        return MM.meson_mass_equation(meson,mass,gamma,0.0,qp,tp,kc)
    end
    p=MM._meson_polarization_params(meson,qp)
    re,im=polarization_rs_k0(p.channel,mass,gamma,p.m1,p.m2,p.μ1,p.μ2,
        tp.T,tp.Φ,tp.Φbar,tp.ξ,p.A1,p.A2,p.num_s_quark;
        energy_nodes=energy_nodes,angle_nodes=angle_nodes)
    1-4MM._meson_coupling(meson,kc)*complex(re,im)
end

function solve_pole(meson,state,scheme,seed; energy_nodes=128,angle_nodes=32)
    p=MM._meson_polarization_params(meson,state.quark_params)
    threshold=p.m1+p.m2
    starts=[seed,[max(.1,.97threshold),0.0],[1.03threshold,.08],
        [meson===:pi ? .75 : meson===:K ? 2.6 : 1.2threshold,.2]]
    best=nothing
    for x0 in starts
        try
            function f!(out,x)
                v=meson_equation(meson,Float64(x[1]),Float64(x[2]),state,scheme;
                    energy_nodes=energy_nodes,angle_nodes=angle_nodes)
                out[1]=real(v);out[2]=imag(v)
            end
            sol=nlsolve(f!,Float64.(x0); ftol=1e-9,xtol=1e-10,iterations=80)
            m,g=sol.zero
            if m<0
                m=-m;g=-g
            end
            residual=abs(meson_equation(meson,m,g,state,scheme;
                energy_nodes=energy_nodes,angle_nodes=angle_nodes))
            candidate=(mass=m,gamma=g,residual=residual,
                converged=isfinite(residual)&&residual<1e-7&&m>0,
                threshold=threshold,gap=m-threshold)
            if best===nothing || residual<best.residual
                best=candidate
            end
            candidate.converged && return candidate
        catch err
            (err isa InterruptException) && rethrow()
        end
    end
    best===nothing ? (mass=NaN,gamma=NaN,residual=Inf,converged=false,threshold=threshold,gap=NaN) : best
end

function threshold_check(meson,state,scheme)
    p=MM._meson_polarization_params(meson,state.quark_params)
    th=p.m1+p.m2
    tp=state.thermo_params
    p.μ1==p.μ2 || error("threshold endpoint requires equal chemical potentials")
    function endpoint(n)
        b=B0_pair_threshold_rs(p.m1,p.m2,p.μ1,tp.T,tp.Φ,tp.Φbar,tp.ξ;
            energy_nodes=n,angle_nodes=n÷4,linear=scheme===:linear)
        pref=(p.channel===:P ? (p.m1-p.m2)^2 : (p.m1+p.m2)^2)-th^2
        pol=-Main.Constants_PNJL.N_color/(8π^2)*(p.A1+p.A2+pref*b)
        1-4MM._meson_coupling(meson,state.K_coeffs)*pol
    end
    low,high=endpoint(128),endpoint(256)
    (threshold_den_re=high,threshold_den_im=0.0,
        threshold_offset_relative=0.0,threshold_endpoint_change=abs(high-low))
end

function main()
    length(ARGS)>=1 || error("expected OUTDIR [LIMIT]")
    outdir=abspath(ARGS[1]);limit=length(ARGS)>=2 ? parse(Int,ARGS[2]) : 0
    selected=[r for r in read_points() if r.p7]
    sort!(selected,by=r->(String(r.review_mode),String(r.plot_panel),String(r.plot_series),-Float64(r.xi)))
    limit>0 && (selected=selected[1:min(limit,length(selected))])
    write_json(joinpath(outdir,"manifest.json"),run_metadata(@__FILE__,
        (points=length(selected),pole_convention="real_axis_width_coupling",couplings="production_isotropic_A",
        full_rs_scope="k=0 occupation resummation, unchanged on-shell denominators",energy_nodes=128,angle_nodes=32)))
    records=NamedTuple[];failures=NamedTuple[];seeds=Dict{Any,Vector{Float64}}()
    for row in selected
        state=state_from_row(row)
        pointrows=NamedTuple[]
        for meson in (:pi,:K,:sigma_pi,:sigma_K)
            key=(String(row.review_mode),String(row.plot_panel),String(row.plot_series),meson)
            p=MM._meson_polarization_params(meson,state.quark_params)
            seed=get(seeds,key,[meson===:pi ? .75 : meson===:K ? 2.6 : p.m1+p.m2+.1,0.0])
            linear=solve_pole(meson,state,:linear,seed)
            linear.converged && (seeds[key]=[linear.mass,linear.gamma])
            schemes=meson===:pi && row.review_mode=="mode_a" && Float64(row.muB_MeV)==0.0 && Float64(row.alpha_T) in (1.,1.1) ? (:linear,:full_rs) : (:linear,)
            for scheme in schemes
                pole=scheme===:linear ? linear : solve_pole(meson,state,scheme,[linear.mass,linear.gamma])
                # Failed roots remain visible; no interpolation across failures.
                th=threshold_check(meson,state,scheme)
                refined_residual=if scheme===:full_rs && pole.converged
                    abs(meson_equation(meson,pole.mass,pole.gamma,state,scheme;energy_nodes=256,angle_nodes=64))
                else
                    NaN
                end
                out=merge(point_fields(row),(meson=String(meson),scheme=String(scheme),
                    mass_MeV=pole.mass*HC,gamma_MeV=pole.gamma*HC,threshold_MeV=pole.threshold*HC,
                    gap_MeV=pole.gap*HC,converged=pole.converged,residual=pole.residual,
                    refined_residual=refined_residual,
                    mass_rel_to_linear=relative_change(pole.mass,linear.mass)),th)
                push!(pointrows,out);push!(records,out)
                !pole.converged && push!(failures,(point_id=point_id(row),meson=String(meson),scheme=String(scheme),residual=pole.residual))
            end
        end
        checkpoint(outdir,point_id(row),(rows=pointrows,))
        write_rows(joinpath(outdir,"meson_poles.csv"),records)
        write_json(joinpath(outdir,"status.json"),(complete=false,points=length(selected),rows=length(records),failed_roots=failures))
    end
    write_json(joinpath(outdir,"status.json"),(complete=true,points=length(selected),rows=length(records),failed_roots=failures))
    println("Completed ",length(records)," poles; unresolved roots: ",length(failures))
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && main()
