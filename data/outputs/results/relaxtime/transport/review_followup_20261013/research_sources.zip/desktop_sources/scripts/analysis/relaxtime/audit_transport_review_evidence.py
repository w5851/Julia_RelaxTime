"""Recheck retained review evidence without changing historical inputs.

DOCX extraction preserves paragraph/image order and source hashes. The convergence
audit checks the actual 60 shard manifests and files, not just their README.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
CASE = "first_canonical_v2_p128_xi001_onshellkernel_validated_anchored_prod_v2"
MODES = {"mode_a": "mode_a_fixed_muB_phase_scaled", "mode_b": "mode_b_fixed_T_sparse_muB"}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_csv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(line for line in stream if not line.startswith("#")))


def write_csv(path, rows):
    if not rows:
        return
    with Path(path).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def extract_docx(path, output):
    from PIL import Image, ImageDraw
    output.mkdir(parents=True, exist_ok=True)
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
          "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
          "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
    blocks, figures = [], []
    with zipfile.ZipFile(path) as archive:
        rels = ET.fromstring(archive.read("word/_rels/document.xml.rels"))
        targets = {rel.attrib["Id"]: rel.attrib.get("Target", "") for rel in rels}
        doc = ET.fromstring(archive.read("word/document.xml"))
        for index, paragraph in enumerate(doc.findall(".//w:body//w:p", ns), 1):
            text = "".join(
                node.text or "" for node in paragraph.findall(".//w:t", ns))
            media = []
            for node in paragraph.findall(".//a:blip", ns):
                target = targets[node.attrib["{" + ns["r"] + "}embed"]]
                member = "word/" + target.lstrip("/")
                dest = output / Path(target).name
                dest.write_bytes(archive.read(member))
                media.append(dest.name)
                figures.append({"paragraph": index, "file": dest.name,
                                "sha256": sha(dest), "context": text})
            if text or media:
                blocks.append({"paragraph": index, "text": text, "images": media})
    (output / "paragraphs.json").write_text(json.dumps(blocks, ensure_ascii=False, indent=2), encoding="utf-8")
    (output / "text.txt").write_text("\n".join(f"[{b['paragraph']}] {b['text']} {' '.join(b['images'])}" for b in blocks), encoding="utf-8")
    thumbs = []
    for item in figures:
        try:
            with Image.open(output / item["file"]) as image:
                image = image.convert("RGB")
                image.thumbnail((600, 380))
                tile = Image.new("RGB", (620, 425), "white")
                tile.paste(image, ((620-image.width)//2, 30))
                ImageDraw.Draw(tile).text((10, 8), f"p{item['paragraph']} / {item['file']}", fill="black")
                thumbs.append(tile)
        except OSError:
            pass
    for start in range(0, len(thumbs), 8):
        batch = thumbs[start:start+8]
        sheet = Image.new("RGB", (1240, 425*math.ceil(len(batch)/2)), "#dddddd")
        for index, tile in enumerate(batch):
            sheet.paste(tile, ((index % 2)*620, (index//2)*425))
        sheet.save(output / f"contact_{start//8+1}.jpg")
    return {"source": str(path), "sha256": sha(path), "paragraph_blocks": len(blocks),
            "figures": figures, "extraction": str(output)}


def audit_convergence(artifact_root):
    summary = {"source": str(artifact_root), "resolutions": {}, "hash_mismatches": [], "input_configs": []}
    comparisons = {}
    for resolution in ("p104", "p128"):
        manifests = sorted((artifact_root / resolution).rglob("run_manifest.json"))
        counts = Counter(shards=len(manifests))
        configs = set()
        point_map = {}
        for path in manifests:
            manifest = json.loads(path.read_text(encoding="utf-8-sig"))
            argv = manifest["argv"]
            opts = {v: argv[i+1] for i, v in enumerate(argv[:-1]) if v.startswith("--") and not argv[i+1].startswith("--")}
            configs.add(tuple(opts.get(k) for k in ("--p-num", "--t-num", "--phase-reference-layer", "--phase-reference-mode", "--tau-p-nodes", "--tau-angle-nodes", "--tau-phi-nodes", "--tau-n-sigma", "--sigma-grid-n")))
            counts["errors"] += manifest["summary"]["error_count"]
            counts["skipped"] += manifest["summary"]["skipped_count"]
            for artifact in manifest["artifacts"]:
                local = path.parent / Path(artifact["path"]).name
                counts["files_checked"] += 1
                if not local.exists() or sha(local) != artifact["sha256"]:
                    summary["hash_mismatches"].append(str(local))
                if local.name in ("phase_guided_transport_scan.csv", "channel_diagnostics.csv", "failed_points.csv"):
                    actual_rows = read_csv(local)
                    counts[local.name] += len(actual_rows)
                    if artifact.get("rows") != len(actual_rows):
                        summary.setdefault("row_count_mismatches", []).append(str(local))
                    if local.name == "phase_guided_transport_scan.csv":
                        for row in actual_rows:
                            key = (row["mode"], row["plot_panel"], row["plot_series"], round(float(row["xi"]), 8))
                            if key in point_map:
                                raise ValueError(f"duplicate convergence key {key}")
                            point_map[key] = row
                            if row["converged"].lower() != "true":
                                counts["unconverged_rows"] += 1
        summary["resolutions"][resolution] = dict(counts)
        summary["input_configs"].append({"resolution": resolution, "configs": [list(c) for c in sorted(configs)]})
        comparisons[resolution] = point_map
    common = comparisons["p104"].keys() & comparisons["p128"].keys()
    summary["matched_points"] = len(common)
    fields = ("tau_u", "tau_s", "eta_over_s", "zeta_over_s", "sigma_over_T")
    summary["relative_changes"] = {}
    for field in fields:
        changes = sorted((abs(float(comparisons["p104"][key][field])-float(comparisons["p128"][key][field])) / max(abs(float(comparisons["p128"][key][field])), 1e-300), key) for key in common)
        summary["relative_changes"][field] = {"max": changes[-1][0], "at": changes[-1][1], "over_1_percent": sum(d>0.01 for d, _ in changes), "p99": changes[int(.99*(len(changes)-1))][0]}
    return summary


def prepare_points(output):
    review = ROOT / "docs/analysis/relaxtime/phase_guided_transport/phase_guided_transport_publication_clean_v5/tables/replacement_map.csv"
    replacements = read_csv(review)
    targets, neighbors = set(), set()
    for row in replacements:
        key = (row["mode_key"], row["plot_panel"], row["plot_series"])
        targets.add((*key, round(float(row["xi"]), 8)))
        for field in ("left_xi", "right_xi"):
            if row[field]:
                neighbors.add((*key, round(float(row[field]), 8)))
    selected = []
    sources = []
    for mode, dirname in MODES.items():
        path = ROOT / "data/outputs/results/relaxtime/transport/phase_guided" / dirname / CASE / "phase_guided_transport_scan.csv"
        sources.append({"path": str(path), "sha256": sha(path)})
        for row in read_csv(path):
            xi = round(float(row["xi"]), 8)
            key = (mode, row["plot_panel"], row["plot_series"], xi)
            p1 = mode == "mode_a" and float(row["alpha_T"]) in (1., 1.2) and xi in (-.5, -.25, .25, .5)
            p4 = key in targets or key in neighbors
            p7 = p4 or (mode == "mode_a" and abs(xi*20-round(xi*20)) < 1e-7)
            if p1 or p4 or p7:
                selected.append(dict(review_mode=mode, p1=p1, p4=p4, p4_target=key in targets, p7=p7, **row))
    write_csv(output / "review_points.csv", selected)
    write_csv(output / "display_replacements.csv", replacements)
    return {"sources": sources, "replacement_sha256": sha(review), "replacement_records": len(replacements), "windows": len({r["window_id"] for r in replacements}), "unique_replacement_points": len(targets), "selected": len(selected), "p1_points": sum(r["p1"] for r in selected), "p4_points_with_neighbors": sum(r["p4"] for r in selected)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--document", type=Path, action="append", default=[])
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    report = {"status": "analysis_only", "source_code_sha256": sha(__file__),
              "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
              "documents": [extract_docx(p, args.outdir / "documents" / p.stem) for p in args.document],
              "convergence": audit_convergence(args.artifacts), "points": prepare_points(args.outdir)}
    (args.outdir / "evidence_audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"documents": [{k:v for k,v in d.items() if k!="figures"} for d in report["documents"]], "convergence":report["convergence"], "points":report["points"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
