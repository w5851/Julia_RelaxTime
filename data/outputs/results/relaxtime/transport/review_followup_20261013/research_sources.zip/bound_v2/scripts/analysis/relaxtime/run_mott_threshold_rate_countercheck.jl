#!/usr/bin/env julia
include(joinpath(@__DIR__,"MottThresholdProbe.jl"))
using .TransportReviewCommon, .MottThresholdProbe, CSV
const AS=Main.RelaxTime.AverageScatteringRate
const CS=Main.RelaxTime.TotalCrossSection

function main(outdir)
    isfile(joinpath(outdir,"manifest.json")) && error("use a new output directory")
    config=merge(tau_config(:p128),(sigma_cutoff=Main.Constants_PNJL.Λ_inv_fm,))
    plan=collect(CSV.File(joinpath(INPUT,"channel_plan.csv")))
    write_json(joinpath(outdir,"manifest.json"),run_metadata(@__FILE__,
        (scope="matched two-channel rate countercheck, unchanged backgrounds and outer grid",
         config=config,channels=("uubar_to_uubar","uubar_to_ddbar"),xis=(0.36,0.37,0.38),
         replacement="direct sigma on original knots plus log-x and uniform-q threshold knots; no asymptotic subtraction",
         levels=(96,192),raw_cache="analysis-supplied cache without production fingerprint; explicit matching parameters in manifest",
         production_modified=false)))
    outputs=NamedTuple[];bands=NamedTuple[];knots=NamedTuple[]
    edges=[0.0,1e-5,1e-4,1e-3,0.01,0.1,0.6,1.2,Inf]
    for xi in (0.36,0.37,0.38), process in (:uubar_to_uubar,:uubar_to_ddbar)
        row=selected_row(xi);state=state_from_row(row);qp,tp,kc=state.quark_params,state.thermo_params,state.K_coeffs
        job=only(j for j in plan if String(j.point_id)==point_id(row) && Symbol(j.channel)==process)
        s0=4qp.m.u^2
        println("RATE ",xi," ",process," stock");flush(stdout)
        stock=AS.build_w0cdf_pchip_cache(process,qp,tp,kc;N=560,
            p_cutoff=Main.Constants_PNJL.Λ_inv_fm,n_sigma_points=24,
            threshold_subtraction=true,asym_window=0.6,asym_fit_min_points=8,
            asym_extra_points=10,sigma_cache_policy=:validated_anchored)
        raw=Dict(s=>AS._exact_cached_sigma_value(stock,s,stock.sigma_vals[i]) for (i,s) in enumerate(stock.s_vals))
        function evaluate(cache,cfg,label)
            bw=Ref(Float64[]);bs=Ref(Float64[])
            value=AS.average_scattering_rate(process,qp,tp,kc;cfg...,cs_cache=cache,
                band_edges=edges,band_omega_out=bw,band_omega_sigma_out=bs)
            push!(outputs,(xi=xi,channel=String(process),method=label,rate=value,
                source_rate=Float64(job.source_rate),source_contribution=Float64(job.source_contribution),
                source_total=Float64(job.source_total),source_tau=1/Float64(job.source_total),
                change_from_source=value/Float64(job.source_rate)-1,cache_nodes=length(cache.s_vals)))
            for i in eachindex(bs[])
                push!(bands,(xi=xi,channel=String(process),method=label,left=edges[i],right=edges[i+1],
                    base_weight=bw[][i],weighted_sigma=bs[][i],rate_in_band=value*bs[][i]/sum(bs[])))
            end
            write_rows(joinpath(outdir,"rates.csv"),outputs)
            write_rows(joinpath(outdir,"rate_bands.csv"),bands)
            return value
        end
        baseline=evaluate(stock,config,"stock")
        abs(baseline/Float64(job.source_rate)-1)<1e-9 || error("stock cache did not reproduce production")
        for level in (96,192)
            println("RATE ",xi," ",process," dense",level);flush(stdout)
            xs=vcat(10.0.^collect(range(log10(s0*1e-10),log10(0.6),length=level)),
                [0.6*(i/level)^2 for i in 1:level])
            for x in xs
                s=s0+x
                haskey(raw,s) || (raw[s]=CS.total_cross_section(process,s,qp,tp,kc;n_points=24))
            end
            grid=sort(collect(keys(raw)))
            dense=AS.CrossSectionCache(process,grid,[raw[s] for s in grid])
            cfg=merge(config,(threshold_subtraction=false,require_cache_fingerprint=false,))
            evaluate(dense,cfg,"dense$(level)")
            if level==192
                for s in grid
                    s-s0>1.2 && continue
                    original=AS._get_sigma_core(stock,s,qp,tp,kc;n_points=24,interpolation_mode=:linear)
                    push!(knots,(xi=xi,channel=String(process),x=s-s0,sigma_direct=raw[s],sigma_stock=original))
                end
            end
        end
        write_rows(joinpath(outdir,"threshold_knots.csv"),knots)
    end
    write_json(joinpath(outdir,"status.json"),(complete=true,rates=length(outputs),bands=length(bands),knots=length(knots)))
    println("COMPLETE ",outdir)
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && main(abspath(only(ARGS)))
