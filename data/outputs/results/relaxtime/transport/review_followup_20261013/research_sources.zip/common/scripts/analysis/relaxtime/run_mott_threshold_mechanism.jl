#!/usr/bin/env julia
include(joinpath(@__DIR__,"MottThresholdProbe.jl"))
using .TransportReviewCommon, .MottThresholdProbe
using LinearAlgebra

function main(outdir;smoke=false)
    isfile(joinpath(outdir,"manifest.json")) && error("use a new output directory")
    write_json(joinpath(outdir,"manifest.json"),run_metadata(@__FILE__,
        (scope="equal-mass k=0 branch point and mixed-P threshold",smoke=smoke,
         loop_schemes=("production","paired_pv"),couplings="retained transport isotropic A",
         background="retained rows; critical and detuned states locally solved p24 angle8",
         integration="threshold-weight projected s-P integral, not full tau")))
    cases=NamedTuple[];criticalrows=NamedTuple[];bindings=NamedTuple[]
    for (xi,family) in (smoke ? ((0.37,:mixed),) : ((0.36,:mixed),(0.37,:mixed),(0.38,:mixed),(-0.25,:pi),(-0.20,:pi)))
        row=selected_row(xi)
        push!(cases,(id="retained_$(family)_$(xi)",family=family,xi=xi,state=state_from_row(row),source="retained"))
    end
    if !smoke
        for (family,seed,lo,hi) in ((:mixed,0.37,0.36,0.37),(:pi,-0.20,-0.22,-0.21))
            println("CRITICAL ",family);flush(stdout)
            crit=critical_state(selected_row(seed),family,lo,hi)
            state=crit.location.state
            push!(cases,(id="critical_$(family)",family=family,xi=crit.xi,state=state,source="local_solve"))
            td=crit.threshold
            mm=td.response.matrix
            ev=eigvals(Symmetric(real.([mm.M00 mm.M08;mm.M08 mm.M88])))
            push!(criticalrows,(family=String(family),xi=crit.xi,T_MeV=state.thermo_params.T*HC,
                m_u_MeV=state.quark_params.m.u*HC,m_s_MeV=state.quark_params.m.s*HC,
                delta=td.delta,c=td.c,detuning_n128=threshold_data(state,family;n=128).delta,
                detuning_n512=threshold_data(state,family;n=512).delta,
                gap_residual=crit.location.base.residual_norm,
                mixed_eigen_1=ev[1],mixed_eigen_2=ev[2],numerator_abs=abs(td.response.mixed_numerator)))
            for dx in (-0.003,-0.001,-0.0003,-0.0001,0.0001,0.0003,0.001,0.003)
                loc=local_state(selected_row(seed),crit.xi+dx);st=loc.state
                t=threshold_data(st,family)
                t.delta*t.c<0 || continue
                predicted=-(t.delta/t.c)^2
                den(x)=begin
                    r=response(st,t.s0+x)
                    real(family===:pi ? r.pi_den : r.mixed_den)
                end
                lower=4predicted
                while den(lower)*t.delta>0
                    lower*=2
                    abs(lower)<0.2t.s0 || error("bound pole left local window")
                end
                l=lower;u=0.0
                for _ in 1:60
                    mid=(l+u)/2
                    if signbit(den(mid))==signbit(den(l));l=mid;else;u=mid;end
                end
                xb=(l+u)/2;h=abs(xb)*1e-3
                derivative=(den(xb+h)-den(xb-h))/(2h)
                rr=response(st,t.s0+xb-h)
                numerator=family===:pi ? 2st.K_coeffs.K123_plus : real(rr.mixed_numerator)
                push!(bindings,(family=String(family),xi=crit.xi+dx,xi_offset=dx,delta=t.delta,c=t.c,
                    binding_s=-xb,predicted_binding_s=-predicted,binding_relative_error=(xb-predicted)/predicted,
                    residue_abs=abs(numerator/derivative),residue_prediction=abs(2numerator*t.delta/t.c^2)))
            end
        end
    end
    write_rows(joinpath(outdir,"critical_states.csv"),criticalrows)
    write_rows(joinpath(outdir,"bound_poles.csv"),bindings)
    write_json(joinpath(outdir,"states.json"),cases)
    samples=NamedTuple[];integrals=NamedTuple[];checks=NamedTuple[]
    for case in cases
        println("PROFILE ",case.id);flush(stdout)
        state=case.state;mu=state.quark_params.m.u;s0=4mu^2
        th=threshold_data(state,case.family)
        z=Main.FullRSKZero.B0_pair_threshold_rs(mu,mu,state.quark_params.μ.u,state.thermo_params.T,
            state.thermo_params.Φ,state.thermo_params.Φbar,state.thermo_params.ξ;energy_nodes=256,angle_nodes=32,linear=true)
        reference=pair_b0(s0,mu,state.quark_params.μ.u,state.thermo_params)
        push!(checks,(case_id=case.id,endpoint_difference=abs(real(reference)-z),
            F0=MottThresholdProbe.occupation_F(0.0,mu,state.quark_params.μ.u,state.thermo_params),
            s0=s0,delta=th.delta,c=th.c))
        for exponent in (smoke ? (-9.0:1.0:-1.0) : (-10.0:0.25:-1.0)), side in (-1,1)
            x=side*s0*10.0^exponent
            for (scheme,n) in ((:paired_pv,128),(:paired_pv,256),(:production,0))
                rr=response(state,s0+x;scheme=scheme,n=n)
                d=case.family===:pi ? rr.pi_den : rr.mixed_den
                D=case.family===:pi ? rr.pi_D : rr.mixed_D
                push!(samples,(case_id=case.id,family=String(case.family),xi=case.xi,scheme=String(scheme),n=n,
                    x=x,epsilon=x/s0,den_re=real(d),den_im=imag(d),D_abs2=abs2(D),
                    piP_re=real(rr.pol.u.P),piP_im=imag(rr.pol.u.P),piS_re=real(rr.pol.u.S),piS_im=imag(rr.pol.u.S),
                    loop_re=real(rr.pol.u.B),loop_im=imag(rr.pol.u.B),mixed_num_abs=abs(rr.mixed_numerator)))
            end
        end
        if !smoke
            for X in (s0*1e-4,s0*1e-2), nq in (64,128), cutoff_fraction in (0.0,1e-4,1e-2)
                value=q_integral(state,case.family,X;nq=nq,xmin=X*cutoff_fraction)
                push!(integrals,(case_id=case.id,family=String(case.family),xi=case.xi,X=X,nq=nq,
                    cutoff_fraction=cutoff_fraction,integral=value))
            end
        end
        write_rows(joinpath(outdir,"profiles.csv"),samples)
        write_rows(joinpath(outdir,"endpoint_checks.csv"),checks)
        write_rows(joinpath(outdir,"threshold_integrals.csv"),integrals)
    end
    write_json(joinpath(outdir,"status.json"),(complete=true,cases=length(cases),samples=length(samples),
        critical_states=length(criticalrows),bound_poles=length(bindings),integrals=length(integrals)))
    println("COMPLETE ",outdir)
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && main(abspath(ARGS[1]);smoke="--smoke" in ARGS)
