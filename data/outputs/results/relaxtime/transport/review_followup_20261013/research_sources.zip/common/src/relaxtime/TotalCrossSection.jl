module TotalCrossSection

"""
# TotalCrossSection Module

总散射截面计算模块，对微分散射截面进行 t 积分，包含末态统计因子。

## 物理公式

总散射截面通过对 Mandelstam 变量 t 积分得到：

σ(s, T, μ_q) = ∫_{t_-}^{t_+} dt · (dσ/dt) · (1 - f_c)(1 - f_d)

其中：
- dσ/dt: 微分散射截面（来自 DifferentialCrossSection 模块）
- (1 - f): 末态费米子统计因子（Pauli blocking）
- E_c, E_d: 末态粒子能量，从 s 与末态质量计算
- t_±: t 积分边界（公式 5.14）

注：本模块只考虑夸克-夸克散射（费米子），不涉及玻色子散射。

## t 积分边界（修正版）

t_± = m_i² + m_c² - (1/2s)·(s + m_i² - m_j²)(s + m_c² - m_d²)
      ± 2√{[(s + m_i² - m_j²)²/(4s) - m_i²]·[(s + m_c² - m_d²)²/(4s) - m_c²]}

此公式基于质心系动量守恒和散射角的物理边界。

## 核心功能

1. **修正的 t 积分边界**: 使用完整公式 (5.14)，而非简化近似
2. **末态粒子能量**: 从 Mandelstam 变量计算质心系能量
3. **末态统计因子**: Pauli blocking (费米子专用)
4. **总散射截面 σ(s)**: 高斯-勒让德数值积分（固定点数，可预测耗时）
5. **批量计算与扫描**: 支持多过程、s 依赖性分析

## Dual Interface Pattern

This module supports **both struct and NamedTuple parameters**:

```julia
# Using structs (recommended)
using Main.ParameterTypes: QuarkParams, ThermoParams

q = QuarkParams(m=(u=1.52, d=1.52, s=3.04), μ=(u=0.3, d=0.3, s=0.3))
t = ThermoParams(0.15, 0.5, 0.5, 0.0)
σ = total_cross_section(:uu_to_uu, 2.0, q, t, K_coeffs)

# Using NamedTuples (backward compatible)
q_nt = (m=(u=1.52, d=1.52, s=3.04), μ=(u=0.3, d=0.3, s=0.3))
t_nt = (T=0.15, Φ=0.5, Φbar=0.5, ξ=0.0)
σ = total_cross_section(:uu_to_uu, 2.0, q_nt, t_nt, K_coeffs)
```

Both produce identical results. Internal normalization ensures type stability.

## 使用示例

```julia
using .TotalCrossSection

# 单个过程的总散射截面
σ = total_cross_section(
    :uu_to_uu, 31.0,
    quark_params, thermo_params, K_coeffs,
    n_points=6  # 高斯积分点数（默认）
)

# 扫描 s 依赖性
s_values = collect(range(10.0, 50.0, length=20))
σ_values = scan_s_dependence(
    s_values, :uu_to_uu,
    quark_params, thermo_params, K_coeffs
)

# 计算所有过程
all_σ = calculate_all_total_cross_sections(
    31.0, quark_params, thermo_params, K_coeffs
)
```

## 参考文档

- doc/formula/散射截面by微分散射截面.md: 公式推导
- api/TotalCrossSection.md: API 详细文档
"""

# Dependencies loaded by RelaxTime.jl entry point

using Main.ParameterTypes: QuarkParams, ThermoParams
using Main.ParameterAdapters: normalize_quark_input, normalize_thermo_input

using Main.Constants_PNJL: SCATTERING_MESON_MAP
using ..KinematicChecks: check_kinematic_threshold, kinematic_error_mode, emit_runtime_failure_notice
using ..GaussLegendre: standard_nodes_weights
using Main.PNJLQuarkDistributions_Aniso: quark_distribution_aniso, antiquark_distribution_aniso
using ..ScatteringAmplitude: scattering_amplitude_squared, prepare_scattering_context, scattering_amplitude_squared_prepared
using ..ParticleSymbols: parse_scattering_process, is_antiquark
using ..DifferentialCrossSection: differential_cross_section
using ..OneLoopIntegrals: distribution_value

# 默认积分点数
const DEFAULT_T_INTEGRAL_POINTS = 6

# 导出函数
export calculate_t_bounds
export calculate_final_state_energies
export final_state_blocking_factor
export combined_final_state_factor
export total_cross_section
export calculate_all_total_cross_sections
export calculate_all_total_cross_sections_detailed
export scan_s_dependence
export scan_s_dependence_detailed
export CrossSectionEvaluationResult

Base.@kwdef struct CrossSectionEvaluationResult
    success::Bool
    value::Union{Nothing, Float64}=nothing
    error_code::Union{Nothing, Symbol}=nothing
    error_message::Union{Nothing, String}=nothing
    exception::Any=nothing
end

@inline CrossSectionEvaluationResult(value::Float64) = CrossSectionEvaluationResult(success=true, value=value)

@inline function _cross_section_error_code(err)::Symbol
    if err isa ArgumentError
        return :argument_error
    elseif err isa DomainError
        return :domain_error
    elseif err isa MethodError
        return :method_error
    elseif err isa BoundsError
        return :bounds_error
    end
    return :runtime_error
end

function _capture_cross_section_evaluation(thunk::Function)::CrossSectionEvaluationResult
    try
        return CrossSectionEvaluationResult(thunk())
    catch err
        return CrossSectionEvaluationResult(
            success=false,
            error_code=_cross_section_error_code(err),
            error_message=sprint(showerror, err),
            exception=err,
        )
    end
end

function _materialize_cross_section_value(
    result::CrossSectionEvaluationResult,
    context::AbstractString;
    on_error::Symbol,
)::Float64
    result.success && return something(result.value)

    if on_error === :nan
        emit_runtime_failure_notice(context, result.exception)
        return NaN
    elseif on_error === :throw
        throw(ErrorException("$(context): $(result.error_code): $(result.error_message)"))
    end

    throw(ArgumentError("Unknown on_error=$(on_error). Allowed values: :throw, :nan"))
end

# 数值容差
const EPS_KINEMATIC = 1e-14  # 运动学阈值容差

# 基本工具
@inline function kallen(x::Float64, y::Float64, z::Float64)
    return x * x + y * y + z * z - 2.0 * (x * y + x * z + y * z)
end

@inline function momentum_from_energy(E::Float64, m::Float64)
    return sqrt(max(E * E - m * m, 0.0))
end

@inline function cos_theta_star(s::Float64, t::Float64, mi::Float64, mj::Float64, mc::Float64, md::Float64)
    λ_in = kallen(s, mi^2, mj^2)
    λ_out = kallen(s, mc^2, md^2)
    denom = sqrt(abs(λ_in)) * sqrt(abs(λ_out))
    if denom < EPS_KINEMATIC
        return 1.0  # 近阈值时退化为正向散射近似
    end
    numerator = (s + mi^2 - mj^2) * (s + mc^2 - md^2) - 2.0 * s * (mi^2 + mc^2 - t)
    return clamp(numerator / denom, -1.0, 1.0)
end

# ----------------------------------------------------------------------------
# 1. t 积分边界计算（修正版，公式 5.14）
# ----------------------------------------------------------------------------

"""
    calculate_t_bounds(s, mi, mj, mc, md) -> NamedTuple

计算 Mandelstam 变量 t 的物理边界 t_±。

# 公式 (5.14)

t_± = m_i² + m_c² - (1/2s)·(s + m_i² - m_j²)(s + m_c² - m_d²)
      ± 2√{[(s + m_i² - m_j²)²/(4s) - m_i²]·[(s + m_c² - m_d²)²/(4s) - m_c²]}

其中：
- 常数项: m_i² + m_c²
- 对称项: -(1/2s)·(s + m_i² - m_j²)(s + m_c² - m_d²)
- 动量项: 2√(p_cm_i² · p_cm_c²)

# 参数

- `s::Float64`: Mandelstam 变量 s [fm⁻²]
- `mi::Float64`: 初态粒子 1 质量 [fm⁻¹]
- `mj::Float64`: 初态粒子 2 质量 [fm⁻¹]
- `mc::Float64`: 末态粒子 1 质量 [fm⁻¹]
- `md::Float64`: 末态粒子 2 质量 [fm⁻¹]

# 返回

`(t_min, t_max)`: t 的物理边界 [fm⁻²]

# 物理意义

- t_min (t_-): 后向散射极限
- t_max (t_+): 正向散射极限
- 满足 Mandelstam 约束: s + t + u = m_i² + m_j² + m_c² + m_d²

# 运动学检查

如果 s 低于阈值（初态或末态），抛出错误：
- 初态阈值: s ≥ (m_i + m_j)²
- 末态阈值: s ≥ (m_c + m_d)²

# 示例

```julia
s = 31.0  # fm⁻²
mi = mj = mc = md = 1.52  # fm⁻¹ (u 夸克)

t_bounds = calculate_t_bounds(s, mi, mj, mc, md)
# 对于相同质量: t_min ≈ -t_max (对称性)
```
"""
function calculate_t_bounds(
    s::Float64,
    mi::Float64,
    mj::Float64,
    mc::Float64,
    md::Float64
)::NamedTuple
    # 常数项
    constant_term = mi^2 + mc^2
    
    # 对称项的中间变量
    term_ij = s + mi^2 - mj^2
    term_cd = s + mc^2 - md^2
    symmetric_term = -(term_ij * term_cd) / (2.0 * s)
    
    # 平方根项（质心系动量的平方）
    # sqrt_arg1 = (term_ij²/(4s) - mi²) = p_cm_i²
    # sqrt_arg2 = (term_cd²/(4s) - mc²) = p_cm_c²
    sqrt_arg1 = (term_ij^2 / (4.0 * s)) - mi^2
    sqrt_arg2 = (term_cd^2 / (4.0 * s)) - mc^2
    
    # 检查运动学可行性
    if sqrt_arg1 < -EPS_KINEMATIC
        check_kinematic_threshold(s, mi, mj; warn_close=false, mode=:strict, context="Initial state kinematic violation")
    end
    if sqrt_arg2 < -EPS_KINEMATIC
        check_kinematic_threshold(s, mc, md; warn_close=false, mode=:strict, context="Final state kinematic violation")
    end
    
    # 处理接近阈值的情况（避免负数开方）
    sqrt_arg1 = max(0.0, sqrt_arg1)
    sqrt_arg2 = max(0.0, sqrt_arg2)
    
    # 计算动量项
    sqrt_term = 2.0 * sqrt(sqrt_arg1 * sqrt_arg2)
    
    # 最终结果: t_± = constant + symmetric ± sqrt
    t_minus = constant_term + symmetric_term - sqrt_term  # 后向散射
    t_plus  = constant_term + symmetric_term + sqrt_term  # 正向散射
    
    return (t_min = t_minus, t_max = t_plus)
end

# ----------------------------------------------------------------------------
# 2. 末态粒子能量计算
# ----------------------------------------------------------------------------

"""
    calculate_final_state_energies(s, mc, md) -> (E_c, E_d)

从 Mandelstam 变量计算质心系中末态粒子的能量。

# 公式

在质心系中：
- E_c = (s + m_c² - m_d²) / (2√s)
- E_d = (s + m_d² - m_c²) / (2√s)

# 参数

- `s::Float64`: Mandelstam 变量 s [fm⁻²]
- `mc, md::Float64`: 末态粒子质量 [fm⁻¹]

# 返回

`(E_c, E_d)`: 末态粒子能量 [fm⁻¹]

# 物理验证

- 能量守恒: E_c + E_d = √s
- 质量壳条件: E_c² - p_c² = m_c²
- E_c ≥ m_c, E_d ≥ m_d

# 示例

```julia
s = 31.0
mc = md = 1.52

E_c, E_d = calculate_final_state_energies(s, mc, md)
@assert E_c + E_d ≈ sqrt(s)  # 能量守恒
```
"""
function calculate_final_state_energies(
    s::Float64,
    mc::Float64,
    md::Float64
)::Tuple{Float64, Float64}
    # 质心系总能量
    sqrt_s = sqrt(s)
    
    # 末态粒子能量（质心系）
    E_c = (s + mc^2 - md^2) / (2.0 * sqrt_s)
    E_d = (s + md^2 - mc^2) / (2.0 * sqrt_s)
    
    return (E_c, E_d)
end

# ----------------------------------------------------------------------------
# 3. 末态统计因子（费米子专用）
# ----------------------------------------------------------------------------

"""
    final_state_blocking_factor(flavor, E, m, μ, T, Φ, Φbar, ξ, cosθ) -> Float64

计算末态费米子统计因子 (1 - f)，支持各向异性 PNJL：
- 当 ξ = 0 使用各向同性分布；
- 当 ξ ≠ 0 调用 `quark_distribution_aniso(p, m, μ, T, Φ, Φbar, ξ, cosθ)`，其中 cosθ 由 t 反解得到的质心系散射角。

# 参数

- `flavor::Symbol`: 粒子味道（用于区分夸克/反夸克）
- `E::Float64`: 粒子能量 [fm⁻¹]
- `m::Float64`: 粒子质量 [fm⁻¹]
- `μ::Float64`: 化学势 [fm⁻¹]
- `T::Float64`: 温度 [fm⁻¹]
- `Φ, Φbar::Float64`: Polyakov loop 及其共轭
- `ξ::Float64`: 各向异性参数（ξ=0 退化为各向同性）
- `cosθ::Float64`: 质心系散射角的余弦（由 t 反解得到的 θ*）

"""
function final_state_blocking_factor(
    flavor::Symbol,
    E::Float64,
    m::Float64,
    μ::Float64,
    T::Float64,
    Φ::Float64,
    Φbar::Float64,
    ξ::Float64,
    cosθ::Float64
)::Float64
    f::Float64 = 0.0  # default to avoid uninitialized path
    # 约定：这里传入的 μ 永远是“夸克化学势” μ_q。
    # 反夸克分布的 ± 号由 sign_flag 决定，而不是通过 μ 的正负来编码。
    if ξ == 0.0
        sign_flag = is_antiquark(flavor) ? :minus : :plus
        f = distribution_value(:pnjl, sign_flag, E, μ, T, Φ, Φbar)
    else
        p = momentum_from_energy(E, m)
        if is_antiquark(flavor)
            f = antiquark_distribution_aniso(p, m, μ, T, Φ, Φbar, ξ, cosθ)
        else
            f = quark_distribution_aniso(p, m, μ, T, Φ, Φbar, ξ, cosθ)
        end
    end

    # 数值误差下 f 可能略超出 [0,1]，这里钳制以避免 (1-f) 变负导致截面出现非物理解。
    f = clamp(f, 0.0, 1.0)
    return 1.0 - f
end

"""
    combined_final_state_factor(flavor_c, flavor_d, E_c, E_d, mc, md, μ_c, μ_d, T, Φ, Φbar, ξ, cosθ_star)

计算组合末态费米子统计因子 (1 - f_c)(1 - f_d)，在各向异性情形下使用 θ*→t 关系得到的角度：
- 出射粒子 c 使用 cosθ*；
- 出射粒子 d 反向，使用 -cosθ*。
"""
function combined_final_state_factor(
    flavor_c::Symbol,
    flavor_d::Symbol,
    E_c::Float64,
    E_d::Float64,
    mc::Float64,
    md::Float64,
    μ_c::Float64,
    μ_d::Float64,
    T::Float64,
    Φ::Float64,
    Φbar::Float64,
    ξ::Float64,
    cosθ_star::Float64
)::Float64
    factor_c = final_state_blocking_factor(flavor_c, E_c, mc, μ_c, T, Φ, Φbar, ξ, cosθ_star)
    factor_d = final_state_blocking_factor(flavor_d, E_d, md, μ_d, T, Φ, Φbar, ξ, -cosθ_star)
    return factor_c * factor_d
end

# ----------------------------------------------------------------------------
# 4. 辅助函数：粒子、质量和化学势
# ----------------------------------------------------------------------------

"""
    parse_particles_from_process(process) -> Tuple{Symbol, Symbol, Symbol, Symbol}

从过程名称解析出粒子类型 (i, j, c, d)。

# 参数

- `process::Symbol`: 过程标识（如 :uu_to_uu, :ud_to_dū, :us_to_us）

# 返回

`(particle_i, particle_j, particle_c, particle_d)`: 粒子味标识

# 示例

```julia
i, j, c, d = parse_particles_from_process(:uu_to_uu)
# 返回: (:u, :u, :u, :u)

i, j, c, d = parse_particles_from_process(:ud_to_dū)
# 返回: (:u, :d, :d, :ubar)
```
"""
function parse_particles_from_process(process::Symbol)::Tuple{Symbol, Symbol, Symbol, Symbol}
    # 统一使用 TotalPropagator 的解析逻辑（包含已知过程的缓存，且支持 "ū/đ/s̄" 形式）。
    q1, q2, q3, q4 = parse_scattering_process(process)
    return (q1, q2, q3, q4)
end

"""
    get_mass_for_flavor(flavor, quark_params) -> Float64

从 quark_params 获取指定味的夸克质量。

# 参数

- `flavor::Symbol`: 夸克味标识
- `quark_params::NamedTuple`: 夸克参数

# 返回

质量 [fm⁻¹]
"""
function get_mass_for_flavor(flavor::Symbol, quark_params::NamedTuple)::Float64
    if flavor === :u || flavor === :ubar
        return quark_params.m.u
    elseif flavor === :d || flavor === :dbar
        return quark_params.m.d
    elseif flavor === :s || flavor === :sbar
        return quark_params.m.s
    else
        error("Unknown flavor: $flavor")
    end
end

"""
    get_chemical_potential(flavor, quark_params) -> Float64

从 quark_params 获取指定味的化学势。

# 参数

- `flavor::Symbol`: 夸克味标识
- `quark_params::NamedTuple`: 夸克参数

# 返回

化学势 [fm⁻¹]

# 说明

本模块内部约定：始终返回“夸克化学势” μ_q（不对反夸克取负）。
反夸克的占据数由分布函数本身（通过 sign_flag 或 antiquark_distribution_*）来实现。
"""
function get_chemical_potential(flavor::Symbol, quark_params::NamedTuple)::Float64
    # 约定：这里返回的永远是“夸克化学势” μ_q（对应每个味 u/d/s），不对反夸克取负。
    # 反夸克的占据数由分布函数的 sign_flag（或 antiquark_distribution_*）负责处理。
    if flavor === :u || flavor === :ubar
        return quark_params.μ.u
    elseif flavor === :d || flavor === :dbar
        return quark_params.μ.d
    elseif flavor === :s || flavor === :sbar
        return quark_params.μ.s
    else
        error("Unknown flavor: $flavor")
    end
end

# ----------------------------------------------------------------------------
# 5. 核心函数：总散射截面计算
# ----------------------------------------------------------------------------

"""
    total_cross_section(process, s, quark_params, thermo_params, K_coeffs; n_points) -> Float64

计算给定 s 下的总散射截面 σ(s)。

# 公式

σ(s) = ∫_{t_-}^{t_+} dt · (dσ/dt) · (1 - f_c)(1 - f_d)

其中：
- dσ/dt: 微分散射截面
- (1 - f_c)(1 - f_d): 末态费米子统计因子（Pauli blocking）
- t_±: 由 calculate_t_bounds 计算

# 参数

- `process::Symbol`: 散射过程标识（如 :uu_to_uu）
- `s::Float64`: Mandelstam 变量 s [fm⁻²]
- `quark_params`: 夸克参数，可以是 `QuarkParams` 结构体或 NamedTuple（质量、化学势）
- `thermo_params`: 热力学参数，可以是 `ThermoParams` 结构体或 NamedTuple（T, Φ, Φbar）
- `K_coeffs::NamedTuple`: 有效耦合常数
- `n_points::Int=6`: 高斯-勒让德积分点数（默认 6 点）

# 返回

`σ(s)`: 总散射截面 [fm²]

# 计算流程

1. 获取过程信息（粒子类型）
2. 获取质量和化学势
3. 计算 t 积分边界
4. 生成高斯-勒让德积分节点和权重
5. 对每个 t 点计算被积函数：
    - 计算散射矩阵元 |M|²
    - 计算微分截面 dσ/dt
    - 计算费米子统计因子 (1-f_c)(1-f_d)
6. 加权求和得到积分结果

# 说明

- 本模块只考虑夸克-夸克散射（费米子），不涉及玻色子散射
- 使用高斯-勒让德积分（固定点数），计算时间可预测
- 积分点数 n_points 越大精度越高，但耗时线性增加

# 性能考虑

- 每个 t 点需要计算 |M|²（~50 ms）
- 总耗时 ≈ n_points × 50 ms
- n_points=6 时约 0.3 秒；n_points=16 时约 0.8 秒

# 示例

```julia
# 使用结构体（推荐）
q = QuarkParams(m=(u=1.52, d=1.52, s=3.04), μ=(u=0.3, d=0.3, s=0.3))
t = ThermoParams(0.15, 0.5, 0.5, 0.0)
σ = total_cross_section(:uu_to_uu, 31.0, q, t, K_coeffs, n_points=6)

# 使用 NamedTuple（向后兼容）
q_nt = (m=(u=1.52, d=1.52, s=3.04), μ=(u=0.3, d=0.3, s=0.3))
t_nt = (T=0.15, Φ=0.5, Φbar=0.5, ξ=0.0)
σ = total_cross_section(:uu_to_uu, 31.0, q_nt, t_nt, K_coeffs, n_points=6)
```
"""
function total_cross_section(
    process::Symbol,
    s::Float64,
    quark_params::NamedTuple,
    thermo_params::NamedTuple,
    K_coeffs::NamedTuple;
    n_points::Int=DEFAULT_T_INTEGRAL_POINTS,
    fast_path::Bool=true,
)::Float64
    return _total_cross_section_core(process, s, quark_params, thermo_params, K_coeffs; n_points=n_points, fast_path=fast_path)
end

function total_cross_section(
    process::Symbol,
    s::Float64,
    quark_params::Union{NamedTuple, QuarkParams},
    thermo_params::Union{NamedTuple, ThermoParams},
    K_coeffs::NamedTuple;
    n_points::Int=DEFAULT_T_INTEGRAL_POINTS,
    fast_path::Bool=true,
)::Float64
    quark_nt = normalize_quark_input(quark_params)
    thermo_nt = normalize_thermo_input(thermo_params)
    return _total_cross_section_core(process, s, quark_nt, thermo_nt, K_coeffs; n_points=n_points, fast_path=fast_path)
end

function _total_cross_section_core(
    process::Symbol,
    s::Float64,
    quark_params::NamedTuple,
    thermo_params::NamedTuple,
    K_coeffs::NamedTuple;
    n_points::Int=DEFAULT_T_INTEGRAL_POINTS,
    fast_path::Bool=true,
)::Float64
    # 步骤1: 预解析过程上下文（热点路径复用）
    ctx = prepare_scattering_context(process, quark_params)
    particle_i = ctx.particle_i
    particle_j = ctx.particle_j
    particle_c = ctx.particle_c
    particle_d = ctx.particle_d

    # 步骤2: 获取质量和化学势
    mi = ctx.m1
    mj = ctx.m2
    mc = ctx.m3
    md = ctx.m4
    
    μ_c = get_chemical_potential(particle_c, quark_params)
    μ_d = get_chemical_potential(particle_d, quark_params)

    # 步骤2.5: 运动学阈值检查；s 低于阈值时截面为 0（避免抛错导致 NaN）
    valid_initial = check_kinematic_threshold(
        s, mi, mj;
        warn_close=false,
        mode=kinematic_error_mode(),
        context="Initial state kinematic violation",
    )
    valid_final = check_kinematic_threshold(
        s, mc, md;
        warn_close=false,
        mode=kinematic_error_mode(),
        context="Final state kinematic violation",
    )
    if !(valid_initial && valid_final)
        return 0.0
    end
    
    # 步骤3: 计算 t 积分边界
    t_bounds = calculate_t_bounds(s, mi, mj, mc, md)
    t_min = t_bounds.t_min
    t_max = t_bounds.t_max

    # 相同粒子散射的对称因子：当出射粒子相同时，t积分范围减半
    # 这是因为相同粒子的不可区分性（与Fortran一致）
    if particle_c == particle_d
        t_min = t_min / 2.0
    end

    # 极近阈值时 t 区间可能退化为零宽度；此时贡献为 0，避免高斯节点报错
    if t_max - t_min <= EPS_KINEMATIC
        return 0.0
    end
    
    # 步骤4: 使用标准区间节点/权重并做仿射变换（避免分配 t_nodes/t_weights）
    nodes_std, weights_std = standard_nodes_weights(n_points)
    scale_t = (t_max - t_min) / 2.0
    shift_t = (t_max + t_min) / 2.0
    
    # 步骤5: 预计算 s 依赖的 Mandelstam 变量
    s_12_plus = s - (mi + mj)^2
    s_12_minus = s - (mi - mj)^2
    
    # 步骤6: 热力学参数
    T = thermo_params.T
    Φ = thermo_params.Φ
    Φbar = thermo_params.Φbar
    ξ = hasproperty(thermo_params, :ξ) ? thermo_params.ξ : 0.0

    # 步骤6.5: 末态能量（与 t 无关）
    E_c, E_d = calculate_final_state_energies(s, mc, md)

    # 步骤6.6: 各向同性时末态统计因子与 t 无关，可预计算
    blocking_factor_const = ξ == 0.0 ? combined_final_state_factor(
        particle_c, particle_d,
        E_c, E_d,
        mc, md,
        μ_c, μ_d,
        T, Φ, Φbar,
        ξ, 0.0
    ) : 0.0
    
    # 步骤7: 对 t 积分（高斯求积）
    σ = 0.0
    @inbounds for i in 1:n_points
        t = scale_t * nodes_std[i] + shift_t
        w = scale_t * weights_std[i]
        
        # 7.1 计算散射矩阵元
        M_squared = if fast_path
            scattering_amplitude_squared_prepared(
                ctx, s, t, quark_params, thermo_params, K_coeffs
            )
        else
            scattering_amplitude_squared(
                process, s, t, quark_params, thermo_params, K_coeffs
            )
        end

        if !isfinite(M_squared)
            continue
        end
        if M_squared < 0.0
            M_squared = 0.0
        end
        
        # 7.2 计算微分截面
        dsigma_dt = differential_cross_section(
            s_12_plus, s_12_minus, M_squared
        )

        if !isfinite(dsigma_dt)
            continue
        end
        if dsigma_dt < 0.0
            dsigma_dt = 0.0
        end
        
        # 7.3 计算末态能量与角度
        # 7.4 计算末态统计因子（费米子，含各向异性）
        if ξ == 0.0
            blocking_factor = blocking_factor_const
        else
            cosθ_star = cos_theta_star(s, t, mi, mj, mc, md)
            blocking_factor = combined_final_state_factor(
                particle_c, particle_d,
                E_c, E_d,
                mc, md,
                μ_c, μ_d,
                T, Φ, Φbar,
                ξ, cosθ_star
            )
        end

        if !isfinite(blocking_factor)
            continue
        end
        if blocking_factor < 0.0
            blocking_factor = 0.0
        end
        
        # 7.5 累加
        term = w * dsigma_dt * blocking_factor
        if isfinite(term)
            σ += term
        end
    end
    
    return σ
end

# ----------------------------------------------------------------------------
# 6. 批量计算与 s 扫描
# ----------------------------------------------------------------------------

"""
    calculate_all_total_cross_sections(s, quark_params, thermo_params, K_coeffs; n_points) -> NamedTuple

计算给定 s 下所有散射过程的总截面。

# 参数

与 `total_cross_section` 相同，但不需要指定 `process`
- `quark_params`: 夸克参数，可以是 `QuarkParams` 结构体或 NamedTuple
- `thermo_params`: 热力学参数，可以是 `ThermoParams` 结构体或 NamedTuple

# 返回

`NamedTuple{Symbol, Float64}`: 所有过程的总截面

# 示例

```julia
# 使用结构体（推荐）
q = QuarkParams(m=(u=1.52, d=1.52, s=3.04), μ=(u=0.3, d=0.3, s=0.3))
t = ThermoParams(0.15, 0.5, 0.5, 0.0)
all_σ = calculate_all_total_cross_sections(31.0, q, t, K_coeffs, n_points=6)

# 使用 NamedTuple（向后兼容）
q_nt = (m=(u=1.52, d=1.52, s=3.04), μ=(u=0.3, d=0.3, s=0.3))
t_nt = (T=0.15, Φ=0.5, Φbar=0.5, ξ=0.0)
all_σ = calculate_all_total_cross_sections(31.0, q_nt, t_nt, K_coeffs, n_points=6)

println("uu→uu: \$(all_σ.uu_to_uu) fm²")
println("dd→dd: \$(all_σ.dd_to_dd) fm²")
```
"""
function calculate_all_total_cross_sections_detailed(
    s::Float64,
    quark_params::Union{NamedTuple, QuarkParams},
    thermo_params::Union{NamedTuple, ThermoParams},
    K_coeffs::NamedTuple;
    n_points::Int=DEFAULT_T_INTEGRAL_POINTS,
    fast_path::Bool=true,
)::NamedTuple
    quark_nt = normalize_quark_input(quark_params)
    thermo_nt = normalize_thermo_input(thermo_params)
    results = Dict{Symbol, CrossSectionEvaluationResult}()

    for process in keys(SCATTERING_MESON_MAP)
        results[process] = _capture_cross_section_evaluation() do
            total_cross_section(
                process, s, quark_nt, thermo_nt, K_coeffs,
                n_points=n_points,
                fast_path=fast_path,
            )
        end
    end

    return NamedTuple(results)
end

function calculate_all_total_cross_sections(
    s::Float64,
    quark_params::Union{NamedTuple, QuarkParams},
    thermo_params::Union{NamedTuple, ThermoParams},
    K_coeffs::NamedTuple;
    n_points::Int=DEFAULT_T_INTEGRAL_POINTS,
    fast_path::Bool=true,
    on_error::Symbol=:throw,
)::NamedTuple
    detailed = calculate_all_total_cross_sections_detailed(
        s,
        quark_params,
        thermo_params,
        K_coeffs;
        n_points=n_points,
        fast_path=fast_path,
    )

    values = Dict{Symbol, Float64}()
    for (process, result) in pairs(detailed)
        values[process] = _materialize_cross_section_value(
            result,
            "Failed to calculate $(process)";
            on_error=on_error,
        )
    end
    return NamedTuple(values)
end

"""
    scan_s_dependence(s_values, process, quark_params, thermo_params, K_coeffs; n_points) -> Vector{Float64}

扫描总散射截面随 s 的变化：σ(s)。

# 参数

- `s_values::Vector{Float64}`: s 值数组 [fm⁻²]
- 其他参数与 `total_cross_section` 相同
- `quark_params`: 夸克参数，可以是 `QuarkParams` 结构体或 NamedTuple
- `thermo_params`: 热力学参数，可以是 `ThermoParams` 结构体或 NamedTuple

# 返回

`σ_values::Vector{Float64}`: 对应的总截面 [fm²]

# 示例

```julia
# 使用结构体（推荐）
q = QuarkParams(m=(u=1.52, d=1.52, s=3.04), μ=(u=0.3, d=0.3, s=0.3))
t = ThermoParams(0.15, 0.5, 0.5, 0.0)
s_values = collect(range(10.0, 50.0, length=20))
σ_values = scan_s_dependence(s_values, :uu_to_uu, q, t, K_coeffs, n_points=6)

# 使用 NamedTuple（向后兼容）
q_nt = (m=(u=1.52, d=1.52, s=3.04), μ=(u=0.3, d=0.3, s=0.3))
t_nt = (T=0.15, Φ=0.5, Φbar=0.5, ξ=0.0)
σ_values = scan_s_dependence(s_values, :uu_to_uu, q_nt, t_nt, K_coeffs, n_points=6)
```
"""
function scan_s_dependence_detailed(
    s_values::Vector{Float64},
    process::Symbol,
    quark_params::Union{NamedTuple, QuarkParams},
    thermo_params::Union{NamedTuple, ThermoParams},
    K_coeffs::NamedTuple;
    n_points::Int=DEFAULT_T_INTEGRAL_POINTS,
    fast_path::Bool=true,
)::Vector{CrossSectionEvaluationResult}
    quark_nt = normalize_quark_input(quark_params)
    thermo_nt = normalize_thermo_input(thermo_params)
    σ_values = CrossSectionEvaluationResult[]

    for s in s_values
        push!(σ_values, _capture_cross_section_evaluation() do
            total_cross_section(
                process, s, quark_nt, thermo_nt, K_coeffs,
                n_points=n_points,
                fast_path=fast_path,
            )
        end)
    end

    return σ_values
end

function scan_s_dependence(
    s_values::Vector{Float64},
    process::Symbol,
    quark_params::Union{NamedTuple, QuarkParams},
    thermo_params::Union{NamedTuple, ThermoParams},
    K_coeffs::NamedTuple;
    n_points::Int=DEFAULT_T_INTEGRAL_POINTS,
    fast_path::Bool=true,
    on_error::Symbol=:throw,
)::Vector{Float64}
    detailed = scan_s_dependence_detailed(
        s_values,
        process,
        quark_params,
        thermo_params,
        K_coeffs;
        n_points=n_points,
        fast_path=fast_path,
    )

    σ_values = Float64[]
    for (idx, result) in enumerate(detailed)
        push!(
            σ_values,
            _materialize_cross_section_value(
                result,
                "Failed to calculate σ at index=$(idx), s=$(s_values[idx])";
                on_error=on_error,
            ),
        )
    end
    return σ_values
end

end  # module TotalCrossSection
