# Analysis-only equal-mass k=0 principal-value oracle and threshold diagnostics.
if !isdefined(Main, :TransportReviewCommon)
    include(joinpath(@__DIR__, "TransportReviewCommon.jl"))
end
if !isdefined(Main, :FullRSKZero)
    include(joinpath(@__DIR__, "FullRSKZero.jl"))
end

module MottThresholdProbe

using Main.TransportReviewCommon
using Main.FullRSKZero
using Main.PNJLQuarkDistributions_Aniso: distribution_aniso
using LinearAlgebra

export pair_b0, polarizations, response, local_state, critical_state,
       selected_row, threshold_data, projected_sigma, q_integral

const RT = Main.RelaxTime
const NC = Main.Constants_PNJL.N_color
const CUTOFF = Main.Constants_PNJL.Λ_inv_fm

function occupation_F(p, m, mu, tp; linear=true)
    angular = FullRSKZero.quadrature(32)
    fq = distribution_aniso(:quark,p,m,mu,tp.T,tp.Φ,tp.Φbar,0.0,0.0) +
        FullRSKZero.occupation_difference(:quark,p,m,mu,tp.T,tp.Φ,tp.Φbar,tp.ξ,angular;linear=linear)
    fa = distribution_aniso(:antiquark,p,m,mu,tp.T,tp.Φ,tp.Φbar,0.0,0.0) +
        FullRSKZero.occupation_difference(:antiquark,p,m,mu,tp.T,tp.Φ,tp.Φbar,tp.ξ,angular;linear=linear)
    return (1-fq-fa)/hypot(p,m)
end

"""Same equal-mass, k=0 loop in p coordinates; analytic endpoint and PV term.

B0(s)=2∫dp p² F(p)/(p²-(s-4m²)/4). The legacy positive-energy cut
has Im B0=+π q F(q). No complex-energy/finite-k extension is implied.
"""
function pair_b0(s::Float64,m::Float64,mu::Float64,tp; n::Int=256,linear=true)
    m>0 && s>0 || throw(ArgumentError("positive mass and energy required"))
    z,w = FullRSKZero.quadrature(n)
    x = s-4m^2
    f0 = occupation_F(0.0,m,mu,tp;linear=linear)
    threshold = 0.0
    regular = 0.0
    if x>0
        q=sqrt(x)/2
        q<CUTOFF || throw(DomainError(q,"probe is restricted below the UV endpoint"))
        fq=occupation_F(q,m,mu,tp;linear=linear)
        for (zi,wi) in zip(z,w)
            p=(zi+1)*CUTOFF/2; weight=wi*CUTOFF/2
            fp=occupation_F(p,m,mu,tp;linear=linear)
            threshold += 2weight*fp
            denominator=p^2-q^2
            value = if abs(denominator)<32eps(max(p^2,q^2,1.0))
                h=max(1e-6*q,1e-8)
                (occupation_F(q+h,m,mu,tp;linear=linear)-occupation_F(max(q-h,0.0),m,mu,tp;linear=linear))/(4q*h)
            else
                (fp-fq)/denominator
            end
            regular += weight*value
        end
        analytic=fq/(2q)*log1p(-2q/(CUTOFF+q))
        return complex(threshold+2q^2*(regular+analytic),π*q*fq)
    elseif x<0
        kappa=sqrt(-x)/2
        for (zi,wi) in zip(z,w)
            p=(zi+1)*CUTOFF/2;weight=wi*CUTOFF/2
            fp=occupation_F(p,m,mu,tp;linear=linear)
            threshold += 2weight*fp
            regular += weight*(fp-f0)/(p^2+kappa^2)
        end
        return complex(threshold-2kappa^2*regular-2kappa*f0*atan(CUTOFF/kappa),0.0)
    else
        for (zi,wi) in zip(z,w)
            p=(zi+1)*CUTOFF/2
            threshold += wi*CUTOFF*occupation_F(p,m,mu,tp;linear=linear)
        end
        return complex(threshold,0.0)
    end
end

function polarizations(state,s; scheme=:paired_pv,n=256)
    qp,tp=state.quark_params,state.thermo_params
    function one(flavor)
        m=getproperty(qp.m,flavor);mu=getproperty(qp.μ,flavor);a=getproperty(qp.A,flavor)
        if scheme===:production
            pol(ch)=complex(RT.PolarizationAniso.polarization_aniso(
                ch,sqrt(s),0.0,m,m,mu,mu,tp.T,tp.Φ,tp.Φbar,tp.ξ,a,a,0)...)
            return (P=pol(:P),S=pol(:S),B=complex(NaN,NaN))
        end
        b=pair_b0(s,m,mu,tp;n=n)
        return (P=-NC/(8π^2)*(2a-s*b), S=-NC/(8π^2)*(2a+(4m^2-s)*b),B=b)
    end
    return (u=one(:u),s=one(:s))
end

function response(state,s;scheme=:paired_pv,n=256)
    pol=polarizations(state,s;scheme=scheme,n=n);kc=state.K_coeffs
    mm=RT.EffectiveCouplings.mixing_matrix_elements(pol.u.P,pol.s.P,kc,:P)
    det=mm.M00*mm.M88-mm.M08^2
    dn=det/kc.det_K_plus
    guarded=RT.MesonPropagator.meson_propagator_mixed(kc.det_K_plus,
        mm.M00,mm.M08,mm.M88,:u,:ubar,:u,:ubar,:s)
    epsden=RT.MesonPropagator.PROPAGATOR_DENOM_EPS
    used_det=abs(det)<epsden ? det+complex(0.0,epsden) : det
    numerator=guarded*used_det/kc.det_K_plus
    dmix=scheme===:production ? guarded : numerator/dn
    dpi=1-4kc.K123_plus*pol.u.P
    dscalar=1-4kc.K123_minus*pol.u.S
    return (pol=pol,pi_den=dpi,mixed_den=dn,scalar_den=dscalar,
        pi_D=2kc.K123_plus/dpi,mixed_D=dmix,
        mixed_numerator=numerator,matrix=mm)
end

function selected_row(xi)
    candidates=[r for r in read_points() if String(r.review_mode)=="mode_a" &&
        String(r.plot_panel)=="muB0.0" && String(r.plot_series)=="alpha1.0"]
    row=candidates[argmin(abs.(Float64[r.xi for r in candidates].-xi))]
    abs(row.xi-xi)<1e-8 || error("missing retained input at xi=$xi")
    return row
end

function local_state(row,xi;nodes=24,angles=8)
    seed=base_from_row(row)
    base=Main.Models.solve(MODEL,Main.Models.FixedMu(),Float64(row.T_fm),Float64(row.muq_fm);
        seed_guess=seed.x_state,xi=xi,p_num=nodes,t_num=angles,residual_norm_max=1e-7)
    base.converged || error("local background failed at xi=$xi")
    modified=merge(NamedTuple(row),(xi=xi,))
    return (state=state_from_base(base,modified),base=base,row=modified)
end

function threshold_data(state,family;n=256)
    s0=4state.quark_params.m.u^2
    r=response(state,s0;n=n)
    delta=family===:pi ? real(r.pi_den) : real(r.mixed_den)
    h=s0*1e-8
    below=response(state,s0-h;n=n)
    c=((family===:pi ? real(below.pi_den) : real(below.mixed_den))-delta)/sqrt(h)
    return (s0=s0,delta=delta,c=c,response=r)
end

function critical_state(row,family,lo,hi;n=256)
    function at(xi)
        loc=local_state(row,xi)
        return (location=loc,threshold=threshold_data(loc.state,family;n=n))
    end
    left=at(lo);right=at(hi)
    left.threshold.delta*right.threshold.delta<0 || error("critical root not bracketed")
    for _ in 1:36
        mid=(lo+hi)/2;v=at(mid)
        if signbit(v.threshold.delta)==signbit(left.threshold.delta)
            lo=mid;left=v
        else
            hi=mid;right=v
        end
    end
    v=at((lo+hi)/2)
    return merge(v,(xi=(lo+hi)/2,bracket=(lo,hi)))
end

function projected_sigma(state,s,family;n=256)
    r=response(state,s;n=n)
    d=family===:pi ? r.pi_D : r.mixed_D
    q=sqrt(max(s-4state.quark_params.m.u^2,0.0))/2
    tp=state.thermo_params;m=state.quark_params.m.u;mu=state.quark_params.μ.u
    z,w=FullRSKZero.quadrature(16)
    blocking=0.0
    for (ct,wt) in zip(z,w)
        fq=distribution_aniso(:quark,q,m,mu,tp.T,tp.Φ,tp.Φbar,tp.ξ,ct)
        fa=distribution_aniso(:antiquark,q,m,mu,tp.T,tp.Φ,tp.Φbar,tp.ξ,ct)
        blocking += wt*(1-fq)*(1-fa)/2
    end
    return s*abs2(d)/(16π)*blocking
end

"""Threshold-weight integral ∫_xmin^X dx x σ_s,P(x), not a full thermal rate."""
function q_integral(state,family,X;nq=96,nloop=256,xmin=0.0)
    s0=4state.quark_params.m.u^2
    lo=sqrt(xmin)/2;hi=sqrt(X)/2
    z,w=FullRSKZero.quadrature(nq)
    sum(wi*(hi-lo)/2*32q^3*projected_sigma(state,s0+4q^2,family;n=nloop)
        for (zi,wi) in zip(z,w) for q in (lo+(zi+1)*(hi-lo)/2,))
end

end
