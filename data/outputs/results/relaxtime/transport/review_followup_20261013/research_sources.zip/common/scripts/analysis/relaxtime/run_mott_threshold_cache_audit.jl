#!/usr/bin/env julia
include(joinpath(@__DIR__,"MottThresholdProbe.jl"))
using .TransportReviewCommon, .MottThresholdProbe
const AS=Main.RelaxTime.AverageScatteringRate
const CS=Main.RelaxTime.TotalCrossSection

function main(outdir)
    isfile(joinpath(outdir,"manifest.json")) && error("use a new output directory")
    write_json(joinpath(outdir,"manifest.json"),run_metadata(@__FILE__,
        (scope="full uubar elastic cross section: direct versus production cache",
         xis=(0.36,0.37,0.38),grids=(560,1120),t_nodes=(24,48),
         weights="integral dx x sigma; local threshold diagnostic, not full thermal rate",
         production_modified=false)))
    samples=NamedTuple[];integrals=NamedTuple[];cacheinfo=NamedTuple[]
    for xi in (0.36,0.37,0.38)
        println("CACHE ",xi);flush(stdout)
        state=state_from_row(selected_row(xi));qp,tp,kc=state.quark_params,state.thermo_params,state.K_coeffs
        s0=4qp.m.u^2
        caches=Dict{Int,Any}()
        for N in (560,1120)
            cache=AS.build_w0cdf_pchip_cache(:uubar_to_uubar,qp,tp,kc;N=N,
                p_cutoff=Main.Constants_PNJL.Λ_inv_fm,n_sigma_points=24,
                threshold_subtraction=true,asym_window=0.6,asym_fit_min_points=8,
                asym_extra_points=10,sigma_cache_policy=:validated_anchored)
            caches[N]=cache
            push!(cacheinfo,(xi=xi,N=N,total_nodes=length(cache.s_vals),
                min_offset=minimum(cache.s_vals)-s0,asym_A=cache.asym_A,asym_enabled=cache.asym_enabled))
        end
        cached(N,x)=AS._get_sigma_core(caches[N],s0+x,qp,tp,kc;n_points=24,interpolation_mode=:linear)
        direct(nt,x)=CS.total_cross_section(:uubar_to_uubar,s0+x,qp,tp,kc;n_points=nt)
        for exponent in -10.0:0.2:-0.1
            x=s0*10.0^exponent
            lo=direct(24,x);hi=direct(48,x)
            push!(samples,(xi=xi,x=x,epsilon=x/s0,sigma_direct24=lo,sigma_direct48=hi,
                sigma_cache560=cached(560,x),sigma_cache1120=cached(1120,x)))
        end
        for X in (s0*1e-4,0.01,0.1,0.6), nq in (64,128)
            z,w=Main.FullRSKZero.quadrature(nq)
            totals=zeros(4)
            for (zi,wi) in zip(z,w)
                q=(zi+1)*sqrt(X)/4
                x=4q^2;weight=wi*sqrt(X)/4*32q^3
                totals .+= weight.*(direct(24,x),direct(48,x),cached(560,x),cached(1120,x))
            end
            push!(integrals,(xi=xi,X=X,nq=nq,direct24=totals[1],direct48=totals[2],
                cache560=totals[3],cache1120=totals[4]))
        end
        write_rows(joinpath(outdir,"sigma_profiles.csv"),samples)
        write_rows(joinpath(outdir,"weighted_integrals.csv"),integrals)
        write_rows(joinpath(outdir,"cache_parameters.csv"),cacheinfo)
    end
    write_json(joinpath(outdir,"status.json"),(complete=true,profiles=length(samples),integrals=length(integrals)))
    println("COMPLETE ",outdir)
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && main(abspath(only(ARGS)))
