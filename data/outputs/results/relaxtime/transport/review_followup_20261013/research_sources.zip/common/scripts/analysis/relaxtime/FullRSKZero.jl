"""Analysis-only RS occupation resummation at k=0.

Keep the existing on-shell denominators, cutoff, B0 cut convention and isotropic
baseline. Integrate the *difference* between the full RS and isotropic thermal
occupations with a principal-value subtraction and an analytic residue. This is
not a non-collinear k>0 kernel or a new analytic continuation in complex energy.
"""
module FullRSKZero

using Main.RelaxTime.GaussLegendre: gauleg
using Main.RelaxTime.OneLoopIntegrals: B0, energy_cutoff
using Main.PNJLQuarkDistributions_Aniso: distribution_aniso, correction_cos_theta_coefficient

export B0_rs_k0, delta_B0_rs_k0, delta_tilde_rs_k0, polarization_rs_k0,
    B0_pair_threshold_rs

const QUADRATURE = Dict{Int, Tuple{Vector{Float64}, Vector{Float64}}}()
quadrature(n::Int) = get!(QUADRATURE, n) do
    n >= 8 || throw(ArgumentError("quadrature node count must be >= 8"))
    gauleg(-1.0, 1.0, n)
end

function check_inputs(λ, m, mp, μ, T, Φ, Φbar, ξ)
    all(isfinite, (λ, m, mp, μ, T, Φ, Φbar, ξ)) || throw(ArgumentError("all inputs must be finite"))
    T > 0 || throw(ArgumentError("T must be positive"))
    m >= 0 && mp >= 0 || throw(ArgumentError("masses must be nonnegative"))
    ξ > -1 || throw(ArgumentError("RS requires xi > -1"))
    abs(λ) > 1e-10 || throw(ArgumentError("lambda=0 requires a separate static-limit formula"))
end

function occupation_difference(mode, p, m, μ, T, Φ, Φbar, ξ, angular; linear=false)
    if linear
        return correction_cos_theta_coefficient(mode, p, m, μ, T, Φ, Φbar, ξ) / 3
    end
    ξ == 0 && return 0.0
    nodes, weights = angular
    iso = distribution_aniso(mode, p, m, μ, T, Φ, Φbar, 0.0, 0.0)
    total = 0.0
    for (x, w) in zip(nodes, weights)
        total += w * (distribution_aniso(mode, p, m, μ, T, Φ, Φbar, ξ, x) - iso)
    end
    return total / 2
end

"""One physical particle/antiparticle thermal correction; units are fm^-1.

The four such terms enter delta_B0 with positive signs, because the negative
energy occupation in the existing B0 is 1-f_antiquark. At the lower threshold
the p(E) numerator vanishes. E=m+(Emax-m)y^2 resolves its square-root endpoint.
An upper-cutoff pole with nonzero residue has a divergent real part and is
reported as a DomainError rather than replaced by a finite number.
"""
function delta_tilde_rs_k0(mode::Symbol, λ::Float64, m::Float64, mp::Float64,
    μ::Float64, T::Float64, Φ::Float64, Φbar::Float64, ξ::Float64;
    energy_nodes::Int=128, angle_nodes::Int=32, linear::Bool=false)
    mode in (:quark, :antiquark) || throw(ArgumentError("mode must be quark or antiquark"))
    check_inputs(λ, m, mp, μ, T, Φ, Φbar, ξ)
    angular = quadrature(angle_nodes)
    nodes, weights = quadrature(energy_nodes)
    ξ == 0 && return (0.0, 0.0)
    Emax = energy_cutoff(m)
    span = Emax - m
    c = (λ^2 + m^2 - mp^2) / 2
    E0 = -c / λ
    inside = m <= E0 <= Emax
    numer(E) = sqrt(max((E-m)*(E+m), 0.0)) * occupation_difference(
        mode, sqrt(max((E-m)*(E+m), 0.0)), m, μ, T, Φ, Φbar, ξ, angular; linear=linear)
    f0 = inside ? numer(E0) : 0.0
    # A mathematically exact endpoint may round one ulp outside the interval.
    # Classify it before the inside test to avoid returning a grid-dependent
    # finite value for the logarithmically divergent upper endpoint.
    if abs(Emax-E0) <= 64eps(Emax) && numer(Emax) != 0
        throw(DomainError(E0, "pole coincides with the upper cutoff"))
    end
    integral = 0.0
    for (x, w) in zip(nodes, weights)
        y = (x+1)/2
        E = m + span*y^2
        jac_weight = w*span*y
        if inside
            d = E-E0
            value = if abs(d) <= 64eps(max(abs(E0), 1.0))
                h = min(1e-5*span, (E0-m)/2, (Emax-E0)/2)
                h > 0 || throw(DomainError(E0, "unresolved endpoint derivative"))
                (numer(E0+h)-numer(E0-h))/(2h)
            else
                (numer(E)-f0)/d
            end
            integral += jac_weight*value/λ
        else
            integral += jac_weight*numer(E)/(λ*E+c)
        end
    end
    if inside && f0 != 0
        integral += f0/λ * log(abs((Emax-E0)/(E0-m)))
    end
    residue = inside ? 2π*f0/λ : 0.0
    result = (2integral, residue)
    all(isfinite, result) || throw(DomainError(result, "nonfinite principal value or residue"))
    return result
end

function delta_B0_rs_k0(λ::Float64, m1::Float64, μ1::Float64, m2::Float64,
    μ2::Float64, T::Float64, Φ::Float64, Φbar::Float64, ξ::Float64; kwargs...)
    a = delta_tilde_rs_k0(:quark, -λ, m1, m2, μ1, T, Φ, Φbar, ξ; kwargs...)
    b = delta_tilde_rs_k0(:antiquark, λ, m1, m2, μ1, T, Φ, Φbar, ξ; kwargs...)
    c = delta_tilde_rs_k0(:quark, λ, m2, m1, μ2, T, Φ, Φbar, ξ; kwargs...)
    d = delta_tilde_rs_k0(:antiquark, -λ, m2, m1, μ2, T, Φ, Φbar, ξ; kwargs...)
    return (a[1]+b[1]+c[1]+d[1], a[2]+b[2]+c[2]+d[2])
end

function B0_rs_k0(λ::Float64, m1::Float64, μ1::Float64, m2::Float64,
    μ2::Float64, T::Float64; Φ::Float64=0.0, Φbar::Float64=0.0, ξ::Float64=0.0, kwargs...)
    check_inputs(λ, m1, m2, μ1, T, Φ, Φbar, ξ)
    base = B0(λ, 0.0, m1, μ1, m2, μ2, T; Φ=Φ, Φbar=Φbar)
    delta = delta_B0_rs_k0(λ, m1, μ1, m2, μ2, T, Φ, Φbar, ξ; kwargs...)
    return (base[1]+delta[1], base[2]+delta[2])
end

"""Real-axis B0 with the same width prefactor and strange-channel symmetry as
the production polarization. This preserves its width approximation; it does
not evaluate B0 at complex energy. Only the RS occupation expansion is changed.
"""
function polarization_rs_k0(channel::Symbol, k0::Float64, gamma::Float64,
    m1::Float64, m2::Float64, μ1::Float64, μ2::Float64, T::Float64,
    Φ::Float64, Φbar::Float64, ξ::Float64, A1::Float64, A2::Float64,
    num_s_quark::Int; kwargs...)
    channel in (:P,:S) || throw(ArgumentError("channel must be P or S"))
    λ = k0+μ1-μ2
    b = B0_rs_k0(λ,m1,μ1,m2,μ2,T; Φ=Φ,Φbar=Φbar,ξ=ξ,kwargs...)
    if num_s_quark == 1
        extra = B0_rs_k0(-k0+μ1-μ2,m1,μ1,m2,μ2,T; Φ=Φ,Φbar=Φbar,ξ=ξ,kwargs...)
        b = ((b[1]+extra[1])/2,(b[2]+extra[2])/2)
    end
    pref = -λ^2 + (channel === :P ? (m1-m2)^2 : (m1+m2)^2) + gamma^2/4
    value = complex(A1+A2,0.0) + complex(pref,gamma*λ)*complex(b...)
    factor = -Main.Constants_PNJL.N_color/(8π^2)
    (factor*real(value),factor*imag(value))
end

"""Exact lower pair endpoint at equal quark chemical potentials.

For equal masses, B0(2m,0)=2∫₀^Λ dp (1-fq-faq)/E. For unequal masses this
returns the same +/- energy symmetrization used by the production K channel:
2/(m1+m2) ∫₀^Λ dp [m1(1-f1-fbar1)/E1 + m2(1-f2-fbar2)/E2].
The p-variable removes the integrable endpoint. No regulator gap is removed.
The imaginary part vanishes at this endpoint. Only use this formula for the
equal-mass channel or the explicitly symmetrized unequal-mass channel.
"""
function B0_pair_threshold_rs(m1::Float64,m2::Float64,μ::Float64,T::Float64,
    Φ::Float64,Φbar::Float64,ξ::Float64; energy_nodes::Int=128,angle_nodes::Int=32,linear::Bool=false)
    check_inputs(m1+m2,m1,m2,μ,T,Φ,Φbar,ξ)
    m1>0 && m2>0 || throw(ArgumentError("threshold formula requires positive masses"))
    angular=quadrature(angle_nodes)
    nodes,weights=quadrature(energy_nodes)
    cutoff=Main.Constants_PNJL.Λ_inv_fm
    total=0.0
    for (x,w) in zip(nodes,weights)
        p=(x+1)*cutoff/2
        for m in (m1,m2)
            fq=distribution_aniso(:quark,p,m,μ,T,Φ,Φbar,0.0,0.0)+
                occupation_difference(:quark,p,m,μ,T,Φ,Φbar,ξ,angular;linear=linear)
            fa=distribution_aniso(:antiquark,p,m,μ,T,Φ,Φbar,0.0,0.0)+
                occupation_difference(:antiquark,p,m,μ,T,Φ,Φbar,ξ,angular;linear=linear)
            total += w*cutoff/2*m*(1-fq-fa)/hypot(p,m)
        end
    end
    2total/(m1+m2)
end

end
