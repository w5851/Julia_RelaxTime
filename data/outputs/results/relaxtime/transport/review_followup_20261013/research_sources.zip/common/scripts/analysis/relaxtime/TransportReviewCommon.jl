#= Shared, analysis-only inputs for the October 2026 transport review.

States are reconstructed from the retained production CSV, not re-solved at a
rounded temperature. Couplings and A fields follow the production conventions.
=#
if !isdefined(Main, :Models)
    include(joinpath(@__DIR__, "..", "..", "..", "src", "models", "Models.jl"))
end
if !isdefined(Main, :RelaxTime)
    include(joinpath(@__DIR__, "..", "..", "..", "src", "relaxtime", "RelaxTime.jl"))
end

module TransportReviewCommon

using CSV, JSON, SHA, Dates, NLsolve, StaticArrays
using Main: Models, RelaxTime
using Main.Constants_PNJL: ħc_MeV_fm, G_fm2, K_fm5

export ROOT, INPUT, CASE, HC, SPECIES, MODEL, read_points, point_id, point_fields,
    state_from_row, base_from_row, production_tau, densities_from_row, tau_config,
    write_json, write_rows, state_from_base, run_metadata, relative_change,
    transport_for_tau, bulk_for_base, checkpoint

const ROOT = normpath(joinpath(@__DIR__, "..", "..", ".."))
const INPUT = joinpath(ROOT, "data", "outputs", "results", "relaxtime", "transport", "review_followup_20261013")
const CASE = "first_canonical_v2_p128_xi001_onshellkernel_validated_anchored_prod_v2"
const HC = ħc_MeV_fm
const SPECIES = (:u, :d, :s, :ubar, :dbar, :sbar)
const MODEL = Models.create_model(:PNJL)
const A_CONFIG = (p_nodes=16, p_max=20.0, cos_nodes=4, use_aniso=true)
const RT = RelaxTime

read_points() = collect(CSV.File(joinpath(INPUT, "review_points.csv")))
point_id(row) = replace("$(row.review_mode)_$(row.plot_panel)_$(row.plot_series)_xi$(row.xi)", "."=>"p", "-"=>"m")
point_fields(row) = (point_id=point_id(row), mode=String(row.review_mode),
    plot_panel=String(row.plot_panel), plot_series=String(row.plot_series),
    T_MeV=Float64(row.T_MeV), muB_MeV=Float64(row.muB_MeV), xi=Float64(row.xi))
relative_change(a, b) = (a-b)/max(abs(b), 1e-300)

json_safe(x::AbstractFloat) = isfinite(x) ? x : nothing
json_safe(x::NamedTuple) = Dict(string(k)=>json_safe(v) for (k,v) in pairs(x))
json_safe(x::AbstractDict) = Dict(string(k)=>json_safe(v) for (k,v) in pairs(x))
json_safe(x::Union{Tuple,AbstractVector}) = [json_safe(v) for v in x]
json_safe(x::Symbol) = string(x)
json_safe(x) = x

function write_json(path, value)
    mkpath(dirname(path))
    temporary=path*".writing"
    open(temporary, "w") do io
        JSON.print(io, json_safe(value), 2)
        println(io)
    end
    mv(temporary,path;force=true)
end

function write_rows(path, rows)
    isempty(rows) && return
    mkpath(dirname(path))
    CSV.write(path, rows)
end

function checkpoint(outdir, name, value)
    write_json(joinpath(outdir, "points", name*".json"), value)
    println("SAVED ", name)
    flush(stdout)
end

function state_from_row(row)
    qp0 = (m=(u=Float64(row.m_u), d=Float64(row.m_d), s=Float64(row.m_s)),
        μ=(u=Float64(row.muq_fm), d=Float64(row.muq_fm), s=Float64(row.muq_fm)))
    tp = (T=Float64(row.T_fm), Φ=Float64(row.Phi), Φbar=Float64(row.Phibar), ξ=Float64(row.xi))
    av = RT.AFieldBuilder.build_A_triplet(qp0, tp; A_CONFIG...)
    # Production builds effective couplings from the isotropic A integral on
    # the default momentum grid, while polarization uses the full RS A field.
    pn, pw = RT.GaussLegendre.DEFAULT_MOMENTUM_NODES, RT.GaussLegendre.DEFAULT_MOMENTUM_WEIGHTS
    au = RT.OneLoopIntegrals.A(qp0.m.u, qp0.μ.u, tp.T, tp.Φ, tp.Φbar, pn, pw)
    ass = RT.OneLoopIntegrals.A(qp0.m.s, qp0.μ.s, tp.T, tp.Φ, tp.Φbar, pn, pw)
    gu = RT.EffectiveCouplings.calculate_G_from_A(au, qp0.m.u)
    gs = RT.EffectiveCouplings.calculate_G_from_A(ass, qp0.m.s)
    kc = RT.EffectiveCouplings.calculate_effective_couplings(G_fm2, K_fm5, gu, gs)
    return (quark_params=merge(qp0, (A=av,)), thermo_params=tp, K_coeffs=kc)
end

function base_from_row(row)
    masses = Float64[row.m_u, row.m_d, row.m_s]
    function residual!(out, phi)
        out .= Models.calculate_mass_vec(MODEL, SVector{3}(phi)) .- masses
    end
    sol = nlsolve(residual!, [-0.5, -0.5, -1.0]; ftol=1e-12, xtol=1e-12)
    reconstructed = Models.calculate_mass_vec(MODEL, SVector{3}(sol.zero))
    maximum(abs.(reconstructed .- masses)) < 1e-10 || error("mass-to-condensate inversion failed")
    all(sol.zero .<= 1e-9) || error("nonphysical condensate inversion branch")
    return (x_state=vcat(sol.zero, [Float64(row.Phi), Float64(row.Phibar)]),
        masses=masses, mu_vec=fill(Float64(row.muq_fm), 3), converged=true,
        pressure=Float64(row.P_fm4inv), energy=Float64(row.epsilon_fm4inv),
        entropy=Float64(row.s_fm3inv))
end

function state_from_base(base, row)
    state_from_row(merge(NamedTuple(row), (m_u=Float64(base.masses[1]),
        m_d=Float64(base.masses[2]), m_s=Float64(base.masses[3]),
        Phi=Float64(base.x_state[4]), Phibar=Float64(base.x_state[5]))))
end

production_tau(row) = NamedTuple{SPECIES}(Tuple(Float64(getproperty(row, Symbol("tau_", f))) for f in SPECIES))
densities_from_row(row) = NamedTuple{SPECIES}(Tuple(Float64(getproperty(row, Symbol("n_", f))) for f in SPECIES))

function tau_config(level::Symbol)
    dims = level === :p64 ? (64,12,18,24,560) :
        level === :p96 ? (96,16,28,24,560) :
        level === :p104 ? (104,18,30,20,440) :
        level === :p128 ? (128,20,36,24,560) :
        level === :sigma_refined ? (128,20,36,48,1120) :
        level === :p160 ? (160,24,44,64,1440) :
        throw(ArgumentError("unknown resolution $level"))
    return (p_nodes=dims[1], angle_nodes=dims[2], phi_nodes=dims[3],
        n_sigma_points=dims[4], sigma_grid_n=dims[5],
        sigma_cache_policy=:validated_anchored, threshold_subtraction=true,
        asym_window=0.6, asym_fit_min_points=8, asym_extra_points=10,
        interpolation_mode=:linear)
end

function bulk_for_base(row, base; p_num=24, t_num=8)
    Models.bulk_viscosity_coefficients(Float64(row.T_fm), Float64(row.muq_fm);
        xi=Float64(row.xi), p_num=p_num, t_num=t_num, model=MODEL,
        base_state=base.x_state, base_masses=base.masses, base_mu_vec=base.mu_vec,
        base_state_source=:review_retained_production_state)
end

function transport_for_tau(state, tau, bulk;
    p_nodes=24, cos_nodes=length(RT.GaussLegendre.DEFAULT_COSΘ_NODES), p_max=8.0)
    RT.TransportCoefficients.transport_coefficients(state.quark_params, state.thermo_params;
        tau=tau, bulk_coeffs=bulk,
        config=RT.TransportCoefficients.TransportIntegrationConfig(
            p_nodes=p_nodes, cos_nodes=cos_nodes, p_max=p_max))
end

function run_metadata(script, parameters)
    (status="analysis_only", created_utc=string(now(UTC)), julia=string(VERSION),
        head=strip(read(`git -C $ROOT rev-parse HEAD`, String)),
        script=relpath(script,ROOT), script_sha256=bytes2hex(sha256(read(script))),
        common_sha256=bytes2hex(sha256(read(@__FILE__))),
        input_sha256=bytes2hex(sha256(read(joinpath(INPUT,"review_points.csv")))),
        parameters=parameters, nonfinite_json="null; inspect convergence/status fields and CSV",
        formal_data_modified=false, manuscript_eligible=false)
end

end
