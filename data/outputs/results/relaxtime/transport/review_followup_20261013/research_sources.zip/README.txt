Historical research source (2026-10-14 to 2026-10-16)
Repository base: d6282e456cbda0d406809b239a4f2e62b35ca6cd (reachable from main).
Start with that Git checkout; extract common/ over its root, then add the
relevant stage overlay. Unchanged tracked source is supplied by Git.
common/ also preserves exact original line endings where they differed.
run_v2 and cache_v1 use the base plus common/.
bound_v2 and rates_v1 add their respective overlays.
meson_v2 contains the final 2026-10-15 analysis-script overlay, including
its FullRSKZero implementation and the matching meson runner.
desktop_sources preserves subsequent unique, uncommitted analysis/test files.
These historical scripts are research source, not current CLI entrypoints.
Raw result paths relative to the repository are retained in this directory.
Repeated identical snapshots, per-point checkpoints and execution logs
were omitted after comparing their retained source and result bytes.
