#!/usr/bin/env python
"""Render heatmaps from combined meson-density scan CSV output."""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import numpy as np


def read_rows(path: Path) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    with path.open("r", encoding="utf-8") as f:
        data_lines = (line for line in f if not line.lstrip().startswith("#"))
        for row in csv.DictReader(data_lines):
            rows.append(row)
    return rows


def as_float(row: dict[str, str], field: str) -> float:
    try:
        return float(row.get(field, "nan"))
    except ValueError:
        return math.nan


def matrix(rows: list[dict[str, str]], regime: str, field: str, x_field: str):
    selected = [
        row
        for row in rows
        if row.get("regime") == regime and row.get("status") == "ok"
    ]
    xs = np.array(sorted({as_float(row, x_field) for row in selected}), dtype=float)
    temps = np.array(sorted({as_float(row, "T_MeV") for row in selected}), dtype=float)
    xs = xs[np.isfinite(xs)]
    temps = temps[np.isfinite(temps)]
    values = np.full((temps.size, xs.size), np.nan, dtype=float)
    x_index = {v: i for i, v in enumerate(xs)}
    temp_index = {v: i for i, v in enumerate(temps)}
    for row in selected:
        x = as_float(row, x_field)
        temp = as_float(row, "T_MeV")
        val = as_float(row, field)
        if not (math.isfinite(x) and math.isfinite(temp) and math.isfinite(val)):
            continue
        if val < 0.0:
            continue
        values[temp_index[temp], x_index[x]] = val
    return xs, temps, values


def centers_to_edges(xs: np.ndarray) -> np.ndarray:
    if xs.size == 0:
        return np.array([], dtype=float)
    if xs.size == 1:
        return np.array([xs[0] - 0.5, xs[0] + 0.5], dtype=float)
    edges = np.empty(xs.size + 1, dtype=float)
    edges[1:-1] = 0.5 * (xs[:-1] + xs[1:])
    edges[0] = xs[0] - (edges[1] - xs[0])
    edges[-1] = xs[-1] + (xs[-1] - edges[-2])
    return edges


def finite_max(mats: list[np.ndarray]) -> float:
    vals = np.concatenate([m[np.isfinite(m)] for m in mats if np.isfinite(m).any()])
    if vals.size == 0:
        return 1.0
    return max(0.2, float(np.max(vals)))


def finite_min(mats: list[np.ndarray]) -> float:
    vals = np.concatenate([m[np.isfinite(m)] for m in mats if np.isfinite(m).any()])
    if vals.size == 0:
        return 0.0
    return float(np.min(vals))


def finite_positive_min(mats: list[np.ndarray]) -> float:
    vals = np.concatenate([
        m[np.isfinite(m) & (m > 0.0)]
        for m in mats
        if np.isfinite(m).any()
    ])
    if vals.size == 0:
        raise SystemExit("log color scale requires positive finite rows")
    return float(np.min(vals))


def manifest_path(path: Path) -> str:
    root = Path.cwd().resolve()
    resolved = path.resolve()
    try:
        return resolved.relative_to(root).as_posix()
    except ValueError:
        return resolved.as_posix()


def write_plot_manifest(path: Path, csv_path: Path, out_path: Path, args: argparse.Namespace) -> None:
    payload: dict[str, object]
    if path.exists():
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            payload = {}
    else:
        payload = {}

    payload["format"] = "combined_meson_density_plot_manifest_v1"
    payload["date"] = dt.date.today().isoformat()
    payload["generated_by"] = "scripts/analysis/relaxtime/render_combined_meson_density_fig3_like.py"
    payload["source_csv"] = manifest_path(csv_path)

    figures = payload.get("figures")
    if not isinstance(figures, list):
        figures = []
    out_rel = manifest_path(out_path)
    figures = [
        item for item in figures
        if not (isinstance(item, dict) and item.get("path") == out_rel)
    ]
    fmt = out_path.suffix.lstrip(".").lower() or "unknown"
    figures.append({
        "path": out_rel,
        "kind": args.kind or f"combined_meson_density_heatmap_{fmt}",
        "field": args.field,
        "x_field": args.x_field,
        "y_field": "T_MeV",
        "color_scale": args.color_scale,
        "color_vmin": args.resolved_vmin,
        "color_vmax": args.resolved_vmax,
        "format": fmt,
        "dpi": args.dpi,
        "title": args.title,
        "generated_by": "scripts/analysis/relaxtime/render_combined_meson_density_fig3_like.py",
    })
    payload["figures"] = figures
    path.write_text(json.dumps(payload, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")


def strip_trailing_whitespace(path: Path) -> None:
    if path.suffix.lower() != ".svg":
        return
    lines = path.read_text(encoding="utf-8").splitlines()
    path.write_text("\n".join(line.rstrip() for line in lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--manifest", default=None, type=Path)
    parser.add_argument("--field", default="kpi_ratio")
    parser.add_argument("--x-field", default="muq_MeV")
    parser.add_argument("--x-label", default=None)
    parser.add_argument("--x-unit", default="MeV")
    parser.add_argument("--kind", default=None)
    parser.add_argument("--color-scale", choices=("linear", "log"), default="linear")
    parser.add_argument("--vmin", type=float, default=None)
    parser.add_argument("--dpi", type=int, default=220)
    parser.add_argument("--vmax", type=float, default=None)
    parser.add_argument("--title", default="Combined meson-density FIG3-like scan")
    args = parser.parse_args()
    x_label = args.x_label if args.x_label is not None else args.x_field
    x_unit = f" [{args.x_unit}]" if args.x_unit else ""

    rows = read_rows(args.csv)
    regimes = sorted({row.get("regime", "") for row in rows if row.get("regime")})
    panels = []
    for regime in regimes:
        xs, temps, mat = matrix(rows, regime, args.field, args.x_field)
        if xs.size and temps.size:
            panels.append((regime, xs, temps, mat))
    if not panels:
        raise SystemExit("no plottable rows")

    mats = [panel[3] for panel in panels]
    if args.color_scale == "log":
        vmin = args.vmin if args.vmin is not None else finite_positive_min(mats)
        vmax = args.vmax if args.vmax is not None else finite_max(mats)
        if not (math.isfinite(vmin) and math.isfinite(vmax) and vmin > 0.0 and vmax > vmin):
            raise SystemExit("log color scale requires finite 0 < vmin < vmax")
        norm = LogNorm(vmin=vmin, vmax=vmax)
        value_label = f"{args.field} (log scale)"
    else:
        vmin = args.vmin if args.vmin is not None else min(0.0, finite_min(mats))
        vmax = args.vmax if args.vmax is not None else finite_max(mats)
        if not (math.isfinite(vmin) and math.isfinite(vmax) and vmax > vmin):
            raise SystemExit("linear color scale requires finite vmin < vmax")
        norm = None
        value_label = args.field
    args.resolved_vmin = vmin
    args.resolved_vmax = vmax
    ncols = 2
    nrows = int(math.ceil(len(panels) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(12.5, 4.8 * nrows), constrained_layout=True)
    axes_arr = np.atleast_1d(axes).ravel()
    cmap = plt.get_cmap("viridis").copy()
    cmap.set_bad("0.7")
    last_im = None
    for ax, (regime, xs, temps, mat) in zip(axes_arr, panels):
        xedges = centers_to_edges(xs)
        yedges = centers_to_edges(temps)
        masked = np.ma.masked_invalid(mat)
        if args.color_scale == "log":
            masked = np.ma.masked_where(masked <= 0.0, masked)
            last_im = ax.pcolormesh(xedges, yedges, masked, cmap=cmap, norm=norm, shading="auto")
        else:
            last_im = ax.pcolormesh(xedges, yedges, masked, cmap=cmap, vmin=vmin, vmax=vmax, shading="auto")
        ax.set_title(regime)
        ax.set_xlabel(f"{x_label}{x_unit}")
        ax.set_ylabel("T [MeV]")
        ax.set_xlim(xedges[0], xedges[-1])
        ax.set_ylim(yedges[0], yedges[-1])
    for ax in axes_arr[len(panels):]:
        ax.axis("off")
    fig.suptitle(args.title)
    if last_im is not None:
        fig.colorbar(last_im, ax=axes_arr[:len(panels)], label=value_label)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    if args.out.suffix.lower() == ".svg":
        fig.savefig(args.out, dpi=args.dpi, metadata={"Date": None})
    else:
        fig.savefig(args.out, dpi=args.dpi)
    plt.close(fig)
    strip_trailing_whitespace(args.out)
    manifest = args.manifest if args.manifest is not None else args.out.parent / "plot_manifest.json"
    write_plot_manifest(manifest, args.csv, args.out, args)
    print(args.out)


if __name__ == "__main__":
    main()
