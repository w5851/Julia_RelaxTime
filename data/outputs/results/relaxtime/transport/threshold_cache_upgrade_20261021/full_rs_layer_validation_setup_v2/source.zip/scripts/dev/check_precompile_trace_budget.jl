#!/usr/bin/env julia

using Pkg
Pkg.activate(joinpath(@__DIR__, "..", ".."))
using Libdl

const PROJECT_ROOT = normpath(joinpath(@__DIR__, "..", ".."))
const TRACE_DIR = joinpath(PROJECT_ROOT, "build", "trace")
const SYSIMAGE_PATH = joinpath(PROJECT_ROOT, "build", "JuliaRelaxTime.$(Libdl.dlext)")

const _TRACE_EXPR = "ENV[\"UNIT_FILES\"]=\"pnjl/test_conserved_charge_susceptibilities.jl\"; include(\"tests/unit/runtests.jl\")"
const NO_SYS_CMD = `$(Base.julia_cmd()) --project=$(PROJECT_ROOT) --trace-compile=$(joinpath(TRACE_DIR, "unit_conserved_no_sys.jl")) -e $(_TRACE_EXPR)`
const WITH_SYS_CMD = `$(Base.julia_cmd()) --sysimage=$(SYSIMAGE_PATH) --project=$(PROJECT_ROOT) --trace-compile=$(joinpath(TRACE_DIR, "unit_conserved_with_sys.jl")) -e $(_TRACE_EXPR)`

# GitHub Actions (Ubuntu 24.04, Julia 1.12.5) previously stabilized at 1002
# lines before TaylorDiff joined the sysimage package set. Including TaylorDiff
# lowers the with-sys trace substantially and raises `delta` because more
# no-sys lines are now covered by the sysimage; keep focus delta bounded so the
# AD-facing specialization surface remains guarded.
const MAX_WITH_SYS_LINES = 1025
const MAX_DELTA_LINES = 650
const MAX_FOCUS_DELTA_LINES = 120

mkpath(TRACE_DIR)
isfile(SYSIMAGE_PATH) || error("sysimage not found at $(SYSIMAGE_PATH); run scripts/dev/build_sysimage.jl first")

println("[trace-budget] collecting no-sys trace...")
run(NO_SYS_CMD)

println("[trace-budget] collecting with-sys trace...")
run(WITH_SYS_CMD)

no_lines = readlines(joinpath(TRACE_DIR, "unit_conserved_no_sys.jl"))
with_lines = readlines(joinpath(TRACE_DIR, "unit_conserved_with_sys.jl"))

no_set = Set(no_lines)
with_set = Set(with_lines)
delta = [line for line in no_lines if !(line in with_set)]

focus_re = r"ForwardDiff|NLSolversBase|Conserved|Thermo|chi|cumulant|baryon|StaticArrays"
focus = [line for line in delta if occursin(focus_re, line)]

println("[trace-budget] no-sys lines   = $(length(no_lines))")
println("[trace-budget] with-sys lines = $(length(with_lines))")
println("[trace-budget] delta lines    = $(length(delta))")
println("[trace-budget] focus delta    = $(length(focus))")

errors = String[]
length(with_lines) <= MAX_WITH_SYS_LINES || push!(errors, "with-sys lines exceed budget: $(length(with_lines)) > $(MAX_WITH_SYS_LINES)")
length(delta) <= MAX_DELTA_LINES || push!(errors, "delta lines exceed budget: $(length(delta)) > $(MAX_DELTA_LINES)")
length(focus) <= MAX_FOCUS_DELTA_LINES || push!(errors, "focus delta exceeds budget: $(length(focus)) > $(MAX_FOCUS_DELTA_LINES)")

open(joinpath(TRACE_DIR, "unit_conserved_delta_focus.jl"), "w") do io
    for line in focus
        println(io, line)
    end
end

if isempty(errors)
    println("[trace-budget] OK")
    exit(0)
end

println("[trace-budget] FAILED")
for err in errors
    println("  - " * err)
end
exit(1)
