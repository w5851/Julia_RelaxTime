$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$caseRoot='D:\CodexCompute\trmott-eta-fine-20261029-v1'
$sourceRoot='D:\CodexCompute\trfull-20261026-v1\case\source'
$pythonExe='C:\Users\82306\AppData\Local\Programs\Python\Python313\python.exe'
$statusPath=Join-Path $caseRoot 'finish_eta_v1.status.json'
if(Test-Path -LiteralPath $statusPath){throw 'Existing completion watcher'}
$started=[DateTime]::UtcNow
function Write-FinishStatus([string]$state,[string]$message){
    [ordered]@{status=$state;stage=$message;started_utc=$started.ToString('o');updated_utc=[DateTime]::UtcNow.ToString('o')} |
        ConvertTo-Json | Set-Content -LiteralPath $statusPath -Encoding UTF8
}
try {
    Write-FinishStatus 'waiting' 'full fine grid and launch of all main-queue jobs'
    while($true){
        try {$main=Get-Content -LiteralPath (Join-Path $caseRoot 'transport_queue_v2.status.json') -Raw | ConvertFrom-Json}
        catch {Start-Sleep -Seconds 1;continue}
        if($main.status -eq 'failed'){throw 'Main queue failed'}
        if($main.workers.Count -eq 6){break}
        Start-Sleep -Seconds 20
    }
    Write-FinishStatus 'running' 'review fine grid and refine peak intervals'
    & (Join-Path $caseRoot 'run_remote_peak_refinement.ps1')
    Write-FinishStatus 'waiting' 'remaining central precision checks'
    while($true){
        try {$main=Get-Content -LiteralPath (Join-Path $caseRoot 'transport_queue_v2.status.json') -Raw | ConvertFrom-Json}
        catch {Start-Sleep -Seconds 1;continue}
        if($main.status -eq 'failed'){throw 'Main precision queue failed'}
        if($main.status -eq 'finished'){break}
        Start-Sleep -Seconds 20
    }
    Write-FinishStatus 'running' 'final numerical review'
    $fine='fine_a_mu0_v1,fine_a_mu450_v1,fine_a_mu0_v2,fine_a_mu450_v2,fine_b_mu0_v2'
    $tight='tighter_a_mu0_v2,tighter_a_mu450_v2,tighter_b_mu0_v2,tighter_peak_a_mu0_v1,tighter_peak_a_mu450_v1,tighter_peak_b_mu0_v1'
    & $pythonExe (Join-Path $caseRoot 'review_transport_eta_refinement.py') $caseRoot --runs $fine --comparison-runs $tight `
        --peak-plan (Join-Path $caseRoot 'peak_plan_v1') --output (Join-Path $caseRoot 'review_final_v1') `
        *> (Join-Path $caseRoot 'review_final_v1.stdout.log')
    if($LASTEXITCODE -ne 0){throw 'Final refinement review failed'}
    Write-FinishStatus 'running' 'source verification and result package'
    & $pythonExe (Join-Path $caseRoot 'package_transport_eta_refinement.py') $caseRoot $sourceRoot
    if($LASTEXITCODE -ne 0){throw 'Result packaging failed'}
    Write-FinishStatus 'finished' 'numeric results ready for verified return and PNG rendering'
} catch {
    Write-FinishStatus 'failed' $_.Exception.Message
    throw
}
