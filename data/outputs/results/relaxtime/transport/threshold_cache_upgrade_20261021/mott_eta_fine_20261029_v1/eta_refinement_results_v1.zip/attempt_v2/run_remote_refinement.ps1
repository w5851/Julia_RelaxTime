param(
    [ValidateSet('locate','transport')][string]$Stage='locate',
    [string]$Variant='fine', [string]$OutputTag='v1',
    [string]$LocateName='locate_v1', [string]$PointIds='all'
)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$caseRoot='D:\CodexCompute\trmott-eta-fine-20261029-v1'
$sourceRoot='D:\CodexCompute\trfull-20261026-v1\case\source'
$juliaExe='D:\CodexCompute\Julia_RelaxTime\transport-preflight-20261023-v1\runtime\julia-1.12.5\bin\julia.exe'
$pythonExe='C:\Users\82306\AppData\Local\Programs\Python\Python313\python.exe'
$expected=Get-Content -LiteralPath (Join-Path $caseRoot 'expected_source_hashes.json') -Raw | ConvertFrom-Json
function Test-FrozenSource {
    $count=0
    foreach($entry in $expected.PSObject.Properties) {
        $actual=(Get-FileHash -LiteralPath (Join-Path $sourceRoot $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if($actual -ne $entry.Value) { throw "Frozen source changed: $($entry.Name)" }
        $count++
    }
    return $count
}
if(@(Get-Process julia -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Another Julia job is active; no new workers started' }
$stageName=if($Stage -eq 'locate'){"locate_$OutputTag"}else{"transport_${Variant}_$OutputTag"}
$statusPath=Join-Path $caseRoot ($stageName+'.status.json')
if(Test-Path -LiteralPath $statusPath){throw 'Existing stage name'}
$start=[DateTime]::UtcNow
$before=Test-FrozenSource
if(-not(Test-Path -LiteralPath (Join-Path $caseRoot 'inputs'))) {
    & $pythonExe (Join-Path $caseRoot 'prepare_transport_eta_refinement.py') `
        'D:\CodexCompute\trmott-eta-survey-20261029-v1' $sourceRoot (Join-Path $caseRoot 'inputs') `
        *> (Join-Path $caseRoot 'prepare.stdout.log')
    if($LASTEXITCODE -ne 0){throw 'Input preparation failed'}
}
$env:JULIA_NUM_THREADS='1'
$env:OPENBLAS_NUM_THREADS='1'
$env:OMP_NUM_THREADS='1'
$env:JULIA_PKG_PRECOMPILE_AUTO='0'
$env:ETA_LOCATE_DIR=Join-Path $caseRoot $LocateName
$env:ETA_POINT_IDS=$PointIds
$workers=@()
$workItems=if($Stage -eq 'locate'){@('all')}else{@('a_mu0','a_mu450','b_mu0')}
$freeGB=(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1MB
$parallelism=if($Stage -eq 'locate'){1}elseif($freeGB -ge 8){3}elseif($freeGB -ge 5){2}else{1}
try {
    foreach($item in $workItems) {
        while(@($workers | Where-Object {-not $_.process.HasExited}).Count -ge $parallelism) { Start-Sleep -Milliseconds 250 }
        $name=if($Stage -eq 'locate'){$stageName}else{"${Variant}_${item}_$OutputTag"}
        $argv=@('--startup-file=no','--threads=1',('--project='+$sourceRoot),
            (Join-Path $caseRoot 'run_transport_eta_refinement.jl'),$sourceRoot,
            (Join-Path $caseRoot 'inputs'),(Join-Path $caseRoot $name),$Stage,$item,$Variant)
        $p=Start-Process -FilePath $juliaExe -ArgumentList $argv -WorkingDirectory $sourceRoot `
            -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $caseRoot ($name+'.stdout.log')) `
            -RedirectStandardError (Join-Path $caseRoot ($name+'.stderr.log'))
        $processHandle=$p.Handle
        $workers+=@{name=$name;process=$p;arguments=$argv}
        [ordered]@{status='running';started_utc=$start.ToString('o');free_memory_GB_at_start=$freeGB;
            parallelism=$parallelism;workers=@($workers | ForEach-Object {@{name=$_.name;pid=$_.process.Id;arguments=$_.arguments}})} |
            ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $statusPath -Encoding UTF8
        Write-Output ("STARTED "+$name+" pid="+$p.Id)
    }
    foreach($worker in $workers){$worker.process.WaitForExit()}
    $after=Test-FrozenSource
    $results=@($workers | ForEach-Object {@{name=$_.name;pid=$_.process.Id;exit_code=$_.process.ExitCode}})
    $okay=@($results | Where-Object {$_.exit_code -ne 0}).Count -eq 0
    [ordered]@{status=if($okay){'finished'}else{'failed'};started_utc=$start.ToString('o');
        finished_utc=[DateTime]::UtcNow.ToString('o');elapsed_seconds=([DateTime]::UtcNow-$start).TotalSeconds;
        workers=$results;source_files_checked_before=$before;source_files_checked_after=$after;
        all_source_hashes_match=$true} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $statusPath -Encoding UTF8
    if(-not $okay){throw 'A diagnostic worker failed; inspect retained stderr and partial outputs'}
} catch {
    Write-Error $_
    exit 1
}
