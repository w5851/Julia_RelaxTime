$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$caseRoot='D:\CodexCompute\trmott-eta-fine-20261029-v1'
$sourceRoot='D:\CodexCompute\trfull-20261026-v1\case\source'
$juliaExe='D:\CodexCompute\Julia_RelaxTime\transport-preflight-20261023-v1\runtime\julia-1.12.5\bin\julia.exe'
$pythonExe='C:\Users\82306\AppData\Local\Programs\Python\Python313\python.exe'
$expected=Get-Content -LiteralPath (Join-Path $caseRoot 'expected_source_hashes.json') -Raw | ConvertFrom-Json
function Test-FrozenSource {
    $count=0
    foreach($entry in $expected.PSObject.Properties){
        $actual=(Get-FileHash -LiteralPath (Join-Path $sourceRoot $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if($actual -ne $entry.Value){throw "Frozen source changed: $($entry.Name)"}
        $count++
    }
    return $count
}
if(@(Get-Process julia -ErrorAction SilentlyContinue).Count -gt 0){throw 'Existing Julia job; queue not started'}
$statusPath=Join-Path $caseRoot 'transport_queue_v2.status.json'
if(Test-Path -LiteralPath $statusPath){throw 'Existing queue status'}
$before=Test-FrozenSource
& $pythonExe (Join-Path $caseRoot 'resume_transport_eta_refinement.py') $caseRoot *> (Join-Path $caseRoot 'resume_v2.stdout.log')
if($LASTEXITCODE -ne 0){throw 'Resume validation failed'}
$plan=Get-Content -LiteralPath (Join-Path $caseRoot 'resume_v2.json') -Raw | ConvertFrom-Json
$env:JULIA_NUM_THREADS='1'
$env:OPENBLAS_NUM_THREADS='1'
$env:OMP_NUM_THREADS='1'
$env:JULIA_PKG_PRECOMPILE_AUTO='0'
$env:ETA_LOCATE_DIR=Join-Path $caseRoot 'locate_v3'
$env:ETA_EVAL_POLES='false'
$start=[DateTime]::UtcNow
$workers=@()
function Write-QueueStatus([string]$state){
    [ordered]@{status=$state;started_utc=$start.ToString('o');updated_utc=[DateTime]::UtcNow.ToString('o');
        max_parallel_workers=3;per_worker_launch_free_GiB=3.25;source_files_checked_before=$before;
        workers=@($workers | ForEach-Object {[ordered]@{name=$_.name;pid=$_.process.Id;
            exited=$_.process.HasExited;exit_code=if($_.process.HasExited){$_.process.ExitCode}else{$null};arguments=$_.arguments}})} |
        ConvertTo-Json -Depth 7 | Set-Content -LiteralPath $statusPath -Encoding UTF8
}
foreach($job in $plan.jobs){
    while($true){
        $running=@($workers | Where-Object {-not $_.process.HasExited}).Count
        $freeGB=(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1MB
        if($running -lt 3 -and $freeGB -ge 3.25){break}
        Start-Sleep -Seconds 5
    }
    $name=$job.name
    $env:ETA_POINT_IDS=$job.point_ids -join ','
    $argv=@('--startup-file=no','--threads=1',('--project='+$sourceRoot),
        (Join-Path $caseRoot 'run_transport_eta_refinement_v2.jl'),$sourceRoot,
        (Join-Path $caseRoot 'inputs_v2'),(Join-Path $caseRoot $name),'transport',$job.curve_id,$job.variant)
    $p=Start-Process -FilePath $juliaExe -ArgumentList $argv -WorkingDirectory $sourceRoot `
        -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $caseRoot ($name+'.stdout.log')) `
        -RedirectStandardError (Join-Path $caseRoot ($name+'.stderr.log'))
    $processHandle=$p.Handle
    $workers+=@{name=$name;process=$p;arguments=$argv}
    Write-QueueStatus 'running'
    Write-Output ('STARTED '+$name+' points='+$job.point_ids.Count+' pid='+$p.Id+' free_GiB='+$freeGB)
}
foreach($worker in $workers){$worker.process.WaitForExit()}
$after=Test-FrozenSource
$okay=@($workers | Where-Object {$null -eq $_.process.ExitCode -or $_.process.ExitCode -ne 0}).Count -eq 0
Write-QueueStatus $(if($okay){'finished'}else{'failed'})
[ordered]@{source_files_checked_before=$before;source_files_checked_after=$after;all_source_hashes_match=$true;
    completed_utc=[DateTime]::UtcNow.ToString('o');elapsed_seconds=([DateTime]::UtcNow-$start).TotalSeconds} |
    ConvertTo-Json | Set-Content -LiteralPath (Join-Path $caseRoot 'transport_queue_v2.source_verification.json') -Encoding UTF8
if(-not $okay){throw 'A queue worker failed; completed point outputs retained'}
