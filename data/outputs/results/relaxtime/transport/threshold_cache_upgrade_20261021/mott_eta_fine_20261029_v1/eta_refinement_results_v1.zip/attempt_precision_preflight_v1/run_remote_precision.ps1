param([string]$OutputTag='v1')
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$caseRoot='D:\CodexCompute\trmott-eta-fine-20261029-v1'
$sourceRoot='D:\CodexCompute\trfull-20261026-v1\case\source'
$juliaExe='D:\CodexCompute\Julia_RelaxTime\transport-preflight-20261023-v1\runtime\julia-1.12.5\bin\julia.exe'
$expected=Get-Content -LiteralPath (Join-Path $caseRoot 'expected_source_hashes.json') -Raw | ConvertFrom-Json
function Test-FrozenSource {
    $count=0
    foreach($entry in $expected.PSObject.Properties){
        $actual=(Get-FileHash -LiteralPath (Join-Path $sourceRoot $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if($actual -ne $entry.Value){throw "Frozen source changed: $($entry.Name)"}
        $count++
    }
    return $count
}
$statusPath=Join-Path $caseRoot ('precision_'+$OutputTag+'.status.json')
if(Test-Path -LiteralPath $statusPath){throw 'Existing precision stage'}
$env:JULIA_NUM_THREADS='1'
$env:OPENBLAS_NUM_THREADS='1'
$env:OMP_NUM_THREADS='1'
$env:JULIA_PKG_PRECOMPILE_AUTO='0'
$env:ETA_LOCATE_DIR=Join-Path $caseRoot 'locate_v3'
$start=[DateTime]::UtcNow
$results=@()
$before=Test-FrozenSource
foreach($curve in @('a_mu0','a_mu450','b_mu0')){
    # The two main workers peaked at 2.2 GB each. Add at most one
    # precision worker, and retain at least 3.25 GiB of measured free RAM
    # before its launch; no process outside this case is stopped.
    do {
        $jobs=@(Get-CimInstance Win32_Process -Filter "Name='julia.exe'")
        if(@($jobs | Where-Object {$_.CommandLine -notlike ('*'+$caseRoot+'*')}).Count -gt 0){throw 'Unrelated Julia job is active'}
        $freeGB=(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1MB
        $ready=$jobs.Count -le 2 -and $freeGB -ge 3.25
        if(-not $ready){Write-Output ('WAIT_MEMORY '+$freeGB+' GiB; workers='+$jobs.Count);Start-Sleep -Seconds 30}
    } while(-not $ready)
    $name='tighter_'+$curve+'_'+$OutputTag
    $env:ETA_POINT_IDS=$curve+'_p01,'+$curve+'_p02'
    $argv=@('--startup-file=no','--threads=1',('--project='+$sourceRoot),
        (Join-Path $caseRoot 'run_transport_eta_refinement.jl'),$sourceRoot,
        (Join-Path $caseRoot 'inputs_v2'),(Join-Path $caseRoot $name),'transport',$curve,'tighter')
    $p=Start-Process -FilePath $juliaExe -ArgumentList $argv -WorkingDirectory $sourceRoot `
        -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $caseRoot ($name+'.stdout.log')) `
        -RedirectStandardError (Join-Path $caseRoot ($name+'.stderr.log'))
    $processHandle=$p.Handle
    [ordered]@{status='running';started_utc=$start.ToString('o');current_worker=$name;pid=$p.Id;
        free_memory_GB_before_worker=$freeGB;other_workers=$jobs.Count;completed=$results;arguments=$argv} |
        ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $statusPath -Encoding UTF8
    Write-Output ('PRECISION_STARTED '+$name+' pid='+$p.Id+' free_GiB='+$freeGB)
    $p.WaitForExit()
    $code=$p.ExitCode
    $results+=@{name=$name;pid=$p.Id;exit_code=$code}
    $after=Test-FrozenSource
    if($null -eq $code -or $code -ne 0){
        [ordered]@{status='failed';workers=$results;all_source_hashes_match=$true;source_files_checked=$after} |
            ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $statusPath -Encoding UTF8
        throw 'Precision worker failed; main fine grid continues independently'
    }
    Write-Output ('PRECISION_DONE '+$name)
}
[ordered]@{status='finished';started_utc=$start.ToString('o');finished_utc=[DateTime]::UtcNow.ToString('o');
    elapsed_seconds=([DateTime]::UtcNow-$start).TotalSeconds;workers=$results;
    source_files_checked_before=$before;source_files_checked_after=$after;all_source_hashes_match=$true} |
    ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $statusPath -Encoding UTF8
