$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$caseRoot='D:\CodexCompute\trmott-eta-fine-20261029-v1'
$sourceRoot='D:\CodexCompute\trfull-20261026-v1\case\source'
$juliaExe='D:\CodexCompute\Julia_RelaxTime\transport-preflight-20261023-v1\runtime\julia-1.12.5\bin\julia.exe'
$pythonExe='C:\Users\82306\AppData\Local\Programs\Python\Python313\python.exe'
$main=Get-Content -LiteralPath (Join-Path $caseRoot 'transport_queue_v2.status.json') -Raw | ConvertFrom-Json
if($main.workers.Count -ne 6){throw 'Wait until the main queue has launched all six jobs'}
$statusPath=Join-Path $caseRoot 'peak_refinement_v1.status.json'
if(Test-Path -LiteralPath $statusPath){throw 'Existing peak-refinement stage'}
# Launching all six queue jobs does not imply that the longest fine-grid job
# has finished: a short precision job can release a slot first.
$requiredFine=@('fine_a_mu0_v2','fine_a_mu450_v2','fine_b_mu0_v2')
while($true){
    try {$main=Get-Content -LiteralPath (Join-Path $caseRoot 'transport_queue_v2.status.json') -Raw | ConvertFrom-Json}
    catch {Start-Sleep -Seconds 1;continue}
    if($null -eq $main){Start-Sleep -Seconds 1;continue}
    if($main.status -eq 'failed'){throw 'Main queue failed while waiting for complete fine grid'}
    $fineReady=$true
    foreach($name in $requiredFine){
        $summaryPath=Join-Path (Join-Path $caseRoot $name) 'summary.json'
        if(-not (Test-Path -LiteralPath $summaryPath)){$fineReady=$false;continue}
        try {$summary=Get-Content -LiteralPath $summaryPath -Raw | ConvertFrom-Json}
        catch {$fineReady=$false;continue}
        if($null -eq $summary){$fineReady=$false;continue}
        if($summary.status -ne 'completed_diagnostic'){throw ('Unexpected fine-grid status: '+$name)}
    }
    if($fineReady){break}
    if($main.status -eq 'finished'){throw 'Main queue finished without all fine-grid summaries'}
    Start-Sleep -Seconds 20
}
$expected=Get-Content -LiteralPath (Join-Path $caseRoot 'expected_source_hashes.json') -Raw | ConvertFrom-Json
function Test-FrozenSource {
    $count=0
    foreach($entry in $expected.PSObject.Properties){
        $actual=(Get-FileHash -LiteralPath (Join-Path $sourceRoot $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if($actual -ne $entry.Value){throw "Frozen source changed: $($entry.Name)"}
        $count++
    }
    return $count
}
$before=Test-FrozenSource
$fineRuns='fine_a_mu0_v1,fine_a_mu450_v1,fine_a_mu0_v2,fine_a_mu450_v2,fine_b_mu0_v2'
& $pythonExe (Join-Path $caseRoot 'review_transport_eta_refinement.py') $caseRoot --runs $fineRuns `
    --output (Join-Path $caseRoot 'review_fine_v1') *> (Join-Path $caseRoot 'review_fine_v1.stdout.log')
if($LASTEXITCODE -ne 0){throw 'Full fine-grid review failed'}
& $pythonExe (Join-Path $caseRoot 'refine_transport_eta_peak_intervals.py') $caseRoot `
    (Join-Path $caseRoot 'review_fine_v1') (Join-Path $caseRoot 'peak_plan_v1') *> (Join-Path $caseRoot 'peak_plan_v1.stdout.log')
if($LASTEXITCODE -ne 0){throw 'Peak-interval selection failed'}
$plan=Import-Csv -LiteralPath (Join-Path $caseRoot 'peak_plan_v1\transport_plan.csv')
$env:JULIA_NUM_THREADS='1'
$env:OPENBLAS_NUM_THREADS='1'
$env:OMP_NUM_THREADS='1'
$env:JULIA_PKG_PRECOMPILE_AUTO='0'
$env:ETA_EVAL_POLES='false'
$env:ETA_LOCATE_DIR=Join-Path $caseRoot 'peak_plan_v1'
$start=[DateTime]::UtcNow
$workers=@()
foreach($curve in @('a_mu0','a_mu450','b_mu0')){
    do {
        $jobs=@(Get-CimInstance Win32_Process -Filter "Name='julia.exe'")
        $known=@($main.workers | ForEach-Object {$_.pid})+@($workers | ForEach-Object {$_.process.Id})
        if(@($jobs | Where-Object {$_.ProcessId -notin $known -or $_.ExecutablePath -ne $juliaExe}).Count -gt 0){throw 'Unrelated Julia process'}
        $freeGB=(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1MB
        $ready=$jobs.Count -lt 3 -and $freeGB -ge 3.25
        if(-not $ready){Start-Sleep -Seconds 5}
    } while(-not $ready)
    $name='tighter_peak_'+$curve+'_v1'
    $env:ETA_POINT_IDS=@($plan | Where-Object {$_.curve_id -eq $curve} | ForEach-Object {$_.point_id}) -join ','
    $argv=@('--startup-file=no','--threads=1',('--project='+$sourceRoot),
        (Join-Path $caseRoot 'run_transport_eta_refinement_v2.jl'),$sourceRoot,
        (Join-Path $caseRoot 'inputs_v2'),(Join-Path $caseRoot $name),'transport',$curve,'tighter')
    $p=Start-Process -FilePath $juliaExe -ArgumentList $argv -WorkingDirectory $sourceRoot `
        -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $caseRoot ($name+'.stdout.log')) `
        -RedirectStandardError (Join-Path $caseRoot ($name+'.stderr.log'))
    $processHandle=$p.Handle
    $workers+=@{name=$name;process=$p;arguments=$argv}
    [ordered]@{status='running';started_utc=$start.ToString('o');workers=@($workers | ForEach-Object {
        @{name=$_.name;pid=$_.process.Id;arguments=$_.arguments}})} |
        ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $statusPath -Encoding UTF8
    Write-Output ('PEAK_STARTED '+$name+' pid='+$p.Id+' ids='+$env:ETA_POINT_IDS)
}
foreach($worker in $workers){$worker.process.WaitForExit()}
$after=Test-FrozenSource
$results=@($workers | ForEach-Object {@{name=$_.name;pid=$_.process.Id;exit_code=$_.process.ExitCode}})
$okay=@($results | Where-Object {$null -eq $_.exit_code -or $_.exit_code -ne 0}).Count -eq 0
[ordered]@{status=if($okay){'finished'}else{'failed'};started_utc=$start.ToString('o');finished_utc=[DateTime]::UtcNow.ToString('o');
    elapsed_seconds=([DateTime]::UtcNow-$start).TotalSeconds;workers=$results;
    source_files_checked_before=$before;source_files_checked_after=$after;all_source_hashes_match=$true} |
    ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $statusPath -Encoding UTF8
if(-not $okay){throw 'A peak-refinement worker failed'}
