using CSV, JSON, SHA, Dates
const WORK = raw"D:\CodexCompute\Julia_RelaxTime\full-rs-layer-validation-20261025-v1"
const PROJECT = joinpath(WORK, "project")
const OUTPUT = joinpath(WORK, "identity_diagnostic_v1")
ispath(OUTPUT) && error("diagnostic output already exists")
include(joinpath(PROJECT, "scripts/analysis/relaxtime/run_transport_full_rs_layer_validation.jl"))

function diagnose_layer_identity()
    package = JSON.parsefile(joinpath(WORK, "package_manifest.json"))
    bytes2hex(sha256(read(joinpath(WORK, "source.zip")))) == package["zip_sha256"] || error("archive changed")
    for (relative, hash) in package["source_files"]
        bytes2hex(sha256(read(joinpath(PROJECT, relative)))) == hash || error("source changed: $relative")
    end
    points = filter(r -> (r.muB_MeV, r.alpha_T, r.xi) in FULL_RS_CONTROLS,
        collect(CSV.File(joinpath(WORK, "inputs/review_points.csv"))))
    records = NamedTuple[]
    for row in points, config in (merge(joint_config("candidate"), (p=48,)), joint_config("reference"))
        background = joint_background(row, config)
        state = background.state
        rebuilt = full_rs_refined_a(state, config.a_p, config.a_c)
        repeated = full_rs_refined_a(state, config.a_p, config.a_c)
        for (group, original, actual, again) in (("A", state.quark_params.A, rebuilt.quark_params.A, repeated.quark_params.A),
                ("coupling", state.K_coeffs, rebuilt.K_coeffs, repeated.K_coeffs))
            for field in propertynames(original)
                a, b, c = getproperty(original, field), getproperty(actual, field), getproperty(again, field)
                all(isfinite, (a, b, c)) || error("nonfinite identity value")
                push!(records, (point_id=String(row.point_id), configuration=config.name, group=group,
                    field=String(field), original=a, rebuilt=b, repeated=c,
                    exact_equal=a==b, repeat_exact_equal=b==c, absolute_difference=abs(b-a),
                    relative_difference=abs(b-a)/max(abs(a),abs(b),floatmin(Float64)),
                    ulp_distance=abs(Int128(reinterpret(Int64,a))-Int128(reinterpret(Int64,b)))))
            end
        end
    end
    mkpath(OUTPUT)
    CSV.write(joinpath(OUTPUT, "identity.csv"), records)
    summary = (created_utc=string(now(UTC)), julia=string(VERSION), host=get(ENV,"COMPUTERNAME",""),
        source_archive_sha256=package["zip_sha256"], source_files_verified=length(package["source_files"]),
        diagnostic_script_sha256=bytes2hex(sha256(read(@__FILE__))), backgrounds=2length(points),
        fields=length(records), unequal_fields=count(r->!r.exact_equal,records),
        unequal_A_fields=count(r->r.group=="A" && !r.exact_equal,records),
        maximum_relative_difference=maximum(r.relative_difference for r in records),
        maximum_ulp_distance=maximum(r.ulp_distance for r in records),
        repeats_exact=all(r->r.repeat_exact_equal,records))
    open(joinpath(OUTPUT,"summary.json"),"w") do io
        JSON.print(io,summary,2);println(io)
    end
    cp(@__FILE__,joinpath(OUTPUT,basename(@__FILE__)))
    for (relative, hash) in package["source_files"]
        bytes2hex(sha256(read(joinpath(PROJECT, relative)))) == hash || error("source changed after diagnostic: $relative")
    end
    JSON.print(stdout,summary,2);println()
end
diagnose_layer_identity()
