"""Review layer CSVs and independently check their densities with NumPy on W."""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import math
import os
import zipfile

os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
WORK = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-layer-validation-20261025-v1')
JOINT = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-joint-representatives-20261025-v1\results')
PILOT = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-transport-validation-20261025-v1\joint_pilot')

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

def same(a, b):
    return math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-14)

package = read_json(WORK / 'package_manifest.json')
assert package['zip_sha256'] == '9fc7dac27790bf73c2b6cb9f57196067f078ca39fb2da7790de2e61962b4fddc'
assert digest(WORK / 'source.zip') == package['zip_sha256']
for relative, expected in package['source_files'].items():
    assert digest(WORK / 'project' / relative) == expected, relative
verification = read_json(WORK / 'verification.json')
assert verification['source_verified_before_and_after']
assert all(r['process_exit_code'] == 0 for r in verification['layers'])
assert {r['layer'] for r in verification['layers']} == {'cheap', 'kernel', 'outer'}
for name in ('cheap', 'kernel', 'outer'):
    status = read_json(WORK / name / 'status.json')
    assert status['all_cases_complete'] and status['layer_target_passed']
    manifest = read_json(WORK / name / 'manifest.json')
    assert manifest['source_archive']['sha256'] == package['zip_sha256']
    assert manifest['head'] is None and manifest['source_archive']['calculation_commit'] is None
    for entry in manifest['source_files']:
        relative = entry['path'].replace('\\', '/')
        assert digest(WORK / name / 'source' / relative) == entry['sha256'] == package['source_files'][relative]

joint_backgrounds = {}
for run in (PILOT, JOINT):
    for row in rows(run / 'background.csv'):
        joint_backgrounds[row['point_id'], row['configuration']] = row
backgrounds = {(r['point_id'], r['configuration']): r for r in rows(WORK / 'cheap/background.csv')}
assert set(backgrounds) == set(joint_backgrounds) and len(backgrounds) == 24
background_changes = []
for key, row in backgrounds.items():
    for field in ('m_u', 'm_d', 'm_s', 'Phi', 'Phibar', 'A_u', 'A_d', 'A_s'):
        change = abs(float(row[field]) / float(joint_backgrounds[key][field]) - 1)
        assert math.isfinite(change) and change <= 1e-10, (key, field, change)
        background_changes.append(change)

module_path = WORK / 'project/scripts/analysis/relaxtime/verify_transport_joint_density.py'
spec = importlib.util.spec_from_file_location('independent_density', module_path)
density = importlib.util.module_from_spec(spec)
spec.loader.exec_module(density)
density_rows = rows(WORK / 'cheap/densities.csv')
assert len(density_rows) == 576
python_replays, python_references = [], []
for row in density_rows:
    key = row['point_id'], row['background_configuration']
    state = backgrounds[key]
    name = row['configuration']
    if name == 'workflow_p64_c8':
        value = density.density(state, row['species'], 64, 8, 25.0 if key[1] == 'candidate' else 30.0, semi=False)
    else:
        order, angles = {'thermal_p32_c36': (32, 36), 'thermal_p32_c48': (32, 48),
                         'identity_p128_c64': (128, 64)}[name]
        value = density.density(state, row['species'], order, angles, 10.0)
    reference = density.density(state, row['species'], 256, 1, 5.0, xi=0.0) / math.sqrt(1 + float(state['xi']))
    check = density.density(state, row['species'], 128, 1, 5.0, xi=0.0) / math.sqrt(1 + float(state['xi']))
    assert all(math.isfinite(x) and x > 0 for x in (value, reference, check))
    assert abs(check / reference - 1) <= 1e-9
    python_replays.append(abs(value / float(row['density']) - 1))
    python_references.append(abs(reference / float(row['reference']) - 1))
    relative = float(row['density']) / float(row['reference']) - 1
    assert same(relative, float(row['relative_change'])) and abs(relative) <= float(row['target'])
    assert row['passed'] == 'true'
assert max(python_replays + python_references) <= 1e-10
pair_rows = rows(WORK / 'cheap/pair_bounds.csv')
assert len(pair_rows) == 48
for row in pair_rows:
    selected = [r for r in density_rows if all(r[k] == row[k] for k in ('point_id', 'background_configuration', 'configuration'))]
    assert len(selected) == 6
    relative = [float(r['relative_change']) for r in selected]
    bound = max(abs(1 / ((1+a)*(1+b)) - 1) for a in relative for b in relative)
    assert same(bound, float(row['maximum_pair_rate_error'])) and bound <= 1e-3 and row['passed'] == 'true'
moment_rows = rows(WORK / 'cheap/moments.csv')
a_rows = rows(WORK / 'cheap/A.csv')
assert len(moment_rows) == 144 and len(a_rows) == 216
for row in moment_rows:
    values = [float(row[k]) for k in ('eta_any_positive_tau_bound', 'sigma_any_positive_tau_bound', 'bulk_any_bracket_bound')]
    assert all(math.isfinite(v) and 0 <= v <= 0.01 for v in values) and row['passed'] == 'true'
for row in a_rows:
    relative = float(row['A']) / float(row['reference']) - 1
    assert same(relative, float(row['relative_change'])) and abs(relative) <= 0.01 and row['passed'] == 'true'
maxima = {}
for layer, count, comparisons in (('kernel', 48, 40), ('outer', 36, 33)):
    rates = rows(WORK / layer / 'rates.csv')
    compared = rows(WORK / layer / 'comparisons.csv')
    assert len(rates) == count and len(compared) == comparisons
    values = {(r['point_id'], r['channel'], r['configuration']): float(r['rate']) for r in rates}
    assert len(values) == count
    for row in rates:
        assert math.isfinite(float(row['rate'])) and float(row['rate']) > 0
        assert 0 <= float(row['reference_l1']) <= 2e-4
    for row in compared:
        key = row['point_id'], row['channel']
        candidate = values[*key, row['candidate_configuration']]
        reference = values[*key, row['reference_configuration']]
        assert same(candidate, float(row['candidate'])) and same(reference, float(row['reference']))
        relative = candidate / reference - 1
        assert same(relative, float(row['relative_change'])) and abs(relative) <= 0.01 and row['passed'] == 'true'
    maxima[layer] = max(abs(float(r['relative_change'])) for r in compared)
review = dict(host='W', backgrounds=24, density_comparisons=576, pair_bounds=48,
              moment_comparisons=144, A_comparisons=216, kernel_rates=48, kernel_comparisons=40,
              outer_rates=36, outer_comparisons=33, layer_targets_passed=True,
              maximum_background_replay_relative=max(background_changes), numpy=density.np.__version__,
              maximum_numpy_julia_density_relative=max(python_replays + python_references),
              maximum_pair_normalization_error=max(float(r['maximum_pair_rate_error']) for r in pair_rows),
              maximum_terminal_bound=max(float(r[k]) for r in moment_rows for k in ('eta_any_positive_tau_bound', 'sigma_any_positive_tau_bound', 'bulk_any_bracket_bound')),
              maximum_A_relative=max(abs(float(r['relative_change'])) for r in a_rows),
              maximum_layer_relative_changes=maxima, source_archive_sha256=package['zip_sha256'],
              source_files_verified=package['files'], full_qualification=False)
(WORK / 'reviewed_result.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8')
archive = WORK / 'returned_evidence.zip'
assert not archive.exists()
files = []
for directory in ('cheap', 'kernel', 'outer', 'joint_complete_summary_v1'):
    files.extend(p for p in (WORK / directory).rglob('*') if p.is_file())
files.extend(p for p in WORK.iterdir() if p.is_file() and p.suffix in ('.json', '.log', '.ps1', '.py'))
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path in sorted(set(files)):
        output.write(path, path.relative_to(WORK).as_posix())
info = dict(sha256=digest(archive), bytes=archive.stat().st_size, remote_archive=str(archive), files=len(set(files)))
(WORK / 'returned_archive_manifest.json').write_text(json.dumps(info, indent=2) + '\n', encoding='utf-8')
print(json.dumps(review, indent=2))
print(json.dumps(info, indent=2))
