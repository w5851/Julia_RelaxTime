"""Preserve the failed bitwise identity guard and its independent diagnostic."""
import hashlib
import json
from pathlib import Path
import zipfile

WORK = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-layer-validation-20261025-v1')

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

status = read_json(WORK / 'cheap/status.json')
diagnostic = read_json(WORK / 'identity_diagnostic_v1/summary.json')
assert not status['layer_target_passed'] and status['failures'] == 5
assert diagnostic['backgrounds'] == 24 and diagnostic['unequal_A_fields'] == 0
assert diagnostic['maximum_ulp_distance'] == 1 and diagnostic['repeats_exact']
review = dict(original_layer_target_passed=False, complete=False,
              reason='Bitwise K identity guard rejected one-ULP cross-call rounding; A values match exactly',
              diagnostic=diagnostic, original_failure_status=status,
              production_numerical_parameters_changed=False,
              next_run='full-rs-layer-validation-20261025-v2')
(WORK / 'reviewed_failure.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8')
archive = WORK / 'failed_evidence.zip'
assert not archive.exists()
files = []
for directory in ('cheap', 'identity_diagnostic_v1'):
    files.extend(p for p in (WORK / directory).rglob('*') if p.is_file())
files.extend(p for p in WORK.iterdir() if p.is_file() and p.suffix in ('.json', '.log', '.ps1', '.py', '.jl'))
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path in sorted(set(files)):
        output.write(path, path.relative_to(WORK).as_posix())
info = dict(sha256=digest(archive), bytes=archive.stat().st_size, files=len(set(files)))
(WORK / 'failed_archive_manifest.json').write_text(json.dumps(info, indent=2) + '\n', encoding='utf-8')
print(json.dumps(info, indent=2))
