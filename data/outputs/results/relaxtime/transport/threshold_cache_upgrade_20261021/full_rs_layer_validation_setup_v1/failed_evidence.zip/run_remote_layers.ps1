$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$layerWorkspace = 'D:\CodexCompute\Julia_RelaxTime\full-rs-layer-validation-20261025-v1'
$layerProject = Join-Path $layerWorkspace 'project'
$layerInputs = Join-Path $layerWorkspace 'inputs'
$layerRuntime = 'D:\CodexCompute\Julia_RelaxTime\transport-preflight-20261023-v1\runtime\julia-1.12.5\bin\julia.exe'
$layerStart = [DateTime]::UtcNow
$layerStage = 'verify_package'
$layerRuns = @()
function Write-LayerStatus([bool]$finished, [object]$exitCode, [string]$message = '') {
    [ordered]@{host=$env:COMPUTERNAME; stage=$script:layerStage; finished=$finished; exit_code=$exitCode;
        error=$message; started_utc=$layerStart.ToString('o'); updated_utc=[DateTime]::UtcNow.ToString('o')} |
        ConvertTo-Json | Set-Content -LiteralPath (Join-Path $layerWorkspace 'remote_status.json') -Encoding UTF8
    Write-Output $script:layerStage
}
function Test-LayerSource {
    foreach ($entry in $layerManifest.source_files.PSObject.Properties) {
        $hash = (Get-FileHash -LiteralPath (Join-Path $layerProject $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $entry.Value) { throw "Source identity mismatch: $($entry.Name)" }
    }
    foreach ($entry in $layerManifest.input_files.PSObject.Properties) {
        $hash = (Get-FileHash -LiteralPath (Join-Path $layerInputs $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $entry.Value) { throw "Input identity mismatch: $($entry.Name)" }
    }
}
try {
    Write-LayerStatus $false $null
    if ($env:COMPUTERNAME -ne 'W') { throw 'Unexpected remote host' }
    if (@(Get-Process -Name julia -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Another Julia process is running' }
    $layerManifestPath = Join-Path $layerWorkspace 'package_manifest.json'
    $layerManifest = Get-Content -LiteralPath $layerManifestPath -Raw | ConvertFrom-Json
    foreach ($item in @(@('source.zip',$layerManifest.zip_sha256),@('inputs.zip',$layerManifest.inputs_zip_sha256),@('run_remote_layers.ps1',$layerManifest.runner_sha256))) {
        $hash = (Get-FileHash -LiteralPath (Join-Path $layerWorkspace $item[0]) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $item[1]) { throw "Package identity mismatch: $($item[0])" }
    }
    if (Test-Path -LiteralPath $layerProject) { throw 'Source directory already exists; refusing to replace it' }
    if (Test-Path -LiteralPath $layerInputs) { throw 'Input directory already exists; refusing to replace it' }
    Expand-Archive -LiteralPath (Join-Path $layerWorkspace 'source.zip') -DestinationPath $layerProject
    Expand-Archive -LiteralPath (Join-Path $layerWorkspace 'inputs.zip') -DestinationPath $layerInputs
    Test-LayerSource
    $env:JULIA_NUM_THREADS = '1'
    $env:OPENBLAS_NUM_THREADS = '1'
    $env:JULIA_NUM_PRECOMPILE_TASKS = '1'
    $env:JULIA_PKG_PRECOMPILE_AUTO = '0'
    $env:THRESHOLD_SOURCE_MANIFEST = $layerManifestPath
    foreach ($layer in @('cheap','kernel','outer')) {
        $layerStage = $layer
        Write-LayerStatus $false $null
        $started = [DateTime]::UtcNow
        $arguments = @('--startup-file=no','--threads=1',"--project=$layerProject",'--heap-size-hint=1200M',
            (Join-Path $layerProject 'scripts\analysis\relaxtime\run_transport_full_rs_layer_validation.jl'),
            $layerInputs,(Join-Path $layerWorkspace $layer),$layer)
        $layerProcess = Start-Process -FilePath $layerRuntime -ArgumentList $arguments `
          -WorkingDirectory $layerProject -WindowStyle Hidden -Wait -PassThru `
          -RedirectStandardOutput (Join-Path $layerWorkspace ($layer+'.stdout.log')) `
          -RedirectStandardError (Join-Path $layerWorkspace ($layer+'.stderr.log'))
        Test-LayerSource
        $resultPath = Join-Path $layerWorkspace ($layer+'\status.json')
        $result = if (Test-Path -LiteralPath $resultPath) { Get-Content -LiteralPath $resultPath -Raw | ConvertFrom-Json } else { $null }
        $layerRuns += [ordered]@{layer=$layer; process_exit_code=$layerProcess.ExitCode; result=$result;
            elapsed_seconds=([DateTime]::UtcNow-$started).TotalSeconds; arguments=$arguments}
        [ordered]@{host=$env:COMPUTERNAME; runtime_version='1.12.5'; threads=1;
            source_archive_sha256=$layerManifest.zip_sha256; source_files_verified=$layerManifest.files;
            source_verified_before_and_after=$true; layers=$layerRuns; final_transport_qualification=$false} |
            ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $layerWorkspace 'verification.json') -Encoding UTF8
        if ($layerProcess.ExitCode -ne 0 -or -not $result.layer_target_passed) { throw "Layer $layer did not pass" }
    }
    $layerStage = 'complete'
    Write-LayerStatus $true 0
    exit 0
} catch {
    Write-LayerStatus $true 1 $_.Exception.Message
    exit 1
}
