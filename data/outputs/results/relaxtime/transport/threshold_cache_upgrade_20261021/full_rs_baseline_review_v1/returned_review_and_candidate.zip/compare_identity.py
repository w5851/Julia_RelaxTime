"""Identify exact data/order differences behind the identity assertion failures."""
import hashlib
import json
from pathlib import Path

WORK=Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-baseline-review-20261025-v1')
REPLAY=Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-production-replay-20261025-v3\production_replay')
current=json.loads((WORK/'current_identity.json').read_text(encoding='utf-8-sig'))
paths=sorted((REPLAY/'points').glob('*/phase_guided_transport_scan_sampling_contract.json'))
saved=[json.loads(p.read_text(encoding='utf-8-sig')) for p in paths]
assert len(saved)==12
differences=[]
def compare(a,b,path='identity'):
    if isinstance(a,dict) and isinstance(b,dict):
        if list(a)!=list(b): differences.append(dict(path=path,kind='key_order',previous=list(a),current=list(b)))
        for key in set(a)|set(b):
            if key not in a or key not in b: differences.append(dict(path=path+'.'+key,kind='key_missing'))
            else: compare(a[key],b[key],path+'.'+key)
    elif isinstance(a,list) and isinstance(b,list):
        if len(a)!=len(b): differences.append(dict(path=path,kind='length',previous=len(a),current=len(b)))
        for i,(left,right) in enumerate(zip(a,b)): compare(left,right,f'{path}[{i}]')
    elif a!=b:
        differences.append(dict(path=path,kind='value',previous=a,current=b))
compare(saved[0]['identity'],current)
report=dict(saved_identity_hashes=sorted({s['identity_sha256'] for s in saved}),
            all_saved_identities_equal=all(s['identity']==saved[0]['identity'] for s in saved),
            current_raw_sha256=hashlib.sha256((WORK/'current_identity.json').read_bytes()).hexdigest(),
            differences=differences)
out=WORK/'identity_difference.json'
assert not out.exists()
out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
