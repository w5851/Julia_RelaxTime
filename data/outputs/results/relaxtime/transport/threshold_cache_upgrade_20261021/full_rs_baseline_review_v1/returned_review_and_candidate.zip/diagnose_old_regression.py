"""Classify actual assertion failures and compare both execution source trees."""
from collections import Counter
import csv
import hashlib
import json
import math
from pathlib import Path
import re

WORK = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-baseline-review-20261025-v1')
SOURCE = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-layer-validation-20261025-v2\project')
EXECUTION = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-production-replay-20261025-v3')


def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(line for line in stream if line.strip() and not line.startswith('#')))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


targets = rows(WORK / 'old_evidence/old_baseline_v2.csv')
candidate_failures, reference_failures, changes = [], [], []
for target in targets:
    actual = rows(EXECUTION / 'production_replay/points' / target['point_id'] / 'phase_guided_transport_scan.csv')[0]
    value, candidate, reference = float(actual[target['observable']]), float(target['candidate']), float(target['reference'])
    key = target['point_id'], target['observable']
    if not math.isclose(value, candidate, rel_tol=1e-6, abs_tol=1e-8):
        candidate_failures.append(key)
    if abs(value / reference - 1) > .01:
        reference_failures.append(key)
    changes.append(dict(point_id=key[0], observable=key[1], current=value, previous=candidate,
                        xi=float(actual['xi']), relative_change=value / candidate - 1))
log = (WORK / 'old_regression.stdout.log').read_text(encoding='utf-8-sig')
expressions = Counter(re.findall(r'^\s*Expression:\s*(.*)$', log, flags=re.MULTILINE))
locations = Counter(re.findall(r'Test Failed at .*native_transport_fixture.jl:(\d+)', log))
checks = {}
for root in (SOURCE, EXECUTION / 'project'):
    files = {p.relative_to(root).as_posix(): digest(p)
             for prefix in ('src', 'scripts/relaxtime', 'config/models/pnjl', 'config/physics')
             for p in (root / prefix).rglob('*') if p.is_file() and p.suffix in ('.jl', '.toml')}
    files.update({name: digest(root / name) for name in ('Project.toml', 'Manifest.toml')})
    checks[str(root)] = files
left, right = checks.values()
different = [name for name in set(left) | set(right) if left.get(name) != right.get(name)]
report = dict(candidate_failures=len(candidate_failures), reference_failures=len(reference_failures),
              expected_observable_failures=len(candidate_failures) + len(reference_failures),
              assertion_expressions=dict(expressions), assertion_lines=dict(locations),
              numerical_file_counts=[len(left), len(right)], different_numerical_files=sorted(different),
              maximum_relative_change=max(abs(r['relative_change']) for r in changes),
              maximum_xi_zero_relative_change=max(abs(r['relative_change']) for r in changes if r['xi'] == 0))
destination = WORK / 'assertion_mismatch_diagnosis.json'
assert not destination.exists()
destination.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
