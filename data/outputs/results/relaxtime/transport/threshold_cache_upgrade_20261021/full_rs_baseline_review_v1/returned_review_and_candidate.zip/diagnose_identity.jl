using CSV, JSON3, SHA
const PROJECT=raw"D:\CodexCompute\Julia_RelaxTime\full-rs-layer-validation-20261025-v2\project"
const OUT=raw"D:\CodexCompute\Julia_RelaxTime\full-rs-baseline-review-20261025-v1"
const REPLAY=raw"D:\CodexCompute\Julia_RelaxTime\full-rs-production-replay-20261025-v3\production_replay"
include(joinpath(PROJECT,"tests","regression","relaxtime","native_transport_fixture.jl"))
point=first(CSV.File(NativeTransportRegression.BASELINE))
folder=joinpath(REPLAY,"points",String(point.point_id))
args=["--outdir",folder,"--mode","fixed-T-sparse-muB","--channel-diagnostics",
    "--T-list",string(point.T_MeV),"--muB-list",string(point.muB_MeV),"--xi-list",string(point.xi)]
opts=PhaseGuidedCLI.parse_args(args)
scan_opts=_build_runtime_scan_opts(joinpath(folder,"phase_guided_transport_scan.csv"),opts)
saved=JSON3.read(read(TransportSamplingScanConfig.sampling_contract_path(scan_opts),String))
identity=TransportSamplingScanConfig.calculation_identity(scan_opts)
raw=JSON3.write(identity)
destination=joinpath(OUT,"current_identity.json")
ispath(destination) && error("preserve previous diagnostic")
write(destination,raw)
println(JSON3.write((saved_sha256=saved.identity_sha256,current_sha256=bytes2hex(sha256(raw)),
    saved_json_reencoded_sha256=bytes2hex(sha256(JSON3.write(saved.identity))),
    point_id=String(point.point_id),solvers_called=false)))
