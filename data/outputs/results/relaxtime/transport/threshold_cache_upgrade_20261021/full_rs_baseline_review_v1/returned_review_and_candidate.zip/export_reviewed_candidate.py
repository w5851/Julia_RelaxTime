"""Export a new candidate only after the old regression differences are explained."""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

WORK=Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-baseline-review-20261025-v1')
SOURCE=Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-layer-validation-20261025-v2')
PRODUCTION=Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-production-replay-20261025-v3')


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


old=read_json(WORK/'old_baseline_review.json')
assert old['all_test_failures_explained_by_actual_old_baseline_values']
assert old['maximum_background_relative_change']==old['maximum_xi_zero_relative_change']==0
assert old['julia_test_counts']==dict(passed=219,failed=95,errored=0,broken=0)
assert old['profile_and_sampling_parameters_unchanged'] and old['relative_velocity']=='cm'
assert old['regression_rtol']==1e-6 and old['regression_atol']==1e-8
out=WORK/'candidate_v3/baseline_thermal_weighted_transport_v3.csv'
assert not out.exists()
subprocess.run([sys.executable,str(PRODUCTION/'project/scripts/dev/export_thermal_weighted_transport_baseline.py'),
                str(SOURCE/'joint_complete_summary_v1'),str(SOURCE/'inputs'),str(out),
                '--production-replay',str(PRODUCTION/'production_replay')],check=True)
metadata=read_json(out.with_suffix('.json'))
assert digest(out)==metadata['baseline_sha256']
assert metadata['production_source_archive']['sha256']==old['source_archive_sha256']
with out.open(encoding='utf-8',newline='') as stream:
    values=list(csv.DictReader(stream))
assert len(values)==108 and len({(r['point_id'],r['observable']) for r in values})==108
candidate_review=dict(baseline_sha256=digest(out),points=12,comparisons=108,
    production_source_archive_sha256=old['source_archive_sha256'],old_difference_review_sha256=digest(WORK/'old_baseline_review.json'),
    regression_rtol=1e-6,regression_atol=1e-8,independent_relative_target=0.01,
    physical_conventions=dict(a_polarization='full_RS',a_coupling='full_RS',relative_velocity='cm'),
    source_data_verified_by_exporter=True,candidate_generated=True,consumer_updated=False,new_regression_passed=False)
(WORK/'candidate_review.json').write_text(json.dumps(candidate_review,indent=2)+'\n',encoding='utf-8')
archive=WORK/'returned_review_and_candidate.zip'
assert not archive.exists()
files=[p for p in WORK.iterdir() if p.is_file() and p.suffix in ('.ps1','.py','.jl','.log','.json','.csv')]
files.extend(p for p in (WORK/'candidate_v3').rglob('*') if p.is_file())
files.append(WORK/'old_baseline_evidence.zip')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    for path in sorted(set(files)):
        output.write(path,path.relative_to(WORK).as_posix())
info=dict(sha256=digest(archive),bytes=archive.stat().st_size,files=len(set(files)))
(WORK/'returned_archive_manifest.json').write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8')
print(json.dumps(candidate_review,indent=2))
print(json.dumps(info,indent=2))
