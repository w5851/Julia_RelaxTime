"""Explain every old v2 regression failure before generating any new baseline."""
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import zipfile

WORK = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-baseline-review-20261025-v1')
SOURCE = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-layer-validation-20261025-v2')
REPLAY = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-production-replay-20261025-v3\production_replay')

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(line for line in stream if line.strip() and not line.startswith('#')))

package = read_json(WORK / 'old_evidence_manifest.json')
assert digest(WORK / 'old_baseline_evidence.zip') == package['sha256']
old = WORK / 'old_evidence'
assert old.is_dir()
with zipfile.ZipFile(WORK / 'old_baseline_evidence.zip') as archive:
    assert len(archive.namelist()) == len(package['files']) and set(archive.namelist()) == set(package['files'])
    for entry in archive.infolist():
        target = (old / entry.filename).resolve()
        assert target.is_relative_to(old.resolve())
        data = archive.read(entry)
        assert hashlib.sha256(data).hexdigest() == digest(target) == package['files'][entry.filename]

test = read_json(WORK / 'old_regression_run_v2.json')
metadata = read_json(old / 'old_baseline_v2.json')
assert test['source_verified_before_and_after']
assert test['baseline_sha256'] == metadata['baseline_sha256'] == digest(old / 'old_baseline_v2.csv')
old_manifest = read_json(old / 'old_production/manifest.json')
new_manifest = read_json(REPLAY / 'manifest.json')
old_profile, new_profile = (manifest['parameters']['profile'] for manifest in (old_manifest, new_manifest))
assert old_profile['a_coupling'] == 'isotropic' and new_profile['a_coupling'] == 'full_RS'
for field in ('id', 'source_sha256', 'algorithm', 'background', 'a_integral', 'tau_integral',
              'terminal_integral', 'a_polarization', 'sigma_cutoff_inv_fm', 'internal_density', 'external_density'):
    assert old_profile[field] == new_profile[field], field
old_sampling = {**old_profile['sampling'], 'relative_velocity': old_profile['sampling'].get('relative_velocity', 'cm')}
assert old_sampling == new_profile['sampling'] and new_profile['sampling']['relative_velocity'] == 'cm'
inventory = read_json(old / 'source_change_inventory.json')
assert test['source_archive_sha256'] == new_manifest['source_archive']['sha256'] == inventory['current_source_archive_sha256']
assert digest(old / 'old_production/manifest.json') == inventory['previous_manifest_sha256']
current_package = read_json(SOURCE / 'package_manifest.json')
for entry in old_manifest['source_files']:
    relative = entry['path'].replace('\\', '/')
    assert digest(old / 'old_production/source' / relative) == entry['sha256']
for entry in inventory['changed_files']:
    assert current_package['source_files'][entry['path']] == entry['current_sha256']
    assert digest(old / 'old_production/source' / entry['path']) == entry['previous_sha256']
targets = rows(old / 'old_baseline_v2.csv')
assert len(targets) == 108 and len({(r['point_id'], r['observable']) for r in targets}) == 108
differences, background_changes = [], []
for point in sorted({r['point_id'] for r in targets}):
    old_rows = rows(old / 'old_production/points' / point / 'phase_guided_transport_scan.csv')
    new_rows = rows(REPLAY / 'points' / point / 'phase_guided_transport_scan.csv')
    assert len(old_rows) == len(new_rows) == 1
    before, after = old_rows[0], new_rows[0]
    assert before['converged'] == after['converged'] == 'true'
    assert tuple(float(before[k]) for k in ('T_MeV', 'muB_MeV', 'xi')) == tuple(float(after[k]) for k in ('T_MeV', 'muB_MeV', 'xi'))
    for field in ('m_u', 'm_d', 'm_s', 'Phi', 'Phibar', 's_fm3inv', 'n_u', 'n_d', 'n_s', 'n_ubar', 'n_dbar', 'n_sbar'):
        a, b = float(before[field]), float(after[field])
        assert math.isfinite(a) and math.isfinite(b) and a > 0 and b > 0
        background_changes.append(dict(point_id=point, field=field, previous=a, current=b,
                                       relative_change=b/a-1, absolute_change=b-a))
    for target in (r for r in targets if r['point_id'] == point):
        previous, reference, current = float(target['candidate']), float(target['reference']), float(after[target['observable']])
        assert float(before[target['observable']]) == previous and math.isfinite(current) and current > 0
        differences.append(dict(point_id=point, observable=target['observable'], xi=float(after['xi']),
                                previous_candidate=previous, previous_reference=reference, current=current,
                                absolute_change=current-previous, relative_change=current/previous-1,
                                regression_passed=math.isclose(current, previous, rel_tol=1e-6, abs_tol=1e-8),
                                old_reference_passed=abs(current/reference-1) <= 0.01))
expected_failures = sum(not r['regression_passed'] for r in differences) + sum(not r['old_reference_passed'] for r in differences)
if expected_failures:
    assert test['test_exit_code'] != 0
    error_log = (WORK / 'old_regression_v2.stderr.log').read_text(encoding='utf-8-sig')
    match = re.search(r'(\d+) passed, (\d+) failed, (\d+) errored, (\d+) broken', error_log)
    assert match is not None, 'missing Julia assertion summary'
    passed, failed, errors, broken = map(int, match.groups())
    assert failed == expected_failures and errors == broken == 0 and passed + failed == 314
else:
    assert test['test_exit_code'] == 0
    passed, failed, errors, broken = 314, 0, 0, 0
for name, data in (('old_baseline_differences.csv', differences), ('background_differences.csv', background_changes)):
    path = WORK / name
    assert not path.exists()
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(data[0]))
        writer.writeheader(); writer.writerows(data)
report = dict(source_archive_sha256=test['source_archive_sha256'], previous_baseline_sha256=metadata['baseline_sha256'],
              julia_test_counts=dict(passed=passed, failed=failed, errored=errors, broken=broken),
              differences=108, regression_failures=sum(not r['regression_passed'] for r in differences),
              old_reference_failures=sum(not r['old_reference_passed'] for r in differences),
              maximum_relative_change=max(abs(r['relative_change']) for r in differences),
              maximum_xi_zero_relative_change=max(abs(r['relative_change']) for r in differences if r['xi'] == 0),
              maximum_background_relative_change=max(abs(r['relative_change']) for r in background_changes),
              physical_change='effective coupling A: isotropic -> full_RS', relative_velocity='cm',
              profile_and_sampling_parameters_unchanged=True, regression_rtol=1e-6, regression_atol=1e-8,
              all_test_failures_explained_by_actual_old_baseline_values=True,
              new_baseline_generated=False, previous_evidence_preserved=True,
              initial_regression_identity_failures=12, identity_issue='absolute model configuration path differs between identical source copies',
              original_regression_failures=107, numerical_sources_identical_across_copies=True, regression_attempt=2)
(WORK / 'old_baseline_review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
