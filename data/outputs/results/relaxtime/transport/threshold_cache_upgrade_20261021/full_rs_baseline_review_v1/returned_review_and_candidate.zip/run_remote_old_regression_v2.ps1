$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$regressionWorkspace = 'D:\CodexCompute\Julia_RelaxTime\full-rs-baseline-review-20261025-v1'
$regressionSource = 'D:\CodexCompute\Julia_RelaxTime\full-rs-layer-validation-20261025-v2'
$regressionProject = 'D:\CodexCompute\Julia_RelaxTime\full-rs-production-replay-20261025-v3\project'
$regressionReplay = 'D:\CodexCompute\Julia_RelaxTime\full-rs-production-replay-20261025-v3\production_replay'
$regressionRuntime = 'D:\CodexCompute\Julia_RelaxTime\transport-preflight-20261023-v1\runtime\julia-1.12.5\bin\julia.exe'
function Test-RegressionSource {
    foreach ($entry in $regressionPackage.source_files.PSObject.Properties) {
        $hash = (Get-FileHash -LiteralPath (Join-Path $regressionProject $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $entry.Value) { throw "Regression source mismatch: $($entry.Name)" }
    }
}
if ($env:COMPUTERNAME -ne 'W') { throw 'Unexpected host' }
if (@(Get-Process -Name julia -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Another Julia process is running' }
if (Test-Path -LiteralPath (Join-Path $regressionWorkspace 'old_regression_run_v2.json')) { throw 'Old regression evidence already exists' }
$regressionPackage = Get-Content -LiteralPath (Join-Path $regressionSource 'package_manifest.json') -Raw | ConvertFrom-Json
if ($regressionPackage.zip_sha256 -ne '789c20ef317b0327692772cb256a408cf0a7ed84b5ad3fa9637ca1ea266888e5') { throw 'Unexpected source archive' }
$review = Get-Content -LiteralPath 'D:\CodexCompute\Julia_RelaxTime\full-rs-production-replay-20261025-v3\reviewed_result.json' -Raw | ConvertFrom-Json
if (-not $review.production_replay_passed -or $review.source_archive_sha256 -ne $regressionPackage.zip_sha256) { throw 'Production replay review is incomplete' }
Test-RegressionSource
$env:JULIA_NUM_THREADS = '1'
$env:OPENBLAS_NUM_THREADS = '1'
$env:JULIA_PKG_PRECOMPILE_AUTO = '0'
$env:TRANSPORT_REGRESSION_REPLAY_DIR = $regressionReplay
$arguments = @('--startup-file=no','--threads=1',"--project=$regressionProject",'--heap-size-hint=1200M',
    (Join-Path $regressionProject 'tests\regression\relaxtime\test_phase_guided_transport_mode_b_full_regression.jl'))
$started = [DateTime]::UtcNow
$process = Start-Process -FilePath $regressionRuntime -ArgumentList $arguments -WorkingDirectory $regressionProject `
    -WindowStyle Hidden -Wait -PassThru -RedirectStandardOutput (Join-Path $regressionWorkspace 'old_regression_v2.stdout.log') `
    -RedirectStandardError (Join-Path $regressionWorkspace 'old_regression_v2.stderr.log')
Test-RegressionSource
[ordered]@{host=$env:COMPUTERNAME; julia='1.12.5'; threads=1; test_exit_code=$process.ExitCode;
    started_utc=$started.ToString('o'); finished_utc=[DateTime]::UtcNow.ToString('o');
    source_archive_sha256=$regressionPackage.zip_sha256; source_verified_before_and_after=$true;
    arguments=$arguments; replay=$regressionReplay; baseline='baseline_thermal_weighted_transport_v2';
    baseline_sha256=(Get-FileHash -LiteralPath (Join-Path $regressionProject 'tests\baselines\relaxtime\baseline_thermal_weighted_transport_v2.csv') -Algorithm SHA256).Hash.ToLowerInvariant();
    regression_rtol=1e-6; regression_atol=1e-8; expected_semantics_change='isotropic to full-RS A in effective couplings';
    failure_is_not_a_pass=$true; attempt=2; identity_context='same execution root as original production; original 12 path-identity failures retained'} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $regressionWorkspace 'old_regression_run_v2.json') -Encoding UTF8
Get-Content -LiteralPath (Join-Path $regressionWorkspace 'old_regression_v2.stdout.log') -Tail 4
Get-Content -LiteralPath (Join-Path $regressionWorkspace 'old_regression_v2.stderr.log') -Tail 4
exit $process.ExitCode
