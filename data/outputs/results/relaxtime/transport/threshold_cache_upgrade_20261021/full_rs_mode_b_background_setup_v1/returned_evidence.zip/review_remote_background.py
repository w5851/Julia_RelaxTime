"""Review the requested mode-B background grid; retain transport qualification as open."""
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import zipfile

WORK = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-mode-b-background-20261025-v1')
SOURCE = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-baseline-acceptance-20261025-v1')
PROJECT = SOURCE / 'project'
RUN = WORK / 'background'


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def helper(relative, name):
    spec = importlib.util.spec_from_file_location(name, PROJECT / relative)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


package = read_json(SOURCE / 'package_manifest.json')
assert digest(SOURCE / 'source.zip') == package['zip_sha256']
for name, checksum in package['source_files'].items():
    assert digest(PROJECT / name) == checksum, name
verification = read_json(WORK / 'verification.json')
assert verification['source_verified_before_and_after'] and verification['process_exit_code'] == 0
assert verification['source_archive_sha256'] == package['zip_sha256']
manifest, status = read_json(RUN / 'manifest.json'), read_json(RUN / 'status.json')
inputs = helper('scripts/analysis/relaxtime/prepare_transport_production_inputs.py', 'inputs')
baseline = helper('scripts/dev/export_thermal_weighted_transport_baseline.py', 'baseline')
sources = inputs.verified_sources(RUN, manifest, PROJECT.resolve())
commit, identity = baseline.replay_artifact_commit(RUN, manifest)
assert commit == 'unknown' and identity['sha256'] == package['zip_sha256']
assert status['mode'] == 'B' and status['complete'] and status['phase_plan_passed']
assert status['failures'] == 0 and status['points'] == status['completed_points'] == 909
assert status['cold_seed_audits_passed'] and not status['transport_qualified']
plan, background, audits = (rows(RUN / name) for name in ('sampling_plan.csv', 'background.csv', 'cold_seed_audits.csv'))
expected = {(t, mu, i / 100) for t in (120, 160, 200) for mu in (0, 450, 900) for i in range(-50, 51)}
assert len(plan) == len(background) == 909
assert {inputs.point_key(r) for r in plan} == {inputs.point_key(r) for r in background} == expected
assert all(r['mode'] == 'mode_b_fixed_T_sparse_muB' for r in plan)
groups = {r['scan_group'] for r in plan}
assert len(groups) == 9
for row in background:
    assert row['passed'] == row['coexistence_resolved'] == 'true'
    assert 0 <= float(row['max_mass_relative_change']) <= 0.01
    assert abs(float(row['entropy_relative_change'])) <= 0.01
    assert all(math.isfinite(float(row[k])) and float(row[k]) > 0 for k in ('m_u', 'm_d', 'm_s', 'entropy'))
    if row['distinct_branches'] == row['refined_distinct_branches'] == 'true':
        assert row['stable_phase'] == row['refined_stable_phase']
seen_audits = {(r['scan_group'], r['level'], float(r['xi'])) for r in audits}
assert len(seen_audits) == len(audits) == status['cold_seed_audits']
required_audits = {(group, level, xi) for group in groups for level in ('candidate', 'refined') for xi in (-.5, -.25, 0, .25, .5)}
for group in groups:
    selected = sorted((r for r in background if r['scan_group'] == group), key=lambda r: float(r['xi']))
    assert len(selected) == 101
    for distinct, delta in (('distinct_branches', 'delta_omega'), ('refined_distinct_branches', 'refined_delta_omega')):
        for left, right in zip(selected, selected[1:]):
            if left[distinct] == right[distinct] == 'true' and float(left[delta]) * float(right[delta]) <= 0:
                required_audits.update((group, level, float(row['xi'])) for level in ('candidate', 'refined') for row in (left, right))
assert seen_audits == required_audits
for row in audits:
    assert row['passed'] == 'true'
    assert 0 <= float(row['max_mass_relative_change']) <= 1e-6
    assert 0 <= float(row['omega_absolute_change']) <= 1e-8
assert len(list((RUN / 'traces').glob('*.csv'))) == 36
trace_count = 0
for group in groups:
    group_keys = {inputs.point_key(r) for r in plan if r['scan_group'] == group}
    for level in ('candidate', 'refined'):
        for direction in ('forward', 'backward'):
            trace = rows(RUN / 'traces' / f'{group}_{level}_{direction}.csv')
            assert len(trace) == 101 and {inputs.point_key(r) for r in trace} == group_keys
            assert all(0 <= float(r['residual_norm']) <= 1e-8 for r in trace)
            trace_count += len(trace)
boundaries = rows(RUN / 'phase_boundaries.csv') if (RUN / 'phase_boundaries.csv').exists() else []
assert len(boundaries) == status['first_order_boundaries']
for row in boundaries:
    left, right = float(row['bracket_lower_xi']), float(row['bracket_upper_xi'])
    assert left < float(row['xi']) < right and left < float(row['refined_xi']) < right
review = dict(host='W', mode='B', mode_b_background_qualified=True, points=909, groups=9,
              cold_seed_audits=len(audits), continuation_files=36, continuation_rows=trace_count,
              maximum_mass_relative_change=max(float(r['max_mass_relative_change']) for r in background),
              maximum_entropy_relative_change=max(abs(float(r['entropy_relative_change'])) for r in background),
              first_order_boundaries=boundaries, source_archive_sha256=identity['sha256'],
              numerical_sources_verified=len(sources), source_snapshots_verified=len(manifest['source_files']),
              calculation_commit=None, transport_qualified=False, global_phase_diagram_qualified=False,
              formal_production_promoted=False)
(WORK / 'reviewed_result.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8')
archive = WORK / 'returned_evidence.zip'
assert not archive.exists()
files = [p for p in RUN.rglob('*') if p.is_file()]
files.extend(p for p in WORK.iterdir() if p.is_file() and p.suffix in ('.json', '.log', '.py', '.ps1'))
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path in sorted(set(files)):
        output.write(path, path.relative_to(WORK).as_posix())
info = dict(sha256=digest(archive), bytes=archive.stat().st_size, files=len(set(files)))
(WORK / 'returned_archive_manifest.json').write_text(json.dumps(info, indent=2) + '\n', encoding='utf-8')
print(json.dumps(review, indent=2))
print(json.dumps(info, indent=2))
