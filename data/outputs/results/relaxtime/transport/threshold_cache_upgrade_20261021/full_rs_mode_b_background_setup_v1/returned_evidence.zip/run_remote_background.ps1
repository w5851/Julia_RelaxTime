$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$backgroundWork = 'D:\CodexCompute\Julia_RelaxTime\full-rs-mode-b-background-20261025-v1'
$backgroundSource = 'D:\CodexCompute\Julia_RelaxTime\full-rs-baseline-acceptance-20261025-v1'
$backgroundProject = Join-Path $backgroundSource 'project'
$backgroundRuntime = 'D:\CodexCompute\Julia_RelaxTime\transport-preflight-20261023-v1\runtime\julia-1.12.5\bin\julia.exe'
$backgroundStart = [DateTime]::UtcNow
function Write-BackgroundStatus([string]$stage, [bool]$finished, [object]$exitCode, [string]$message = '') {
    [ordered]@{host=$env:COMPUTERNAME;stage=$stage;finished=$finished;exit_code=$exitCode;error=$message;
        started_utc=$backgroundStart.ToString('o');updated_utc=[DateTime]::UtcNow.ToString('o')} |
        ConvertTo-Json | Set-Content -LiteralPath (Join-Path $backgroundWork 'remote_status.json') -Encoding UTF8
    [Console]::WriteLine($stage)
}
function Test-BackgroundSource {
    foreach ($entry in $backgroundPackage.source_files.PSObject.Properties) {
        $hash = (Get-FileHash -LiteralPath (Join-Path $backgroundProject $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $entry.Value) { throw "Source mismatch: $($entry.Name)" }
    }
    foreach ($entry in $backgroundPackage.input_files.PSObject.Properties) {
        $hash = (Get-FileHash -LiteralPath (Join-Path $backgroundSource ('inputs\'+$entry.Name)) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $entry.Value) { throw "Input mismatch: $($entry.Name)" }
    }
}
try {
    if ($env:COMPUTERNAME -ne 'W') { throw 'Unexpected host' }
    if (@(Get-Process -Name julia -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Another Julia process is running' }
    if (Test-Path -LiteralPath (Join-Path $backgroundWork 'remote_status.json')) { throw 'Background run already started' }
    Write-BackgroundStatus 'verify' $false $null
    $manifestPath = Join-Path $backgroundSource 'package_manifest.json'
    $backgroundPackage = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    if ((Get-FileHash -LiteralPath (Join-Path $backgroundSource 'source.zip') -Algorithm SHA256).Hash.ToLowerInvariant() -ne $backgroundPackage.zip_sha256) { throw 'Source archive changed' }
    $acceptance = Get-Content -LiteralPath (Join-Path $backgroundSource 'reviewed_result.json') -Raw | ConvertFrom-Json
    if (-not $acceptance.default_entrypoint_passed -or $acceptance.regression_assertions_passed -ne 314 -or $acceptance.source_archive_sha256 -ne $backgroundPackage.zip_sha256) { throw 'Baseline/default entrypoint acceptance is incomplete' }
    $phase = Get-Content -LiteralPath 'D:\CodexCompute\Julia_RelaxTime\full-rs-phase-validation-20261025-v1\reviewed_result.json' -Raw | ConvertFrom-Json
    if (-not $phase.phase_plan_passed) { throw 'Mode-A phase qualification is incomplete' }
    Test-BackgroundSource
    $env:JULIA_NUM_THREADS = '1'
    $env:OPENBLAS_NUM_THREADS = '1'
    $env:JULIA_PKG_PRECOMPILE_AUTO = '0'
    $env:THRESHOLD_SOURCE_MANIFEST = $manifestPath
    $arguments = @('--startup-file=no','--threads=1',"--project=$backgroundProject",'--heap-size-hint=1200M',
        (Join-Path $backgroundProject 'scripts\analysis\relaxtime\run_transport_mode_b_background_validation.jl'),
        (Join-Path $backgroundSource 'inputs'),(Join-Path $backgroundWork 'background'))
    Write-BackgroundStatus 'background' $false $null
    $process = Start-Process -FilePath $backgroundRuntime -ArgumentList $arguments -WorkingDirectory $backgroundProject `
        -WindowStyle Hidden -Wait -PassThru -RedirectStandardOutput (Join-Path $backgroundWork 'background.stdout.log') `
        -RedirectStandardError (Join-Path $backgroundWork 'background.stderr.log')
    Test-BackgroundSource
    [ordered]@{host=$env:COMPUTERNAME;source_archive_sha256=$backgroundPackage.zip_sha256;
        source_files_verified=$backgroundPackage.files;source_verified_before_and_after=$true;
        process_exit_code=$process.ExitCode;arguments=$arguments;
        elapsed_seconds=([DateTime]::UtcNow-$backgroundStart).TotalSeconds;transport_qualified=$false} |
        ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $backgroundWork 'verification.json') -Encoding UTF8
    if ($process.ExitCode -ne 0) { throw "Mode-B background process exited $($process.ExitCode)" }
    $result = Get-Content -LiteralPath (Join-Path $backgroundWork 'background\status.json') -Raw | ConvertFrom-Json
    if (-not $result.phase_plan_passed -or -not $result.cold_seed_audits_passed -or $result.completed_points -ne 909 -or $result.transport_qualified) { throw 'Mode-B background qualification failed' }
    Write-BackgroundStatus 'complete' $true 0
    exit 0
} catch {
    Write-BackgroundStatus 'failed' $true 1 $_.Exception.Message
    exit 1
}
