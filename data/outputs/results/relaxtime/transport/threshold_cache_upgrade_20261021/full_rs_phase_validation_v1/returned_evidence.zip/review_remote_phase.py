"""Review the reanchored mode-A plan and both continuation directions on W."""
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import zipfile

WORK = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-phase-validation-20261025-v1')
SOURCE = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-layer-validation-20261025-v2')
EXECUTION = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-production-replay-20261025-v3')
PROJECT = EXECUTION / 'project'
RUN = WORK / 'phase_revalidation'

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

def helper(relative, name):
    spec = importlib.util.spec_from_file_location(name, PROJECT / relative)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

phase_inputs = read_json(EXECUTION / 'phase_reference_input_manifest.json')
assert digest(EXECUTION / 'phase_reference_inputs.zip') == phase_inputs['zip_sha256']
for name, checksum in phase_inputs['files'].items():
    assert digest(PROJECT / name) == checksum, name
verification = read_json(WORK / 'verification.json')
assert verification['source_verified_before_and_after'] and len(verification['stages']) == 1
assert verification['stages'][0]['stage'] == 'phase' and verification['stages'][0]['process_exit_code'] == 0
manifest = read_json(RUN / 'manifest.json')
status = read_json(RUN / 'status.json')
inputs = helper('scripts/analysis/relaxtime/prepare_transport_production_inputs.py', 'inputs')
baseline = helper('scripts/dev/export_thermal_weighted_transport_baseline.py', 'baseline')
sources = inputs.verified_sources(RUN, manifest, PROJECT.resolve())
commit, identity = baseline.replay_artifact_commit(RUN, manifest)
assert commit == 'unknown' and identity['sha256'] == '789c20ef317b0327692772cb256a408cf0a7ed84b5ad3fa9637ca1ea266888e5'
assert manifest['parameters']['anchor_source'] is None
plan = inputs.verified_phase_plan(RUN)
assert len(plan) == 910 and status['cold_seed_audits'] == 18 and status['cold_seed_audits_passed']
anchors = rows(RUN / 'anchors.csv')
assert len(anchors) == 3 and {float(r['muB_MeV']) for r in anchors} == {0, 450, 900}
groups = {}
for row in plan:
    groups.setdefault(row['scan_group'], []).append(row)
assert len(groups) == 9
anchor_values = {float(r['muB_MeV']): float(r['T_MeV']) for r in anchors}
for selected in groups.values():
    mu, alpha = float(selected[0]['muB_MeV']), float(selected[0]['alpha_T'])
    expected = {i/100 for i in range(-50, 51)}
    if (mu, alpha) == (900, 1):
        expected = (expected - {0}) | {-0.003, 0.003}
    assert {float(r['xi']) for r in selected} == expected and len(selected) == len(expected)
    assert all(math.isclose(float(r['T_MeV']), anchor_values[mu]*alpha, rel_tol=0, abs_tol=1e-10) for r in selected)
audits = rows(RUN / 'cold_seed_audits.csv')
assert len(audits) == 18 and {(r['scan_group'], r['level']) for r in audits} == {
    (group, level) for group in groups for level in ('candidate', 'refined')}
for row in audits:
    assert row['passed'] == 'true'
    assert 0 <= float(row['max_mass_relative_change']) <= 1e-6
    assert 0 <= float(row['omega_absolute_change']) <= 1e-8
trace_count = 0
assert len(list((RUN / 'traces').glob('*.csv'))) == 36
for group, selected in groups.items():
    expected = {inputs.point_key(row) for row in selected}
    for level in ('candidate', 'refined'):
        for direction in ('forward', 'backward'):
            traced = rows(RUN / 'traces' / f'{group}_{level}_{direction}.csv')
            assert len(traced) == len(expected) and {inputs.point_key(row) for row in traced} == expected
            for row in traced:
                assert 0 <= float(row['residual_norm']) <= 1e-8
                assert all(math.isfinite(float(row[key])) and float(row[key]) > 0 for key in ('m_u', 'm_d', 'm_s'))
            trace_count += len(traced)
background = rows(RUN / 'background.csv')
boundaries = rows(RUN / 'phase_boundaries.csv') if (RUN / 'phase_boundaries.csv').exists() else []
assert len(boundaries) == status['first_order_boundaries']
for row in boundaries:
    a, b = float(row['bracket_lower_xi']), float(row['bracket_upper_xi'])
    assert a < float(row['xi']) < b and a < float(row['refined_xi']) < b
    assert math.isclose(float(row['refined_xi'])-float(row['xi']), float(row['refinement_delta_xi']), rel_tol=0, abs_tol=1e-14)
review = dict(host='W', mode='A', phase_plan_passed=True, points=910, groups=9, anchors=anchors,
              cold_seed_audits=18, continuation_files=36, continuation_rows=trace_count,
              maximum_mass_relative_change=max(float(r['max_mass_relative_change']) for r in background),
              maximum_entropy_relative_change=max(abs(float(r['entropy_relative_change'])) for r in background),
              first_order_boundaries=boundaries, source_archive_sha256=identity['sha256'],
              numerical_sources_verified=len(sources), source_snapshots_verified=len(manifest['source_files']),
              calculation_commit=None, reused_historical_anchors=False, mode_B_qualified=False,
              global_phase_diagram_qualified=False, formal_production_promoted=False)
(WORK / 'reviewed_result.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8')
archive = WORK / 'returned_evidence.zip'
assert not archive.exists()
files = [p for p in RUN.rglob('*') if p.is_file()]
files.extend(p for p in WORK.iterdir() if p.is_file() and p.suffix in ('.json', '.log', '.ps1', '.py'))
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path in sorted(set(files)):
        output.write(path, path.relative_to(WORK).as_posix())
info = dict(sha256=digest(archive), bytes=archive.stat().st_size, files=len(set(files)))
(WORK / 'returned_archive_manifest.json').write_text(json.dumps(info, indent=2) + '\n', encoding='utf-8')
print(json.dumps(review, indent=2))
print(json.dumps(info, indent=2))
