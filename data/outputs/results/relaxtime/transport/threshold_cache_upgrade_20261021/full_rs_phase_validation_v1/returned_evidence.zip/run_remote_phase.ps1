$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$productionWorkspace = 'D:\CodexCompute\Julia_RelaxTime\full-rs-phase-validation-20261025-v1'
$productionSource = 'D:\CodexCompute\Julia_RelaxTime\full-rs-layer-validation-20261025-v2'
$productionExecution = 'D:\CodexCompute\Julia_RelaxTime\full-rs-production-replay-20261025-v3'
$productionProject = Join-Path $productionExecution 'project'
$productionRuntime = 'D:\CodexCompute\Julia_RelaxTime\transport-preflight-20261023-v1\runtime\julia-1.12.5\bin\julia.exe'
$productionStart = [DateTime]::UtcNow
$productionStage = 'verify_qualification'
$productionRuns = @()
function Write-ProductionStatus([bool]$finished, [object]$exitCode, [string]$message = '') {
    [ordered]@{host=$env:COMPUTERNAME; stage=$script:productionStage; finished=$finished;
        exit_code=$exitCode; error=$message; started_utc=$productionStart.ToString('o');
        updated_utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json |
        Set-Content -LiteralPath (Join-Path $productionWorkspace 'remote_status.json') -Encoding UTF8
    [Console]::WriteLine($script:productionStage)
}
function Test-ProductionSource {
    foreach ($entry in $phaseInputManifest.files.PSObject.Properties) {
        $hash = (Get-FileHash -LiteralPath (Join-Path $productionProject $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $entry.Value) { throw "Phase input mismatch: $($entry.Name)" }
    }
    foreach ($entry in $productionManifest.source_files.PSObject.Properties) {
        $hash = (Get-FileHash -LiteralPath (Join-Path $productionProject $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $entry.Value) { throw "Source identity mismatch: $($entry.Name)" }
    }
    foreach ($entry in $productionManifest.input_files.PSObject.Properties) {
        $hash = (Get-FileHash -LiteralPath (Join-Path $productionSource ('inputs\'+$entry.Name)) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $entry.Value) { throw "Input identity mismatch: $($entry.Name)" }
    }
}
function Invoke-ProductionStage([string]$name, [string[]]$scriptArguments, [string]$statusFile) {
    $script:productionStage = $name
    Write-ProductionStatus $false $null
    $started = [DateTime]::UtcNow
    $arguments = @('--startup-file=no','--threads=1',"--project=$productionProject",'--heap-size-hint=1200M') + $scriptArguments
    $process = Start-Process -FilePath $productionRuntime -ArgumentList $arguments `
      -WorkingDirectory $productionProject -WindowStyle Hidden -Wait -PassThru `
      -RedirectStandardOutput (Join-Path $productionWorkspace ($name+'.stdout.log')) `
      -RedirectStandardError (Join-Path $productionWorkspace ($name+'.stderr.log'))
    Test-ProductionSource
    $result = if (Test-Path -LiteralPath $statusFile) { Get-Content -LiteralPath $statusFile -Raw | ConvertFrom-Json } else { $null }
    $script:productionRuns += [ordered]@{stage=$name; process_exit_code=$process.ExitCode; arguments=$arguments;
        result=$result; elapsed_seconds=([DateTime]::UtcNow-$started).TotalSeconds}
    [ordered]@{host=$env:COMPUTERNAME; runtime_version='1.12.5'; threads=1;
        source_archive_sha256=$productionManifest.zip_sha256; source_files_verified=$productionManifest.files;
        source_verified_before_and_after=$true; stages=$script:productionRuns; formal_production_promoted=$false} |
        ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $productionWorkspace 'verification.json') -Encoding UTF8
    if ($process.ExitCode -ne 0) { throw "Stage $name failed with exit code $($process.ExitCode)" }
    return $result
}
try {
    Write-ProductionStatus $false $null
    if ($env:COMPUTERNAME -ne 'W') { throw 'Unexpected remote host' }
    if (@(Get-Process -Name julia -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Another Julia process is running' }
    $productionManifestPath = Join-Path $productionSource 'package_manifest.json'
    $productionManifest = Get-Content -LiteralPath $productionManifestPath -Raw | ConvertFrom-Json
    if ($productionManifest.zip_sha256 -ne '789c20ef317b0327692772cb256a408cf0a7ed84b5ad3fa9637ca1ea266888e5') { throw 'Unexpected source package' }
    $review = Get-Content -LiteralPath 'D:\CodexCompute\Julia_RelaxTime\full-rs-production-replay-20261025-v3\reviewed_result.json' -Raw | ConvertFrom-Json
    if (-not $review.production_replay_passed -or -not $review.fortran_comparison_passed -or $review.source_archive_sha256 -ne $productionManifest.zip_sha256) { throw 'Production review is incomplete' }
    $phaseInputManifest = Get-Content -LiteralPath (Join-Path $productionExecution 'phase_reference_input_manifest.json') -Raw | ConvertFrom-Json
    if ($review.phase_reference_input_sha256 -ne $phaseInputManifest.zip_sha256) { throw 'Phase input package changed' }
    Test-ProductionSource
    $env:JULIA_NUM_THREADS = '1'
    $env:OPENBLAS_NUM_THREADS = '1'
    $env:JULIA_NUM_PRECOMPILE_TASKS = '1'
    $env:JULIA_PKG_PRECOMPILE_AUTO = '0'
    $env:THRESHOLD_SOURCE_MANIFEST = $productionManifestPath
    $phaseResult = Invoke-ProductionStage 'phase' @(
        (Join-Path $productionProject 'scripts\analysis\relaxtime\run_transport_phase_revalidation.jl'),
        (Join-Path $productionSource 'inputs'), (Join-Path $productionWorkspace 'phase_revalidation')
    ) (Join-Path $productionWorkspace 'phase_revalidation\status.json')
    if (-not $phaseResult.phase_plan_passed -or -not $phaseResult.cold_seed_audits_passed -or $phaseResult.completed_points -ne 910 -or $phaseResult.cold_seed_audits -ne 18) { throw 'Phase revalidation gates were not met' }
    $productionStage = 'complete'
    Write-ProductionStatus $true 0
    exit 0
} catch {
    Write-ProductionStatus $true 1 $_.Exception.Message
    exit 1
}
