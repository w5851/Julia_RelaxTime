program crossover_tmu_export
use nrtype, only: dp
use constant, only: hc
use variable, only: T, mu_B, arrMu
use type_state
use nr, only: newt
use PNJL, only: funcv_tmu, quantity
implicit none

integer, parameter :: n_mu_targets = 4
integer, parameter :: n_t_points = 101
real(dp), parameter :: T_min_mev = 150d0
real(dp), parameter :: T_max_mev = 250d0
real(dp), parameter :: step_t_mev = 1d0
real(dp), dimension(n_mu_targets), parameter :: target_mu_mev = [2d0, 105d0, 209d0, 291d0]

type(state), dimension(n_t_points) :: scan_states
real(dp), dimension(5) :: x_seed
real(dp), dimension(5) :: x_work
real(dp), dimension(n_t_points) :: delta_phi_scan
logical, dimension(n_t_points) :: check_scan
logical :: check
integer :: mu_index
integer :: t_index
integer :: best_index
real(dp) :: target_mu_b_fm
real(dp) :: target_t_mev

call set_integral

open(unit=931, file='results\crossover_tmu_reference_fortran.dat', status='replace', action='write')
write(931, '(A)') '# point_index muB_MeV T_MeV phi_u phi_d phi_s Phi Phibar m_u_MeV m_d_MeV m_s_MeV delta_phi check'

do mu_index = 1, n_mu_targets
    target_mu_b_fm = target_mu_mev(mu_index) / hc
    if (target_mu_mev(mu_index) < 3d0) then
        target_mu_b_fm = 2d0 / hc
    end if

    x_seed = [-1.8d0, -1.8d0, -2.2d0, 0.01d0, 0.01d0]

    do t_index = 1, n_t_points
        target_t_mev = T_min_mev + step_t_mev * dble(t_index - 1)

        T = target_t_mev / hc
        mu_B = target_mu_b_fm
        arrMu(:) = mu_B / 3d0

        x_work(:) = x_seed(:)
        call newt(x_work, check, funcv_tmu)

        scan_states(t_index)%T = T
        scan_states(t_index)%mu_B = mu_B
        scan_states(t_index)%arrMu(:) = arrMu(:)
        scan_states(t_index)%arrPhi(:) = x_work(:)
        call quantity(scan_states(t_index))

        delta_phi_scan(t_index) = 0d0
        check_scan(t_index) = check
        x_seed(:) = x_work(:)
    end do

    do t_index = 2, n_t_points - 1
        delta_phi_scan(t_index) = abs(scan_states(t_index + 1)%arrPhi(1) - scan_states(t_index - 1)%arrPhi(1))
    end do

    best_index = maxloc(delta_phi_scan(2:n_t_points - 1), dim=1) + 1
    scan_states(best_index)%delta_phi = delta_phi_scan(best_index)

    write(931, '(I6,1X,F10.4,1X,F10.4,9(1X,ES24.16E3),1X,L1)') &
        mu_index, &
        scan_states(best_index)%mu_B * hc, &
        scan_states(best_index)%T * hc, &
        scan_states(best_index)%arrPhi(:), &
        scan_states(best_index)%arrMass(:) * hc, &
        scan_states(best_index)%delta_phi, &
        check_scan(best_index)
end do

close(931)
end program crossover_tmu_export