!module of the meson functions   
module meson_function
    !>ɢ�����
    interface
        function amplitude2(s_cm,t_cm,quark_code)
            use nrtype, only: dp
            implicit none
            real(dp):: amplitude2
            real(dp), intent(in):: s_cm, t_cm
            integer, dimension(4,3), intent(in):: quark_code
        end function amplitude2
    end interface
    !>ƽ��ɢ����
    interface
        subroutine averaged_rate( qk_code, wij, wijn )
            use nrtype, only: dp
            implicit none
            integer, dimension(4,3), intent(in):: qk_code
            real(dp), intent(out):: wij, wijn
        end subroutine averaged_rate
    end interface
    !>two fermion line integral
    interface
        subroutine B0SUM(k0, k, m1, m2, mu1, mu2, B0_re, B0_im)
            use nrtype, only: dp
            implicit none
            real(dp), intent(in):: k0, k, m1, m2, mu1, mu2
            real(dp), intent(out):: B0_re, B0_im
        end subroutine B0SUM!(k0, k, m1, m2, mu1, mu2, B0_re, B0_im)
    end interface
    interface
        subroutine BPM(z,k,m1,m2,mu,pm,B_re,B_im)
            use nrtype, only: dp
            implicit none
            real(dp), intent(in):: z, k, m1, m2, mu, pm
            real(dp), intent(out):: B_re, B_im
        end subroutine BPM!(z,k,m1,m2,mu,pm,B_re,B_im)
    end interface
    !>ѡ���
    interface
        subroutine channel_select(quark_code,cha8)
            implicit none
            integer, dimension(2,4), intent(in):: quark_code
            integer, dimension(8), intent(out):: cha8
        end subroutine channel_select
    end interface
    !>���ɢ����������������Ľ��
    interface
        subroutine cross_section(codes)
            implicit none
            integer, dimension(4,3), intent(in):: codes
        end subroutine cross_section
    end interface
    !>�����ֵ��������
    interface
        subroutine CPVI(a, b, x0, x, w, n)
            use nrtype
            implicit none
            real(dp), intent(in):: a, b, x0
            real(dp), dimension(n), intent(out):: x, w
            integer, intent(inout):: n
        end subroutine CPVI
    end interface
    !>��������Pi
    interface
        subroutine polarization(k0, kk, ps, i, j, pi_re, pi_im)
            use nrtype, only: dp
	        implicit none
            real(dp), intent(in):: k0, kk, ps
            real(dp), intent(out):: pi_re, pi_im
            integer, intent(in):: i, j
        end subroutine polarization
    end interface
    !>������
    interface
        subroutine propagator(k0, k, ps, fpol, im_pol, q4, eta_if)
            use nrtype, only: dp
	        implicit none
            real(dp), intent(in):: k0, k, ps
            real(dp), intent(out):: fpol, im_pol
            integer, dimension(4), intent(in):: q4
            integer, intent(in):: eta_if
        end subroutine
    end interface
    !>relaxation_time
    interface
        subroutine relaxation_time(arrTau)
            use nrtype, only: dp
            implicit none
            real(dp), dimension(2,3), intent(out):: arrTau
        end subroutine
    end interface
    !>ɢ�����Ļ���
    interface
        function tint(s_cm, qk_code)
            use nrtype, only: dp
            implicit none
            real(dp):: tint
            real(dp), intent(in):: s_cm
            integer, dimension(4,3), intent(in):: qk_code
        end function tint
    end interface
    !���� s/t/u - (E pm E)^2
    interface
        function s_pm(s, mi, mj, pm)
        use nrtype, only: dp
        implicit none
        real(dp):: s_pm
        real(dp), intent(in):: s, mi, mj, pm
        end function s_pm
    end interface
    interface
        function t_pm(t, mi, mj, pm)
        use nrtype, only: dp
        implicit none
        real(dp):: t_pm
        real(dp), intent(in):: t, mi, mj, pm
        end function t_pm
    end interface
    interface
        function u_pm(u, mi, mj, pm)
        use nrtype, only: dp
        implicit none
        real(dp):: u_pm
        real(dp), intent(in):: u, mi, mj, pm
        end function u_pm
    end interface
end module