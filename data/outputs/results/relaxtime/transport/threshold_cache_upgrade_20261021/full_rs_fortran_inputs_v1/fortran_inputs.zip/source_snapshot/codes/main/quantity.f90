!>�����������ѧ����ͨ���Զ�������state����
subroutine quantity(phy)
    use nrtype, only: dp
    use constant
    use integral
    use quark_fun, only: fphi, fphibar, AA, AA_bar
    use type_state
    implicit none
!***********************************************************************
    type(state), intent(inout):: phy
!***********************************************************************
    integer:: i, j, k
    real(dp):: phi_u, phi_d, phi_s, Phi1, Phi2
    real(dp):: T, mu_B, n_B, n_charge, n_strange
    real(dp):: pressure, energy, s
    real(dp):: delta_s1, delta_s2!�������ʱ�м���
    real(dp), dimension(3):: arrEi, arrMu, arrMass, arrA, phi, arrG
    real(dp), dimension(2,3):: arrN, arrX
    real(dp), dimension(2,3):: arrFq, arrFA
    real(dp):: p
    real(dp):: s1, s2
    real(dp):: pressure1, pressure2
    real(dp):: a_t, b_t
    real(dp):: dU_dt, U
    real(dp):: f_phi
!***********************************************************************
T = phy%T
mu_B = phy%mu_B
arrMu(:) = phy%arrMu(:)
phi_u = phy%arrPhi(1)
phi_d = phy%arrPhi(2)
phi_s = phy%arrPhi(3)
Phi1 = phy%arrPhi(4)
Phi2 = phy%arrPhi(5)
phi(:) = [phi_u, phi_d, phi_s]
mu_B = arrMu(1)*2d0 + arrMu(2)
!***********************************************************************
arrMass(:) = arrm0(:) - 4.0d0*G_f*phi( ijk(:,1) ) + 2.0d0*K_f*phi( ijk(:,2) )*phi( ijk(:,3) )
a_T = a0 + a1*(T0/T) + a2*(T0/T)**2
b_T = b3*(T0/T)**3 
f_phi = 1d0 - 6d0*Phi2*Phi1 + 4d0*(Phi2**3 + Phi1**3) - 3.0d0*(Phi2*Phi1)**2
U = T**4.0d0*( -1.0d0/2.0d0*a_T*Phi2*Phi1 + b_T*log(f_phi) )
dU_dt = -1d0/2d0*Phi2*Phi1*( 4d0*a0*T**3 + 3d0*a1*T0*T**2 + 2d0*a2*T0**2*T ) + (b3*T0**3)*log(f_phi)
!***********************************************************************
pressure1 = 0d0
do i = 1, npoint!��ɢ���֣���������ΪLambda
    p = y(i)
    arrEi(:) = sqrt(p**2 + arrMass(:)**2)
    pressure1 = pressure1 + w(i)* p**2 * sum( arrEi(:) ) 
end do
pressure1 = pressure1*N_c/(pi**2)
!***********************************************************************
pressure = 0d0
s1 = 0d0!s1����p^2dp*(Q_1+Q_2)�����������ܶȺ�ѹǿ�ļ���
s2 = 0d0!s2����p^2dp*( (E-mu)*nn(E-mu) + (E+mu)*nn_bar(E+mu) )
arrN(:,:) = 0d0!�������ܶ�
do i = 1, npoint1
    p = y1(i)
    arrEi(:) = sqrt(p**2 + arrMass(:)**2)
    arrX(1,:) = arrEi(:) - arrMu(:)
    arrX(2,:) = arrEi(:) + arrMu(:)
    do k = 1, 3, 1!ζ��
        arrFq(1,k) = fphi(arrX(1,k), T, Phi1, Phi2)
        arrFq(2,k) = fphibar(arrX(2,k), T, Phi1, Phi2)
        arrFA(1,k) = AA(arrX(1,k), T, Phi1, Phi2)
        arrFA(2,k) = AA_bar(arrX(2,k), T, Phi1, Phi2)
    end do
    delta_s1 = 0d0
    delta_s2 = 0d0
    do k = 1, 3, 1
        do j = 1, 2, 1
            delta_s1 = delta_s1 + log(arrFA(j,k))
            delta_s2 = delta_s2 + arrX(j,k)*arrFq(j,k)
        end do
    end do
    s1 = s1 + w1(i)*p**2 *delta_s1
    s2 = s2 + w1(i)*p**2 *delta_s2
    arrN(:,:) = arrN(:,:) + w1(i)* p**2 *arrFq(:,:)
end do
pressure2 = s1*( N_c*T ) / ( 3d0*pi**2 )
arrN(:,:) = arrN(:,:) * N_c / (pi**2)
n_B = sum( arrN(:,:)*arr_quark_baryon(:,:) )
n_charge = sum( arrN(:,:)*arr_quark_charge(:,:) )
n_strange = sum( arrN(:,:)*arr_quark_strange(:,:) )
!***********************************************************************
pressure = pressure1 + pressure2 - 2.0d0*G_f*( phi_u**2 + phi_d**2 + phi_s**2 ) &
    + 4d0*K_f*phi_u*phi_d*phi_s - U - 21.60669816d0
s = ( s1/3.0d0 + s2/T )*N_c/(pi**2) - dU_dT
energy = T*S + sum( (arrN(1,:)-arrN(2,:))*arrMu(:) ) - pressure
!***********************************************************************
arrA(:) = 0d0
do i = 1, npoint, 1
    p = y(i)
    arrEi(:) = sqrt(p**2 + arrMass(:)**2)
    arrA(:) = arrA(:) + w(i) * p**2 * ( - 1d0 ) / arrEi(:)
end do
do i = 1, npoint1, 1
    p = y1(i)
    arrEi(:) = sqrt(p**2 + arrMass(:)**2)
    do k = 1, 3, 1!ζ��
        arrFq(1,k) = fphi(arrEi(k) - arrMu(k), T, Phi1, Phi2)
        arrFq(2,k) = fphibar(arrEi(k) + arrMu(k), T, Phi1, Phi2)
    end do
    arrA(:) = arrA(:) + w1(i) * p**2 * ( arrFq(1,:) + arrFq(2,:) ) / arrEi(:)
end do
arrA(:) = arrA(:)*4d0
arrG(:) = - arrMass(:) * arrA(:) * (3d0*K_f) / (4d0*pi**2)
!***********************************************************************
phy%arrMass(:) = arrMass(:)!����
phy%rho_mass = sum( arrN(1,:)*arrMass(:) + arrN(2,:)*arrMass(:) )
phy%arrN(:,:) = arrN(:,:)!����������ܶ�(����,3ζ��)
phy%N_B = n_B!�ܶ�
phy%n_charge = n_charge
phy%n_strange = n_strange
phy%pressure = pressure!ѹǿ
phy%energy = energy!�����ܶ�
phy%s = s!���ܶ�
phy%arrA(:) = arrA(:)
phy%arrG(:) = arrG(:)
end subroutine quantity