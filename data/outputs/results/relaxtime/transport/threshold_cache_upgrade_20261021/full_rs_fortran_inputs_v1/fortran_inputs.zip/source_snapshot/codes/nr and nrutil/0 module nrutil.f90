module nrutil
    use nrtype, only: dp
    implicit none
    integer, parameter:: NPAR_ARTH = 16, NPAR2_ARTH = 8
!>Array function returning an arithmetic progression.
    interface arth
        module procedure arth_d, arth_i
    end interface
!>Routines for argument checking and error handling (nrerror is not currently overloaded)
    interface assert_eq
        module procedure assert_eq2, assert_eq3, assert_eq4
    end interface
!>Return the location as integer
    !interface imaxloc
    !    module procedure imaxloc_r, imaxloc_i
    !end interface
    interface swap
        module procedure i_swap, dp_swap
    end interface
contains
!***********************************************************************
    function arth_d(first, increment, n)
        real(dp), intent(in):: first, increment
        integer, intent(in):: n
        real(dp), dimension(n):: arth_d
        integer:: k, k2
        real(dp):: temp
        if (n > 0) then
            arth_d(1) = first
        end if
        if (n <= NPAR_ARTH) then
            do k = 2, n
                arth_d(k) = arth_d(k-1) + increment
            end do
        else
            do k = 2, NPAR2_ARTH
                arth_d(k) = arth_d(k-1) + increment
            end do
            temp = increment*NPAR2_ARTH
            k = NPAR2_ARTH
            do
                if (k >= n) then
                    exit
                end if
                k2 = k + k
                arth_d(k+1:min(k2,n)) = arth_d(1:min(k,n-k)) + temp
                temp = temp + temp!6
                k = k2
            end do
        end if
    end function arth_d
    function arth_i(first, increment, n)
        integer, intent(in):: first, increment
        integer, intent(in):: n
        integer, dimension(n):: arth_i
        integer:: k, k2, temp
        if (n > 0) then
            arth_i(1) = first
        end if
        if (n <= NPAR_ARTH) then
            do k = 2, n
                arth_i(k) = arth_i(k-1) + increment
            end do
        else
            do k = 2, NPAR2_ARTH
                arth_i(k) = arth_i(k-1) + increment
            end do
            temp = increment*NPAR2_ARTH
            k = NPAR2_ARTH
            do
                if (k >= n) then
                    exit
                end if
                k2 = k + k
                arth_i(k+1:min(k2,n)) = arth_i(1:min(k,n-k)) + temp
                temp = temp + temp!6
                k = k2
            end do
        end if
    end function arth_i

!>Report and die if integers not all equal
    function assert_eq2(n1,n2,string)!2
        implicit none
        character(len=*), intent(in):: string
        integer, intent(in):: n1, n2
        integer:: assert_eq2
        if (n1 == n2) then
            assert_eq2 = n1
        else
            write(*,*) "assert_eq failed with: ", string
            write(*,*) "n1,n2 = ", n1, n2
            stop "progam terminated by assert_eq"
        end if
    end function assert_eq2
    function assert_eq3(n1,n2,n3,string)!3
        implicit none
        character(len=*), intent(in):: string
        integer, intent(in):: n1, n2, n3
        integer:: assert_eq3
        if (n1 == n2 .and. n1 == n3) then
            assert_eq3 = n1
        else
            write(*,*) "assert_eq failed with: ", string
            write(*,*) "n1,n2,43 = ", n1, n2, n3
            stop "progam terminated by assert_eq"
        end if
    end function assert_eq3
    function assert_eq4(n1,n2,n3,n4,string)!4
        implicit none
        character(len=*), intent(in):: string
        integer, intent(in):: n1, n2, n3, n4
        integer:: assert_eq4
        if (n1 == n2 .and. n1 == n3 .and. n1 == n4) then
            assert_eq4 = n1
        else
            write(*,*) "assert_eq failed with: ", string
            write(*,*) "n1,n2,n3,n4 = ", n1, n2, n3, n4
            stop "progam terminated by assert_eq"
        end if
    end function assert_eq4
!>interpolation, ��ֵ
    !function inpo(x,f,x0)
    !    use nrtype, only: dp
    !    implicit none
    !    real(dp), dimension(:), intent(in):: x, f
    !    real(dp), intent(in):: x0
    !    real(dp):: inpo
    !    i0 = floor((s_cm-s_bo)/h) + 1
    !    inc = (sig(i0+1)-sig(i0)) / (s_cmk(i0+1)-s_cmk(i0))
    !    sig_ij = inc*(s_cm-s_cmk(i0)) + sig(i0)
    !
!>Report a message, then die.
    subroutine nrerror(string)
        character(len=*), intent(in):: string
        write (*,*) "nrerror: ", string
        stop "progam terminated by nerror"
    end subroutine nrerror
!>swap
    subroutine i_swap(a,b)
        implicit none
        integer, intent(inout) :: a,b
        integer:: temp
        temp = a; a = b; b = temp
    end subroutine i_swap
    subroutine dp_swap(a,b)
        use nrtype, only: dp
        implicit none
        real(dp), intent(inout) :: a,b
        real(dp):: temp
        temp = a; a = b; b = temp
    end subroutine dp_swap
    subroutine arr_dp_swap(a,b)
        use nrtype, only: dp
        implicit none
        real(dp), intent(inout) :: a,b
        real(dp):: temp
        temp = a; a = b; b = temp
    end subroutine arr_dp_swap
    
    
end module
