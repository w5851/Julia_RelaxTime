subroutine set_integral
    use integral
    use constant, only: lambda, pi
    use nr, only: gauleg, gauleg_0, gauleg_ab
    implicit none
!***********************************************************************
    call gauleg( 0.0d0, Lambda, y(1:npoint), w(1:npoint) )
    call gauleg( 0.0d0, 15d0, y1(1:npoint1), w1(1:npoint1) )
    call gauleg( 0d0, pi, ypi(1:npoint_rex), wpi(1:npoint_rex) )!averaged_rate
    call gauleg( 0d0, 15d0, yp(1:npoint_rex), wp(1:npoint_rex) )
    !call gauleg( 0d0, Lambda, yp(1:npoint_rex), wp(1:npoint_rex) )
    
    call gauleg( 0d0, Lambda, xb(1:n_bpm), wb(1:n_bpm) )!BPM
    call gauleg_0(zz128, pp128, n128)
    call gauleg_0(zz64, pp64, n64)
end subroutine set_integral