! �����飬ά��Ϊ5
! 5�����������
! 5 ��δ֪���ֱ�Ϊ phi_u,d,s, Phi1,2
function funcv_tmu( x )
use nrtype, only: dp
use nrutil, only: assert_eq
use constant
use variable, only: T, arrMu
use integral
use quark_fun, only: AA, AA_bar, fphi, fphibar
implicit none
!***********************************************************************
real(dp), dimension(:), intent(in):: x
real(dp), dimension(size(x)):: funcv_tmu
!***********************************************************************
integer, parameter:: n_quark = 5
integer:: i, j, k
integer:: n
real(dp):: phi_u, phi_d, phi_s, Phi1, Phi2
real(dp):: a_t, b_t
real(dp):: U
real(dp):: d_U_Phi1, d_U_Phi2, dU_dt
real(dp):: f_phi
real(dp), dimension(3):: phi, arrMass, arrE, EQ1, EQ2
real(dp), dimension(2,3):: arrF, arrFA, arrX
real(dp):: p
real(dp):: EQ_PHI1, EQ_PHI2
!***********************************************************************
n = assert_eq(size(x),n_quark,'funcv_tmu')
phi_u = x(1)
phi_d = x(2)
phi_s = x(3)
Phi1 = x(4)
Phi2 = x(5)
phi(:) = [phi_u, phi_d, phi_s]
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
arrMass(:) = arrm0(:) - 4.0d0*G_f*phi( ijk(:,1) ) + 2.0d0*K_f*phi( ijk(:,2) )*phi( ijk(:,3) )
a_T = a0 + a1*(T0/T) + a2*(T0/T)**2
b_T = b3*(T0/T)**3
f_phi = 1.0d0 - 6.0d0*Phi2*Phi1 + 4.0d0*(Phi2**3+Phi1**3) - 3.0d0*(Phi2*Phi1)**2
U = T**4*( -1.0d0/2.0d0*a_T*Phi2*Phi1 + b_T*log(f_phi) )
dU_dt = -1d0/2d0*Phi2*Phi1*( 4d0*a0*T**3 + 3d0*a1*T0*T**2 + 2d0*a2*T0**2*T ) + (b3*T0**3)*log(f_phi)
d_U_Phi1 = T**4*(-1.0d0/2.0d0*a_t*Phi2 + b_T*(-6d0*Phi2 + 12.0d0*Phi1**2 - 6d0*Phi2**2*Phi1)/f_phi)
d_U_Phi2 = T**4*(-1.0d0/2.0d0*a_t*Phi1 + b_T*(-6d0*Phi1 + 12.0d0*Phi2**2 - 6d0*Phi1**2*Phi2)/f_phi)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
EQ1(:) = 0d0
do i = 1, npoint!�ض�
    p = y(i)
    arrE(:) = sqrt(p**2 + arrMass(:)**2)
!����phi_u,d,s�ķ��̲���1
    EQ1(:) = EQ1(:) + w(i)*p**2/arrE(:)
end do
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
EQ2(:) = 0d0
EQ_PHI1 = 0d0
EQ_PHI2 = 0d0
do i=1, npoint1!y1w1�ϴ�����
    p = y1(i)
    arrE(:) = sqrt(p**2 + arrMass(:)**2)
    arrX(1,:) = arrE(:) - arrMu(:)
    arrX(2,:) = arrE(:) + arrMu(:)
    do k = 1, 3, 1
        arrF(1,k) = fphi(arrX(1,k), T, Phi1, Phi2)
        arrF(2,k) = fphibar(arrX(2,k), T, Phi1, Phi2)
        arrFA(1,k) = AA(arrX(1,k), T, Phi1, Phi2)
        arrFA(2,k) = AA_bar(arrX(2,k), T, Phi1, Phi2)
    end do
!����phi_u,d,s�ķ��̲���2
    EQ2(:) = EQ2(:) + w1(i)*p**2*( arrF(1,:) + arrF(2,:) )/arrE(:)
!����Phi1��Phi2�ķ��̲���
    EQ_PHI1 = EQ_PHI1 + w1(i)*p**2* &
        ( exp(-(arrX(1,1))/T)/arrFA(1,1) + exp(-2d0*(arrX(2,1))/T)/arrFA(2,1)     &
        + exp(-(arrX(1,2))/T)/arrFA(1,2) + exp(-2d0*(arrX(2,2))/T)/arrFA(2,2)     &
        + exp(-(arrX(1,3))/T)/arrFA(1,3) + exp(-2d0*(arrX(2,3))/T)/arrFA(2,3) ) 
    EQ_PHI2 = EQ_PHI2 + w1(i)*p**2* &
        ( exp(-2d0*(arrX(1,1))/T)/arrFA(1,1) + exp(-(arrX(2,1))/T)/arrFA(2,1)     &
        + exp(-2d0*(arrX(1,2))/T)/arrFA(1,2) + exp(-(arrX(2,2))/T)/arrFA(2,2)     &
        + exp(-2d0*(arrX(1,3))/T)/arrFA(1,3) + exp(-(arrX(2,3))/T)/arrFA(2,3) ) 
end do
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
do i = 1, 3, 1
    funcv_tmu(i) = -N_c/(pi**2)*( ( -4d0*G_f*arrMass(ijk(i,1)) ) * (EQ1(ijk(i,1))-EQ2(ijk(i,1))) &
        + ( 2d0*K_f*phi(ijk(i,2))*arrMass(ijk(i,3)) ) * (EQ1(ijk(i,3))-EQ2(ijk(i,3))) &
        + ( 2d0*K_f*phi(ijk(i,3))*arrMass(ijk(i,2)) ) * (EQ1(ijk(i,2))-EQ2(ijk(i,2))) ) &
        + 4d0*G_f*phi(ijk(i,1)) - 4d0*K_f*phi(ijk(i,2))*phi(ijk(i,3))
end do
funcv_tmu(4) = -T*N_c/(pi**2)*EQ_PHI1 + d_U_phi1
funcv_tmu(5) = -T*N_c/(pi**2)*EQ_PHI2 + d_U_phi2
end