subroutine gauleg(x1,x2,x,w)
    use nrtype, only: dp
    use nrutil, only: assert_eq, arth, nrerror
    implicit  none
    real(dp), intent(in):: x1, x2
    real(dp), dimension(:), intent(out):: x, w
!***********************************************************************
    real(dp), parameter:: EPS = 3d-14
    integer, parameter:: MAXIT = 10
    integer:: its, j, m, n
    real(dp):: xl, xm
    real(dp), dimension( (size(x)+1)/2 ):: p1, p2, p3, pp, z, z1
    logical, dimension( (size(x)+1)/2 ):: unfinished
!***********************************************************************
    n = assert_eq(size(x),size(w),"gauleg")
    m = (n+1)/2
    xm = 0.5d0*(x2+x1)
    xl = 0.5d0*(x2-x1)
    z(:) = cos(3.141592654d0*(arth(1,1,m)-0.25d0)/(n+0.5d0))
    unfinished = .true.
    do its = 1, MAXIT
        where (unfinished)
            p1 = 1d0
            p2 = 0d0
        end where
        do j = 1, n
            where (unfinished)
                p3 = p2
                p2 = p1
                p1 = ( (2d0*j-1d0)*z*p2 - (j-1d0)*p3 ) / j
            end where
        end do
        where (unfinished)
            pp = n * (z*p1-p2) / (z*z-1d0)
            z1 = z
            z = z1 - p1/pp
            unfinished = ( abs(z-z1)>EPS )
        end where
        if(.not. any(unfinished)) exit
    end do
    if (its == MAXIT + 1) then
        call nrerror("too many interations in gauleg")
    end if
    x(1:m) = xm - xl*z(:)
    x(n:n-m+1:-1) = xm + xl*z(:)
    w(1:m) = 2d0*xl / ( (1d0-z(:)**2)*pp(:)**2 )
    w(n:n-m+1:-1) = w(1:m)
end subroutine gauleg