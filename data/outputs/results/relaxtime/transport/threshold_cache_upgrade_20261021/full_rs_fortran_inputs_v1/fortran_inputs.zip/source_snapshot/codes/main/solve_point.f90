module solve_point_mod
    use nrtype, only: dp
    use type_state
    implicit none
    private
    public :: solve_gap_at_tmu, load_first_order_line, get_phase_seed

    integer, parameter :: N_1ST_MAX = 127
    integer, save :: n_1st_loaded = 0
    real(dp), dimension(N_1ST_MAX), save :: mu_1st_data, T_1st_data

    real(dp), dimension(5), parameter :: SEED_QGP = &
        [-0.5d0, -0.5d0, -1.8d0, 0.8d0, 0.8d0]

contains

    subroutine load_first_order_line(filename)
        character(len=*), intent(in) :: filename
        integer :: i, ios
        open(unit=199, file=filename, status='old', action='read', iostat=ios)
        if (ios /= 0) then
            print *, '[solve_point] WARNING: cannot open ', trim(filename)
            n_1st_loaded = 0
            return
        end if
        n_1st_loaded = 0
        do i = 1, N_1ST_MAX
            read(199, *, iostat=ios) mu_1st_data(i), T_1st_data(i)
            if (ios /= 0) exit
            n_1st_loaded = n_1st_loaded + 1
        end do
        close(199)
    end subroutine

    subroutine get_phase_seed(T_mev, mu_B_mev, x_prev, x_out)
        use xnum, only: location_dp, ChaZhi
        real(dp), intent(in) :: T_mev, mu_B_mev
        real(dp), dimension(5), intent(in) :: x_prev
        real(dp), dimension(5), intent(out) :: x_out
        integer :: idx
        real(dp) :: mu_t

        x_out(:) = x_prev(:)

        if (n_1st_loaded > 0 .and. T_mev < T_1st_data(n_1st_loaded)) then
            idx = location_dp(T_mev, T_1st_data(1:n_1st_loaded))
            if (idx >= 1 .and. idx < n_1st_loaded) then
                mu_t = ChaZhi(T_mev, T_1st_data(idx), T_1st_data(idx+1), &
                               mu_1st_data(idx), mu_1st_data(idx+1))
                if (mu_B_mev > mu_t) then
                    x_out(:) = SEED_QGP(:)
                end if
            end if
        end if
    end subroutine

    subroutine solve_gap_at_tmu(T_mev, mu_B_mev, x_seed, phy, converged)
        use constant, only: hc
        use variable, only: T_var => T, mu_B_var => mu_B, arrMu_var => arrMu
        use nr, only: newt
        use PNJL, only: funcv_tmu, quantity
        real(dp), intent(in) :: T_mev, mu_B_mev
        real(dp), dimension(5), intent(inout) :: x_seed
        type(state), intent(out) :: phy
        logical, intent(out) :: converged

        real(dp), dimension(5) :: x_work
        real(dp) :: mu_B_fm
        logical :: check

        T_var = T_mev / hc
        mu_B_fm = mu_B_mev / hc
        if (mu_B_mev < 3d0) mu_B_fm = 2d0 / hc
        mu_B_var = mu_B_fm
        arrMu_var(:) = mu_B_fm / 3d0

        phy%T = T_var
        phy%mu_B = mu_B_fm
        phy%arrMu(:) = arrMu_var(:)
        phy%delta_phi = 0d0

        x_work(:) = x_seed(:)
        call newt(x_work, check, funcv_tmu)
        converged = .not. check

        phy%arrPhi(:) = x_work(:)
        x_seed(:) = x_work(:)

        call quantity(phy)
    end subroutine

end module solve_point_mod
