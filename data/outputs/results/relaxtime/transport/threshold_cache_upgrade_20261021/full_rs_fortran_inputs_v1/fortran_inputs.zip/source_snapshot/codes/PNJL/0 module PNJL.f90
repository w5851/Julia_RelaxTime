!>module about the equations of PNJL
module PNJL
    interface
        subroutine coefficients_tmu(phy)
            use type_state
            implicit none
            type(state), intent(inout):: phy
        end subroutine coefficients_tmu
    end interface
    interface
        subroutine coefficients_tn(phy)
            use type_state
            implicit none
            type(state), intent(inout):: phy
        end subroutine coefficients_tn
    end interface
    !>equations of PNJL
    interface
        function funcv_tmu(x)
            use nrtype, only: dp
            implicit none
            real(dp), dimension(:), intent(in):: x
            real(dp), dimension(size(x)):: funcv_tmu
        end function funcv_tmu
    end interface
    interface
        function funcv_quark2(x)
            use nrtype, only: dp
            implicit none
            real(dp), dimension(:), intent(in):: x
            real(dp), dimension(size(x)):: funcv_quark2
        end function funcv_quark2
    end interface
    interface
        subroutine quantity(phy)
            use type_state
            implicit none
            type(state), intent(inout):: phy
        end subroutine
    end interface
end module
    