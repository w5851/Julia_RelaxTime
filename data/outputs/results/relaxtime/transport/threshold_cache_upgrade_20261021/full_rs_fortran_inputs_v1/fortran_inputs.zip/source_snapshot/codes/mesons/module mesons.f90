!>[u/d/s; +/-; s,u lh, t lh]
module scattering_code
    implicit none
    !>qq-qq
    integer, dimension(4,3), parameter:: uu_code = reshape([1,1,1,1, 1,1,1,1, 1,1,1,1], [4,3])!>uu-uu
    integer, dimension(4,3), parameter:: ud_code = reshape([1,2,1,2, 1,1,1,1, 1,-1,1,1], [4,3])!>ud-ud
    integer, dimension(4,3), parameter:: us_code = reshape([1,3,1,3, 1,1,1,1, 1,-1,-1,1], [4,3])!>us-us
    integer, dimension(4,3), parameter:: ss_code = reshape([3,3,3,3, 1,1,1,1, -1,1,-1,1], [4,3])!>ss-ss
    !>qqb-qqb
    integer, dimension(4,3), parameter:: uub_code = reshape([1,1,1,1, 1,-1,1,-1, 1,1,1,1], [4,3])!>uub-uub
    integer, dimension(4,3), parameter:: udb_code = reshape([1,2,1,2, 1,-1,1,-1, 1,-1,1,1], [4,3])!>udb-udb
    integer, dimension(4,3), parameter:: usb_code = reshape([1,3,1,3, 1,-1,1,-1, 1,-1,-1,1], [4,3])!>usb-usb
    integer, dimension(4,3), parameter:: uubddb_code = reshape([1,1,2,2, 1,-1,1,-1, 1,1,1,-1], [4,3])!>uub-ddb
    integer, dimension(4,3), parameter:: uubssb_code = reshape([1,1,3,3, 1,-1,1,-1, -1,1,1,-1], [4,3])!>uub-ssb
    integer, dimension(4,3), parameter:: ssbuub_code = reshape([3,3,1,1, 1,-1,1,-1, -1,1,1,-1], [4,3])!>ssb-uub
    integer, dimension(4,3), parameter:: ssb_code = reshape([3,3,3,3, 1,-1,1,-1, -1,1,-1,1], [4,3])!>ssb-ssb
    !>qqb-qqb(added)
    integer, dimension(4,3), parameter:: dub_code = reshape([2,1,2,1, 1,-1,1,-1, 1,-1,1,1], [4,3])!>dub-dub
    integer, dimension(4,3), parameter:: sub_code = reshape([3,1,3,1, 1,-1,1,-1, 1,-1,-1,1], [4,3])!>sub-sub
    !>qbqb-qbqb
    integer, dimension(4,3), parameter:: ubub_code = reshape([1,1,1,1, -1,-1,-1,-1, 1,1,1,1], [4,3])!>ubub-ubub
    integer, dimension(4,3), parameter:: ubdb_code = reshape([1,2,1,2, -1,-1,-1,-1, 1,-1,1,1], [4,3])!>ubdb-ubdb
    integer, dimension(4,3), parameter:: ubsb_code = reshape([1,3,1,3, -1,-1,-1,-1, 1,-1,-1,1], [4,3])!>ubsb-ubsb
    integer, dimension(4,3), parameter:: sbsb_code = reshape([3,3,3,3, -1,-1,-1,-1, -1,1,-1,1], [4,3])!>sbsb-sbsb
end module scattering_code