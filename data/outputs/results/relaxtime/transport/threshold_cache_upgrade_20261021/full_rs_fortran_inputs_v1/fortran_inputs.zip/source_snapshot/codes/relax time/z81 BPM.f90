!>z����lambda=m+mu1-mu2��k�������Ӷ���
subroutine BPM(z,k,m1,m2,mu,pm,B_re,B_im)
    use nrtype, only: dp
    use constant, only: pi, Lambda
    use variable, only: T, Phi1, Phi2
    use integral, only: xb, wb, n_bpm, zz128, pp128, n128!, yp, wp
    use meson_function, only: CPVI
    use quark_fun, only: fd
    use nr, only: gauleg_ab
    implicit none
!***********************************************************************
    real(dp), intent(in):: z, k, m1, m2, mu, pm
    real(dp), intent(out):: B_re, B_im
!***********************************************************************
    integer:: i, npoint_n
    integer, parameter:: npoint0 = n128
    real(dp), dimension(npoint0):: yy, ww
    real(dp):: p, E, E1, E2, up, bo, E0, Emax, log_e
    real(dp):: E_temp1, E_temp2
!***********************************************************************
    Emax = sqrt(m1**2 + lambda**2)
!>����Ϊ������
    !if(abs(k) < 1d-10 .and. abs(z) > 1d-10)then
    if(abs(k) < 1d-12)then
		E0 = -z/2d0 - (m1**2 - m2**2) / (2d0*z)
        B_Re = 0d0
		if(E0 > m1 .and. E0 < Emax)then!singular point
            npoint_n = npoint0
			call CPVI(m1, Emax, E0, yy, ww, npoint_n)
			B_im = 2d0*pi/z*fd(pm*E0,mu,T,phi1,phi2)*sqrt(E0**2-m1**2)
		    do i = 1, npoint_n
			    E = yy(i)
			    p = sqrt(E**2-m1**2)
			    B_Re = B_Re + ww(i) * p * fd(pm*E,mu,T,phi1,phi2) / (z**2 + 2d0*z*E + m1**2 - m2**2)
		    end do
		else!no singular point
			B_im = 0d0
		    do i = 1, n_bpm!���������е����� 0<p<lambda
			    p = xb(i)
			    E = sqrt(p**2+m1**2)
			    B_Re = B_Re + wb(i) * p**2 * fd(pm*E,mu,T,phi1,phi2) / (z**2 + 2d0*z*E + m1**2 - m2**2)/E
            end do
        end if
        B_Re = B_Re * 4d0
        return
    end if
!***********************************************************************
!������Ϊ��, if(abs(k) > 1d-10)then
!real part
    E_temp1 = -z/2d0 + z*(m1**2-m2**2)/(2d0*(k**2-z**2))
    E_temp2 = k*sqrt((z**2-k**2+m1**2-m2**2)**2+4d0*m1**2*(k**2-z**2)) / (2d0*(k**2-z**2))
    E1 = E_temp1 + E_temp2
    E2 = E_temp1 - E_temp2
    log_e = (k**2-m1**2+m2**2-z**2)/2d0/z
    B_Re = 0d0
    if (log_e > m1 .and. log_e < Emax) then
        npoint_n = npoint0
        call CPVI(m1, Emax, log_e, yy, ww, npoint_n)
        do i = 1, npoint_n, 1
            E = yy(i)
            p = sqrt(E**2-m1**2)
            B_Re = B_Re + ww(i)*fd(pm*E,mu,T,phi1,phi2)*log(abs((((z+E)**2-(p-k)**2-m2**2)/((z+E)**2-(p+k)**2-m2**2))))
        end do
    else
        do i = 1, n_bpm, 1!���������е����� 0<p<lambda
            p = xb(i)
            E = sqrt(p**2+m1**2)
            B_Re = B_Re + wb(i)*fd(pm*E,mu,T,phi1,phi2)*log(abs( ((z+E)**2-(p-k)**2-m2**2) / ((z+E)**2-(p+k)**2-m2**2) ))*p/E
        end do	
    end if
    !do i = 1, n_bpm, 1!���������е����� 0<p<lambda
    !    p = xb(i)
    !    E = sqrt(p**2+m1**2)
    !    B_Re = B_Re + wb(i)*fd(pm*E,mu,T,phi1,phi2)*log(abs( ((z+E)**2-(p-k)**2-m2**2) / ((z+E)**2-(p+k)**2-m2**2) ))*p/E
    !end do
    B_Re = B_Re / k
!imaginary part
    B_im = 0d0
    if((E1-Emax)*(E1-m1) <= 0d0 .or. (E2-Emax)*(E2-m1) <= 0d0) then!�н��ڷ�Χ��
        if( (E1-Emax)*(E1-m1)<0d0 .and. (E2-Emax)*(E2-m1)<0d0 ) then!��������ڷ�Χ��
            bo = min(E2,E1)
            up = max(E2,E1)				
        else
            up = Emax
            if((E1-Emax)*(E1-m1).lt.0d0)then!һ�����ڷ�Χ��
                bo = E1
            end if
            if((E2-Emax)*(E2-m1).lt.0d0)then!һ�����ڷ�Χ��
                bo = E2
            end if
        end if!���ifȷ�����鲿�Ļ���������
        if(abs(z) < 1d-15)then
            B_im = 0d0
        else
            if(abs(up-bo) < 1d-12)then
                B_im = 0d0
            else
                call gauleg_ab(bo, up, zz128(:), pp128(:), yy(:), ww(:), npoint0)
                B_im = 0d0
                do i = 1, npoint0
                    E = yy(i)
                    B_im = B_im + ww(i)*fd(pm*E,mu,T,phi1,phi2)
                end do
                B_im = pi/k*B_im
                if ( z < 0d0 ) B_im = -B_im
            end if
        end if						
    else
        B_im = 0d0
    end if
end