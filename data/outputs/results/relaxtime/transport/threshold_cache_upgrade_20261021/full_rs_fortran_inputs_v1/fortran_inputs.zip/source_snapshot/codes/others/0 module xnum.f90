module xnum
    interface
        function location_dp(x,arr)
            use nrtype, only: dp
            real(dp), intent(in):: x
            real(dp), dimension(:), intent(in):: arr
            integer:: location_dp
        end function
    end interface
    interface
        function ChaZhi(x,x1,x2,y1,y2)
            use nrtype, only: dp
            real(dp), intent(in):: x, x1, x2, y1, y2
            real(dp):: ChaZhi
        end function ChaZhi
    end interface
    
    
    
    

    
    
    
    
    
    
    
    
    
end module xnum    
!***********************************************************************
!***********************************************************************
!***********************************************************************
function location_dp(x,arr)
    use nrtype, only: dp
    use nrutil, only: nrerror
    real(dp), intent(in):: x
    real(dp), dimension(:), intent(in):: arr
    integer:: location_dp
!***********************************************************************
    integer:: n
!***********************************************************************
    n = size(arr)
    if((x-arr(1))*(x-arr(n))>0d0) then
        call nrerror("error in location_dp.")
    end if
    do location_dp = 1,n,1
        if(.not.((x-arr(location_dp))*(x-arr(location_dp+1))>0d0) &
            .and. (x/=arr(location_dp+1)))then
            return
        end if
    end do
end function location_dp
!***********************************************************************
!***********************************************************************
function ChaZhi(x,x1,x2,y1,y2)
    use nrtype, only: dp
    real(dp), intent(in):: x, x1, x2, y1, y2
    real(dp):: ChaZhi
!***********************************************************************
    ChaZhi = ( (y2-y1)*x + y1*x2 - y2*x1 ) / ( x2 - x1 )
end function ChaZhi