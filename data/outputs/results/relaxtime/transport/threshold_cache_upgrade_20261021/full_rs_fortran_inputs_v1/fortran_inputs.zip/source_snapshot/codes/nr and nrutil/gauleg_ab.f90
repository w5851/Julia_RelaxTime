subroutine gauleg_ab(x1, x2, z, pp, x, w, n)
    use nrtype, only: dp
    use nrutil, only: assert_eq
    implicit none
!***********************************************************************
    real(dp), intent(in):: x1, x2
    real(dp), dimension(:), intent(in):: z, pp
    real(dp), dimension(:), intent(out):: x, w
    integer, intent(in):: n
!***********************************************************************
    real(dp):: xl, xm
    integer:: m
!***********************************************************************
    m = (n+1)/2
    xm = 0.5d0*(x2+x1)
    xl = 0.5d0*(x2-x1)
    x(1:m) = xm - xl*z(:)
    x(n:n-m+1:-1) = xm + xl*z(:)
    w(1:m) = 2d0*xl / ( (1d0-z(:)**2)*pp(:)**2 )
    w(n:n-m+1:-1) = w(1:m)
end subroutine gauleg_ab