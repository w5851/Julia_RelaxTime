!��ֲ�������صĺ���
module quark_fun
    interface
        function fermion(x, T)
        use nrtype, only: dp
        implicit none
        real(dp):: fermion
        real(dp), intent(in):: x, T
        end function fermion
    end interface
    
    interface
        function AA(x, T, Phi1, Phi2)
        use nrtype, only: dp
        implicit none
        real(dp), intent(in):: x, T, Phi1, Phi2
        real(dp):: AA
        end function AA
    end interface
    interface
        function AA_bar(x, T, Phi1, Phi2)
        use nrtype, only: dp
        implicit none
        real(dp), intent(in):: x, T, Phi1, Phi2
        real(dp):: AA_bar
        end function AA_bar
    end interface
    interface
        function fphi(x, T, Phi1, Phi2)
        use nrtype, only: dp
        implicit none
        real(dp), intent(in):: x, T, Phi1, Phi2
        real(dp):: fphi
        end function fphi
    end interface
    interface
        function fphibar(x, T, Phi1, Phi2)
        use nrtype, only: dp
        implicit none
        real(dp), intent(in):: x, T, Phi1, Phi2
        real(dp):: fphibar
        end function fphibar
    end interface
    interface
        function fd(E, mu, T, phi1, phi2)
        use nrtype, only: dp
        implicit none
        real(dp):: fd
        real(dp), intent(in):: E, mu, T, phi1, phi2
        end function fd
    end interface
    interface
        function f1f(x, T, phi1, phi2)
        use nrtype, only: dp
        implicit none
        real(dp):: f1f
        real(dp), intent(in):: x, T, phi1, phi2
        end function f1f
    end interface
    interface
        function f1fb(x, T, Phi1, Phi2)
        use nrtype, only: dp
        implicit none
        real(dp):: f1fb
        real(dp), intent(in):: x, T, Phi1, Phi2
        end function f1fb
    end interface
end module quark_fun
!***********************************************************************
!***********************************************************************
!>��׼���׺���
function fermion(x, T)
    use nrtype, only: dp
    implicit none
    real(dp):: fermion
    real(dp), intent(in):: x, T
    fermion=1.0d0/(exp(X/T)+1.0d0)
end function fermion

!***********************************************************************
function AA(x, T, Phi1, Phi2)
    use nrtype, only: dp
    implicit none
    real(dp):: x, T, Phi1, Phi2
    real(dp):: AA
    real(dp):: ee
    ee = exp(-X/T)
    AA = 1.0d0 + 3.0d0*Phi1*ee + 3.0d0*Phi2*ee**2 + ee**3
end function AA
function AA_bar(x, T, Phi1, Phi2)
    use nrtype, only: dp
    implicit none
    real(dp):: x, T, Phi1, Phi2
    real(dp):: AA_bar
    real(dp):: ee
    ee = exp(-X/T)
    AA_bar = 1.0d0 + 3.0d0*Phi2*ee + 3.0d0*Phi1*ee**2 + ee**3
end function AA_bar
!>PNJL (anti)quark distribution function
function fphi(x, T, Phi1, Phi2)
    use nrtype, only: dp
    implicit none
    real(dp), intent(in):: x, T, Phi1, Phi2
    real(dp):: fphi
    real(dp):: ee
    ee = exp(-X/T)
    fphi=(Phi1*ee + 2d0*Phi2*ee**2 + ee**3)&
        /(1d0 + 3d0*Phi1*ee + 3d0*Phi2*ee**2 + ee**3)
end function fphi
function fphibar(x, T, Phi1, Phi2)
    use nrtype, only: dp
    implicit none
    real(dp), intent(in):: x, T, Phi1, Phi2
    real(dp):: fphibar
    real(dp):: ee
    ee = exp(-X/T)
    fphibar=(Phi2*ee + 2d0*Phi1*ee**2 + ee**3)&
        /(1d0 + 3d0*Phi2*ee + 3d0*Phi1*ee**2 + ee**3)
end function fphibar
!***********************************************************************
function fd(E, mu, T, phi1, phi2)
    use nrtype, only: dp
    use quark_fun, only: fphi, fphibar
    implicit none
    real(dp):: fd
    real(dp), intent(in):: E, T, mu, phi1, phi2
    if(mu >= 0d0)then
        fd = fphi(E-mu, T, phi1, phi2)!fd=fermion(E-mu,T)
    else
        fd = fphibar(E-mu, T, phi1, phi2)!fd=fermion(E-mu,T)
    end if
end function fd
!>f(1-f)
function f1f(x, T, Phi1, Phi2)
    use nrtype, only: dp
    use quark_fun, only: fphi
    implicit none
    real(dp), intent(in):: x, T, Phi1, Phi2
    real(dp):: f1f
    f1f = fphi(x, T, Phi1, Phi2)*(1d0-fphi(x, T, Phi1, Phi2))
end function
function f1fb(x, T, Phi1, Phi2)
    use nrtype, only: dp
    use quark_fun, only: fphibar
    implicit none
    real(dp), intent(in):: x, T, Phi1, Phi2
    real(dp):: f1fb
    f1fb = fphibar(x, T, Phi1, Phi2)*(1d0-fphibar(x, T, Phi1, Phi2))
end function