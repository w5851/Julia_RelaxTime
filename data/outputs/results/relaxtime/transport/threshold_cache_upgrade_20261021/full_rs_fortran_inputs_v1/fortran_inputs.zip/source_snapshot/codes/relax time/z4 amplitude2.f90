!
function amplitude2( s_cm, t_cm, qk_code )
    use nrtype, only: dp
    use constant, only: pi, po, mi
    use variable, only: Phi1, Phi2, arrMass
    use meson_function, only: s_pm, t_pm, u_pm, propagator
    use facc, only: fac
    use nrutil, only: nrerror
    implicit none
!***********************************************************************
    real(dp):: amplitude2
    real(dp), intent(in):: s_cm, t_cm
    integer, dimension(4,3), intent(in):: qk_code
!***********************************************************************
    real(dp):: u_cm, fpol, im_pol, amp_i, amp_r
    real(dp):: s_rt
    real(dp):: E1, E2, E3, E4, k0, k
    real(dp):: amp_r1, amp_r2, amp_r3, amp_r4
    real(dp):: amp_i1, amp_i2, amp_i3, amp_i4
    real(dp):: amp_t, amp_us, amp_tus1, amp_tus2, amp_tus3, amp_tus4
    real(dp):: m(4)
    integer, dimension(4):: q4
!***********************************************************************
m(:) = arrMass( qk_code(:,1) )
u_cm = sum(m(1:4)**2) - s_cm - t_cm
s_rt = sqrt(s_cm)
E1 = (s_cm + m(1)**2 - m(2)**2) / (2d0*s_rt)
E2 = (s_cm - m(1)**2 + m(2)**2) / (2d0*s_rt)
E3 = (s_cm + m(3)**2 - m(4)**2) / (2d0*s_rt)
E4 = (s_cm - m(3)**2 + m(4)**2) / (2d0*s_rt)
!***********************************************************************
amp_r1 = 0d0; amp_r2 = 0d0; amp_r3 = 0d0; amp_r4 = 0d0
amp_i1 = 0d0; amp_i2 = 0d0; amp_i3 = 0d0; amp_i4 = 0d0
if (qk_code(1,2)*qk_code(2,2) < 0) then!��-�����ɢ��
!>s channel
    q4(:) = qk_code(:,1)
    k0 = abs(E1+E2)
    k = 0d0 
    if(qk_code(1,3) > 0)then
        call propagator(k0, k, 1d0, fpol, im_pol, q4(:), 0)
        amp_i1 = fac(q4(1),q4(2))*fac(q4(3),q4(4))*im_pol
        amp_r1 = fac(q4(1),q4(2))*fac(q4(3),q4(4))*fpol
        call propagator(k0, k, -1d0, fpol, im_pol, q4(:), 0)
        amp_i2 = fac(q4(1),q4(2)) * fac(q4(3),q4(4)) * im_pol
        amp_r2 = fac(q4(1),q4(2)) * fac(q4(3),q4(4)) * fpol
    end if
    if(qk_code(2,3) > 0)then
        call propagator(k0, k, 1d0, fpol, im_pol, q4(:), 1)
        amp_i1 = amp_i1 + im_pol
        amp_r1 = amp_r1 + fpol
        call propagator(k0, k, -1d0, fpol, im_pol, q4(:), 1)
        amp_i2 = im_pol + amp_i2
        amp_r2 = fpol + amp_r2
    end if
!***********************************************************************
!>t channel
    k0 = abs(E1-E3)
    !k0 = E1-E3
    if(k0**2-t_cm >= 0d0)then
        k = sqrt(k0**2 - t_cm)
    else if ( k0**2-t_cm > -1d-12 ) then
        k = 0d0
    else
        call nrerror("k2<E31 in 'amplicude'.")
    end if
    q4(:) = qk_code([1,3,2,4],1)
    if(qk_code(3,3) > 0)then
        call propagator(k0,k,1d0,fpol,im_pol,q4(:),0)
        amp_i3 = fac(q4(1),q4(2)) * fac(q4(3),q4(4)) * im_pol
        amp_r3 = fac(q4(1),q4(2)) * fac(q4(3),q4(4)) * fpol
        call propagator(k0,k,-1d0,fpol,im_pol,q4(:),0)
        amp_i4 = fac(q4(1),q4(2)) * fac(q4(3),q4(4)) * im_pol
        amp_r4 = fac(q4(1),q4(2)) * fac(q4(3),q4(4)) * fpol
    end if
    if(qk_code(4,3) > 0)then
        call propagator(k0,k,1d0,fpol,im_pol,q4(:),1)
        amp_i3 = im_pol + amp_i3
        amp_r3 = fpol + amp_r3
        call propagator(k0,k,-1d0,fpol,im_pol,q4(:),1)
        amp_i4 = im_pol+amp_i4
        amp_r4 = fpol+amp_r4
    end if
    amp_us = (amp_i1**2+amp_r1**2) * s_pm(s_cm,m(1),m(2),mi) * s_pm(s_cm,m(3),m(4),mi) &
        + (amp_i2**2+amp_r2**2)*s_pm(s_cm,m(1),m(2),po)*s_pm(s_cm,m(3),m(4),po)
    amp_t = (amp_i3**2+amp_r3**2) * t_pm(t_cm,m(1),m(3),mi) * t_pm(t_cm,m(2),m(4),mi) &
        + (amp_i4**2+amp_r4**2)*t_pm(t_cm,m(1),m(3),po)*t_pm(t_cm,m(2),m(4),po)
    amp_tus1 = 1d0/12d0*(amp_i2*amp_i4+amp_r2*amp_r4)*(&
        s_pm(s_cm,m(1),m(2),po)*s_pm(s_cm,m(3),m(4),po)&
        -u_pm(u_cm,m(1),m(4),po)*u_pm(u_cm,m(2),m(3),po)&
        +t_pm(t_cm,m(1),m(3),po)*t_pm(t_cm,m(2),m(4),po))
    amp_tus2 = -1d0/12d0*(amp_i2*amp_i3+amp_r2*amp_r3)*(&
        s_pm(s_cm,m(1),m(2),po)*s_pm(s_cm,m(3),m(4),po)&
        -u_pm(u_cm,m(1),m(4),mi)*u_pm(u_cm,m(2),m(3),mi)&
        +t_pm(t_cm,m(1),m(3),mi)*t_pm(t_cm,m(2),m(4),mi))
    amp_tus3 = -1d0/12d0*(amp_i1*amp_i4+amp_r1*amp_r4)*(&
        s_pm(s_cm,m(1),m(2),mi)*s_pm(s_cm,m(3),m(4),mi)&
        -u_pm(u_cm,m(1),m(4),mi)*u_pm(u_cm,m(2),m(3),mi)&
        +t_pm(t_cm,m(1),m(3),po)*t_pm(t_cm,m(2),m(4),po))
    amp_tus4 = 1d0/12d0*(amp_i1*amp_i3+amp_r1*amp_r3)*(&
        s_pm(s_cm,m(1),m(2),mi)*s_pm(s_cm,m(3),m(4),mi)&
        -u_pm(u_cm,m(1),m(4),po)*u_pm(u_cm,m(2),m(3),po)&
        +t_pm(t_cm,m(1),m(3),mi)*t_pm(t_cm,m(2),m(4),mi))
    amplitude2 = (amp_t + amp_us - 2.0d0*(amp_tus1+amp_tus2+amp_tus3+amp_tus4))
else!>quark-quark scattering********************************************
!>u channel
    k0 = abs(E1-E4)
    !k0 = E1-E4
    if(k0**2-u_cm >= 0d0)then
        k = sqrt(k0**2-u_cm)
    else if(k0**2-u_cm>-1d-12)then
        k = 0d0
    else
        call nrerror("k2<E41 in 'amplicude'.")
    end if
    q4(:) = qk_code([1,4,2,3],1)
    if(qk_code(1,3) > 0)then
        call propagator(k0,k,1d0,fpol,im_pol,q4(:),0)
        amp_i1 = fac(q4(1),q4(2))*fac(q4(3),q4(4)) * im_pol
        amp_r1 = fac(q4(1),q4(2))*fac(q4(3),q4(4)) * fpol
        call propagator(k0,k,-1d0,fpol,im_pol,q4(:),0)
        amp_i2 = fac(q4(1),q4(2))*fac(q4(3),q4(4)) * im_pol
        amp_r2 = fac(q4(1),q4(2))*fac(q4(3),q4(4)) * fpol
    end if
    if(qk_code(2,3) > 0)then
        call propagator(k0,k,1d0,fpol,im_pol,q4(:),1)
        amp_i1=im_pol+amp_i1
        amp_r1=fpol+amp_r1
        call propagator(k0,k,-1d0,fpol,im_pol,q4(:),1)
        amp_i2 = im_pol+amp_i2
        amp_r2 = fpol+amp_r2
    end if
    !print*, k0,k
!***********************************************************************
!>t channel
    k0 = abs(E1-E3)
    !k0 = E1-E3
    if ( k0**2-t_cm >= 0d0 ) then
        k = sqrt(k0**2-t_cm)
    else if (k0**2-t_cm>-1d-12) then
        k = 0d0
    else
        call nrerror("k2<E31 in 'amplicude'.")
    end if
    q4(:) = qk_code( [1,3,2,4], 1 )
    if (qk_code(3,3)>0) then
        call propagator(k0,k,1d0,fpol,im_pol,q4(:),0)
        amp_i3 = fac(q4(1),q4(2))*fac(q4(3),q4(4))*im_pol
		amp_r3 = fac(q4(1),q4(2))*fac(q4(3),q4(4))*fpol
        call propagator(k0,k,-1d0,fpol,im_pol,q4(:),0)
        amp_i4 = fac(q4(1),q4(2))*fac(q4(3),q4(4))*im_pol
        amp_r4 = fac(q4(1),q4(2))*fac(q4(3),q4(4))*fpol
    end if
    if (qk_code(4,3)>0) then
        call propagator(k0,k,1d0,fpol,im_pol,q4(:),1)
        amp_i3 = amp_i3 + im_pol
        amp_r3 = amp_r3 + fpol
        call propagator(k0,k,-1d0,fpol,im_pol,q4(:),1)
        amp_i4 = amp_i4 + im_pol
        amp_r4 = amp_r4 + fpol
    end if
    amp_us = (amp_i1**2+amp_r1**2)*u_pm(u_cm,m(1),m(4),mi)*u_pm(u_cm,m(2),m(3),mi)&
         + (amp_i2**2+amp_r2**2)*u_pm(u_cm,m(1),m(4),po)*u_pm(u_cm,m(2),m(3),po)
    amp_t=(amp_i3**2+amp_r3**2)*t_pm(t_cm,m(1),m(3),mi)*t_pm(t_cm,m(2),m(4),mi)&
         + (amp_i4**2+amp_r4**2)*t_pm(t_cm,m(1),m(3),po)*t_pm(t_cm,m(2),m(4),po)
    amp_tus1 = 1d0/12d0*(amp_i4*amp_i2+amp_r4*amp_r2)*(&
        t_pm(t_cm,m(1),m(3),po)*t_pm(t_cm,m(2),m(4),po)&
        +u_pm(u_cm,m(1),m(4),po)*u_pm(u_cm,m(2),m(3),po)&
        -s_pm(s_cm,m(1),m(2),po)*s_pm(s_cm,m(3),m(4),po))
    amp_tus2=-1d0/12d0*(amp_i4*amp_i1+amp_r4*amp_r1)*(&
        t_pm(t_cm,m(1),m(3),po)*t_pm(t_cm,m(2),m(4),po)&
        +u_pm(u_cm,m(1),m(4),mi)*u_pm(u_cm,m(2),m(3),mi)&
        -s_pm(s_cm,m(1),m(2),mi)*s_pm(s_cm,m(3),m(4),mi))
    amp_tus3=-1d0/12d0*(amp_i3*amp_i2+amp_r3*amp_r2)*(&
        t_pm(t_cm,m(1),m(3),mi)*t_pm(t_cm,m(2),m(4),mi)&
        +u_pm(u_cm,m(1),m(4),po)*u_pm(u_cm,m(2),m(3),po)&
        -s_pm(s_cm,m(1),m(2),mi)*s_pm(s_cm,m(3),m(4),mi))
    amp_tus4=1d0/12d0*(amp_i3*amp_i1+amp_r3*amp_r1)*(&
        t_pm(t_cm,m(1),m(3),mi)*t_pm(t_cm,m(2),m(4),mi)&
        +u_pm(u_cm,m(1),m(4),mi)*u_pm(u_cm,m(2),m(3),mi)&
        -s_pm(s_cm,m(1),m(2),po)*s_pm(s_cm,m(3),m(4),po))
    amplitude2=(amp_t+amp_us-2.0d0*(amp_tus1+amp_tus2+amp_tus3+amp_tus4))
end if
!print*, amp_r1, amp_r2, amp_r3, amp_r4
!print*, "*******************",amplitude2
end function amplitude2!(s_cm, t_cm, qk_code)