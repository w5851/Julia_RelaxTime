subroutine lnsrch(xold, fold, g, p, x, f, stpmax, check, func, funcv)
	use nrtype, only: dp
    use nrutil, only: assert_eq, nrerror
	implicit none
    real(dp), dimension(:), intent(in):: xold, g
    real(dp), dimension(:), intent(out):: x
    real(dp), dimension(:), intent(inout):: p
    real(dp), intent(in):: fold, stpmax
	real(dp), intent(out):: f
	logical, intent(out):: check
    interface
		function func(x,funcv)
			use nrtype, only: dp
			implicit none
			real(dp):: func
			real(dp), dimension(:), intent(in):: x
            interface
				function funcv(x)
					use nrtype, only: dp
					implicit none
					real(dp), dimension(:), intent(in):: x
					real(dp), dimension(size(x)):: funcv
				end function funcv
			end interface
        end function func
    end interface
    interface
        function funcv(x)
            use nrtype, only: dp
            implicit none
            real(dp), dimension(:), intent(in):: x
            real(dp), dimension(size(x)):: funcv
        end function funcv
    end interface
!***********************************************************************
	!>parameter (ALF=1.e-4,TOLX=1.e-7)
    real(dp), parameter:: ALF = 1d-6, TOLX = 1d-9
	integer:: ndum
	real(dp):: a, alam, alam2, alamin, b, disc, f2, fold2, rhs1, rhs2
    real(dp):: slope, temp, tmplam, pabs
!***********************************************************************
	ndum = assert_eq(size(g), size(x), "lnsrch")
	check = .false.
    pabs = sqrt(dot_product(p,p))
	if(pabs > stpmax) then
        p(:) = p(:)*stpmax/pabs
	endif
    slope = dot_product(g(:),p(:))
	if ( slope >= 0d0 ) then
		call nrerror("roundoff problem in lnsrch")
    end if
    temp = tolx/maxval( abs(p(:)) / max(abs(xold(:)),1d0) )
    !max(abs(xold(:)),1d0)��������abs(xold),������С��1���滻Ϊ1
	alam = 1d0
!***********************************************************************
    do
		x(:) = xold(:) + alam*p(:)
		f = func(x(:),funcv)
		if (alam < alamin) then
			x(:) = xold(:)
			check = .true.
			return
		else if(f <= fold + ALF*alam*slope) then
			return
		else
			if(alam == 1d0) then
				tmplam = -slope / (2d0*(f-fold-slope))
			else
				rhs1 = f - fold - alam*slope
				rhs2 = f2 - fold - alam2*slope
				a = (rhs1/alam**2-rhs2/alam2**2) / (alam-alam2)
				b = (-alam2*rhs1/alam**2+alam*rhs2/alam2**2) / (alam-alam2)
				if(a == 0d0) then
					tmplam = -slope/(2d0*b)
				else
					disc = b*b - 3d0*a*slope
					if(disc < 0.0d0)then
						tmplam = 0.5d0*alam
					else if(b <= 0.0d0)then
						tmplam = (-b+sqrt(disc)) / (3d0*a)
					else
						tmplam = -slope/(b+sqrt(disc))
					endif
				end if
				if(tmplam > 0.5d0*alam)then!lambda < 0.5lambda_1
                    tmplam = 0.5d0*alam
                end if
			end if
		end if
		alam2 = alam
		f2 = f
		alam = max(tmplam,0.1d0*alam)!lambda >= 0.1lambda_1
    end do
end subroutine lnsrch