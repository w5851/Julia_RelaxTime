!���㼫������(polarization function)
!>ps>0��ӦP,m-m
!>ps<0��ӦP,m+m
subroutine polarization(k0, kk, ps, i, j, pi_re, pi_im)
    use nrtype, only: dp
    use constant, only: pi, hc
    use variable, only: arrMu, arrMass, arrA
    use meson_function, only: B0SUM
	implicit none
!***********************************************************************
    real(dp), intent(in):: k0, kk, ps
    real(dp), intent(out):: pi_re, pi_im
    integer, intent(in):: i, j
!***********************************************************************
    real(dp):: B_re, B_im, B_r0, B_i0
    real(dp):: A_i, A_j, m_i, m_j, mu_i, mu_j
!***********************************************************************
A_i = arrA(i); m_i = arrMass(i); mu_i = arrMu(i)
A_j = arrA(j); m_j = arrMass(j); mu_j = arrMu(j)
call B0SUM(k0, kk, m_i, m_j, mu_i, mu_j, B_re, B_im)
if (i*j ==3 .or. i*j==6) then
    call B0SUM(-k0, kk, m_i, m_j, mu_i, mu_j, B_r0, B_i0)
    B_re = (B_re + B_r0) / 2d0
    B_im = (B_im + B_i0) / 2d0
end if
pi_re = ( A_i + A_j + ((m_i-ps*m_j)**2-(k0+mu_i-mu_j)**2+kk**2)*B_re ) * (-3d0) / (8d0*pi**2)
pi_im = (((m_i-ps*m_j)**2-(k0+mu_i-mu_j)**2+kk**2)*B_im) * (-3d0) / (8d0*pi**2)
end subroutine polarization!(k0, kk, ps, i, j, pi_re, pi_im)