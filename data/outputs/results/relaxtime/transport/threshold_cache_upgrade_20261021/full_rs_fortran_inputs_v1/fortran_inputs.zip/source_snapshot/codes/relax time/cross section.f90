!>���ڼ���ɢ����������������ı仯
subroutine cross_section(codes)
    use nrtype, only: dp
    use constant, only: Lambda, hc
    use variable, only: arrMass, mu_B, T
    use meson_function, only: tint
    implicit none
!***********************************************************************
    integer, dimension(4,3), intent(in):: codes
!***********************************************************************
    real(dp):: s, s_min, s_max, delta_s, cs, sqs
    real(dp), dimension(4):: m
    integer, parameter:: nn = 300
    integer:: i
!***********************************************************************
    m(:) = arrMass(codes(:,1))
    s_max = min( (sqrt(m(1)**2+lambda**2)+sqrt(m(2)**2+lambda**2))**2, &
                (sqrt(m(3)**2+lambda**2)+sqrt(m(4)**2+lambda**2))**2 )
    s_min = max( (m(1)+m(2))**2, (m(3)+m(4))**2 )*( 1d0 + 1d-5 )
    !delta_s = (sqrt(s_max)-sqrt(s_min))/dble(nn-1)
    delta_s = 1.2d0*1000d0/hc/dble(nn-1)
    do i = 1, nn, 1
        !s = (sqrt(s_min) + delta_s*dble(i-1))**2
        sqs = ( delta_s*dble(i-1))**2
        s = sqs**2
        if ( s_min < s .and. s < s_max ) then
            cs = tint( s, codes(:,:) )
        else
            cs = 0d0
        end if
        open(unit=305, file='results\cross_section.dat')!eta and sigma
            write(305, "(4(4XE17.10))") sqs*hc/1000d0, mu_B*hc, T*hc, cs*10d0
    end do
end subroutine cross_section