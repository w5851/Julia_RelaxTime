!>>>> MAIN <<<<
program main
use nrtype, only: dp
use constant, only: lambda, pi, hc, n0, T0
use variable, only: T, mu_B, arrMu
use xnum, only: location_dp, ChaZhi
use type_state
use nrutil, only: swap, arth
use nr, only: newt
use PNJL, only: funcv_tmu
use scattering_code
implicit none
!***********************************************************************
integer:: time_i, time_f, time_rate
integer, parameter:: Tn = 127           !5~131
integer:: n_1st
real(dp), dimension(Tn):: mu_1st, T_1st
real(dp):: mu_t!>Chemical potential of 1 order phase transition
integer, parameter:: n_eq = 5
real(dp), dimension(n_eq):: x_quark
logical:: check
integer:: i, j, k
integer:: count_j, count_k
real(dp), parameter:: mu_initial = 5d0, mu_final = 5d0, step_mu = 1d0
real(dp), parameter:: T_initial = 50d0, T_final = 350d0, step_T = 1d0
real(dp), allocatable:: temp_t(:), temp_mu(:)
real(dp), allocatable:: x_array(:,:)!>store x in x_arr(n_eq,j or k)
type(state), allocatable:: phy(:,:) !>information of each point
integer, dimension(2):: max_loc
!***********************************************************************
call system_clock(time_i, time_rate)!time
call set_integral!>
!***********************************************************************
do i = 1, Tn
    open(122,file='data_files\1st.txt')
    read(122,*) mu_1st(i), T_1st(i)
end do
!***********************************************************************
count_j = floor(abs((mu_final-mu_initial)/step_mu)) + 1 !>����ѭ������
count_k = floor(abs((T_final-T_initial)/step_T)) + 1
print*, count_j, count_k
allocate( temp_mu(count_j) )!>�����ڴ�ռ�
allocate( temp_t(count_k) )
allocate( phy(count_j,count_k) )
allocate( x_array(n_eq, count_j) )!>��������ѭ��������ͬ
temp_mu(:) = arth(mu_initial/hc, step_mu/hc, count_j)
temp_t(:) = arth(T_initial/hc, step_T/hc, count_k)
do k = 1, count_k, 1!T
    do j = 1, count_j, 1!mu
        phy(j,k)%mu_B = temp_mu(j)
        phy(j,k)%T = temp_t(k)
        if(phy(j,k)%mu_B*hc<3d0)then
            phy(j,k)%mu_B = 2d0/hc
        end if
        phy(j,k)%arrMu(:) = phy(j,k)%mu_B/3d0
        !print*, phy(j,k)%mu_B*hc, phy(j,k)%T*hc
    end do
end do
deallocate(temp_mu)
deallocate(temp_t)
!>initial guess value for root
x_array(:,1) = [-1.8d0,-1.8d0,-2.2d0,0.01d0,0.01d0]!>hadron phase
!x_array(:,1) = [-0.01d0, -0.01d0, -0.1d0, 0.8d0, 0.8d0]!>����
!x_array(:,1) = [-0.35d0,-0.35d0,-1.9d0,0.36d0,0.38d0]!>mu873,T138
!x_array(:,1) = [-0.39d0,-0.39d0,-1.68d0,0.64d0,0.64d0]!>mu150,T206
!x_array(:,1) = [-1.45d0,-1.45d0,-2.06d0,0.44d0,0.44d0]!>180
!x_array(:,1) = [-0.73d0,-0.73d0,-1.8d0,0.61d0,0.61d0]!>200
!x_array(:,1) = [-0.18d0,-0.18d0,-1.5d0,0.69d0,0.69d0]!>220
!x_array(:,1) = [-0.311d0,-0.311d0,-1.89d0,0.375d0,0.398d0]!>mu873,T140
!x_array(:,1) = [-0.37d0,-0.37d0,-1.9d0,0.3d0,0.3d0]!>mu900,T131
!�ж�ѭ������Ƿ���һ��������Ҳ�
n_1st = 1
do i = 1, Tn
    if(abs(T_initial-T_1st(i)) < 0.01d0)then        
        n_1st = i
    end if
end do
if (mu_initial > mu_1st(n_1st)) then!>ѭ�������һ��������Ҳ�
    x_array(:,1) = [ -0.5d0, -0.5d0, -1.8d0, 0.8d0, 0.8d0 ]
end if
if(T_initial<131d0)then
    n_1st = location_dp(T_initial,T_1st(:))
    mu_t = ChaZhi(T_initial,T_1st(n_1st),T_1st(n_1st+1),mu_1st(n_1st),mu_1st(n_1st+1))
    if(mu_initial > mu_t)then
        x_quark(:) = [-0.5d0,-0.5d0,-1.8d0,0.8d0,0.8d0]
    end if
end if
!***********************************************************************
!***********************************************************************
do k = 1, count_k, 1
    T = phy(1,k)%T
    if(T*hc<131d0)then
        n_1st = location_dp(T*hc,T_1st(:))
        mu_t = ChaZhi(T*hc,T_1st(n_1st),T_1st(n_1st+1),mu_1st(n_1st),mu_1st(n_1st+1))
    end if
    do j = 1, count_j, 1
        mu_B = phy(j,k)%mu_B
        arrMu(:) = phy(j,k)%arrMu(:)
        T = phy(j,k)%T
        if(j == 1) then
            x_quark(:) = x_array(:,1)
        else
            x_quark(:) = x_array(:,j-1)
            if(T*hc < 131d0) then
                if(mu_B*hc > mu_t .and. mu_B*hc-step_mu < mu_t)then
                    x_quark(:) = [-0.5d0,-0.5d0,-1.8d0,0.8d0,0.8d0]
                end if
            end if
        end if
        call newt(x_quark, check, funcv_tmu)
        x_array(:,j) = x_quark(:)
        print*, mu_B*hc, T*hc, x_quark(1)
        phy(j,k)%arrPhi(1:5) = x_quark(1:5)
        call coefficients_tmu( phy(j,k) )
    end do
end do
!***********************************************************************
!do j = 1, count_j, 1
!    k = maxloc(phy(j,:)%delta_phi, dim=1)
!    print*, max_loc
!    open(unit=01, file='results\crossover.dat')
!        write(01, "(4(4XF16.8),10(4XE17.10))") phy(j,k)%mu_B*hc, phy(j,k)%T*hc
!end do
!***********************************************************************
call system_clock(time_f, time_rate)
write(*,*) "Time: ", (time_f-time_i)/time_rate, "s, ", (time_f-time_i)/time_rate/60, "min"
stop
end