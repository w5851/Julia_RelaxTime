!�����ӡ����ӣ���������������/�꣬ʵ�����鲿���������ӣ��Ƿ��ؽ���
subroutine propagator(k0, k, ps, fpol, im_pol, q4, eta_if)
    use nrtype, only: dp
    use constant, only: pi, G_f, l0, l8
    use variable, only: arrMass, arrA, arrG
    use meson_function, only: polarization
    implicit none
!***********************************************************************
    real(dp), intent(in):: k0, k, ps
    real(dp), intent(out):: fpol, im_pol
    integer, dimension(4), intent(in):: q4
    integer, intent(in):: eta_if
!***********************************************************************
    integer, dimension(4):: qx
    real(dp), dimension(3):: co
    real(dp):: pi_re, pi_im
    real(dp):: s_cm, t_cm, im_D, Re_D, p_ij
    real(dp):: pi_ur, pi_sr, pi_ui, pi_si
    real(dp):: detk, k00, k08, k88
    real(dp):: m00_i, m08_i, m88_i, m00_r, m08_r, m88_r
    real(dp):: re_n, re_de, im_n, im_De
    integer:: ij
!***********************************************************************
if(eta_if < 1)then!K��pi����
    call polarization( k0, k, ps, q4(1), q4(2), pi_re, pi_im )
    if(q4(1) == q4(2))then
        if(q4(1) <= 2)then
            ij = 3
        else
            ij = 1
        end if
    else
        ij = 6 - (q4(1) + q4(2))
    end if
    p_ij = G_f + ps * 0.5d0 * arrG(ij)  !ϵ��K
    Re_D = 1d0 - 4d0*p_ij*pi_re
    im_D = 4d0*p_ij*pi_Im
    fpol = 2d0*p_ij*re_D / (re_D**2+im_D**2)
    im_pol = 2d0*p_ij*im_D / (re_D**2+im_D**2)
else!>eta or sigma
    k00 = G_f - ps * ( arrG(1) + arrG(2) + arrG(3) )/3d0
    k88 = G_f + ps * ( 2d0*arrG(1) + 2d0*arrG(2) - arrG(3) )/6d0
    k08 = ps * ( arrG(1) + arrG(2) - 2d0*arrG(3) )*sqrt(2d0)/12d0
    detk = k00*k88 - k08**2
    call polarization( k0, k, ps, 1, 1, pi_ur, pi_ui )
    call polarization( k0, k, ps, 3, 3, pi_sr, pi_si )
    !print*, "pro"
    !print*, pi_ur, pi_ui
    !print*, pi_sr, pi_si
    m00_r = k00 - 4d0/3d0*(pi_ur+2d0*pi_sr)*detk
    m00_i = (pi_ui + 2d0*pi_si) * detk*(-4d0/3d0)
    m08_r = k08 + 4d0/3d0*sqrt(2d0)*(pi_ur-pi_sr)*detk
    m08_i = 4d0/3d0*sqrt(2d0)*(pi_ui-pi_si)*detk
    m88_r = k88 - 4d0/3d0*(2d0*pi_ur+pi_sr)*detk
    m88_i = -4d0/3d0*(2d0*pi_ui+pi_si)*detk
    qx(:) = 2
    where (q4 <= 2)
        qx = 1
    end where
    !co(1) = 2d0
    co(1) = l0(qx(1),qx(2))*l0(qx(3),qx(4))
    co(2) = l0(qx(1),qx(2))*l8(qx(3),qx(4)) + l0(qx(3),qx(4))*l8(qx(1),qx(2))
    co(3) = l8(qx(1),qx(2))*l8(qx(3),qx(4))
    co(:) = co(:)/2d0
    re_n = co(1)*m00_r + co(2)*m08_r + co(3)*m88_r
    im_n = co(1)*m00_i + co(2)*m08_i + co(3)*m88_i
    re_De = m00_r*m88_r - m00_i*m88_i - m08_r**2 + m08_i**2
    im_De = m00_r*m88_i + m00_i*m88_r - 2d0*m08_r*m08_i
    fpol = 4d0/3d0*detk*(re_n*re_De+Im_n*im_De)/(re_De**2+im_de**2)
    im_pol = 4d0/3d0*detk*(im_n*re_De-Re_n*im_De)/(re_De**2+im_de**2)
end if
end subroutine propagator!(k0, k, ps, fpol, im_pol, q4, eta_if)