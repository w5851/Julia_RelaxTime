!> scan_config: scanning parameter types and defaults for AA_PHASE_SCAN
module scan_config
    use nrtype, only: dp
    implicit none

    !> Parameters for T-mu grid scan
    type :: tmu_scan_params
        real(dp) :: T_min_mev
        real(dp) :: T_max_mev
        real(dp) :: step_T_mev
        real(dp) :: mu_min_mev
        real(dp) :: mu_max_mev
        real(dp) :: step_mu_mev
        logical  :: adaptive_T
        real(dp) :: adapt_threshold    ! delta_Phi threshold to trigger refinement
        real(dp) :: adapt_min_step     ! minimum T step in MeV (stop refining below this)
        integer  :: adapt_max_refine   ! maximum refinement rounds
    end type

    !> Parameters for crossover line scan
    type :: crossover_scan_params
        real(dp) :: mu_min_mev
        real(dp) :: mu_max_mev
        real(dp) :: step_mu_mev
        real(dp) :: T_search_min_mev
        real(dp) :: T_search_max_mev
        real(dp) :: T_search_step_mev
        integer  :: refine_max_iter
        real(dp) :: refine_tol_mev
    end type

contains

    !> Set default T-mu grid scan parameters
    subroutine default_tmu_params(par)
        type(tmu_scan_params), intent(out) :: par
        par%T_min_mev       = 50.0d0
        par%T_max_mev       = 350.0d0
        par%step_T_mev      = 5.0d0
        par%mu_min_mev      = 0.0d0
        par%mu_max_mev      = 900.0d0
        par%step_mu_mev     = 50.0d0
        par%adaptive_T      = .true.
        par%adapt_threshold  = 0.1d0
        par%adapt_min_step   = 0.5d0
        par%adapt_max_refine = 5
    end subroutine

    !> Set default crossover scan parameters
    subroutine default_crossover_params(par)
        type(crossover_scan_params), intent(out) :: par
        par%mu_min_mev       = 0.0d0
        par%mu_max_mev       = 900.0d0
        par%step_mu_mev      = 5.0d0
        par%T_search_min_mev = 100.0d0
        par%T_search_max_mev = 250.0d0
        par%T_search_step_mev = 2.0d0
        par%refine_max_iter  = 30
        par%refine_tol_mev   = 0.1d0
    end subroutine

end module scan_config
