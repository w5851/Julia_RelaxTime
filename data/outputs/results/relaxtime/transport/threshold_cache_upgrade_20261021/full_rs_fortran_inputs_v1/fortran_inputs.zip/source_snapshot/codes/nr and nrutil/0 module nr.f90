module nr
    !jacobian
    interface
        subroutine fdjac(x, fvec, df, funcv)
	        use nrtype, only: dp
	        implicit none
	        real(dp), dimension(:), intent(inout):: x
            real(dp), dimension(:), intent(in):: fvec
            real(dp), dimension(:,:), intent(out):: df
            interface
                function funcv(x)
                    use nrtype, only: dp
                    implicit none
                    real(dp), dimension(:), intent(in):: x
                    real(dp), dimension(size(x)):: funcv
                end function funcv
            end interface
        end subroutine fdjac
    end interface
    !gauleg
    interface
        subroutine gauleg(x1,x2,x,w)
            use nrtype, only: dp
            implicit  none
            real(dp), intent(in):: x1, x2
            real(dp), dimension(:), intent(out):: x, w
        end subroutine gauleg
    end interface
    interface
        subroutine gauleg_0(z, pp, n)
            use nrtype, only: dp
            implicit  none
            real(dp), dimension(:), intent(inout):: pp, z
            integer, intent(in):: n
        end subroutine gauleg_0
    end interface
    interface
        subroutine gauleg_ab(x1, x2, z, pp, x, w, n)
            use nrtype, only: dp
            implicit none
            real(dp), intent(in):: x1, x2
            real(dp), dimension(:), intent(in):: z, pp
            real(dp), dimension(:), intent(out):: x, w
            integer, intent(in):: n
        end subroutine gauleg_ab
    end interface
    !LU
    interface
        subroutine ludcmp(a, indx, d)
            use nrtype, only: dp
	        implicit none
            real(dp), dimension(:,:), intent(inout):: a
            integer, dimension(:), intent(out):: indx
	        real(dp), intent(out):: d
        end subroutine ludcmp
    end interface
    !forward substitution and backsubstitution
    interface
        subroutine lubksb(a, indx, b)
	        use nrtype, only: dp
	        implicit none
	        integer, dimension(:), intent(in):: indx
	        real(dp), dimension(:,:), intent(in):: a
	        real(dp), dimension(:), intent(inout):: b
        end subroutine lubksb
    end interface
    !lnsrch
    interface
        subroutine lnsrch(xold, fold, g, p, x, f, stpmax, check, func, funcv)
	        use nrtype, only: dp
	        implicit none
            real(dp), dimension(:), intent(in):: xold, g
            real(dp), dimension(:), intent(out):: x
            real(dp), dimension(:), intent(inout):: p
            real(dp), intent(in):: fold, stpmax
	        real(dp), intent(out):: f
	        logical, intent(out):: check
            interface
		        function func(x,funcv)
			        use nrtype, only: dp
			        implicit none
			        real(dp):: func
			        real(dp), dimension(:), intent(in):: x
                    interface
				        function funcv(x)
					        use nrtype, only: dp
					        implicit none
					        real(dp), dimension(:), intent(in):: x
					        real(dp), dimension(size(x)):: funcv
				        end function funcv
			        end interface
                end function func
            end interface
            interface
                function funcv(x)
                    use nrtype, only: dp
                    implicit none
                    real(dp), dimension(:), intent(in):: x
                    real(dp), dimension(size(x)):: funcv
                end function funcv
            end interface
        end subroutine lnsrch
    end interface
    
    !newt
    interface
        subroutine newt(x, check, funcv)
	        use nrtype, only: dp
	        implicit none
	        real(dp), dimension(:), intent(inout):: x
	        logical, intent(out):: check
            interface
                function funcv(x)
                    use nrtype, only: dp
                    implicit none
                    real(dp), dimension(:), intent(in):: x
                    real(dp), dimension(size(x)):: funcv
                end function funcv
            end interface
        end subroutine newt
    end interface
    
    

end module