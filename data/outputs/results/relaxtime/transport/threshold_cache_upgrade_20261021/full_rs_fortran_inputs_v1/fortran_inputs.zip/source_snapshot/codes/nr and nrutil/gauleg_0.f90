subroutine gauleg_0(z, pp, n)
    use nrtype, only: dp
    use nrutil, only: arth, nrerror, assert_eq
    implicit none
!***********************************************************************
    real(dp), dimension(:), intent(inout):: pp, z
    integer, intent(in):: n
!***********************************************************************
    real(dp), parameter:: EPS = 3d-14
    integer, parameter:: MAXIT = 10
    integer:: its, j, m
    real(dp), dimension( (n+1)/2 ):: p1, p2, p3, z1
    logical, dimension( (n+1)/2 ):: unfinished
!***********************************************************************
    m = assert_eq(size(z), size(pp), (n+1)/2, "gauleg0")
    z(:) = cos(3.141592654d0*(arth(1,1,m)-0.25d0)/(n+0.5d0))
    unfinished = .true.
    do its = 1, MAXIT
        where (unfinished)
            p1 = 1d0
            p2 = 0d0
        end where
        do j = 1, n
            where (unfinished)
                p3 = p2
                p2 = p1
                p1 = ( (2d0*j-1d0)*z*p2 - (j-1d0)*p3 ) / j
            end where
        end do
        where (unfinished)
            pp = n * (z*p1-p2) / (z*z-1d0)
            z1 = z
            z = z1 - p1/pp
            unfinished = ( abs(z-z1)>EPS )
        end where
        if(.not. any(unfinished)) exit
    end do
    if (its == MAXIT + 1) then
        call nrerror("too many interations in gauleg")
    end if
end subroutine gauleg_0