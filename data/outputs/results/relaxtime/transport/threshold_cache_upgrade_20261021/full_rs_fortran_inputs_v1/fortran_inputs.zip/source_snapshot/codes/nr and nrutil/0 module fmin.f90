!>f=0.5 X \dot X
module fminln
    use nrtype, only: dp
    use nrutil, only: nrerror
    real(dp), dimension(:), pointer:: fmin_fvecp
contains
    function fmin(x,funcv)
        !use PNJL, only: funcv
        implicit none
        real(dp), dimension(:), intent(in):: x
        real(dp):: fmin
        interface
		    function funcv(x)
                use nrtype, only: dp
	            implicit none
			    real(dp), dimension(:), intent(in):: x
                real(dp), dimension(size(x)):: funcv
            end function funcv
        end interface
!***********************************************************************
        if (.not. associated(fmin_fvecp)) then
            call nrerror("fmin: problem with pointer for returned values.")
        end if
        fmin_fvecp = funcv(x)
        fmin = 0.5d0 * dot_product(fmin_fvecp,fmin_fvecp)
    end function fmin
end module fminln