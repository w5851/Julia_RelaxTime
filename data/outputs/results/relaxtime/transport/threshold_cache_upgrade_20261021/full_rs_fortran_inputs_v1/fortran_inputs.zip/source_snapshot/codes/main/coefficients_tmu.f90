!>���������򴫵ݵ� phy ��Ϣ�������������
!>������Χ������ƫ��
!>u  d   s
!>ub db  sb
subroutine coefficients_tmu(phy)
    use nrtype, only: dp
    use constant; use variable; use type_state
    use integral
    use quark_fun, only: f1f, f1fb
    use nr, only: newt
    use PNJL, only: funcv_tmu, quantity
    use meson_function, only: relaxation_time, tint, amplitude2
    use scattering_code
    implicit none
!***********************************************************************
    type(state), intent(inout):: phy
!***********************************************************************
    !����Χ������ƫ����Ҫ��ģ��
    !T
    !!!!!!!! 3 !!!!!!!!
    !!!! 1 !   ! 4 !!!!
    !!!!!!!! 2 !!!!!!!! mu
    integer:: i4
    integer, parameter:: n_eq5p = 5
    logical:: check
    real(dp), parameter:: delta_T = 1d0/hc, delta_mu = 1d0/hc!����ƫ������
    real(dp), dimension(4), parameter:: delta_mu4 = [-delta_mu, 0d0, 0d0, delta_mu]
    real(dp), dimension(4), parameter:: delta_T4 = [0d0, -delta_T, delta_T, 0d0]
    real(dp), dimension(n_eq5p):: x_eq5p
    type(state), dimension(4):: phy4
!***********************************************************************
    integer:: i, j, k
    real(dp):: p
    real(dp), dimension(3):: arrEi!>Energy of quark
    real(dp), dimension(2,3):: arrFF
    !>ƫ��
    real(dp), dimension(3):: arrdm_t, arrdm_mu, arrde_t, arrde_mu
    real(dp):: dn_t, dn_mu
    real(dp):: ds_t, ds_mu
    real(dp):: dsig_t, dsig_mu
    real(dp):: dMuT_Sigma!>Partial mu/t_sigma
    real(dp), dimension(2,3):: arrdX_t, arrdxt_t!������(E-mu)/T��T ��ƫ�����̶�sigma
    !>����ѧ��
    real(dp):: c_n,c_s!>����
    real(dp):: c_p!>����
    real(dp), dimension(2,3):: arrtau!relax_time
    real(dp):: eta, zeta, sigma, coe_lam!>����ճ��ϵ������ճ��ϵ�����絼�ʣ��ȵ���
    real(dp):: kappa_BB, kappa_qq, kappa_ss!>��ɢϵ�������ӣ���ɣ����죩
    real(dp), dimension(2,3):: arrEta, arrZeta, arrSigma
    real(dp), dimension(2,3):: arrKappa_BB, arrKappa_QQ, arrKappa_SS
    real(dp):: lorentz, R_etasig, pr, RI, zeta_eta!>ϵ����ֵ
    integer, dimension(4,3):: codes
    real(dp):: aaa,bbb
!***********************************************************************
do i4 = 1, 4
    T = phy%T + delta_T4(i4)
    mu_B = phy%mu_B + delta_mu4(i4)
    arrMu(:) = [mu_B/3.0d0, mu_B/3.0d0, mu_B/3.0d0]
    phy4(i4)%T = T; phy4(i4)%mu_B = mu_B; phy4(i4)%arrMu(:) = arrMu(:)
    x_eq5p(:) = [ phy%arrPhi(1), phy%arrPhi(2), phy%arrPhi(3), phy%arrPhi(4), phy%arrPhi(5) ]
    call newt(x_eq5p, check, funcv_tmu)
    phy4(i4)%arrPhi(:) = x_eq5p(1:5)
    call quantity( phy4(i4) )
    !print*, mu_B*hc, T*hc, x_eq5p(1)
    open(unit=221, file='results\solution_4p.dat')
        write(221, "(4(4XF16.8),10(4XE17.10))") mu_B*hc, T*hc, x_eq5p(1:5)
end do
!***********************************************************************
T = phy%T; mu_B = phy%mu_B; arrMu(:) = phy%arrMu(:)
phi_u = phy%arrPhi(1); phi_d = phy%arrPhi(2); phi_s = phy%arrPhi(3)
Phi1 = phy%arrPhi(4); Phi2 = phy%arrPhi(5)
call quantity(phy)
arrmass(:) = phy%arrMass(:)
n_B = phy%n_B; n_charge = phy%n_charge; n_strange = phy%n_strange
arrN(:,:) = phy%arrN(:,:)!>(2*3)
s = phy%s; energy = phy%energy; pressure = phy%pressure
rho_mass = phy%rho_mass
arrA(:) = phy%arrA(:); arrG(:) = phy%arrG(:)
phy%delta_phi = abs(phy4(3)%arrPhi(1)-phy4(2)%arrPhi(1))
!***********************************************************************
!ƫ����
arrdm_t(:) = ( phy4(3)%arrMass(:) - phy4(2)%arrMass(:) )/(2*delta_T)
arrdm_mu(:) = ( phy4(4)%arrMass(:) - phy4(1)%arrMass(:) )/(2*delta_mu)
ds_t = ( phy4(3)%s - phy4(2)%s )/(2*delta_T)
ds_mu = ( phy4(4)%s - phy4(1)%s )/(2*delta_mu)
dn_t = ( phy4(3)%n_B - phy4(2)%n_B )/(2*delta_T)
dn_mu = ( phy4(4)%n_B - phy4(1)%n_B )/(2*delta_mu)
dsig_T = ds_t/n_B - dn_t*s/n_B**2
dsig_mu = ds_mu/n_B - dn_mu*s/n_B**2
dMuT_Sigma = -dsig_T/dsig_mu
c_n = ( s*dn_mu - n_B*dn_t ) / ( T*(ds_t*dn_mu-ds_mu*dn_t) )!�������ٷ�
c_s = ( s*ds_mu - n_B*ds_t ) / ( mu_B*(dn_t*ds_mu-ds_t*dn_mu) )!�������ٷ�
c_p = T * ( ds_t - ds_mu*s/n_B )!����
!***********************************************************************
arrtau(:,:) = 0.1d0!>relax_time
call relaxation_time(arrtau(:,:))
print*, c_n, c_p
call averaged_rate( us_code, aaa, bbb )
!print*,"ave",  aaa, bbb
!do i=1,1000
!	print*, tint(2d0, uu_code)
!end do
!print*, "tint", tint(2d0, usb_code)
!print*, arrA(:)
!print*, arrG(:)
!print*, amplitude2(0.2d0, -10d0, uu_code)
!***********************************************************************
!***********************************************************************
arrEta(:,:) = 0d0
arrZeta(:,:) = 0d0
arrSigma(:,:) = 0d0
arrKappa_BB(:,:) = 0d0
arrKappa_QQ(:,:) = 0d0
arrKappa_SS(:,:) = 0d0
do i = 1, npoint1
    p = y1(i)
    arrEi(:) = sqrt(arrmass(:)**2 + p**2)
    do k = 1, 3, 1!ζ��
        arrFF(1,k) = f1f(arrEi(k) - arrMu(k), T, Phi1, Phi2)
        arrFF(2,k) = f1fb(arrEi(k) + arrMu(k), T, Phi1, Phi2)
    end do
    arrdE_t(:) = arrdm_t(:) * arrMass(:) / arrEi(:)!>Partial E_t and E_mu
    arrdE_mu(:) = arrdm_mu(:) * arrMass(:) / arrEi(:)
    
    arrdx_t(1,:) = arrdE_t(:) + (arrdE_mu(:)-1d0/3d0)*dMuT_Sigma
    arrdx_t(2,:) = arrdE_t(:) + (arrdE_mu(:)+1d0/3d0)*dMuT_Sigma
    arrdxt_t(1,:) = arrdx_t(1,:)/T - (arrEi(:)-arrMu(:)) / T**2
    arrdxt_t(2,:) = arrdx_t(2,:)/T - (arrEi(:)+arrMu(:)) / T**2
    
    !arrdx_t(1,:) = arrdE_t(:)! + (arrdE_mu(:)-1d0/3d0)*dMuT_Sigma
    !arrdx_t(2,:) = arrdE_t(:)! + (arrdE_mu(:)+1d0/3d0)*dMuT_Sigma
    !arrdxt_t(1,:) = arrdx_t(1,:)/T - arrEi(:)/T**2
    !arrdxt_t(2,:) = arrdx_t(2,:)/T - arrEi(:)/T**2
    
    do k = 1, 3, 1!>flavor
        do j = 1, 2, 1!>quark/antiquark
            arrEta(j,k) = arrEta(j,k) + w1(i)*p**6/(arrEi(k)**2)*arrFF(j,k)
            arrSigma(j,k) = arrSigma(j,k) + w1(i)*p**4/(arrEi(k)**2)*arrFF(j,k)
            arrZeta(j,k) = arrZeta(j,k) + w1(i)*p**2/(arrEi(k)**2)*arrFF(j,k) * ( p**2 + 3d0*c_n*T**2*arrEi(k)*arrdxt_t(j,k) )**2
            arrKappa_BB(j,k) = arrKappa_BB(j,k) + w1(i)*p**4/(arrEi(k)**2)*arrFF(j,k) * ( arr_quark_baryon(j,k) - n_B*arrEi(k)/(energy+pressure) )**2
            arrKappa_QQ(j,k) = arrKappa_QQ(j,k) + w1(i)*p**4/(arrEi(k)**2)*arrFF(j,k) * ( arr_quark_charge(j,k) - n_charge*arrEi(k)/(energy+pressure) )**2
            arrKappa_SS(j,k) = arrKappa_SS(j,k) + w1(i)*p**4/(arrEi(k)**2)*arrFF(j,k) * ( arr_quark_strange(j,k) - n_strange*arrEi(k)/(energy+pressure) )**2
        end do
    end do
end do
!***********************************************************************
!>shear
arrEta(:,:) = arrEta(:,:) * arrTau(:,:) * N_c / ( 15d0*pi**2*T )
eta = sum(arrEta(:,:))
!>bulk viscosity
arrZeta(:,:) = arrZeta(:,:) * arrTau(:,:) * N_c / ( 9d0*pi**2*T )
zeta = sum(arrZeta(:,:))
!>�絼��
arrSigma(:,:) = arrSigma(:,:) * arrTau(:,:) * arr_quark_charge(:,:)**2 * ( 4d0 * alpha_em * N_c ) / ( 3d0 * pi * T )
sigma = sum(arrSigma(:,:))
!>��ɢϵ��
arrKappa_BB(:,:) = arrKappa_BB(:,:) * arrTau(:,:) * N_c / (3d0*pi**2)
arrKappa_QQ(:,:) = arrKappa_QQ(:,:) * arrTau(:,:) * N_c / (3d0*pi**2) * (4d0*pi*alpha_em)
arrKappa_SS(:,:) = arrKappa_SS(:,:) * arrTau(:,:) * N_c / (3d0*pi**2)
kappa_BB = sum(arrKappa_BB(:,:))
kappa_QQ = sum(arrKappa_QQ(:,:))
kappa_SS = sum(arrKappa_SS(:,:))
!>�ȵ���
coe_lam = kappa_BB * ( (energy+pressure)/(n_B*T) )**2
!>ratio
Lorentz = coe_lam / (sigma/T)
R_etasig = (eta/s) / (sigma/T)
Pr = eta*c_p / ( coe_lam*rho_mass )
RI = 4d0/(eta/rho_mass)
zeta_eta = zeta/eta
!***********************************************************************
open(unit=11, file='results\A0 solution.dat')
    write(11, "(4(4XF16.8),10(4XE17.10))") n_B/n0, mu_B*hc, T*hc, T/T0, phi_u, phi_s, Phi1, Phi2, arrMu(:)*hc
open(unit=12, file='results\A1 quantity.dat')
    write(12, "(4(4XF16.8),10(4XE17.10))") n_B/n0, mu_B*hc, T*hc, T/T0, pressure*hc, s, energy*hc, s/n_B, s/T**3
open(unit=13, file='results\rho and mu.dat')
    write(13, "(4(4XF16.8),10(4XE17.10))") n_B/n0, mu_B*hc, T*hc, T/T0, (arrN(1,:)-arrN(2,:))/n0
open(unit=14, file='results\sound_speed.dat')
    write(14, "(4(4XF16.8),10(4XE17.10))") n_B/n0, mu_B*hc, T*hc, T/T0, c_s
!***********************************************************************
open(unit=201, file='results\rex_time.dat')
    write(201, "(4(4XF16.8),10(4XE17.10))") n_B/n0, mu_B*hc, T*hc, T/T0, arrtau(1,:), arrtau(2,:)
open(unit=203, file='results\Coe_ratio.dat')
    write(203, "(5(4XF16.8),10(4XE17.10))") n_B/n0, mu_B*hc, T*hc, T/T0, s/n_B, zeta/eta, eta*T/(pressure+energy), zeta*T/(pressure+energy)
open(unit=211, file='results\related_coe.dat')
    write(211, "(4(4XF16.8),10(4XE17.10))") n_B/n0, mu_B*hc, T*hc, T/T0, lorentz, R_etasig, pr, zeta_eta, RI
        
open(unit=245, file='results\eta and sigma.dat')!eta and sigma
    write(245, "(5(4XF16.8),10(4XE17.10))") n_B/n0, mu_B*hc, T*hc, T/T0, s/n_B, eta/s, eta/T**3, s/T**3, sigma/t, R_etasig
open(unit=246, file='results\zeta.dat')!zeta
    write(246, "(5(4XF16.8),10(4XE17.10))") n_B/n0, mu_B*hc, T*hc, T/T0, s/n_B, zeta/s, zeta/T**3, s/T**3, zeta_eta, zeta*T/(pressure+energy)
open(unit=247, file='results\coe_diffusion.dat')!diffusion
    write(247, "(5(4XF16.8),10(4XE17.10))") n_B/n0, mu_B*hc, T*hc, T/T0, s/n_B, kappa_BB/T**2, kappa_QQ/T**2, kappa_SS/T**2
open(unit=248, file='results\coe_lambda.dat')!lambda
    write(248, "(5(4XF16.8),10(4XE17.10))") n_B/n0, mu_B*hc, T*hc, T/T0, s/n_B, kappa_BB/T**2, coe_lam/T**2 
    
end subroutine coefficients_tmu