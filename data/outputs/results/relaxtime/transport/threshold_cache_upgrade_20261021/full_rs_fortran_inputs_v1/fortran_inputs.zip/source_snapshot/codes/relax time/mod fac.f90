! Module facc: factor matrix (ASCII comment to avoid encoding issues)
module facc
    use nrtype, only: dp
    ! fac is a 3x3 parameter matrix �? use RESHAPE to provide a 2D initializer
    real(dp), dimension(3,3), parameter :: fac = reshape((/ &
        1d0, sqrt(2d0), sqrt(2d0), &
        sqrt(2d0), -1d0,    sqrt(2d0), &
        sqrt(2d0), sqrt(2d0), 2d0  &
    /), (/3,3/))
end module