subroutine area(kmax,xx,yy,T)
    implicit none
    real*8 a,b,c,area1,area2,cc,au,cd,ch1,rho1,rho2,ds,T
    integer i,k,j,n,auk,cdk,kk,kmax
    real*8 x(kmax),y(kmax),xx(kmax),yy(kmax),fb(3),rho(3)
    
    

    auk=0
    cdk=0
    do i=1,kmax
if(i>3)then
if(yy(i).lt.yy(i-1).and.yy(i-2).lt.yy(i-1))then
    au=xx(i-1)
    auk=i-1
end if
if(yy(i)>yy(i-1).and.yy(i-2)>yy(i-1))then
    cd=xx(i-1)
    cdk=i-1
end if
end if

    end do
 print*,auk,cdk,au,cd  
   ds=10000.d0
    do j=auk+10,cdk-10,1
        

     cc=yy(j)
     b=xx(j)
     
      kk=0
      n=3
      do while(kk.lt.3.and.n.lt.kmax)
          n=n+1
        fb(1)=abs(yy(n-2)-cc)
        fb(2)=abs(yy(n-1)-cc)
        fb(3)=abs(yy(n)-cc)
        
        if(fb(2).lt.fb(1).and.fb(2).lt.fb(3))then
        kk=kk+1
        rho(kk)=xx(n-1)
        end if
      end do  
       
      
   a=rho(1)
    c=rho(3)
   ! print*,a,c,n,cc
    
    k=0
    do i=1,kmax,1
        if(xx(i).ge.a.and.xx(i).le.c)then
            k=k+1
            x(k)=xx(i)
            y(k)=yy(i)
        end if
    end do
    
   area1=0.0d0
   area2=0.0d0
    
    do i=2,k,1
        if(x(i).le.b)then
           area1=area1+(y(i)+y(i-1)-2.0*cc)*(x(i)-x(i-1))/2.0d0
        else
            area2=area2+(2.0*cc-(y(i)+y(i-1)))*(x(i)-x(i-1))/2.0d0
        end if
        
    end do

 ! print*,abs(abs(area1)-abs(area2)),cc,a,c
    if(abs(abs(area1)-abs(area2)).le.ds)then
        ds=abs(abs(area1)-abs(area2))
        rho1=a
        rho2=c
        ch1=cc
        !print*,ds,abs(abs(area1)-abs(area2))
    end if
    
10    continue
    end do
    print*,T*197.33d0,rho1,xx(auk),xx(cdk),rho2,yy(cdk),ch1,yy(auk)
 open(unit=1729,file='quark_phase\first.dat')
    write(1729, "(8(1(5XE15.7),9(8XE15.7)))")T*197.33d0,rho1,xx(auk),xx(cdk),rho2,yy(cdk),ch1,yy(auk)   

    end