!> Unified phase-diagram scanning program
!> scan_mode = 1: T-mu grid scan (with optional adaptive T)
!> scan_mode = 2: Crossover line detection
!> scan_mode = 3: Both (grid scan + crossover line)
program AA_PHASE_SCAN
use nrtype, only: dp
use constant, only: hc, n0
use type_state
use scan_config
use solve_point_mod
implicit none
!***********************************************************************
integer, parameter :: MAX_PTS = 4096
integer :: time_i, time_f, time_rate
integer, parameter :: scan_mode = 3  ! <-- change this to select mode

real(dp), dimension(5), parameter :: SEED_HADRON_INIT = &
    [-1.8d0, -1.8d0, -2.2d0, 0.01d0, 0.01d0]
!***********************************************************************
call system_clock(time_i, time_rate)
call set_integral
call load_first_order_line('data_files\1st.txt')

select case(scan_mode)
case(1)
    call run_tmu_grid_scan()
case(2)
    call run_crossover_scan()
case(3)
    call run_tmu_grid_scan()
    call run_crossover_scan()
case default
    print *, 'Unknown scan_mode:', scan_mode
end select

call system_clock(time_f, time_rate)
write(*,'(A,I0,A,I0,A)') ' Total time: ', (time_f-time_i)/time_rate, &
    's, ', (time_f-time_i)/time_rate/60, 'min'

contains

!***********************************************************************
!> Standard T-mu grid scan with optional adaptive T refinement
!***********************************************************************
subroutine run_tmu_grid_scan()
    type(tmu_scan_params) :: par
    real(dp), dimension(5) :: x_prev_mu
    integer :: j_mu, n_mu, unit_sol
    real(dp) :: mu_mev

    real(dp), dimension(MAX_PTS) :: T_grid
    type(state), dimension(MAX_PTS) :: phy_grid
    real(dp), dimension(5, MAX_PTS) :: seed_grid
    logical, dimension(MAX_PTS) :: conv_grid
    integer :: n_T

    call default_tmu_params(par)
    n_mu = floor(abs((par%mu_max_mev - par%mu_min_mev) / par%step_mu_mev)) + 1

    unit_sol = 301
    open(unit=unit_sol, file='results\phase_scan_solution.dat', status='replace', action='write')
    write(unit_sol, '(A)') '# mu_B_MeV  T_MeV  phi_u  phi_d  phi_s  Phi1  Phi2  m_u_MeV  m_d_MeV  m_s_MeV  n_B/n0  converged'

    x_prev_mu(:) = SEED_HADRON_INIT(:)

    do j_mu = 1, n_mu
        mu_mev = par%mu_min_mev + (j_mu - 1) * par%step_mu_mev

        if (par%adaptive_T) then
            call adaptive_T_scan(mu_mev, par, T_grid, phy_grid, seed_grid, conv_grid, n_T, x_prev_mu)
        else
            call uniform_T_scan(mu_mev, par, T_grid, phy_grid, seed_grid, conv_grid, n_T, x_prev_mu)
        end if

        call write_scan_results(unit_sol, mu_mev, T_grid, phy_grid, conv_grid, n_T)
        print '(A,F8.2,A,I0,A)', ' mu_B=', mu_mev, ' MeV: ', n_T, ' T-points'
    end do
    close(unit_sol)
    print *, 'Grid scan done. Output: results\phase_scan_solution.dat'
end subroutine

!***********************************************************************
!> Uniform T scan at fixed mu_B
!***********************************************************************
subroutine uniform_T_scan(mu_mev, par, T_grid, phy_grid, seed_grid, conv_grid, n_T, x_start)
    real(dp), intent(in) :: mu_mev
    type(tmu_scan_params), intent(in) :: par
    real(dp), dimension(MAX_PTS), intent(out) :: T_grid
    type(state), dimension(MAX_PTS), intent(out) :: phy_grid
    real(dp), dimension(5, MAX_PTS), intent(out) :: seed_grid
    logical, dimension(MAX_PTS), intent(out) :: conv_grid
    integer, intent(out) :: n_T
    real(dp), dimension(5), intent(inout) :: x_start

    real(dp), dimension(5) :: x_seed, x_tmp
    integer :: k

    n_T = floor(abs((par%T_max_mev - par%T_min_mev) / par%step_T_mev)) + 1
    if (n_T > MAX_PTS) n_T = MAX_PTS

    x_seed(:) = x_start(:)
    do k = 1, n_T
        T_grid(k) = par%T_min_mev + (k - 1) * par%step_T_mev
        x_tmp(:) = x_seed(:)
        call get_phase_seed(T_grid(k), mu_mev, x_tmp, x_seed)
        call solve_gap_at_tmu(T_grid(k), mu_mev, x_seed, phy_grid(k), conv_grid(k))
        seed_grid(:, k) = x_seed(:)
    end do
    x_start(:) = x_seed(:)
end subroutine

!***********************************************************************
!> Adaptive T scan: coarse pass + iterative refinement
!***********************************************************************
subroutine adaptive_T_scan(mu_mev, par, T_grid, phy_grid, seed_grid, conv_grid, n_T, x_start)
    real(dp), intent(in) :: mu_mev
    type(tmu_scan_params), intent(in) :: par
    real(dp), dimension(MAX_PTS), intent(out) :: T_grid
    type(state), dimension(MAX_PTS), intent(out) :: phy_grid
    real(dp), dimension(5, MAX_PTS), intent(out) :: seed_grid
    logical, dimension(MAX_PTS), intent(out) :: conv_grid
    integer, intent(out) :: n_T
    real(dp), dimension(5), intent(inout) :: x_start

    real(dp), dimension(MAX_PTS) :: T_new
    type(state), dimension(MAX_PTS) :: phy_new
    real(dp), dimension(5, MAX_PTS) :: seed_new
    logical, dimension(MAX_PTS) :: conv_new
    integer :: n_new

    real(dp), dimension(5) :: x_seed_mid, x_tmp
    type(state) :: phy_mid
    logical :: conv_mid
    real(dp) :: delta_phi, T_mid, gap
    integer :: k, round, insert_count

    ! Step 1: Coarse uniform scan
    call uniform_T_scan(mu_mev, par, T_grid, phy_grid, seed_grid, conv_grid, n_T, x_start)

    ! Step 2: Iterative refinement
    do round = 1, par%adapt_max_refine
        n_new = 0
        insert_count = 0
        do k = 1, n_T
            n_new = n_new + 1
            if (n_new > MAX_PTS) exit
            T_new(n_new) = T_grid(k)
            phy_new(n_new) = phy_grid(k)
            seed_new(:, n_new) = seed_grid(:, k)
            conv_new(n_new) = conv_grid(k)

            if (k < n_T) then
                gap = T_grid(k+1) - T_grid(k)
                delta_phi = abs(phy_grid(k+1)%arrPhi(1) - phy_grid(k)%arrPhi(1))
                if (delta_phi > par%adapt_threshold .and. gap > par%adapt_min_step) then
                    T_mid = 0.5d0 * (T_grid(k) + T_grid(k+1))
                    x_tmp(:) = seed_grid(:, k)
                    call get_phase_seed(T_mid, mu_mev, x_tmp, x_seed_mid)
                    call solve_gap_at_tmu(T_mid, mu_mev, x_seed_mid, phy_mid, conv_mid)
                    n_new = n_new + 1
                    if (n_new > MAX_PTS) exit
                    T_new(n_new) = T_mid
                    phy_new(n_new) = phy_mid
                    seed_new(:, n_new) = x_seed_mid(:)
                    conv_new(n_new) = conv_mid
                    insert_count = insert_count + 1
                end if
            end if
        end do

        n_T = min(n_new, MAX_PTS)
        T_grid(1:n_T) = T_new(1:n_T)
        phy_grid(1:n_T) = phy_new(1:n_T)
        seed_grid(:, 1:n_T) = seed_new(:, 1:n_T)
        conv_grid(1:n_T) = conv_new(1:n_T)

        if (insert_count == 0) exit
    end do
end subroutine

!***********************************************************************
!> Crossover line scan: detect T_c(mu) across mu range
!***********************************************************************
subroutine run_crossover_scan()
    type(crossover_scan_params) :: par
    type(state) :: phy
    real(dp), dimension(5) :: x_seed, x_tmp
    logical :: converged
    integer :: j_mu, n_mu, unit_cro

    integer, parameter :: MAX_T = 2048
    real(dp), dimension(MAX_T) :: T_arr, delta_phi_arr
    real(dp), dimension(5, MAX_T) :: seed_arr
    type(state), dimension(MAX_T) :: phy_arr
    logical, dimension(MAX_T) :: conv_arr
    integer :: n_T, k, best_k
    real(dp) :: mu_mev
    real(dp) :: T_cross_mev, best_delta
    real(dp) :: T_lo, T_hi
    real(dp), dimension(5) :: xs_lo

    call default_crossover_params(par)
    n_mu = floor(abs((par%mu_max_mev - par%mu_min_mev) / par%step_mu_mev)) + 1

    unit_cro = 302
    open(unit=unit_cro, file='results\crossover_line.dat', status='replace', action='write')
    write(unit_cro, '(A)') '# mu_B_MeV  T_crossover_MeV  phi_u  phi_s  Phi1  delta_phi  converged'

    do j_mu = 1, n_mu
        mu_mev = par%mu_min_mev + (j_mu - 1) * par%step_mu_mev

        n_T = floor(abs((par%T_search_max_mev - par%T_search_min_mev) / par%T_search_step_mev)) + 1
        if (n_T > MAX_T) n_T = MAX_T

        x_seed(:) = SEED_HADRON_INIT(:)
        do k = 1, n_T
            T_arr(k) = par%T_search_min_mev + (k - 1) * par%T_search_step_mev
            x_tmp(:) = x_seed(:)
            call get_phase_seed(T_arr(k), mu_mev, x_tmp, x_seed)
            call solve_gap_at_tmu(T_arr(k), mu_mev, x_seed, phy_arr(k), conv_arr(k))
            seed_arr(:, k) = x_seed(:)
        end do

        delta_phi_arr(:) = 0d0
        do k = 2, n_T - 1
            delta_phi_arr(k) = abs(phy_arr(k+1)%arrPhi(1) - phy_arr(k-1)%arrPhi(1))
        end do

        best_k = 2
        best_delta = delta_phi_arr(2)
        do k = 3, n_T - 1
            if (delta_phi_arr(k) > best_delta) then
                best_delta = delta_phi_arr(k)
                best_k = k
            end if
        end do

        if (best_delta < 1d-6) cycle

        T_lo = T_arr(max(best_k - 1, 1))
        T_hi = T_arr(min(best_k + 1, n_T))
        xs_lo(:) = seed_arr(:, max(best_k - 1, 1))

        call refine_crossover_peak(mu_mev, T_lo, T_hi, xs_lo, par, T_cross_mev, phy, converged)

        write(unit_cro, '(F10.4,1X,F10.4,1X,4(ES18.10,1X),L1)') &
            mu_mev, T_cross_mev, &
            phy%arrPhi(1), phy%arrPhi(3), phy%arrPhi(4), &
            phy%delta_phi, converged

        print '(A,F8.2,A,F8.2,A)', ' Crossover: mu_B=', mu_mev, &
            ' MeV -> T_c=', T_cross_mev, ' MeV'
    end do
    close(unit_cro)
    print *, 'Crossover scan done. Output: results\crossover_line.dat'
end subroutine

!***********************************************************************
!> Refine crossover peak via golden-section search on delta_phi (max)
!> Properly reuses one probe point per iteration
!***********************************************************************
subroutine refine_crossover_peak(mu_mev, T_lo_in, T_hi_in, x_seed_base, par, T_cross, phy_out, converged)
    real(dp), intent(in) :: mu_mev, T_lo_in, T_hi_in
    real(dp), dimension(5), intent(in) :: x_seed_base
    type(crossover_scan_params), intent(in) :: par
    real(dp), intent(out) :: T_cross
    type(state), intent(out) :: phy_out
    logical, intent(out) :: converged

    real(dp), parameter :: delta_T_deriv = 0.5d0
    real(dp) :: T_lo, T_hi, T_m1, T_m2
    real(dp) :: dphi_m1, dphi_m2
    real(dp), dimension(5) :: xs
    integer :: iter
    real(dp), parameter :: golden = 0.381966011d0
    logical :: have_m1, have_m2

    T_lo = T_lo_in
    T_hi = T_hi_in
    have_m1 = .false.
    have_m2 = .false.

    do iter = 1, par%refine_max_iter
        if (T_hi - T_lo < par%refine_tol_mev) exit

        T_m1 = T_lo + golden * (T_hi - T_lo)
        T_m2 = T_hi - golden * (T_hi - T_lo)

        if (.not. have_m1) then
            dphi_m1 = eval_delta_phi(mu_mev, T_m1, x_seed_base, delta_T_deriv)
        end if
        if (.not. have_m2) then
            dphi_m2 = eval_delta_phi(mu_mev, T_m2, x_seed_base, delta_T_deriv)
        end if

        if (dphi_m1 < dphi_m2) then
            T_lo = T_m1
            ! m2 becomes the new m1
            dphi_m1 = dphi_m2
            have_m1 = .true.
            have_m2 = .false.
        else
            T_hi = T_m2
            ! m1 becomes the new m2
            dphi_m2 = dphi_m1
            have_m2 = .true.
            have_m1 = .false.
        end if
    end do

    T_cross = 0.5d0 * (T_lo + T_hi)
    xs(:) = x_seed_base(:)
    call solve_gap_at_tmu(T_cross, mu_mev, xs, phy_out, converged)
    phy_out%delta_phi = eval_delta_phi(mu_mev, T_cross, x_seed_base, delta_T_deriv)
end subroutine

!***********************************************************************
!> Evaluate |phi_u(T+dT) - phi_u(T-dT)| at given (T, mu)
!***********************************************************************
function eval_delta_phi(mu_mev, T_mev, x_seed_base, dT) result(dphi)
    real(dp), intent(in) :: mu_mev, T_mev, dT
    real(dp), dimension(5), intent(in) :: x_seed_base
    real(dp) :: dphi
    type(state) :: phy_p, phy_m
    real(dp), dimension(5) :: xs_p, xs_m, xt
    logical :: cv

    xt(:) = x_seed_base(:)
    call get_phase_seed(T_mev - dT, mu_mev, xt, xs_m)
    call solve_gap_at_tmu(T_mev - dT, mu_mev, xs_m, phy_m, cv)

    xt(:) = x_seed_base(:)
    call get_phase_seed(T_mev + dT, mu_mev, xt, xs_p)
    call solve_gap_at_tmu(T_mev + dT, mu_mev, xs_p, phy_p, cv)

    dphi = abs(phy_p%arrPhi(1) - phy_m%arrPhi(1))
end function

!***********************************************************************
!> Write scan results to file
!***********************************************************************
subroutine write_scan_results(unit_num, mu_mev, T_grid, phy_grid, conv_grid, n_T)
    integer, intent(in) :: unit_num, n_T
    real(dp), intent(in) :: mu_mev
    real(dp), dimension(MAX_PTS), intent(in) :: T_grid
    type(state), dimension(MAX_PTS), intent(in) :: phy_grid
    logical, dimension(MAX_PTS), intent(in) :: conv_grid
    integer :: k

    do k = 1, n_T
        write(unit_num, '(F10.4,1X,F10.4,1X,5(ES16.8,1X),3(F12.4,1X),ES14.6,1X,L1)') &
            mu_mev, T_grid(k), &
            phy_grid(k)%arrPhi(1), phy_grid(k)%arrPhi(2), phy_grid(k)%arrPhi(3), &
            phy_grid(k)%arrPhi(4), phy_grid(k)%arrPhi(5), &
            phy_grid(k)%arrMass(1)*hc, phy_grid(k)%arrMass(2)*hc, phy_grid(k)%arrMass(3)*hc, &
            phy_grid(k)%N_B/n0, conv_grid(k)
    end do
end subroutine

end program AA_PHASE_SCAN
