function s_pm(s,mi,mj,pm)
    use nrtype, only: dp
    implicit none
    real(dp):: s_pm
    real(dp), intent(in):: s, mi, mj, pm
    s_pm = s - (mi + pm*mj)**2
end function
function t_pm(t,mi,mj,pm)
    use nrtype, only: dp
    implicit none
    real(dp):: t_pm
    real(dp), intent(in):: t, mi, mj, pm
    t_pm = t - (mi + pm*mj)**2 
end function
function u_pm(u,mi,mj,pm)
    use nrtype, only: dp
    implicit none
    real(dp):: u_pm
    real(dp), intent(in):: u, mi, mj, pm
    u_pm = u - (mi + pm*mj)**2
end function