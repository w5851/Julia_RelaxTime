program usbar_mu0_scan
use nrtype, only: dp
use constant, only: hc
use variable, only: phi_u, phi_d, phi_s, Phi1, Phi2, T, mu_B, n_B, n_charge, n_strange, &
    rho_mass, pressure, energy, s, arrMu, arrMass, arrA, arrG, arrN
use type_state
use nr, only: newt
use PNJL, only: funcv_tmu, quantity
use scattering_code, only: usb_code
use meson_function, only: cross_section
implicit none

integer, parameter :: n_targets = 2
real(dp), dimension(n_targets), parameter :: target_t_mev = [210d0, 250d0]
real(dp), dimension(5) :: x_quark
type(state) :: phy
logical :: check
integer :: target_index

call set_integral

open(unit=901, file='results\cross_section.dat', status='replace', action='write')
close(901)
open(unit=902, file='results\usbar_mu0_state_summary.dat', status='replace', action='write')
write(902, '(A)') 'T_MeV muB_MeV check phi_u phi_d phi_s Phi PhiBar m_u_MeV m_d_MeV m_s_MeV nB pressure energy entropy'

x_quark = [-0.18d0, -0.18d0, -1.5d0, 0.69d0, 0.69d0]

do target_index = 1, n_targets
    T = target_t_mev(target_index) / hc
    mu_B = 0d0
    arrMu(:) = 0d0

    if (target_index == 2) then
        x_quark(:) = phy%arrPhi(:)
    end if

    call newt(x_quark, check, funcv_tmu)

    phy%T = T
    phy%mu_B = mu_B
    phy%arrMu(:) = arrMu(:)
    phy%arrPhi(:) = x_quark(:)
    call quantity(phy)

    phi_u = phy%arrPhi(1)
    phi_d = phy%arrPhi(2)
    phi_s = phy%arrPhi(3)
    Phi1 = phy%arrPhi(4)
    Phi2 = phy%arrPhi(5)
    arrMass(:) = phy%arrMass(:)
    arrA(:) = phy%arrA(:)
    arrG(:) = phy%arrG(:)
    arrN(:,:) = phy%arrN(:,:)
    n_B = phy%n_B
    n_charge = phy%n_charge
    n_strange = phy%n_strange
    rho_mass = phy%rho_mass
    pressure = phy%pressure
    energy = phy%energy
    s = phy%s

    write(902, '(2(1X,F10.4),1X,L1,11(1X,ES24.16E3))') &
        target_t_mev(target_index), mu_B * hc, check, phy%arrPhi(:), phy%arrMass(:) * hc, &
        phy%n_B, phy%pressure, phy%energy, phy%s

    call cross_section(usb_code)
end do

close(902)
end program usbar_mu0_scan