subroutine newt(x, check, funcv)
	use nrtype, only: dp
    use nr, only: fdjac, ludcmp, lubksb, lnsrch
    use fminln
	implicit none
!***********************************************************************
	real(dp), dimension(:), intent(inout):: x
	logical, intent(out):: check
    interface
        function funcv(x)
            use nrtype, only: dp
            implicit none
            real(dp), dimension(:), intent(in):: x
            real(dp), dimension(size(x)):: funcv
        end function funcv
    end interface
!***********************************************************************
	integer:: n, its
	integer, parameter:: MAXITS = 200
	real(dp), parameter:: TOLF = 1d-8, TOLMIN = 1d-8, TOLX = 1d-8, STPMX = 100d0
    integer, dimension(size(x)):: indx
    real(dp), dimension(size(x)):: g, p, xold
    real(dp), dimension(size(x)), target:: fvec
    real(dp), dimension(size(x),size(x)):: fjac
	real(dp):: d, f, fold, stpmax
!***********************************************************************
    n = size(x)
    fmin_fvecp => fvec
	f = fmin(x,funcv)
	if(maxval(abs(fvec(:))) < 0.01d0*TOLF) then
		check = .false.
		return
	end if
	stpmax = STPMX*max(sqrt(dot_product(x(:),x(:))),real(n))
	do its = 1, MAXITS
		call fdjac(x(1:n), fvec(1:n), fjac(1:n,1:n), funcv)
        g(:) = matmul(fvec(:),fjac(:,:))!>compute Grad f for the line search
        xold(:) = x(:)
		fold = f
        p(:) = -fvec(:)
		call ludcmp(fjac(1:n,1:n), indx(1:n), d) 
		call lubksb(fjac(1:n,1:n), indx(1:n), p(1:n))
		call lnsrch( xold(:),fold,g(:),p(:),x(:),f,stpmax,check,fmin,funcv )
		if(maxval(abs(fvec(:))) < TOLF) then
			check = .false.
			return
        end if
        !>Check for gradient of f_0, i.e., spurious convergence
		if(check) then
            check = ( maxval( abs(g(:))*max(abs(x(:)),1d0)/ &
                max(f,0.5d0*n) ) < TOLMIN )
			return
        end if
        if (maxval(abs(x(:)-xold(:))/max(abs(x(:)),1d0)) < TOLX) then
			return
        end if
	end do
	pause 'MAXITS exceeded in newt'
end subroutine newt
        
