!***********************************************************************
!>cha8��ʾ��u/s��t��
!>���ᣬ���أ����ᣬ����
subroutine channel_select(quark_code,cha8)
    use nrutil, only: nrerror
    implicit none
!***********************************************************************
    integer, dimension(2,4), intent(in):: quark_code
    integer, dimension(8), intent(out):: cha8
!***********************************************************************
    integer:: i11
!***********************************************************************
    i11 = -1
    if (quark_code(2,1)*quark_code(2,2) == 1) then!>quark-quark scattering
        select case(quark_code(1,1)*quark_code(1,2))
        case(2)
            i11 = 1; cha8 = (/1,-1,1,-1,1,1,1,1/)
        case(1)
            i11 = 2; cha8 = (/1,1,1,1,1,1,1,1/)
        case(3)
            i11 = 3; cha8 = (/1,-1,1,-1,-1,1,-1,1/)
        case(9)
            i11 = 4; cha8 = (/-1,1,-1,1,-1,1,-1,1/)
        end select
    else if (quark_code(2,1)*quark_code(2,2) == -1) then!>quark-antiquark scattering
        select case(quark_code(1,1)*quark_code(1,2))
        case(1)
            select case(quark_code(1,3)*quark_code(1,4))
            case(1)
                i11 = 6; cha8 = (/1,1,1,1,1,1,1,1/)!>uub-uub
            case(4)
                i11 = 7; cha8 = (/1,1,1,1,1,-1,1,-1/)!>uub-ddb
            case(9)
                i11 = 9; cha8 = (/-1,1,-1,1,1,-1,1,-1/)!>uub-ssb
            end select
        case(2)
            i11 = 5; cha8 = (/1,-1,1,-1,1,1,1,1/)!>udb-udb
        case(3)
            i11 = 8; cha8 = (/1,-1,1,-1,-1,1,-1,1/)!>usb-usb
        case(9)
            select case(quark_code(1,3)*quark_code(1,4))
            case(1)
                i11 = 10; cha8 = (/-1,1,-1,1,1,-1,1,-1/)!>ssb-uub
            case(9)
                i11 = 11; cha8 = (/-1,1,-1,1,-1,1,-1,1/)!>ssb-ssb
            end select
        end select
    end if
    if (i11 < 0) then
        call nrerror("Wrong process in 'channel_select'. ")
    end if
end subroutine channel_select