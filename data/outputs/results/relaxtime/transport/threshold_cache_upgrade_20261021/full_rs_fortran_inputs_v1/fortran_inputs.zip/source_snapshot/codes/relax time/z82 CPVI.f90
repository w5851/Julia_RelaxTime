subroutine CPVI(a, b, x0, x, w, n)
    use nrtype, only: dp
    use nrutil, only: arth
    implicit none
!***********************************************************************
    real(dp), intent(in):: a, b, x0
    real(dp), dimension(n), intent(out):: x, w
    integer, intent(inout):: n
!***********************************************************************
    integer i, j
    real(dp):: h
!***********************************************************************
    h = (b-a) / ((n-1)*1d0)
    i = floor( ( (x0-0.001d0*h)-a )/h ) + 1
    j = floor( ( b-(x0+0.001d0*h) )/h ) + 1
    n = i + j
    w(:) = h
    w(1) = h / 2.0d0
    if(i>0) w(i) = h / 2.0d0
    if(j>0) w(i+1) = h / 2.0d0
    w(n) = h / 2.0d0
    x(i:1:-1) = arth(x0-0.001d0*h, -h, i)
    x(i+1:n) = arth(x0+0.001d0*h, h, j)
end subroutine CPVI