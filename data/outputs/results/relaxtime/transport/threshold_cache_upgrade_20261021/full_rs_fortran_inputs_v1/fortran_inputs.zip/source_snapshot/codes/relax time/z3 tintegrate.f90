!ɢ�����Ļ���
!integral of $\frac{d\sigma}{dt}$ over Mandelstam variables t.	
function tint(s_cm, qk)
    use nrtype
    use constant, only: pi
    use variable, only: T, Phi1, Phi2, arrMu, arrMass
    use integral, only: zz64, pp64, n64
    use quark_fun, only: fd
    use meson_function, only: s_pm, amplitude2
    use nr, only: gauleg_ab
    use omp_lib!���м���
    implicit none
!***********************************************************************
    real(dp):: tint
    real(dp), intent(in):: s_cm
    integer, dimension(4,3), intent(in):: qk
!***********************************************************************
    integer, parameter:: nt = n64
    real(dp), dimension(nt):: wt, yt
    integer:: i
    real(dp):: t_min, t_max, t21, t22, t31, t32
    real(dp), dimension(4):: m, mu
    real(dp):: E3, E4
!***********************************************************************
m(:) = arrMass(qk(:,1)); mu(:) = arrMu(qk(:,1))*dble(qk(:,2))
E3 = (s_cm + m(3)**2 - m(4)**2) / (2d0*sqrt(s_cm))
E4 = (s_cm - m(3)**2 + m(4)**2) / (2d0*sqrt(s_cm))
t21 = s_cm + m(1)**2 - m(2)**2
t22 = s_cm + m(3)**2 - m(4)**2
t31 = sqrt( t21**2 - 4d0*s_cm*m(1)**2 )
t32 = sqrt( t22**2 - 4d0*s_cm*m(3)**2 )
t_max = m(1)**2 + m(3)**2 - t21*t22/(2d0*s_cm) + t31*t32/(2d0*s_cm)*0.999d0
t_min = m(1)**2 + m(3)**2 - t21*t22/(2d0*s_cm) - t31*t32/(2d0*s_cm)*0.999d0
if(qk(4,1) == qk(3,1) .and. qk(3,2) == qk(4,2)) then
    t_min = t_min / 2d0
end if
call gauleg_ab( t_min, t_max, zz64(:), pp64(:), yt(:), wt(:), nt )

tint = 0d0
call OMP_SET_NUM_THREADS(16)!ʹ���߳���
!$OMP PARALLEL reduction(+:tint) PRIVATE(i) DEFAULT(SHARED)
!$OMP Do
do i = 1, nt, 1
    tint = tint + wt(i)*amplitude2( s_cm, yt(i), qk(:,:) )!t_cm = yt(i)
end do
!$OMP End Do
!$OMP END PARALLEL
tint = tint/(16d0*pi*s_pm(s_cm,m(1),m(2),1d0)*s_pm(s_cm,m(1),m(2),-1d0))
tint = tint*(1d0-fd(E3,mu(3),T,phi1,phi2))*(1d0-fd(E4,mu(4),T,phi1,phi2))
end function tint!(s_cm, qk)