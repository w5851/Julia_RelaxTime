!>cha4��ʾ[u/s�ᣬu/s�أ�t�ᣬt��]
subroutine relaxation_time(arrTau)
    use nrtype, only: dp
    use constant, only: hc, n0
    use variable, only: n_B, mu_B, T, arrN
    use meson_function, only: averaged_rate
    use scattering_code
    implicit none
!***********************************************************************
    real(dp), dimension(2,3), intent(out):: arrTau
!***********************************************************************
    real(dp):: tau_l, tau_lb, tau_s, tau_sb
    real(dp):: n_u, n_ub, n_s, n_sb
    real(dp):: w_ij, w_ij_n, sig_bar
    real(dp), dimension(11):: w, wnn, sig
    real(dp), dimension(6):: wa, wann, siga
!***********************************************************************
n_u = arrN(1,1); n_ub = arrN(2,1)
n_s = arrN(1,3); n_sb = arrN(2,3)
!<< quark-quark scatter >>>*********************************************
call averaged_rate( ud_code(:,:), w(1), wnn(1) )!1.ud->ud
call averaged_rate( uu_code(:,:), w(2), wnn(2) )!2.uu->uu
call averaged_rate( us_code(:,:), w(3), wnn(3) )!3.us->us
call averaged_rate( ss_code(:,:), w(4), wnn(4) )!4.ss->ss
!<<< quark-antiquark scatter >>>****************************************
call averaged_rate( udb_code(:,:), w(5), wnn(5) )!>5.udbar->udbar
call averaged_rate( uub_code(:,:), w(6), wnn(6) )!>6.uubar->uubar
call averaged_rate( uubddb_code(:,:), w(7), wnn(7) )!>7.uubar->ddbar
call averaged_rate( usb_code(:,:), w(8), wnn(8) )!>8.usbar->usbar
call averaged_rate( uubssb_code(:,:), w(9), wnn(9) )!>9.uubar->ssbar
call averaged_rate( ssbuub_code(:,:), w(10), wnn(10) )!>10.ssbar->uubar
call averaged_rate( ssb_code(:,:), w(11), wnn(11) )!>11.ssbar->ssbar
!<<< antiquark-antiquark >>>********************************************
call averaged_rate( ubdb_code(:,:), wa(1), wann(1) )!1.u_d_->u_d_
call averaged_rate( ubub_code(:,:), wa(2), wann(2) )!2.u_u_->u_u_
call averaged_rate( ubsb_code(:,:), wa(3), wann(3) )!3.u_s_->u_s_
call averaged_rate( sbsb_code(:,:), wa(4), wann(4) )!4.s_s_->s_s_
!<<<qq_b--qq_b>>>*******************************************************
call averaged_rate( dub_code(:,:), wa(5), wann(5) )!5.dubar->dubar
call averaged_rate( sub_code(:,:), wa(6), wann(6) )!6.subar->subar
!***********************************************************************
open(unit=1101,file='results\w_ij.dat')
    write(1101, "(3(4XF16.8),12(4XE17.10))") n_B/n0, mu_B*hc, T*hc, w
open(unit=1102,file='results\w_ij_n.dat')
    write(1102, "(3(4XF16.8),12(4XE17.10))") n_B/n0, mu_B*hc, T*hc, wnn
open(unit=1103,file='results\w_ija.dat')
    write(1103, "(3(4XF16.8),12(4XE17.10))") n_B/n0, mu_B*hc, T*hc, wa
open(unit=1104,file='results\w_ij_na.dat')
    write(1104, "(3(4XF16.8),12(4XE17.10))") n_B/n0, mu_B*hc, T*hc, wann
tau_l = 1d0 / (n_u*(w(2)+w(1))+n_ub*(w(6)+w(7)+w(9)+w(5))+n_s*w(3)+n_sb*w(8))
tau_s = 1d0 / (2d0*n_u*w(3)+2d0*n_ub*w(8)+n_s*w(4)+n_sb*(w(11)+2d0*w(10)))
tau_lb = 1d0 / (n_u*(w(6)+w(7)+w(9)+wa(5))+n_ub*(wa(1)+wa(2))+n_s*wa(6)+n_sb*wa(3))
tau_sb = 1d0 / (2d0*n_u*w(8)+2d0*n_ub*wa(3)+n_sb*wa(4)+n_s*(w(11)+2d0*w(10)))
arrTau(1,:) = [tau_l, tau_l, tau_s]
arrTau(2,:) = [tau_lb, tau_lb, tau_sb]
end