module nrtype
    integer, parameter:: dp = kind(1.0d0)
    integer, parameter:: I4B = selected_int_kind(9)
    integer, parameter:: I2B = selected_int_kind(5)
    integer, parameter:: I1B = selected_int_kind(2)
end module nrtype
!***********************************************************************
module integral
    use nrtype, only: dp
    implicit none
    integer, parameter:: npoint = 128, npoint1 = 128!PNJL
    real(dp), dimension(npoint):: w, y
    real(dp), dimension(npoint1):: w1, y1
    
    integer, parameter:: npoint_rex = 64!averaged_rate
    real(dp), dimension(npoint_rex):: wp, yp, wpi, ypi
    
    integer, parameter:: n_bpm = 128!BPM
    real(dp), dimension(n_bpm):: xb, wb
    
    integer, parameter:: n128 = 128
    real(dp), dimension(n128):: x128, w128
    real(dp), dimension((n128+1)/2):: zz128, pp128
    
    integer, parameter:: n64 = 64
    real(dp), dimension(n64):: x64, w64
    real(dp), dimension((n64+1)/2):: zz64, pp64
end module
!***********************************************************************
module constant!ģ�飬���峣��
    use nrtype, only: dp
    implicit none
    real(dp), parameter:: pi = 3.141592653d0, hc = 197.33d0, alpha_em = 1d0/137d0
    real(dp), parameter:: po = 1.0d0, mi = -1.0d0           !������
    real(dp), parameter:: error = 1d-15
    real(dp), parameter, dimension(2):: arrPM = [po,mi]
    real(dp), parameter:: T0 = 210d0/hc, n0 = 0.16d0
    real(dp), parameter:: b_a = 1d0/3d0!��˵�������
    real(dp), parameter:: a0 = 3.51d0, a1 = -2.47d0, a2 = 15.2d0, b3 = -1.75d0
    real(dp), parameter:: m0_l = 5.5d0/hc, m0_s = 140.7d0/hc
    real(dp), parameter, dimension(3):: arrm0 = [m0_l,m0_l,m0_s]
    real(dp), parameter:: N_c = 3.d0, N_f = 3.0d0
    real(dp), parameter:: G_Lambda2 = 1.835d0, K_Lambda5 = 12.36d0, Lambda = 602.3d0/hc
    real(dp), parameter:: G_f = G_Lambda2/(Lambda**2d0), K_f = K_Lambda5/(Lambda**5d0)
    real(dp), parameter:: Lambda_QCD = 300d0/hc
    
    integer, parameter, dimension(3,3):: ijk = reshape([1,2,3,2,3,1,3,1,2], [3,3])
    real(dp), parameter, dimension(2,2):: l0 = reshape([sqrt(2d0),0d0,0d0,sqrt(2d0)], [2,2])
    real(dp), parameter, dimension(2,2):: l8 = reshape([1d0,0d0,0d0,-2d0], [2,2])
    
    real(dp), parameter:: q_u = 2d0/3d0, q_d = -1d0/3d0, q_s = -1d0/3d0!��˵��
    real(dp), parameter, dimension(2,3):: arr_quark_charge = reshape([q_u, -q_u, q_d, -q_d, q_s, -q_s], [2,3])
    
    real(dp), parameter:: quark_baryon_number = 1d0/3d0!>���������
    real(dp), parameter, dimension(2,3):: arr_quark_baryon = reshape( &
        [quark_baryon_number, -quark_baryon_number, &
            quark_baryon_number, -quark_baryon_number, &
            quark_baryon_number, -quark_baryon_number], [2,3])
    
    real(dp), parameter:: l_quark_s_number = 0d0, s_quark_s_number = -1d0!>���������
    real(dp), parameter, dimension(2,3):: arr_quark_strange = reshape( &
        [l_quark_s_number, -l_quark_s_number, &
            l_quark_s_number, -l_quark_s_number, &
            s_quark_s_number, -s_quark_s_number], [2,3])
end module
!***********************************************************************
module type_state!�������ͷ�װΪһ��ģ��
    use nrtype, only: dp
    type state!����һ�����ͣ���ʾ��ͼ��һ�����Ϣ
        real(dp), dimension(5):: arrPhi
        real(dp):: T, mu_B, N_B, n_charge, n_strange
        real(dp):: rho_mass, pressure, energy, s
        real(dp), dimension(3):: arrMu, arrMass, arrA, arrG
        real(dp), dimension(2,3):: arrN!������ζ������ܶ�
        real(dp):: delta_phi
    end type
end module
!***********************************************************************
module variable!ģ�飬���岿�ֱ���
    use nrtype, only: dp
    implicit none
    real(dp):: phi_u, phi_d, phi_s, Phi1, Phi2
    real(dp):: T, mu_B, n_B, n_charge, n_strange
    real(dp):: rho_mass, pressure, energy, s
    real(dp), dimension(3):: arrMu, arrMass, arrA, arrG
    real(dp), dimension(2,3):: arrN!������ζ������ܶ�
end module
!***********************************************************************
module parameter_meson
    implicit none
    integer:: fla(3), ii, jj, kk
    real(8):: mes_para(3), lh, ps, is
    !mes_para=(/0,-1,1/)!0��1��or�ؽ��ӣ�1��-1��or�ͱ꣬-1��1�ؽ��Ӵ�����prime
    !fla=(/1,2,3/)!ȡ123pionϵ���ӣ�ȡ132kaonϵ����
end module parameter_meson
!***********************************************************************