subroutine ludcmp(a, indx, d)
    use nrtype, only: dp
    use nrutil, only: swap, nrerror, assert_eq
	implicit none
    real(dp), dimension(:,:), intent(inout):: a
    integer, dimension(:), intent(out):: indx
	real(dp), intent(out):: d
!***********************************************************************
	integer:: n
    real(dp), parameter:: TINY = 1d-20
	integer:: i, imax, j, k
	real(dp):: aamax, dum, sum
    real(dp), dimension(size(indx)):: vv
!***********************************************************************
    n = assert_eq(size(a,1),size(a,2),size(indx),"ludcmp")
	d = 1.0
    vv = maxval(abs(a),dim=2)
    if (any( abs(vv) < TINY )) then
        call nrerror("singular matrix in ludcmp")
    end if
    vv = 1d0 / vv
	do j = 1, n
		do i = 1, j-1
			sum = a(i,j)
			do k = 1, i-1
				sum = sum - a(i,k)*a(k,j)
			end do
			a(i,j) = sum
		end do
		aamax = 0.0
		do i = j, n
			sum = a(i,j)
			do k = 1, j-1
				sum = sum - a(i,k)*a(k,j)
			end do
			a(i,j) = sum
			dum = vv(i)*abs(sum)
			if (dum.ge.aamax) then
				imax=i
				aamax=dum
			end if
		end do
		if (j /= imax) then
			do k = 1, n
				dum=a(imax,k)
				a(imax,k) = a(j,k)
				a(j,k) = dum
			end do
			d=-d
			vv(imax)=vv(j)
		endif
		indx(j) = imax
		if(a(j,j) == 0d0) a(j,j)=TINY

		if(j /= n)then
			dum=1./a(j,j)
			do i=j+1,n
				a(i,j)=a(i,j)*dum
			end do
		endif
	end do
	return
end
!***********************************************************************
!***********************************************************************
subroutine lubksb(a, indx, b)!>forward substitution and backsubstitution
	use nrtype, only: dp
    use nrutil, only: assert_eq
	implicit none
	integer, dimension(:), intent(in):: indx
	real(dp), dimension(:,:), intent(in):: a
	real(dp), dimension(:), intent(inout):: b
!***********************************************************************
	integer:: n, i, j, ii, ll
	real(dp):: summ
!***********************************************************************
    n = assert_eq(size(a,1),size(a,2),size(indx),'lubksb')
	ii = 0
	do i = 1, n
		ll = indx(i)
		summ = b(ll)
		b(ll) = b(i)
		if (ii /= 0) then
            summ = summ - dot_product( a(i,ii:i-1), b(ii:i-1) )
		else if (summ.ne.0.) then
			ii = i
		end if
		b(i) = summ
	end do
	do i = n, 1, -1
        b(i) = ( b(i) - dot_product(a(i,i+1:n),b(i+1:n)) ) / a(i,i)
	end do
end 