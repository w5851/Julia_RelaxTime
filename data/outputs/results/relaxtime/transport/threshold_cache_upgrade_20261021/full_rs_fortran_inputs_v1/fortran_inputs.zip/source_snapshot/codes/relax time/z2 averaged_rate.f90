!
subroutine  averaged_rate(qk_code, w_ij, w_ij_n)
    use nrtype, only: dp
    use constant, only: pi, N_c, Lambda
    use integral, only: npoint_rex, yp, wp, ypi, wpi
    use variable, only: T, Phi1, Phi2, arrMass, arrMu, arrN
    use quark_fun, only: fd
    use meson_function, only: tint
    use nrutil, only: arth, nrerror
    implicit none
!***********************************************************************
    integer, dimension(4,3), intent(in):: qk_code
    real(dp), intent(out):: w_ij, w_ij_n
!***********************************************************************
    integer:: i, j, k, i0
    integer, parameter:: nn = 128
    real(dp), dimension(nn):: sig, s_cmk
    real(dp):: s_bo, s_up, h
    real(dp):: m1, m2, m3, m4, n1, n2, mu1, mu2
    real(dp):: angel
    real(dp), dimension(npoint_rex):: E1, E2, f1, f2
    real(dp):: s_cm, s_rt, sig_ij, v_rel, E11, E22, p11, p22, inc
!***********************************************************************
n1 = arrN( (3-qk_code(1,2))/2, qk_code(1,1) )
n2 = arrN( (3-qk_code(2,2))/2, qk_code(2,1) )!(3-1)/2 = 1, (3+1)/2 = 2
m1 = arrMass(qk_code(1,1)); m2 = arrMass(qk_code(2,1))
m3 = arrMass(qk_code(3,1)); m4 = arrMass(qk_code(4,1))
mu1 = arrMu(qk_code(1,1))*dble(qk_code(1,2))
mu2 = arrMu(qk_code(2,1))*dble(qk_code(2,2))
s_up = min( ( sqrt(m1**2+lambda**2) + sqrt(m2**2+lambda**2) )**2, &
            ( sqrt(m3**2+lambda**2) + sqrt(m4**2+lambda**2) )**2 )
s_bo = max( (m1+m2)**2, (m3+m4)**2 )*( 1d0 + 1d-3 )
!***********************************************************************
h = (s_up-s_bo) / (nn-1)
s_cmk(:) = arth(s_bo, h, nn)!���ɵȲ�����
do k = 1 , nn
    sig(k) = tint(s_cmk(k), qk_code(:,:))
    !print*, k, s_cmk(k), sig(k)
    if(.not.(sig(k) > 0d0))then
        print*,"sig.lt.0d0", k, sig(k)
        !pause
    end if
    
!print*, k, s_cmk(k), sig(k)
end do
!***********************************************************************
do i = 1, npoint_rex
    E1(i) = sqrt(yp(i)**2 + m1**2); f1(i) = fd(E1(i),mu1,T,phi1,phi2)
    E2(i) = sqrt(yp(i)**2 + m2**2); f2(i) = fd(E2(i),mu2,T,phi1,phi2)
end do
!do i = 1, npoint_rex
!    print*,"E1", E1(i)
!    print*, "E2", E2(i)
!    print*, "f", f1(i)
!end do
!***********************************************************************
w_ij = 0d0
do i = 1, npoint_rex
    do j = 1 , npoint_rex
        do k = 1 , npoint_rex
            angel = ypi(k)
            s_cm = m1**2 + m2**2 + 2*E1(i)*E2(j) - 2*yp(i)*yp(j)*cos(angel)
            if (s_cm > s_bo .and. s_cm < s_up) then
                s_rt = sqrt(s_cm)
                E11 = (s_cm + m1**2 - m2**2) / (2d0*s_rt)
                E22 = (s_cm - m1**2 + m2**2) / (2d0*s_rt)
                p11 = sqrt((s_cm-(m1 + m2)**2)*(s_cm-(m1-m2)**2)) / (2d0*s_rt)
                p22 = -p11
                v_rel = sqrt((E11*E22-p11*p22)**2-(m1*m2)**2) / (E11*E22)
                if(v_rel > 2d0 .or. v_rel < 0d0)then
                    call nrerror("v_rel>c in averaged_rate")
                end if
                i0 = floor((s_cm-s_bo)/h) + 1
                inc = (sig(i0+1)-sig(i0)) / (s_cmk(i0+1)-s_cmk(i0))
                sig_ij = inc*(s_cm-s_cmk(i0)) + sig(i0)
				w_ij = w_ij + wp(i)*wp(j)*wpi(k)* yp(i)**2 * yp(j)**2 * sin(angel) * f1(i)*f2(j)*sig_ij*v_rel
            !else
            !    pause "s_cm is not between s_bo and s_up"
            end if
        end do
    end do
end do
!print*, "w_ij0", w_ij
w_ij_n = N_c**2/(2d0*pi**4)*w_ij
w_ij = w_ij_n/(n1*n2)
end subroutine averaged_rate!(qk_code, w_ij, w_ij_n, sig_bar)