subroutine fdjac(x, fvec, df, funcv)
	use nrtype, only: dp
    use nrutil, only: assert_eq
	implicit none
	real(dp), dimension(:):: x
    real(dp), dimension(:), intent(in):: fvec
    real(dp), dimension(:,:), intent(out):: df
    interface
        function funcv(x)
            use nrtype, only: dp
            implicit none
            real(dp), dimension(:), intent(in):: x
            real(dp), dimension(size(x)):: funcv
        end function funcv
    end interface
!***********************************************************************
    real(dp), parameter:: EPS = 1d-4
	integer:: n, j
	real(dp), dimension(size(x)):: h, xsav, xph, f
!***********************************************************************
    n = assert_eq(size(x),size(fvec),size(df,1),size(df,2),'fdjac')
    xsav = x
    h = eps * abs(xsav)
    where ( abs(h) < 1d-15 ) h = eps
    xph = xsav + h
    h = xph - xsav	            !>Trick to reduce finite precision error
	do j = 1, n
		x(j) = xph(j)
        f(1:n) = funcv(x)
		df(:,j) = (f(:)-fvec(:)) / h(j)		!>Forward difference formula
		x(j) = xsav(j)
	end do
end 