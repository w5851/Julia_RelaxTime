!>B=B-B+B-B
subroutine B0SUM(k0, k, m1, m2, mu1, mu2, B0_re, B0_im)
    use nrtype, only: dp
    use meson_function, only: BPM
    implicit none
!***********************************************************************
    real(dp), intent(in):: k0, k, m1, m2, mu1, mu2
    real(dp), intent(out):: B0_re, B0_im
!***********************************************************************
    real(dp):: lam
    real(dp):: Bp1_Re, Bp1_im, Bm1_Re, Bm1_im
    real(dp):: Bp2_Re, Bp2_im, Bm2_Re, Bm2_im
!***********************************************************************
    lam = k0 + mu1 - mu2
    call BPM(-lam, k, m1, m2, mu1, 1d0, Bp1_Re, Bp1_im)
    call BPM(lam, k, m1, m2, mu1, -1d0, Bm1_Re, Bm1_im)
    call BPM(lam, k, m2, m1, mu2, 1d0, Bp2_Re, Bp2_im)
    call BPM(-lam, k, m2, m1, mu2, -1d0, Bm2_Re, Bm2_im)
    B0_re = Bp1_Re - Bm1_Re + Bp2_Re - Bm2_Re
    B0_im = Bp1_im - Bm1_im + Bp2_im - Bm2_im
end subroutine B0SUM!(k0,k,m1,m2,mu1,mu2)