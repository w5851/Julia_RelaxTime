$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$studyWorkspace = 'D:\CodexCompute\Julia_RelaxTime\full-rs-joint-representatives-20261025-v1'
$studySource = 'D:\CodexCompute\Julia_RelaxTime\full-rs-transport-validation-20261025-v1'
$studyProject = Join-Path $studySource 'project'
$studyRuntime = 'D:\CodexCompute\Julia_RelaxTime\transport-preflight-20261023-v1\runtime\julia-1.12.5\bin\julia.exe'
$studyStart = [DateTime]::UtcNow
$studyStage = 'verify_source'
function Write-StudyStatus([bool]$finished, [object]$exitCode, [string]$message = '') {
    [ordered]@{host=$env:COMPUTERNAME; stage=$script:studyStage; finished=$finished; exit_code=$exitCode;
        error=$message; started_utc=$studyStart.ToString('o'); updated_utc=[DateTime]::UtcNow.ToString('o')} |
        ConvertTo-Json | Set-Content -LiteralPath (Join-Path $studyWorkspace 'remote_status.json') -Encoding UTF8
    Write-Output $script:studyStage
}
function Test-StudySource {
    foreach ($entry in $studyManifest.source_files.PSObject.Properties) {
        $hash = (Get-FileHash -LiteralPath (Join-Path $studyProject $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $entry.Value) { throw "Source identity mismatch: $($entry.Name)" }
    }
    foreach ($entry in $studyManifest.input_files.PSObject.Properties) {
        $hash = (Get-FileHash -LiteralPath (Join-Path $studySource ('inputs\' + $entry.Name)) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $entry.Value) { throw "Input identity mismatch: $($entry.Name)" }
    }
}
try {
    Write-StudyStatus $false $null
    if ($env:COMPUTERNAME -ne 'W') { throw 'Unexpected remote host' }
    if (@(Get-Process -Name julia -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Another Julia process is running' }
    $studyManifestPath = Join-Path $studySource 'package_manifest.json'
    $studyManifest = Get-Content -LiteralPath $studyManifestPath -Raw | ConvertFrom-Json
    if ($studyManifest.zip_sha256 -ne '533bbc8dcb13681a3873d6b9e94f5734772311f5f52575ae12f9bbaf6955448a') { throw 'Unexpected source package' }
    Test-StudySource
    $env:JULIA_NUM_THREADS = '1'
    $env:OPENBLAS_NUM_THREADS = '1'
    $env:JULIA_NUM_PRECOMPILE_TASKS = '1'
    $env:JULIA_PKG_PRECOMPILE_AUTO = '0'
    $env:THRESHOLD_SOURCE_MANIFEST = $studyManifestPath
    $studyArguments = @('--startup-file=no', '--threads=1', "--project=$studyProject", '--heap-size-hint=1200M',
        (Join-Path $studyProject 'scripts\analysis\relaxtime\run_transport_joint_validation.jl'),
        (Join-Path $studySource 'inputs'), (Join-Path $studyWorkspace 'results'), 'representatives', '0', '1',
        (Join-Path $studySource 'joint_pilot'), '48')
    [ordered]@{executable=$studyRuntime; arguments=$studyArguments; working_directory=$studyProject;
        source_manifest=$studyManifestPath; reused_pilot=(Join-Path $studySource 'joint_pilot'); numerical_threads=1;
        blas_threads=1; source_archive_sha256=$studyManifest.zip_sha256} | ConvertTo-Json -Depth 4 |
        Set-Content -LiteralPath (Join-Path $studyWorkspace 'execution.json') -Encoding UTF8
    $studyStage = 'joint_representatives_p48'
    Write-StudyStatus $false $null
    $studyProcess = Start-Process -FilePath $studyRuntime -ArgumentList $studyArguments `
      -WorkingDirectory $studyProject -WindowStyle Hidden -Wait -PassThru `
      -RedirectStandardOutput (Join-Path $studyWorkspace 'study.stdout.log') `
      -RedirectStandardError (Join-Path $studyWorkspace 'study.stderr.log')
    Test-StudySource
    $studyResult = Get-Content -LiteralPath (Join-Path $studyWorkspace 'results\status.json') -Raw | ConvertFrom-Json
    [ordered]@{host=$env:COMPUTERNAME; runtime_version='1.12.5'; threads=1;
        source_archive_sha256=$studyManifest.zip_sha256; source_files_verified=$studyManifest.files;
        source_verified_before_and_after=$true; process_exit_code=$studyProcess.ExitCode;
        joint_target_passed=$studyResult.joint_target_passed; points=$studyResult.points;
        comparisons=$studyResult.comparisons; elapsed_seconds=([DateTime]::UtcNow-$studyStart).TotalSeconds;
        full_qualification=$false} | ConvertTo-Json |
        Set-Content -LiteralPath (Join-Path $studyWorkspace 'verification.json') -Encoding UTF8
    if ($studyProcess.ExitCode -ne 0 -or -not $studyResult.joint_target_passed) { throw 'Representative joint validation did not pass' }
    $studyStage = 'complete'
    Write-StudyStatus $true 0
    exit 0
} catch {
    Write-StudyStatus $true 1 $_.Exception.Message
    exit 1
}
