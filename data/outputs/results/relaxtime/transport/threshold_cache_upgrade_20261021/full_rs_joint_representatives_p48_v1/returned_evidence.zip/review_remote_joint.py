"""Review the completed full-RS pilot and representatives on quote-remote."""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import math
import shutil
import zipfile

SOURCE = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-transport-validation-20261025-v1')
WORK = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-joint-representatives-20261025-v1')
LAYER = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-layer-validation-20261025-v1')

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

package = read_json(SOURCE / 'package_manifest.json')
assert package['zip_sha256'] == '533bbc8dcb13681a3873d6b9e94f5734772311f5f52575ae12f9bbaf6955448a'
assert digest(SOURCE / 'source.zip') == package['zip_sha256']
for relative, expected in package['source_files'].items():
    assert digest(SOURCE / 'project' / relative) == expected, relative
verification = read_json(WORK / 'verification.json')
assert verification['source_verified_before_and_after'] and verification['process_exit_code'] == 0
runs = [SOURCE / 'joint_pilot', WORK / 'results']
snapshot_count = rate_count = 0
point_ids = set()
for run in runs:
    manifest = read_json(run / 'manifest.json')
    status = read_json(run / 'status.json')
    assert status['complete'] and status['joint_target_passed'] and status['failures'] == 0
    assert manifest['julia'] == '1.12.5'
    assert manifest['head'] is None and manifest['source_archive']['calculation_commit'] is None
    assert manifest['source_archive']['sha256'] == package['zip_sha256']
    assert manifest['parameters']['configurations']['candidate']['p'] == 48
    assert manifest['parameters']['physical_conventions'].startswith('full-RS A in polarization and couplings;')
    for entry in manifest['source_files']:
        relative = entry['path'].replace('\\', '/')
        assert digest(run / 'source' / relative) == entry['sha256'] == package['source_files'][relative]
        snapshot_count += 1
    for name in ('review_points.csv', 'channel_plan.csv'):
        assert digest(run / 'inputs' / name) == package['input_files'][name]
    rates = rows(run / 'rates.csv')
    observables = rows(run / 'observables.csv')
    points = {r['point_id'] for r in observables}
    assert not points.intersection(point_ids)
    point_ids.update(points)
    for point in points:
        for configuration, budget in (('candidate', 1e-3), ('reference', 2e-4)):
            selected = [r for r in rates if r['point_id'] == point and r['configuration'] == configuration]
            assert len(selected) == len({r['channel'] for r in selected}) == 17
            for row in selected:
                value = float(row['rate'])
                assert math.isfinite(value) and value > 0
                allowance = 1e-12 / value if configuration == 'candidate' else 0.0
                assert 0 <= float(row['estimated_or_reference_l1']) <= budget + allowance
            obs = [r for r in observables if r['point_id'] == point and r['configuration'] == configuration]
            assert len(obs) == 1 and 0 <= float(obs[0]['density_relative_error']) <= 1e-3
    rate_count += len(rates)
assert len(point_ids) == 12 and rate_count == 408
module_path = SOURCE / 'project/scripts/analysis/relaxtime/summarize_transport_joint_validation.py'
spec = importlib.util.spec_from_file_location('joint_summary', module_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
summary = module.summarize(runs, WORK / 'joint_summary', 12, None)
assert summary['joint_target_passed'] and summary['comparisons'] == 108
review = dict(host='W', points=12, comparisons=108, channel_rate_rows=rate_count,
              channels_per_point=17, joint_target_passed=True,
              maximum_absolute_relative_change=max(abs(r['relative_change']) for r in summary['point_maxima']),
              source_archive_sha256=package['zip_sha256'], source_files_verified=package['files'],
              source_snapshots_verified=snapshot_count, calculation_commit=None,
              independent_layers_pending=True, production_replay_pending=True,
              full_qualification=False)
(WORK / 'reviewed_result.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8')
shutil.copytree(WORK / 'joint_summary', LAYER / 'joint_complete_summary_v1')
archive = WORK / 'returned_evidence.zip'
assert not archive.exists()
files = []
for directory in ('results', 'joint_summary'):
    files.extend(p for p in (WORK / directory).rglob('*') if p.is_file())
files.extend(p for p in WORK.iterdir() if p.is_file() and p.suffix in ('.json', '.log', '.ps1', '.py'))
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path in sorted(set(files)):
        output.write(path, path.relative_to(WORK).as_posix())
archive_info = dict(sha256=digest(archive), bytes=archive.stat().st_size,
                    remote_archive=str(archive), files=len(set(files)))
(WORK / 'returned_archive_manifest.json').write_text(json.dumps(archive_info, indent=2) + '\n', encoding='utf-8')
print(json.dumps(review, indent=2))
print(json.dumps(archive_info, indent=2))
