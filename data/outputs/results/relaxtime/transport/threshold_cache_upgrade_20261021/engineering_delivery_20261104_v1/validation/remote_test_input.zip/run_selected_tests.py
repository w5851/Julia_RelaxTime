from pathlib import Path
import unittest,json,hashlib,time,sys
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
contract=json.loads((root/'test_contract.json').read_text(encoding='utf-8'))
def hashes():
 return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in contract['files']}
before=hashes()
assert before==contract['files']
suite=unittest.TestSuite()
for name in contract['tests']:
 suite.addTests(unittest.defaultTestLoader.discover(str(root/'tests/unit/python'),pattern=Path(name).name))
start=time.time()
with (root/'test_output.log').open('w',encoding='utf-8') as out:
 result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
after=hashes()
record=dict(host='quote-remote',tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),seconds=time.time()-start,source_files=len(before),source_all_match=before==after,passed=result.wasSuccessful(),scope='synthetic derivative/decomposition tests and disposable I/O/controller fixtures; no production calculations')
(root/'review.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record),flush=True)
sys.exit(0 if result.wasSuccessful() and before==after else 1)
