$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$productionWorkspace = 'D:\CodexCompute\Julia_RelaxTime\full-rs-baseline-acceptance-20261025-v1'
$productionSource = 'D:\CodexCompute\Julia_RelaxTime\full-rs-baseline-acceptance-20261025-v1'
$productionProject = Join-Path $productionSource 'project'
$productionRuntime = 'D:\CodexCompute\Julia_RelaxTime\transport-preflight-20261023-v1\runtime\julia-1.12.5\bin\julia.exe'
$productionStart = [DateTime]::UtcNow
$productionStage = 'verify_qualification'
$productionRuns = @()
function Write-ProductionStatus([bool]$finished, [object]$exitCode, [string]$message = '') {
    [ordered]@{host=$env:COMPUTERNAME; stage=$script:productionStage; finished=$finished;
        exit_code=$exitCode; error=$message; started_utc=$productionStart.ToString('o');
        updated_utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json |
        Set-Content -LiteralPath (Join-Path $productionWorkspace 'remote_status.json') -Encoding UTF8
    [Console]::WriteLine($script:productionStage)
}
function Test-ProductionSource {
    foreach ($entry in $productionManifest.source_files.PSObject.Properties) {
        $hash = (Get-FileHash -LiteralPath (Join-Path $productionProject $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $entry.Value) { throw "Source identity mismatch: $($entry.Name)" }
    }
    foreach ($entry in $productionManifest.input_files.PSObject.Properties) {
        $hash = (Get-FileHash -LiteralPath (Join-Path $productionSource ('inputs\'+$entry.Name)) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $entry.Value) { throw "Input identity mismatch: $($entry.Name)" }
    }
}
function Invoke-ProductionStage([string]$name, [string[]]$scriptArguments, [string]$statusFile) {
    $script:productionStage = $name
    Write-ProductionStatus $false $null
    $started = [DateTime]::UtcNow
    $arguments = @('--startup-file=no','--threads=1',"--project=$productionProject",'--heap-size-hint=1200M') + $scriptArguments
    $process = Start-Process -FilePath $productionRuntime -ArgumentList $arguments `
      -WorkingDirectory $productionProject -WindowStyle Hidden -Wait -PassThru `
      -RedirectStandardOutput (Join-Path $productionWorkspace ($name+'.stdout.log')) `
      -RedirectStandardError (Join-Path $productionWorkspace ($name+'.stderr.log'))
    Test-ProductionSource
    $result = if (Test-Path -LiteralPath $statusFile) { Get-Content -LiteralPath $statusFile -Raw | ConvertFrom-Json } else { $null }
    $script:productionRuns += [ordered]@{stage=$name; process_exit_code=$process.ExitCode; arguments=$arguments;
        result=$result; elapsed_seconds=([DateTime]::UtcNow-$started).TotalSeconds}
    [ordered]@{host=$env:COMPUTERNAME; runtime_version='1.12.5'; threads=1;
        source_archive_sha256=$productionManifest.zip_sha256; source_files_verified=$productionManifest.files;
        source_verified_before_and_after=$true; stages=$script:productionRuns; formal_production_promoted=$false} |
        ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $productionWorkspace 'verification.json') -Encoding UTF8
    if ($process.ExitCode -ne 0) { throw "Stage $name failed with exit code $($process.ExitCode)" }
    return $result
}
try {
    Write-ProductionStatus $false $null
    if ($env:COMPUTERNAME -ne 'W') { throw 'Unexpected remote host' }
    if (@(Get-Process -Name julia -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Another Julia process is running' }
    $productionManifestPath = Join-Path $productionSource 'package_manifest.json'
    $productionManifest = Get-Content -LiteralPath $productionManifestPath -Raw | ConvertFrom-Json
    $archive = Join-Path $productionSource 'source.zip'
    if ($productionManifest.zip_sha256 -ne 'a9015d74e1ed7928392c949b6370efbe635084a0876e71d090c6e619f153b031' -or (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'a9015d74e1ed7928392c949b6370efbe635084a0876e71d090c6e619f153b031') { throw 'Unexpected source archive' }
    if (Test-Path -LiteralPath $productionProject) { throw 'Acceptance source directory already exists' }
    Expand-Archive -LiteralPath $archive -DestinationPath $productionProject
    $inputArchive = Join-Path $productionSource 'inputs.zip'
    if ((Get-FileHash -LiteralPath $inputArchive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $productionManifest.inputs_zip_sha256) { throw 'Inputs archive changed' }
    Expand-Archive -LiteralPath $inputArchive -DestinationPath (Join-Path $productionSource 'inputs')
    Test-ProductionSource
    $env:JULIA_NUM_THREADS = '1'
    $env:OPENBLAS_NUM_THREADS = '1'
    $env:JULIA_PKG_PRECOMPILE_AUTO = '0'
    $env:THRESHOLD_SOURCE_MANIFEST = $productionManifestPath
    $null = Invoke-ProductionStage 'replay_identity_unit' @(
        (Join-Path $productionProject 'tests\unit\relaxtime\test_transport_replay_identity.jl')
    ) (Join-Path $productionWorkspace 'replay_identity_unit_result.json')
    $env:TRANSPORT_REGRESSION_REPLAY_DIR = 'D:\CodexCompute\Julia_RelaxTime\full-rs-production-replay-20261025-v3\production_replay'
    $null = Invoke-ProductionStage 'regression' @(
        (Join-Path $productionProject 'tests\regression\relaxtime\test_phase_guided_transport_mode_b_full_regression.jl')
    ) (Join-Path $productionWorkspace 'regression_result.json')
    $env:TRANSPORT_REGRESSION_REPLAY_DIR = ''
    $timing = Invoke-ProductionStage 'default_timing' @(
        (Join-Path $productionProject 'benchmark\relaxtime\benchmark_transport_production_entrypoint.jl'),
        (Join-Path $productionSource 'inputs'), (Join-Path $productionWorkspace 'default_repeat_timing'),
        (Join-Path $productionProject 'tests\baselines\relaxtime\baseline_thermal_weighted_transport_v3.csv'), '2'
    ) (Join-Path $productionWorkspace 'default_repeat_timing\status.json')
    if (-not $timing.default_entrypoint_passed -or $timing.measurements -ne 4 -or $timing.warmups -ne 1 -or $timing.comparisons -ne 45) { throw 'Default repeat and timing checks failed' }
    $productionStage = 'complete'
    Write-ProductionStatus $true 0
    exit 0
} catch {
    Write-ProductionStatus $true 1 $_.Exception.Message
    exit 1
}
