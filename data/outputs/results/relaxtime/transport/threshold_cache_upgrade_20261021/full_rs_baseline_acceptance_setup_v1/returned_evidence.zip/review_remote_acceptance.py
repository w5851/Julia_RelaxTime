"""Review strict v3 regression and five actual default-entrypoint artifacts."""
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import statistics
import zipfile

WORK = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-baseline-acceptance-20261025-v1')
PROJECT = WORK / 'project'
RUN = WORK / 'default_repeat_timing'

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(line for line in stream if line.strip() and not line.startswith('#')))

def helper(relative, name):
    spec = importlib.util.spec_from_file_location(name, PROJECT / relative)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

package = read_json(WORK / 'package_manifest.json')
assert digest(WORK / 'source.zip') == package['zip_sha256']
for relative, checksum in package['source_files'].items():
    assert digest(PROJECT / relative) == checksum, relative
verification = read_json(WORK / 'verification.json')
assert verification['source_verified_before_and_after'] and len(verification['stages']) == 3
assert {r['stage'] for r in verification['stages']} == {'replay_identity_unit', 'regression', 'default_timing'}
assert all(r['process_exit_code'] == 0 for r in verification['stages'])
identity_log = (WORK / 'replay_identity_unit.stdout.log').read_text(encoding='utf-8-sig')
assert re.search(r'\|\s+13\s+13\s', identity_log), 'missing replay identity assertion summary'
test_log = (WORK / 'regression.stdout.log').read_text(encoding='utf-8-sig')
assert re.search(r'\|\s+314\s+314\s', test_log), 'missing full regression assertion summary'
baseline_path = PROJECT / 'tests/baselines/relaxtime/baseline_thermal_weighted_transport_v3.csv'
metadata = read_json(baseline_path.with_suffix('.json'))
assert metadata['baseline_sha256'] == package['baseline_sha256'] == digest(baseline_path)
assert metadata['regression_rtol'] == 1e-6 and metadata['regression_atol'] == 1e-8
targets = {(r['point_id'], r['observable']): r for r in rows(baseline_path)}
assert len(targets) == 108
inputs = helper('scripts/analysis/relaxtime/prepare_transport_production_inputs.py', 'inputs')
artifacts = helper('scripts/relaxtime/check_transport_production_artifact.py', 'artifacts')
baseline = helper('scripts/dev/export_thermal_weighted_transport_baseline.py', 'baseline')
manifest = read_json(RUN / 'manifest.json')
inputs.verified_sources(RUN, manifest, PROJECT.resolve())
commit, identity = baseline.replay_artifact_commit(RUN, manifest)
assert commit == 'unknown' and identity['sha256'] == package['zip_sha256']
assert manifest['parameters']['baseline_sha256'] == metadata['baseline_sha256']
status = read_json(RUN / 'status.json')
assert status['complete'] and status['default_entrypoint_passed'] and status['failures'] == 0
assert (status['measurements'], status['warmups'], status['comparisons']) == (4, 1, 45)
timings, comparisons = rows(RUN / 'timings.csv'), rows(RUN / 'comparisons.csv')
points = manifest['parameters']['points']
assert len(points) == 2 and manifest['parameters']['repeats'] == 2
keys = {(point, repeat, 'measurement') for point in points for repeat in (1, 2)} | {(points[0], 0, 'warmup')}
assert len(timings) == 5 and {(r['point_id'], int(r['repeat']), r['role']) for r in timings} == keys
assert len(comparisons) == 45 and len({(r['point_id'], r['repeat'], r['role'], r['observable']) for r in comparisons}) == 45
profile = PROJECT / 'config/models/pnjl/transport_sampling/thermal_weighted_v1.toml'
for timing in timings:
    key = timing['point_id'], int(timing['repeat']), timing['role']
    assert all(math.isfinite(float(timing[name])) and float(timing[name]) > 0 for name in ('total_seconds', 'cpu_seconds'))
    folder = RUN / 'points' / f'{key[0]}_{key[2]}_{key[1]}'
    checked = artifacts.check_artifact(folder, profile, commit, 'production', PROJECT)
    assert checked['completed_points'] == 1 and checked['qualified_channels'] == 17
    actual_rows = rows(folder / 'phase_guided_transport_scan.csv')
    assert len(actual_rows) == 1
    actual = actual_rows[0]
    selected = [r for r in comparisons if (r['point_id'], int(r['repeat']), r['role']) == key]
    assert len(selected) == 9 and {r['observable'] for r in selected} == set(artifacts.OBSERVABLES)
    for row in selected:
        target = targets[row['point_id'], row['observable']]
        value, expected, reference = (float(row[k]) for k in ('actual', 'baseline', 'reference'))
        assert expected == float(target['candidate']) and reference == float(target['reference'])
        assert value == float(actual[row['observable']]) and row['passed'] == 'true'
        assert math.isclose(value, expected, rel_tol=1e-6, abs_tol=1e-8) and abs(value/reference-1) <= 0.01
        assert math.isclose(value/expected-1, float(row['baseline_relative_change']), rel_tol=1e-10, abs_tol=1e-14)
        assert math.isclose(value/reference-1, float(row['reference_relative_change']), rel_tol=1e-10, abs_tol=1e-14)
steady = []
for point in points:
    values = [r for r in timings if r['point_id'] == point and r['role'] == 'measurement']
    steady.append(dict(point_id=point, repeats=2,
                       median_wall_seconds=statistics.median(float(r['total_seconds']) for r in values),
                       median_cpu_seconds=statistics.median(float(r['cpu_seconds']) for r in values)))
review = dict(host='W', baseline='baseline_thermal_weighted_transport_v3', baseline_sha256=metadata['baseline_sha256'],
              source_archive_sha256=package['zip_sha256'], source_files_verified=package['files'],
              source_snapshots_verified=len(manifest['source_files']), regression_assertions_passed=314,
              replay_identity_assertions_passed=13,
              default_entrypoint_passed=True, actual_runs=5, steady_measurements=4, warmups=1,
              observable_comparisons=45, qualified_channels=85, steady_timings=steady,
              maximum_baseline_relative_change=max(abs(float(r['baseline_relative_change'])) for r in comparisons),
              maximum_independent_reference_relative=max(abs(float(r['reference_relative_change'])) for r in comparisons),
              calculation_commit=None, runner_cost_qualified=False, formal_production_promoted=False)
(WORK / 'reviewed_result.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8')
archive = WORK / 'returned_evidence.zip'
assert not archive.exists()
files = [p for p in RUN.rglob('*') if p.is_file()]
files.extend(p for p in WORK.iterdir() if p.is_file() and p.suffix in ('.json', '.log', '.ps1', '.py'))
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path in sorted(set(files)):
        output.write(path, path.relative_to(WORK).as_posix())
info = dict(sha256=digest(archive), bytes=archive.stat().st_size, files=len(set(files)))
(WORK / 'returned_archive_manifest.json').write_text(json.dumps(info, indent=2) + '\n', encoding='utf-8')
print(json.dumps(review, indent=2))
print(json.dumps(info, indent=2))
