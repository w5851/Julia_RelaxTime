$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$validationWorkspace = 'D:\CodexCompute\Julia_RelaxTime\full-rs-transport-validation-20261025-v1'
$validationProject = Join-Path $validationWorkspace 'project'
$validationInputs = Join-Path $validationWorkspace 'inputs'
$validationRuntime = 'D:\CodexCompute\Julia_RelaxTime\transport-preflight-20261023-v1\runtime\julia-1.12.5\bin\julia.exe'
$validationStart = [DateTime]::UtcNow
$validationStage = 'verify_package'
$validationStatus = Join-Path $validationWorkspace 'remote_status.json'
function Write-ValidationStatus([bool]$finished, [object]$exitCode, [string]$message = '') {
    [ordered]@{host=$env:COMPUTERNAME; stage=$script:validationStage; finished=$finished;
        exit_code=$exitCode; error=$message; started_utc=$validationStart.ToString('o');
        updated_utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json |
        Set-Content -LiteralPath $validationStatus -Encoding UTF8
    Write-Host $script:validationStage
}
function Test-ValidationFiles {
    foreach ($entry in $validationManifest.source_files.PSObject.Properties) {
        $actual = (Get-FileHash -LiteralPath (Join-Path $validationProject $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne $entry.Value) { throw "Source identity mismatch: $($entry.Name)" }
    }
    foreach ($entry in $validationManifest.input_files.PSObject.Properties) {
        $actual = (Get-FileHash -LiteralPath (Join-Path $validationInputs $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne $entry.Value) { throw "Input identity mismatch: $($entry.Name)" }
    }
}
try {
    Write-ValidationStatus $false $null
    if ($env:COMPUTERNAME -ne 'W') { throw 'Unexpected remote host' }
    if (@(Get-Process -Name julia -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Another Julia process is running' }
    $validationManifestPath = Join-Path $validationWorkspace 'package_manifest.json'
    $validationManifest = Get-Content -LiteralPath $validationManifestPath -Raw | ConvertFrom-Json
    foreach ($item in @(@('source.zip',$validationManifest.zip_sha256),@('inputs.zip',$validationManifest.inputs_zip_sha256),@('run_remote_validation.ps1',$validationManifest.runner_sha256))) {
        $actual = (Get-FileHash -LiteralPath (Join-Path $validationWorkspace $item[0]) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne $item[1]) { throw "Package identity mismatch: $($item[0])" }
    }
    if (Test-Path -LiteralPath $validationProject) { throw 'Source directory already exists; refusing to replace it' }
    if (Test-Path -LiteralPath $validationInputs) { throw 'Input directory already exists; refusing to replace it' }
    Expand-Archive -LiteralPath (Join-Path $validationWorkspace 'source.zip') -DestinationPath $validationProject
    Expand-Archive -LiteralPath (Join-Path $validationWorkspace 'inputs.zip') -DestinationPath $validationInputs
    Test-ValidationFiles
    $env:JULIA_NUM_THREADS = '1'
    $env:OPENBLAS_NUM_THREADS = '1'
    $env:JULIA_NUM_PRECOMPILE_TASKS = '1'
    $env:JULIA_PKG_PRECOMPILE_AUTO = '0'
    $env:UNIT_PROFILE = 'core'
    $env:UNIT_FILES = 'relaxtime/test_threshold_run_provenance.jl'
    $validationStage = 'provenance_tests'
    Write-ValidationStatus $false $null
    $testProcess = Start-Process -FilePath $validationRuntime -ArgumentList @(
        '--startup-file=no', '--threads=1', "--project=$validationProject", '--heap-size-hint=1200M',
        (Join-Path $validationProject 'tests\unit\runtests.jl')
    ) -WorkingDirectory $validationProject -WindowStyle Hidden -Wait -PassThru `
      -RedirectStandardOutput (Join-Path $validationWorkspace 'unit.stdout.log') `
      -RedirectStandardError (Join-Path $validationWorkspace 'unit.stderr.log')
    if ($testProcess.ExitCode -ne 0) { throw "Provenance tests failed with exit code $($testProcess.ExitCode)" }
    Test-ValidationFiles
    $env:THRESHOLD_SOURCE_MANIFEST = $validationManifestPath
    $validationStage = 'joint_pilot_p48'
    Write-ValidationStatus $false $null
    $validationArguments = @('--startup-file=no', '--threads=1', "--project=$validationProject", '--heap-size-hint=1200M',
        (Join-Path $validationProject 'scripts\analysis\relaxtime\run_transport_joint_validation.jl'),
        $validationInputs, (Join-Path $validationWorkspace 'joint_pilot'), 'pilot', '0', '1', '-', '48')
    [ordered]@{executable=$validationRuntime; arguments=$validationArguments; working_directory=$validationProject;
        source_manifest=$validationManifestPath; numerical_threads=1; blas_threads=1} | ConvertTo-Json -Depth 4 |
        Set-Content -LiteralPath (Join-Path $validationWorkspace 'execution.json') -Encoding UTF8
    $pilotProcess = Start-Process -FilePath $validationRuntime -ArgumentList $validationArguments `
      -WorkingDirectory $validationProject -WindowStyle Hidden -Wait -PassThru `
      -RedirectStandardOutput (Join-Path $validationWorkspace 'pilot.stdout.log') `
      -RedirectStandardError (Join-Path $validationWorkspace 'pilot.stderr.log')
    Test-ValidationFiles
    $pilotStatus = Get-Content -LiteralPath (Join-Path $validationWorkspace 'joint_pilot\status.json') -Raw | ConvertFrom-Json
    [ordered]@{host=$env:COMPUTERNAME; runtime_version='1.12.5'; threads=1;
        source_archive_sha256=$validationManifest.zip_sha256; source_files_verified=$validationManifest.files;
        source_verified_before_and_after=$true; input_files_verified=$validationManifest.input_files;
        test_process_exit_code=$testProcess.ExitCode; pilot_process_exit_code=$pilotProcess.ExitCode;
        joint_target_passed=$pilotStatus.joint_target_passed;
        elapsed_seconds=([DateTime]::UtcNow-$validationStart).TotalSeconds; full_qualification=$false} |
        ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $validationWorkspace 'verification.json') -Encoding UTF8
    if ($pilotProcess.ExitCode -ne 0 -or -not $pilotStatus.joint_target_passed) { throw 'Joint pilot did not pass; inspect retained logs and failures' }
    $validationStage = 'complete'
    Write-ValidationStatus $true 0
    exit 0
} catch {
    Write-ValidationStatus $true 1 $_.Exception.Message
    exit 1
}
