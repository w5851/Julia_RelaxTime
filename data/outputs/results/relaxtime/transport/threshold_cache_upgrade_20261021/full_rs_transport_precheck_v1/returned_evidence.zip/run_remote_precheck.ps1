$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$precheckWorkspace = 'D:\CodexCompute\Julia_RelaxTime\full-rs-transport-precheck-20261025-v1'
$precheckSource = 'D:\CodexCompute\Julia_RelaxTime\full-rs-a-reduction-20261025-v2'
$precheckProject = Join-Path $precheckSource 'project'
$precheckRuntime = 'D:\CodexCompute\Julia_RelaxTime\transport-preflight-20261023-v1\runtime\julia-1.12.5\bin\julia.exe'
$precheckStart = [DateTime]::UtcNow
$precheckStage = 'verify_source'
$precheckStatus = Join-Path $precheckWorkspace 'remote_status.json'

function Write-PrecheckStatus([bool]$finished, [object]$exitCode, [string]$message = '') {
    [ordered]@{host=$env:COMPUTERNAME; stage=$script:precheckStage; finished=$finished;
        exit_code=$exitCode; error=$message; started_utc=$precheckStart.ToString('o');
        updated_utc=[DateTime]::UtcNow.ToString('o')} |
        ConvertTo-Json | Set-Content -LiteralPath $precheckStatus -Encoding UTF8
}

function Test-PrecheckSource {
    foreach ($entry in $precheckManifest.source_files.PSObject.Properties) {
        $actual = (Get-FileHash -LiteralPath (Join-Path $precheckProject $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne $entry.Value) { throw "Source identity mismatch: $($entry.Name)" }
    }
}

try {
    Write-PrecheckStatus $false $null
    if ($env:COMPUTERNAME -ne 'W') { throw 'Unexpected remote host' }
    if (@(Get-Process -Name julia -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Another Julia process is running' }
    $precheckManifest = Get-Content -LiteralPath (Join-Path $precheckSource 'package_manifest.json') -Raw | ConvertFrom-Json
    if ($precheckManifest.zip_sha256 -ne 'cbbe5ac6653c5d71ab3f619d773e5d65f69ce3ec6cd93dac422579a9675f01ae') {
        throw 'Unexpected frozen source package'
    }
    Test-PrecheckSource
    $env:JULIA_NUM_THREADS = '1'
    $env:OPENBLAS_NUM_THREADS = '1'
    $env:JULIA_NUM_PRECOMPILE_TASKS = '1'
    $env:JULIA_PKG_PRECOMPILE_AUTO = '0'
    $env:UNIT_PROFILE = 'core'
    $env:UNIT_FILES = 'models/test_transport_sampling_profiles.jl;relaxtime/test_thermal_weighted_cache.jl;relaxtime/test_thermal_optimization_native.jl'
    $precheckStage = 'selected_unit_tests'
    Write-PrecheckStatus $false $null
    $precheckProcess = Start-Process -FilePath $precheckRuntime -ArgumentList @(
        '--startup-file=no', '--threads=1', "--project=$precheckProject", '--heap-size-hint=1200M',
        (Join-Path $precheckProject 'tests\unit\runtests.jl')
    ) -WorkingDirectory $precheckProject -WindowStyle Hidden -Wait -PassThru `
      -RedirectStandardOutput (Join-Path $precheckWorkspace 'unit.stdout.log') `
      -RedirectStandardError (Join-Path $precheckWorkspace 'unit.stderr.log')
    Test-PrecheckSource
    [ordered]@{host=$env:COMPUTERNAME; runtime_version='1.12.5'; threads=1;
        source_archive_sha256=$precheckManifest.zip_sha256; source_files_verified=$precheckManifest.files;
        source_verified_before_and_after=$true; selected_files=$env:UNIT_FILES;
        process_exit_code=$precheckProcess.ExitCode;
        elapsed_seconds=([DateTime]::UtcNow-$precheckStart).TotalSeconds;
        production_convergence_claim=$false} | ConvertTo-Json |
        Set-Content -LiteralPath (Join-Path $precheckWorkspace 'verification.json') -Encoding UTF8
    $precheckStage = 'complete'
    Write-PrecheckStatus $true $precheckProcess.ExitCode
    exit $precheckProcess.ExitCode
} catch {
    Write-PrecheckStatus $true 1 $_.Exception.Message
    exit 1
}
