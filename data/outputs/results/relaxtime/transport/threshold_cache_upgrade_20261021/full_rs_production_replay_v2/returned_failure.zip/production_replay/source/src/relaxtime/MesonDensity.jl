raw"""
MesonDensity

介子数密度最小实现入口。当前阶段仅覆盖稳定粒子极限：

- 玻色分布函数
- `π/K` 聚合通道默认简并因子
- 稳定粒子极限数密度
- `K/π` 比值与最小温度扫描

后续 BU / BW / 各向异性扩展在此基础上演进。
"""
module MesonDensity

using ForwardDiff
using ..GaussLegendre: gauleg
using ..AFieldBuilder: ensure_quark_params_has_A
using ..EffectiveCouplings: calculate_G_from_A, calculate_effective_couplings,
                            calculate_effective_couplings_from_phi
using ..MesonMass: solve_meson_mass
using ..BUPhaseGates: STRICT_SINGLE_CHARGE_OMEGA_MEASURE,
                      LEGACY_POSITIVE_ENERGY_OMEGA_MEASURE,
                      bu_omega_measure,
                      bu_omega_measure_factor,
                      anchor_phase_high_energy
using ..PolarizationAniso: polarization_aniso, polarization_with_width
using ..MesonInteractionKernel: FullKMTInteraction, charged_coupling
using ..MesonPropagator: meson_propagator_simple
using Main.Constants_PNJL: G_fm2, K_fm5

export DEFAULT_MESON_DENSITY_Q_NODES
export DEFAULT_PHASE_SHIFT_Q_MAX, DEFAULT_PHASE_SHIFT_Q_NODES
export DEFAULT_PHASE_SHIFT_OMEGA_MIN, DEFAULT_PHASE_SHIFT_OMEGA_MAX, DEFAULT_PHASE_SHIFT_OMEGA_NODES
export bose_distribution, meson_degeneracy
export stable_meson_number_density, stable_kpi_ratio, stable_kpi_scan
export strict_bw_meson_number_density, strict_bw_meson_density_summary
export strict_bw_qpole_meson_number_density, strict_bw_qpole_density_summary
export phase_shift_meson_number_density, phase_shift_meson_density_summary
export phase_shift_meson_number_density_derivative_reference, phase_shift_meson_density_derivative_reference_summary
export phase_shift_point_diagnostic
export PhaseShiftInteractionSpec
export DEFAULT_PHASE_SHIFT_OMEGA_MEASURE, DEFAULT_PHASE_SHIFT_PHASE_ANCHOR

const DEFAULT_MESON_DENSITY_Q_NODES = 256
const DEFAULT_PHASE_SHIFT_Q_MAX = 12.0
const DEFAULT_PHASE_SHIFT_Q_NODES = 48
const DEFAULT_PHASE_SHIFT_OMEGA_MIN = 0.05
const DEFAULT_PHASE_SHIFT_OMEGA_MAX = 10.0
const DEFAULT_PHASE_SHIFT_OMEGA_NODES = 48
const DEFAULT_PHASE_SHIFT_ETA = 1e-6
const DEFAULT_PHASE_SHIFT_REAL_AXIS_MODE = :finite_eta
const DEFAULT_PHASE_SHIFT_PHASE_CONVENTION = :arg_propagator
const DEFAULT_PHASE_SHIFT_DENSITY_POLICY = :strict_normal_domain
const DEFAULT_PHASE_SHIFT_NOANOM_POLICY = :none
const DEFAULT_PHASE_SHIFT_OMEGA_MEASURE = LEGACY_POSITIVE_ENERGY_OMEGA_MEASURE
const DEFAULT_PHASE_SHIFT_PHASE_ANCHOR = :none
const DEFAULT_NOANOM_COMPONENT_EPS = 1e-8
const DEFAULT_NOANOM_LEADING_COMPONENT_PEAK_MIN = 0.02 * π
const DEFAULT_NOANOM_LANDAU_MARGIN_STEPS = 0.5
const _PHASE_SHIFT_PROPAGATOR_DENOM_EPS = 1e-12

"""Explicit interaction factors used by the phase-shift density kernel.

The legacy density path uses ``2K/(1-4K*Pi)``.  A diagnostic caller can inject
another coupling while keeping the same denominator convention, or explicitly
record a different RPA normalization.  This avoids changing the historical
`EffectiveCouplings` NamedTuple contract.
"""
struct PhaseShiftInteractionSpec
    backend::Symbol
    pair::Symbol
    channel::Symbol
    coupling::Float64
    numerator_factor::Float64
    denominator_factor::Float64
end

function PhaseShiftInteractionSpec(
    backend::Symbol,
    pair::Symbol,
    channel::Symbol,
    coupling::Real;
    numerator_factor::Real=2.0,
    denominator_factor::Real=4.0,
)
    isfinite(Float64(coupling)) || throw(ArgumentError("interaction coupling must be finite"))
    isfinite(Float64(numerator_factor)) || throw(ArgumentError("interaction numerator_factor must be finite"))
    denominator_value = Float64(denominator_factor)
    isfinite(denominator_value) && denominator_value > 0.0 || throw(ArgumentError(
        "interaction denominator_factor must be finite and positive",
    ))
    return PhaseShiftInteractionSpec(
        backend,
        pair,
        channel,
        Float64(coupling),
        Float64(numerator_factor),
        denominator_value,
    )
end
@inline function _require_nonnegative(name::AbstractString, value::Real)
    value >= 0.0 && return
    throw(ArgumentError("$(name) must be nonnegative, got $(value)"))
end

@inline function _default_qmax(mass::Float64, T::Float64, μ::Float64)::Float64
    gap = max(mass - μ, 0.0)
    return max(8.0, 20.0 * T + 10.0 * gap, 8.0 * mass + 10.0 * T)
end

"""
    meson_degeneracy(meson; charge_resolved=false) -> Int

返回当前主线下的一般介子简并因子。

- 聚合通道（默认）：`d_π = 3`、`d_K = 4`、`d_σπ = 1`、`d_σK = 4`
- 电荷分辨通道：`d = 1`
"""
@inline function meson_degeneracy(meson::Symbol; charge_resolved::Bool=false)::Int
    if meson === :pi
        return charge_resolved ? 1 : 3
    elseif meson === :K
        return charge_resolved ? 1 : 4
    elseif meson === :sigma_pi
        return 1
    elseif meson === :sigma_K
        return 4
    elseif meson === :pi_plus || meson === :pi_minus || meson === :K_plus || meson === :K_minus
        return 1
    else
        throw(ArgumentError("Unsupported meson $(meson). Use :pi, :pi_plus, :pi_minus, :K, :K_plus, :K_minus, :sigma_pi, or :sigma_K."))
    end
end

raw"""
    bose_distribution(E, μ, T) -> Float64

玻色分布函数：

```math
g(E) = 1 / (\exp((E-\mu)/T) - 1)
```
"""
function bose_distribution(E::Real, μ::Real, T::Real)
    _require_nonnegative("temperature T", T)
    T == 0.0 && return 0.0
    E > μ || throw(ArgumentError("Bose distribution requires E > μ to avoid pole, got E=$(E), μ=$(μ)"))

    exponent = (E - μ) / T
    exponent > 700.0 && return 0.0
    return 1.0 / expm1(exponent)
end

raw"""
    stable_meson_number_density(mass, T; μ=0.0, degeneracy=1,
                                qmax=nothing, num_q_nodes=DEFAULT_MESON_DENSITY_Q_NODES) -> Float64

稳定粒子极限介子数密度：

```math
n_M = d_M \\int_0^\\infty \\frac{dq\\,q^2}{2\\pi^2}
      \\frac{1}{\\exp((E_M-\\mu_M)/T)-1},
\\qquad
E_M = \\sqrt{q^2 + m_M^2}.
```
"""
function stable_meson_number_density(mass::Float64, T::Float64;
                                     μ::Float64=0.0,
                                     degeneracy::Integer=1,
                                     qmax::Union{Nothing,Float64}=nothing,
                                     num_q_nodes::Int=DEFAULT_MESON_DENSITY_Q_NODES)::Float64
    _require_nonnegative("mass", mass)
    _require_nonnegative("temperature T", T)
    degeneracy > 0 || throw(ArgumentError("degeneracy must be positive, got $(degeneracy)"))
    num_q_nodes > 1 || throw(ArgumentError("num_q_nodes must be > 1, got $(num_q_nodes)"))
    mass > μ || throw(ArgumentError("Stable boson density requires mass > μ, got mass=$(mass), μ=$(μ)"))
    T == 0.0 && return 0.0

    q_upper = qmax === nothing ? _default_qmax(mass, T, μ) : Float64(qmax)
    q_upper > 0.0 || throw(ArgumentError("qmax must be positive, got $(q_upper)"))

    nodes, weights = gauleg(0.0, q_upper, num_q_nodes)
    integral = 0.0
    @inbounds for i in eachindex(nodes, weights)
        q = nodes[i]
        E = hypot(q, mass)
        integral += weights[i] * q^2 * bose_distribution(E, μ, T)
    end
    return degeneracy * integral / (2.0 * π^2)
end

"""
    stable_kpi_ratio(m_pi, m_K, T; μ_pi=0.0, μ_K=0.0, d_pi=3, d_K=4, kwargs...) -> Float64

返回稳定粒子极限的 `K/π` 数密度比值。
"""
function stable_kpi_ratio(m_pi::Float64, m_K::Float64, T::Float64;
                          μ_pi::Float64=0.0, μ_K::Float64=0.0,
                          d_pi::Integer=3, d_K::Integer=4,
                          kwargs...)::Float64
    n_pi = stable_meson_number_density(m_pi, T; μ=μ_pi, degeneracy=d_pi, kwargs...)
    n_K = stable_meson_number_density(m_K, T; μ=μ_K, degeneracy=d_K, kwargs...)
    return iszero(n_pi) ? NaN : n_K / n_pi
end

"""
    stable_kpi_scan(temperatures; m_pi, m_K, μ_pi=0.0, μ_K=0.0, d_pi=3, d_K=4, kwargs...)
        -> NamedTuple

对一组温度执行稳定粒子极限 `π/K` 数密度扫描，返回：

- `temperatures`
- `n_pi`
- `n_K`
- `kpi_ratio`
"""
function stable_kpi_scan(temperatures::AbstractVector{<:Real};
                         m_pi::Float64, m_K::Float64,
                         μ_pi::Float64=0.0, μ_K::Float64=0.0,
                         d_pi::Integer=3, d_K::Integer=4,
                         kwargs...)
    Ts = Float64[Float64(T) for T in temperatures]
    n_pi = Vector{Float64}(undef, length(Ts))
    n_K = Vector{Float64}(undef, length(Ts))
    ratios = Vector{Float64}(undef, length(Ts))

    for i in eachindex(Ts)
        Ti = Ts[i]
        n_pi[i] = stable_meson_number_density(m_pi, Ti; μ=μ_pi, degeneracy=d_pi, kwargs...)
        n_K[i] = stable_meson_number_density(m_K, Ti; μ=μ_K, degeneracy=d_K, kwargs...)
        ratios[i] = iszero(n_pi[i]) ? NaN : n_K[i] / n_pi[i]
    end

    return (temperatures=Ts, n_pi=n_pi, n_K=n_K, kpi_ratio=ratios)
end

@inline function _strict_bw_kernel(Δω::Float64, gamma::Float64)::Float64
    half_gamma = gamma / 2.0
    return half_gamma / (Δω^2 + half_gamma^2)
end

@inline function _strict_bw_energy_kernel(ω::Float64, E::Float64, gamma::Float64)::Float64
    half_gamma = gamma / 2.0
    return half_gamma / ((ω - E)^2 + half_gamma^2)
end

function _strict_bw_spectral_window_average(
    E::Float64,
    gamma::Float64,
    T::Float64,
    μ::Float64,
    omega_min::Float64,
    omega_max::Float64,
    omega_nodes::Int,
)::Float64
    half_gamma = gamma / 2.0
    θ_min = atan((omega_min - E) / half_gamma)
    θ_max = atan((omega_max - E) / half_gamma)
    θ_max > θ_min || return 0.0

    θ_grid, θ_w = gauleg(θ_min, θ_max, omega_nodes)
    integral = 0.0
    @inbounds for iθ in eachindex(θ_grid, θ_w)
        ω = E + half_gamma * tan(θ_grid[iθ])
        integral += θ_w[iθ] * bose_distribution(ω, μ, T)
    end
    return integral / π
end

raw"""
    strict_bw_meson_number_density(mass, gamma, T; μ=0.0, degeneracy=1,
                                   qmax=DEFAULT_PHASE_SHIFT_Q_MAX,
                                   q_nodes=DEFAULT_PHASE_SHIFT_Q_NODES,
                                   omega_min=DEFAULT_PHASE_SHIFT_OMEGA_MIN,
                                   omega_max=DEFAULT_PHASE_SHIFT_OMEGA_MAX,
                                   omega_nodes=DEFAULT_PHASE_SHIFT_OMEGA_NODES,
                                   gamma_zero_tol=1e-12) -> NamedTuple

reduced strict BW 单通道介子数密度：

```math
n_M^{BW,red}(T)
= d_M \int_0^\infty \frac{dq\,q^2}{2\pi^2}
\int_{\omega_{\min}}^{\omega_{\max}} d\omega\,
g(\omega)
\frac{\Gamma_M}
{2\pi\left[(\omega-\sqrt{q^2+m_M^2})^2+\Gamma_M^2/4\right]}.
```

这里采用当前 Stage-1 reduced strict BW 口径：

- `E_M(q)=sqrt(q^2+m_M^2)`
- `Γ_M(q)=Γ_M`
- 内层直接在 `ω` 上积分，而不是只保留 `ω >= E_M(q)` 的右半边变量
- `omega_min` 必须位于 Bose pole 之上；生产扫描默认复用 phase-shift 的安全下界
- 实现上使用 `θ = atan(2(ω-E_M(q))/Γ_M)` 的等价变量变换，避免小宽度下
  固定 `ω` 节点欠采样 Lorentzian 峰；有限窗口谱权不做逐 `q` 归一化
"""
function strict_bw_meson_number_density(
    mass::Float64,
    gamma::Float64,
    T::Float64;
    μ::Float64=0.0,
    degeneracy::Integer=1,
    qmax::Float64=DEFAULT_PHASE_SHIFT_Q_MAX,
    q_nodes::Int=DEFAULT_PHASE_SHIFT_Q_NODES,
    omega_min::Float64=DEFAULT_PHASE_SHIFT_OMEGA_MIN,
    omega_max::Float64=DEFAULT_PHASE_SHIFT_OMEGA_MAX,
    omega_nodes::Int=DEFAULT_PHASE_SHIFT_OMEGA_NODES,
    gamma_zero_tol::Float64=1e-12,
)
    _require_nonnegative("mass", mass)
    _require_nonnegative("gamma", gamma)
    _require_nonnegative("temperature T", T)
    degeneracy > 0 || throw(ArgumentError("degeneracy must be positive, got $(degeneracy)"))
    _require_positive_node_count("q_nodes", q_nodes)
    _require_positive_node_count("omega_nodes", omega_nodes)
    qmax > 0.0 || throw(ArgumentError("qmax must be positive, got $(qmax)"))
    omega_min >= 0.0 || throw(ArgumentError("omega_min must be nonnegative, got $(omega_min)"))
    omega_max > omega_min || throw(ArgumentError("omega_max must exceed omega_min, got omega_min=$(omega_min), omega_max=$(omega_max)"))
    gamma_zero_tol >= 0.0 || throw(ArgumentError("gamma_zero_tol must be nonnegative, got $(gamma_zero_tol)"))
    mass > μ || throw(ArgumentError("strict BW helper requires mass > μ, got mass=$(mass), μ=$(μ)"))
    omega_min > μ || throw(ArgumentError("strict BW omega_min must exceed μ to avoid Bose pole, got omega_min=$(omega_min), μ=$(μ)"))

    T == 0.0 && return (
        density=0.0,
        q_integral_estimate=0.0,
        omega_shell_at_qmax=0.0,
        qmax=qmax,
        q_nodes=q_nodes,
        omega_min=omega_min,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        degeneracy=Int(degeneracy),
        gamma=gamma,
        mass=mass,
        mode=:strict_bw_reduced_spectral_window,
        omega_measure=STRICT_SINGLE_CHARGE_OMEGA_MEASURE,
        omega_measure_factor=bu_omega_measure_factor(STRICT_SINGLE_CHARGE_OMEGA_MEASURE),
    )

    if gamma <= gamma_zero_tol
        density = stable_meson_number_density(
            mass,
            T;
            μ=μ,
            degeneracy=degeneracy,
            qmax=qmax,
            num_q_nodes=q_nodes,
        )
        return (
            density=density,
            q_integral_estimate=density / Float64(degeneracy),
            omega_shell_at_qmax=0.0,
            qmax=qmax,
            q_nodes=q_nodes,
            omega_min=omega_min,
            omega_max=omega_max,
            omega_nodes=omega_nodes,
            degeneracy=Int(degeneracy),
            gamma=gamma,
            mass=mass,
            mode=:stable_limit,
            omega_measure=STRICT_SINGLE_CHARGE_OMEGA_MEASURE,
            omega_measure_factor=bu_omega_measure_factor(STRICT_SINGLE_CHARGE_OMEGA_MEASURE),
        )
    end

    q_grid, q_w = gauleg(0.0, qmax, q_nodes)
    q_shell_weighted_sum = 0.0
    q_shell_at_qmax = NaN
    @inbounds for iq in eachindex(q_grid, q_w)
        q = q_grid[iq]
        E = hypot(q, mass)
        omega_val = _strict_bw_spectral_window_average(E, gamma, T, μ, omega_min, omega_max, omega_nodes)
        q_shell = (q^2 / (2.0 * π^2)) * omega_val
        q_shell_weighted_sum += q_w[iq] * q_shell
        if iq == length(q_grid)
            q_shell_at_qmax = q_shell
        end
    end

    return (
        density=Float64(degeneracy) * q_shell_weighted_sum,
        q_integral_estimate=q_shell_weighted_sum,
        omega_shell_at_qmax=q_shell_at_qmax,
        qmax=qmax,
        q_nodes=q_nodes,
        omega_min=omega_min,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        degeneracy=Int(degeneracy),
        gamma=gamma,
        mass=mass,
        mode=:strict_bw_reduced_spectral_window,
        omega_measure=STRICT_SINGLE_CHARGE_OMEGA_MEASURE,
        omega_measure_factor=bu_omega_measure_factor(STRICT_SINGLE_CHARGE_OMEGA_MEASURE),
    )
end

"""
    strict_bw_meson_density_summary(pi_mass, pi_gamma, k_mass, k_gamma, T; kwargs...) -> NamedTuple

聚合 `π/K` reduced strict BW 数密度摘要。
"""
function strict_bw_meson_density_summary(
    pi_mass::Float64,
    pi_gamma::Float64,
    k_mass::Float64,
    k_gamma::Float64,
    T::Float64;
    μ_pi::Float64=0.0,
    μ_K::Float64=0.0,
    d_pi::Integer=meson_degeneracy(:pi),
    d_K::Integer=meson_degeneracy(:K),
    qmax::Float64=DEFAULT_PHASE_SHIFT_Q_MAX,
    q_nodes::Int=DEFAULT_PHASE_SHIFT_Q_NODES,
    omega_min::Float64=DEFAULT_PHASE_SHIFT_OMEGA_MIN,
    omega_max::Float64=DEFAULT_PHASE_SHIFT_OMEGA_MAX,
    omega_nodes::Int=DEFAULT_PHASE_SHIFT_OMEGA_NODES,
    gamma_zero_tol::Float64=1e-12,
)
    pi_density = strict_bw_meson_number_density(
        pi_mass,
        pi_gamma,
        T;
        μ=μ_pi,
        degeneracy=Int(d_pi),
        qmax=qmax,
        q_nodes=q_nodes,
        omega_min=omega_min,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        gamma_zero_tol=gamma_zero_tol,
    )
    k_density = strict_bw_meson_number_density(
        k_mass,
        k_gamma,
        T;
        μ=μ_K,
        degeneracy=Int(d_K),
        qmax=qmax,
        q_nodes=q_nodes,
        omega_min=omega_min,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        gamma_zero_tol=gamma_zero_tol,
    )

    return (
        n_pi=pi_density.density,
        n_K=k_density.density,
        kpi_ratio=iszero(pi_density.density) ? NaN : k_density.density / pi_density.density,
        pi_density=pi_density,
        k_density=k_density,
        qmax=qmax,
        q_nodes=q_nodes,
        omega_min=omega_min,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        gamma_zero_tol=gamma_zero_tol,
    )
end

@inline function _sorted_gauleg(a::Float64, b::Float64, n::Int)
    nodes, weights = gauleg(a, b, n)
    perm = sortperm(nodes)
    return nodes[perm], weights[perm]
end

@inline function _strict_bw_stage_symbol(stage::Symbol)::Symbol
    if stage === :stage1_reduced || stage === :reduced
        return :strict_bw_stage1_reduced
    elseif stage === :stage2_qpole || stage === :qpole
        return :strict_bw_stage2_qpole
    end
    throw(ArgumentError("strict BW stage must be :stage1_reduced/:reduced or :stage2_qpole/:qpole, got $(stage)"))
end

function _solve_qpole_at_q(
    meson::Symbol,
    q::Float64,
    quark_params,
    thermo_params;
    initial_mass::Float64,
    initial_gamma::Float64,
    solver_iterations::Int,
    residual_norm_max::Float64,
    require_converged::Bool,
)
    seeds = (
        (initial_mass, max(initial_gamma, 0.0)),
        (max(initial_mass, 1e-6), 0.0),
        (hypot(q, max(initial_mass, 1e-6)), max(initial_gamma, 0.0)),
    )

    best = nothing
    for (m0, g0) in seeds
        for method in (:trust_region, :newton)
            rr = try
                solve_meson_mass(
                    meson,
                    quark_params,
                    thermo_params;
                    k_norm=q,
                    initial_mass=Float64(m0),
                    initial_gamma=Float64(max(g0, 0.0)),
                    method=method,
                    iterations=solver_iterations,
                )
            catch
                nothing
            end
            rr === nothing && continue
            if best === nothing || Float64(rr.residual_norm) < Float64(best.residual_norm)
                best = rr
            end
            if isfinite(Float64(rr.residual_norm)) &&
               Float64(rr.residual_norm) <= residual_norm_max &&
               (!require_converged || Bool(rr.converged))
                return (
                    mass=Float64(rr.mass),
                    gamma=max(Float64(rr.gamma), 0.0),
                    residual_norm=Float64(rr.residual_norm),
                    converged=Bool(rr.converged),
                    accepted=true,
                    method=method,
                )
            end
        end
    end

    best === nothing && return (
        mass=NaN,
        gamma=NaN,
        residual_norm=Inf,
        converged=false,
        accepted=false,
        method=:failed,
    )

    return (
        mass=Float64(best.mass),
        gamma=max(Float64(best.gamma), 0.0),
        residual_norm=Float64(best.residual_norm),
        converged=Bool(best.converged),
        accepted=isfinite(Float64(best.residual_norm)) &&
                 Float64(best.residual_norm) <= residual_norm_max &&
                 (!require_converged || Bool(best.converged)),
        method=:best_effort,
    )
end

"""
    strict_bw_qpole_meson_number_density(meson, mass0, gamma0, quark_params, thermo_params; ...) -> NamedTuple

Stage-2 q 依赖复极点版本的 strict BW 单通道介子数密度。
"""
function strict_bw_qpole_meson_number_density(
    meson::Symbol,
    mass0::Float64,
    gamma0::Float64,
    quark_params,
    thermo_params;
    μ::Float64=0.0,
    degeneracy::Integer=1,
    qmax::Float64=DEFAULT_PHASE_SHIFT_Q_MAX,
    q_nodes::Int=DEFAULT_PHASE_SHIFT_Q_NODES,
    omega_max::Float64=DEFAULT_PHASE_SHIFT_OMEGA_MAX,
    omega_nodes::Int=DEFAULT_PHASE_SHIFT_OMEGA_NODES,
    gamma_zero_tol::Float64=1e-12,
    solver_iterations::Int=20,
    pole_residual_norm_max::Float64=1e-6,
    pole_require_converged::Bool=true,
)
    degeneracy > 0 || throw(ArgumentError("degeneracy must be positive, got $(degeneracy)"))
    _require_nonnegative("mass0", mass0)
    _require_nonnegative("gamma0", gamma0)
    _require_nonnegative("temperature T", Float64(thermo_params.T))
    qmax > 0.0 || throw(ArgumentError("qmax must be positive, got $(qmax)"))
    _require_positive_node_count("q_nodes", q_nodes)
    _require_positive_node_count("omega_nodes", omega_nodes)
    omega_max > 0.0 || throw(ArgumentError("omega_max must be positive, got $(omega_max)"))

    T = Float64(thermo_params.T)
    T == 0.0 && return (
        meson=meson,
        density=0.0,
        q_integral_estimate=0.0,
        omega_shell_at_qmax=0.0,
        q_values=Float64[],
        E_values=Float64[],
        gamma_values=Float64[],
        residual_norms=Float64[],
        converged_flags=Bool[],
        accepted_flags=Bool[],
        qmax=qmax,
        q_nodes=q_nodes,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        degeneracy=Int(degeneracy),
        mode=:strict_bw_stage2_qpole,
    )

    if gamma0 <= gamma_zero_tol
        density = stable_meson_number_density(
            mass0,
            T;
            μ=μ,
            degeneracy=degeneracy,
            qmax=qmax,
            num_q_nodes=q_nodes,
        )
        return (
            meson=meson,
            density=density,
            q_integral_estimate=density / Float64(degeneracy),
            omega_shell_at_qmax=0.0,
            q_values=Float64[],
            E_values=Float64[],
            gamma_values=Float64[],
            residual_norms=Float64[],
            converged_flags=Bool[],
            accepted_flags=Bool[],
            qmax=qmax,
            q_nodes=q_nodes,
            omega_max=omega_max,
            omega_nodes=omega_nodes,
            degeneracy=Int(degeneracy),
            mode=:stable_limit,
        )
    end

    qp = ensure_quark_params_has_A(quark_params, thermo_params)
    q_grid, q_w = _sorted_gauleg(0.0, qmax, q_nodes)
    ω_grid, ω_w = gauleg(0.0, omega_max, omega_nodes)

    q_values = Float64[]
    E_values = Float64[]
    gamma_values = Float64[]
    residual_norms = Float64[]
    converged_flags = Bool[]
    accepted_flags = Bool[]

    q_shell_weighted_sum = 0.0
    q_shell_at_qmax = NaN
    prev_mass = mass0
    prev_gamma = gamma0

    @inbounds for iq in eachindex(q_grid, q_w)
        q = Float64(q_grid[iq])
        pole = _solve_qpole_at_q(
            meson,
            q,
            qp,
            thermo_params;
            initial_mass=prev_mass,
            initial_gamma=prev_gamma,
            solver_iterations=solver_iterations,
            residual_norm_max=pole_residual_norm_max,
            require_converged=pole_require_converged,
        )

        E_q = pole.mass
        gamma_q = pole.gamma
        push!(q_values, q)
        push!(E_values, E_q)
        push!(gamma_values, gamma_q)
        push!(residual_norms, pole.residual_norm)
        push!(converged_flags, pole.converged)
        push!(accepted_flags, pole.accepted)

        if pole.accepted && isfinite(E_q) && isfinite(gamma_q) && E_q > μ
            omega_val = 0.0
            for iω in eachindex(ω_grid, ω_w)
                ω = ω_grid[iω]
                omega_val += ω_w[iω] * bose_distribution(ω, μ, T) * _strict_bw_energy_kernel(ω, E_q, gamma_q)
            end
            omega_val /= (2.0 * π)
            q_shell = (q^2 / (2.0 * π^2)) * omega_val
            q_shell_weighted_sum += q_w[iq] * q_shell
            if iq == length(q_grid)
                q_shell_at_qmax = q_shell
            end
            prev_mass = E_q
            prev_gamma = gamma_q
        else
            if iq == length(q_grid)
                q_shell_at_qmax = NaN
            end
        end
    end

    return (
        meson=meson,
        density=Float64(degeneracy) * q_shell_weighted_sum,
        q_integral_estimate=q_shell_weighted_sum,
        omega_shell_at_qmax=q_shell_at_qmax,
        q_values=q_values,
        E_values=E_values,
        gamma_values=gamma_values,
        residual_norms=residual_norms,
        converged_flags=converged_flags,
        accepted_flags=accepted_flags,
        qmax=qmax,
        q_nodes=q_nodes,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        degeneracy=Int(degeneracy),
        mode=:strict_bw_stage2_qpole,
    )
end

function strict_bw_qpole_density_summary(
    pi_mass::Float64,
    pi_gamma::Float64,
    k_mass::Float64,
    k_gamma::Float64,
    quark_params,
    thermo_params;
    pi_channel::Symbol=:pi,
    k_channel::Symbol=:K,
    μ_pi::Float64=0.0,
    μ_K::Float64=0.0,
    d_pi::Integer=meson_degeneracy(:pi),
    d_K::Integer=meson_degeneracy(:K),
    qmax::Float64=DEFAULT_PHASE_SHIFT_Q_MAX,
    q_nodes::Int=DEFAULT_PHASE_SHIFT_Q_NODES,
    omega_max::Float64=DEFAULT_PHASE_SHIFT_OMEGA_MAX,
    omega_nodes::Int=DEFAULT_PHASE_SHIFT_OMEGA_NODES,
    gamma_zero_tol::Float64=1e-12,
    solver_iterations::Int=20,
    pole_residual_norm_max::Float64=1e-6,
    pole_require_converged::Bool=true,
)
    pi_density = strict_bw_qpole_meson_number_density(
        pi_channel,
        pi_mass,
        pi_gamma,
        quark_params,
        thermo_params;
        μ=μ_pi,
        degeneracy=Int(d_pi),
        qmax=qmax,
        q_nodes=q_nodes,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        gamma_zero_tol=gamma_zero_tol,
        solver_iterations=solver_iterations,
        pole_residual_norm_max=pole_residual_norm_max,
        pole_require_converged=pole_require_converged,
    )
    k_density = strict_bw_qpole_meson_number_density(
        k_channel,
        k_mass,
        k_gamma,
        quark_params,
        thermo_params;
        μ=μ_K,
        degeneracy=Int(d_K),
        qmax=qmax,
        q_nodes=q_nodes,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        gamma_zero_tol=gamma_zero_tol,
        solver_iterations=solver_iterations,
        pole_residual_norm_max=pole_residual_norm_max,
        pole_require_converged=pole_require_converged,
    )

    return (
        n_pi=pi_density.density,
        n_K=k_density.density,
        kpi_ratio=iszero(pi_density.density) ? NaN : k_density.density / pi_density.density,
        pi_channel=pi_channel,
        k_channel=k_channel,
        pi_density=pi_density,
        k_density=k_density,
        qmax=qmax,
        q_nodes=q_nodes,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        gamma_zero_tol=gamma_zero_tol,
        solver_iterations=solver_iterations,
        pole_residual_norm_max=pole_residual_norm_max,
        pole_require_converged=pole_require_converged,
    )
end

@inline function _require_phase_shift_isotropic_xi(ξ::Float64)
    abs(ξ) <= 1e-12 && return
    throw(ArgumentError(
        "current phase-shift meson-density helper only supports xi = 0 isotropic reduction, got xi=$(ξ)"
    ))
end

@inline function _require_positive_node_count(name::AbstractString, n::Int)
    n > 1 && return
    throw(ArgumentError("$(name) must be > 1, got $(n)"))
end

@inline function _real_axis_mode_symbol(real_axis_mode::Symbol)::Symbol
    if real_axis_mode === :finite_eta || real_axis_mode === :legacy_finite_eta
        return :finite_eta
    elseif real_axis_mode === :pv_b0_eta0 ||
           real_axis_mode === :bu2020_pv_eta0 ||
           real_axis_mode === :eta0_pv_b0
        return :pv_b0_eta0
    end
    throw(ArgumentError("real_axis_mode must be :finite_eta or :pv_b0_eta0, got $(real_axis_mode)"))
end

@inline function _phase_convention_symbol(phase_convention::Symbol)::Symbol
    if phase_convention === :arg_propagator || phase_convention === :propagator
        return :arg_propagator
    elseif phase_convention === :arg_inverse_propagator ||
           phase_convention === :inverse_propagator ||
           phase_convention === :arg_inverse
        return :arg_inverse_propagator
    end
    throw(ArgumentError("phase_convention must be :arg_propagator or :arg_inverse_propagator, got $(phase_convention)"))
end

@inline function _phase_display_symbol(phase_display::Symbol)::Symbol
    if phase_display === :unwrapped || phase_display === :phase_unwrapped
        return :unwrapped
    elseif phase_display === :fold_0_pi ||
           phase_display === :folded_0_pi ||
           phase_display === :display_fold_0_pi
        return :fold_0_pi
    end
    throw(ArgumentError("phase_display must be :unwrapped or :fold_0_pi, got $(phase_display)"))
end

@inline function _phase_anchor_symbol(phase_anchor::Symbol)::Symbol
    if phase_anchor === :none || phase_anchor === :legacy_unanchored
        return :none
    elseif phase_anchor === :high_energy_zero ||
           phase_anchor === :anchor_high_energy_zero ||
           phase_anchor === :strict_high_energy_zero
        return :high_energy_zero
    end
    throw(ArgumentError("phase_anchor must be :none or :high_energy_zero, got $(phase_anchor)"))
end

@inline function _density_policy_symbol(density_policy::Symbol)::Symbol
    if density_policy === :strict_normal_domain || density_policy === :strict
        return :strict_normal_domain
    elseif density_policy === :excitation_only_E_gt_mu || density_policy === :excitation_only
        return :excitation_only_E_gt_mu
    elseif density_policy === :x_min_cut || density_policy === :bose_x_min_cut
        return :x_min_cut
    end
    throw(ArgumentError("density_policy must be :strict_normal_domain, :excitation_only_E_gt_mu, or :x_min_cut, got $(density_policy)"))
end

@inline function _noanom_policy_symbol(noanom_policy::Symbol)::Symbol
    if noanom_policy === :none || noanom_policy === :full
        return :none
    elseif noanom_policy === :low_energy_branch_subtraction ||
           noanom_policy === :temp7_low_energy_branch_subtraction
        return :low_energy_branch_subtraction
    end
    throw(ArgumentError("noanom_policy must be :none or :low_energy_branch_subtraction, got $(noanom_policy)"))
end

@inline function _empty_noanom_diag(noanom_policy::Symbol)
    policy = _noanom_policy_symbol(noanom_policy)
    return (
        noanom_policy=policy,
        noanom_applied=false,
        noanom_removed_component_count=0,
        noanom_removed_omega_min=NaN,
        noanom_removed_omega_max=NaN,
        noanom_landau_omega_min=NaN,
        noanom_landau_omega_max=NaN,
    )
end

@inline function _phase_shift_omega_lower_bound(omega_min::Float64, μ::Float64)::Float64
    return omega_min > μ ? omega_min : nextfloat(μ)
end

@inline function _resolve_real_axis_config(real_axis_mode::Symbol, eta::Float64)
    mode = _real_axis_mode_symbol(real_axis_mode)
    if mode === :finite_eta
        eta > 0.0 || throw(ArgumentError(
            "real_axis_mode=:finite_eta requires eta > 0; use real_axis_mode=:pv_b0_eta0 for the eta=0 principal-value branch"
        ))
        return (mode=mode, eta=eta, polarization_backend=:finite_width)
    end
    return (mode=mode, eta=0.0, polarization_backend=:pv_b0_real_axis)
end

function _phase_shift_energy_domain(
    omega_min::Float64,
    omega_max::Float64,
    omega_nodes::Int,
    μ::Float64,
    T::Float64;
    density_policy::Symbol,
    bose_x_min::Float64=0.0,
)
    policy = _density_policy_symbol(density_policy)
    omega_max > omega_min || throw(ArgumentError("omega_max must exceed omega_min=$(omega_min)"))
    bose_x_min >= 0.0 || throw(ArgumentError("bose_x_min must be nonnegative, got $(bose_x_min)"))

    probe_grid, _ = gauleg(omega_min, omega_max, omega_nodes)
    unsafe_support = omega_min <= μ
    unsafe_count = count(ω -> Float64(ω) <= μ, probe_grid)
    unsafe_count = unsafe_support ? max(unsafe_count, 1) : unsafe_count
    min_E_minus_mu = omega_min - μ

    if policy === :strict_normal_domain
        if unsafe_support
            return (
                policy=policy,
                omega_lower=omega_min,
                unsafe=true,
                no_support=false,
                unsafe_bose_count=unsafe_count,
                min_E_minus_mu=min_E_minus_mu,
                bose_x_min=0.0,
                status=:unsafe_bose_domain,
                message="strict_normal_domain found omega <= mu_M support; use an explicit diagnostic density_policy to continue",
            )
        end
        return (
            policy=policy,
            omega_lower=omega_min,
            unsafe=false,
            no_support=false,
            unsafe_bose_count=0,
            min_E_minus_mu=min_E_minus_mu,
            bose_x_min=0.0,
            status=:ok,
            message="",
        )
    elseif policy === :excitation_only_E_gt_mu
        omega_lower = omega_min > μ ? omega_min : nextfloat(μ)
        return (
            policy=policy,
            omega_lower=omega_lower,
            unsafe=false,
            no_support=omega_lower >= omega_max,
            unsafe_bose_count=unsafe_count,
            min_E_minus_mu=min_E_minus_mu,
            bose_x_min=0.0,
            status=omega_lower >= omega_max ? :no_bose_safe_support : :ok,
            message=omega_lower >= omega_max ? "excitation_only_E_gt_mu has no omega > mu_M support in the requested window" : "",
        )
    end

    T > 0.0 || throw(ArgumentError("density_policy=:x_min_cut requires T > 0"))
    omega_lower = max(omega_min, μ + bose_x_min * T)
    return (
        policy=policy,
        omega_lower=omega_lower,
        unsafe=false,
        no_support=omega_lower >= omega_max,
        unsafe_bose_count=unsafe_count,
        min_E_minus_mu=min_E_minus_mu,
        bose_x_min=bose_x_min,
        status=omega_lower >= omega_max ? :no_bose_safe_support : :ok,
        message=omega_lower >= omega_max ? "x_min_cut has no omega support above the requested Bose x_min" : "",
    )
end

@inline function _complex_phase(z::Complex{T})::T where {T<:Real}
    return atan(imag(z), real(z))
end

@inline function _phase_derivative_from_components(reD::T, imD::T, dre::T, dim::T) where {T<:Real}
    denom = reD * reD + imD * imD
    return (reD * dim - imD * dre) / denom
end

function _unwrap_phases(phases::AbstractVector{<:Real}; branch_tol::Real=0.0)
    branch_tol >= 0.0 || throw(ArgumentError("branch_tol must be nonnegative, got $(branch_tol)"))
    out = similar(phases)
    isempty(phases) && return out
    out[1] = phases[1]
    shift = zero(eltype(phases))
    for i in 2:length(phases)
        Δ = phases[i] - phases[i - 1]
        if Δ > (π - branch_tol)
            shift -= 2π
        elseif Δ < (-π + branch_tol)
            shift += 2π
        end
        out[i] = phases[i] + shift
    end
    return out
end

@inline function _fold_phase_0_pi(δ::Real)
    return π - abs(mod(Float64(δ), 2π) - π)
end

function _apply_phase_display(phase_unwrapped::AbstractVector{<:Real}, phase_display::Symbol)
    display = _phase_display_symbol(phase_display)
    if display === :fold_0_pi
        return [_fold_phase_0_pi(δ) for δ in phase_unwrapped]
    end
    return [Float64(δ) for δ in phase_unwrapped]
end

function _strip_small_leading_components(
    δs::Vector{Float64};
    eps::Float64=DEFAULT_NOANOM_COMPONENT_EPS,
    leading_peak_min::Float64=DEFAULT_NOANOM_LEADING_COMPONENT_PEAK_MIN,
)
    out = copy(δs)
    i = 1
    while i <= length(out)
        while i <= length(out) && !(isfinite(out[i]) && out[i] > eps)
            i += 1
        end
        i > length(out) && return out

        j = i
        peak = out[i]
        while j < length(out) && isfinite(out[j + 1]) && out[j + 1] > eps
            j += 1
            peak = max(peak, out[j])
        end
        peak >= leading_peak_min && return out
        out[i:j] .= 0.0
        i = j + 1
    end
    return out
end

function _connected_positive_components(
    ωs::AbstractVector{<:Real},
    δs::AbstractVector{<:Real};
    eps::Float64=DEFAULT_NOANOM_COMPONENT_EPS,
)
    length(ωs) == length(δs) || throw(ArgumentError("omega and phase arrays must have the same length"))
    comps = NamedTuple[]
    i = 1
    while i <= length(δs)
        while i <= length(δs) && !(isfinite(Float64(δs[i])) && Float64(δs[i]) > eps)
            i += 1
        end
        i > length(δs) && break

        j = i
        peak = Float64(δs[i])
        peak_idx = i
        while j < length(δs) && isfinite(Float64(δs[j + 1])) && Float64(δs[j + 1]) > eps
            j += 1
            if Float64(δs[j]) >= peak
                peak = Float64(δs[j])
                peak_idx = j
            end
        end
        push!(comps, (
            i=i,
            j=j,
            ω_lo=Float64(ωs[i]),
            ω_hi=Float64(ωs[j]),
            peak=peak,
            peak_ω=Float64(ωs[peak_idx]),
        ))
        i = j + 1
    end
    return comps
end

function _noanom_landau_window(meson::Symbol, qp)
    meson === :K_plus || return nothing
    μ_shift = Float64(qp.μ.u) - Float64(qp.μ.s)
    hi = μ_shift + abs(Float64(qp.m.s) - Float64(qp.m.u))
    hi <= 0.0 && return nothing
    return (lo=max(0.0, μ_shift), hi=hi)
end

function _apply_noanom_policy(
    meson::Symbol,
    omega_grid::AbstractVector{<:Real},
    phase_unwrapped::AbstractVector{<:Real},
    qp;
    noanom_policy::Symbol,
    phase_display::Symbol=:unwrapped,
)
    policy = _noanom_policy_symbol(noanom_policy)
    base_diag = (
        noanom_policy=policy,
        noanom_applied=false,
        noanom_removed_component_count=0,
        noanom_removed_omega_min=NaN,
        noanom_removed_omega_max=NaN,
        noanom_landau_omega_min=NaN,
        noanom_landau_omega_max=NaN,
    )
    policy === :none && return _apply_phase_display(phase_unwrapped, phase_display), base_diag

    display_phases = _strip_small_leading_components([_fold_phase_0_pi(δ) for δ in phase_unwrapped])
    window = _noanom_landau_window(meson, qp)
    window === nothing && return display_phases, merge(base_diag, (noanom_applied=(meson === :K_plus),))

    comps = _connected_positive_components(omega_grid, display_phases)
    isempty(comps) && return display_phases, merge(base_diag, (
        noanom_applied=true,
        noanom_landau_omega_min=window.lo,
        noanom_landau_omega_max=window.hi,
    ))

    out = copy(display_phases)
    steps = [
        abs(Float64(omega_grid[i + 1]) - Float64(omega_grid[i]))
        for i in 1:(length(omega_grid) - 1)
        if isfinite(Float64(omega_grid[i + 1])) && isfinite(Float64(omega_grid[i]))
    ]
    omega_margin = isempty(steps) ? 0.0 : DEFAULT_NOANOM_LANDAU_MARGIN_STEPS * minimum(steps)
    removed_min = Inf
    removed_max = -Inf
    removed_count = 0

    for comp in comps
        overlaps_landau = comp.ω_hi >= window.lo - omega_margin && comp.ω_lo <= window.hi + omega_margin
        ends_in_landau = comp.ω_hi <= window.hi + omega_margin
        has_visible_weight = comp.peak > DEFAULT_NOANOM_COMPONENT_EPS
        if overlaps_landau && ends_in_landau && has_visible_weight
            out[comp.i:comp.j] .= 0.0
            removed_count += 1
            removed_min = min(removed_min, comp.ω_lo)
            removed_max = max(removed_max, comp.ω_hi)
        end
    end

    return out, (
        noanom_policy=policy,
        noanom_applied=true,
        noanom_removed_component_count=removed_count,
        noanom_removed_omega_min=removed_count == 0 ? NaN : removed_min,
        noanom_removed_omega_max=removed_count == 0 ? NaN : removed_max,
        noanom_landau_omega_min=window.lo,
        noanom_landau_omega_max=window.hi,
    )
end

@inline function _phase_shift_scheme_symbol(scheme::Symbol)::Symbol
    if scheme === :current || scheme === :phase_e3 || scheme === :phase_shift_current
        return :phase_shift_current
    elseif scheme === :gbu || scheme === :gbu_reference || scheme === :generalized_bu || scheme === :phase_shift_gbu_reference
        return :phase_shift_gbu_reference
    end
    throw(ArgumentError("phase-shift scheme must be :current/:phase_e3 or :gbu/:gbu_reference/:generalized_bu, got $(scheme)"))
end

@inline function _gbu_phase_function(δ::T)::T where {T<:Real}
    return δ - 0.5 * sin(2.0 * δ)
end

@inline function _phase_shift_weighted_phase(δ::T, scheme::Symbol)::T where {T<:Real}
    scheme_sym = _phase_shift_scheme_symbol(scheme)
    if scheme_sym === :phase_shift_current
        return δ
    end
    return _gbu_phase_function(δ)
end

@inline function _phase_shift_weight_derivative_factor(δ::T, scheme::Symbol)::T where {T<:Real}
    scheme_sym = _phase_shift_scheme_symbol(scheme)
    if scheme_sym === :phase_shift_current
        return one(T)
    end
    return T(2) * sin(δ)^2
end

function _simple_meson_pol_params(meson::Symbol, qp)
    if meson === :pi
        return (
            channel=:P,
            m1=qp.m.u, m2=qp.m.u,
            μ1=qp.μ.u, μ2=qp.μ.u,
            A1=qp.A.u, A2=qp.A.u,
            num_s_quark=0,
        )
    elseif meson === :pi_plus
        return (
            channel=:P,
            m1=qp.m.u, m2=qp.m.d,
            μ1=qp.μ.u, μ2=qp.μ.d,
            A1=qp.A.u, A2=qp.A.d,
            num_s_quark=0,
        )
    elseif meson === :pi_minus
        return (
            channel=:P,
            m1=qp.m.d, m2=qp.m.u,
            μ1=qp.μ.d, μ2=qp.μ.u,
            A1=qp.A.d, A2=qp.A.u,
            num_s_quark=0,
        )
    elseif meson === :K
        return (
            channel=:P,
            m1=qp.m.u, m2=qp.m.s,
            μ1=qp.μ.u, μ2=qp.μ.s,
            A1=qp.A.u, A2=qp.A.s,
            num_s_quark=1,
        )
    elseif meson === :K_plus
        return (
            channel=:P,
            m1=qp.m.u, m2=qp.m.s,
            μ1=qp.μ.u, μ2=qp.μ.s,
            A1=qp.A.u, A2=qp.A.s,
            num_s_quark=1,
        )
    elseif meson === :K_minus
        return (
            channel=:P,
            m1=qp.m.s, m2=qp.m.u,
            μ1=qp.μ.s, μ2=qp.μ.u,
            A1=qp.A.s, A2=qp.A.u,
            num_s_quark=1,
        )
    elseif meson === :sigma_pi
        return (
            channel=:S,
            m1=qp.m.u, m2=qp.m.u,
            μ1=qp.μ.u, μ2=qp.μ.u,
            A1=qp.A.u, A2=qp.A.u,
            num_s_quark=0,
        )
    elseif meson === :sigma_K
        return (
            channel=:S,
            m1=qp.m.u, m2=qp.m.s,
            μ1=qp.μ.u, μ2=qp.μ.s,
            A1=qp.A.u, A2=qp.A.s,
            num_s_quark=1,
        )
    end
    throw(ArgumentError("Unsupported simple meson: $(meson)"))
end

function _build_k_coeffs(qp)
    # Analysis callers may carry the already-solved condensates alongside the
    # quark masses/chemical potentials.  Prefer that phi-native view so the
    # legacy compatibility tuple does not reconstruct H_f from a second A_f
    # quadrature.  Plain historical callers without :phi retain the old path.
    if hasproperty(qp, :phi)
        phi = qp.phi
        all(flavor -> hasproperty(phi, flavor), (:u, :d, :s)) || throw(ArgumentError(
            "quark_params.phi must provide fields :u, :d, and :s",
        ))
        return calculate_effective_couplings_from_phi(
            G_fm2,
            K_fm5,
            Float64(phi.u),
            Float64(phi.s),
        )
    end

    G_u = calculate_G_from_A(qp.A.u, qp.m.u)
    G_s = calculate_G_from_A(qp.A.s, qp.m.s)
    return calculate_effective_couplings(G_fm2, K_fm5, G_u, G_s)
end

@inline function _simple_meson_coupling(meson::Symbol, K_coeffs)
    if meson === :pi || meson === :pi_plus || meson === :pi_minus
        return K_coeffs.K123_plus
    elseif meson === :K || meson === :K_plus || meson === :K_minus
        return K_coeffs.K4567_plus
    elseif meson === :sigma_pi
        return K_coeffs.K123_minus
    elseif meson === :sigma_K
        return K_coeffs.K4567_minus
    end
    throw(ArgumentError("Unsupported simple meson: $(meson)"))
end

@inline function _phase_shift_pair(meson::Symbol)::Symbol
    if meson === :pi || meson === :pi_plus || meson === :pi_minus || meson === :sigma_pi
        return :K12
    elseif meson === :K || meson === :K_plus || meson === :K_minus || meson === :sigma_K
        return :K45
    end
    throw(ArgumentError("Unsupported phase-shift meson: $(meson)"))
end

@inline function _legacy_phase_shift_interaction(meson::Symbol, K_coeffs)
    pair = meson === :pi || meson === :pi_plus || meson === :pi_minus ? :K123 : :K4567
    channel = meson === :sigma_pi || meson === :sigma_K ? :S : :P
    return PhaseShiftInteractionSpec(
        :legacy_effective,
        pair,
        channel,
        _simple_meson_coupling(meson, K_coeffs),
        numerator_factor=2.0,
        denominator_factor=4.0,
    )
end

@inline function _full_kmt_phase_shift_interaction(meson::Symbol, kernel::FullKMTInteraction)
    if meson === :pi || meson === :K
        throw(ArgumentError("FullKMTInteraction requires charge-resolved mesons; use :pi_plus/:pi_minus/:K_plus/:K_minus"))
    end
    return _full_kmt_phase_shift_interaction_resolved(meson, kernel)
end

@inline function _full_kmt_phase_shift_interaction_resolved(meson::Symbol, kernel::FullKMTInteraction)
    return PhaseShiftInteractionSpec(
        :full_kmt_charged,
        _phase_shift_pair(meson),
        meson === :sigma_pi || meson === :sigma_K ? :S : :P,
        charged_coupling(
            kernel,
            _phase_shift_pair(meson),
            meson === :sigma_pi || meson === :sigma_K ? :S : :P,
        ),
        # Keep the current scalar BU denominator for an apples-to-apples
        # coupling A/B.  The matrix-RPA 2K normalization remains a separate
        # backend and is not silently mixed into this density diagnostic.
        numerator_factor=2.0,
        denominator_factor=4.0,
    )
end

function _resolve_phase_shift_interaction(meson::Symbol, K_coeffs, interaction)
    if interaction === nothing
        return _legacy_phase_shift_interaction(meson, K_coeffs)
    elseif interaction isa PhaseShiftInteractionSpec
        return interaction
    elseif interaction isa FullKMTInteraction
        return _full_kmt_phase_shift_interaction(meson, interaction)
    end
    throw(ArgumentError(
        "interaction must be nothing, PhaseShiftInteractionSpec, or FullKMTInteraction",
    ))
end

@inline function _phase_shift_interaction_metadata(interaction)
    interaction === nothing && return (
        backend=:legacy_effective,
        pair=:unknown,
        channel=:unknown,
        coupling=NaN,
        numerator_factor=NaN,
        denominator_factor=NaN,
    )
    interaction isa FullKMTInteraction && return (
        backend=:full_kmt_charged,
        pair=:unknown,
        channel=:unknown,
        coupling=NaN,
        numerator_factor=2.0,
        denominator_factor=4.0,
    )
    return (
        backend=interaction.backend,
        pair=interaction.pair,
        channel=interaction.channel,
        coupling=interaction.coupling,
        numerator_factor=interaction.numerator_factor,
        denominator_factor=interaction.denominator_factor,
    )
end

function _polarization_components(
    meson::Symbol,
    ω::T,
    q::Real,
    qp,
    tp;
    eta::Float64,
    real_axis_mode::Symbol,
) where {T<:Real}
    pol = _simple_meson_pol_params(meson, qp)
    axis = _resolve_real_axis_config(real_axis_mode, eta)
    Π_re, Π_im = if axis.mode === :finite_eta
        polarization_with_width(
            pol.channel, ω, 2.0 * axis.eta, q,
            pol.m1, pol.m2,
            pol.μ1, pol.μ2,
            tp.T, tp.Φ, tp.Φbar, tp.ξ,
            pol.A1, pol.A2, pol.num_s_quark,
        )
    else
        polarization_aniso(
            pol.channel, ω, q,
            pol.m1, pol.m2,
            pol.μ1, pol.μ2,
            tp.T, tp.Φ, tp.Φbar, tp.ξ,
            pol.A1, pol.A2, pol.num_s_quark,
        )
    end
    TΠ = promote_type(typeof(Π_re), typeof(Π_im))
    return Complex{TΠ}(Π_re, Π_im)
end

function _propagator_components(
    meson::Symbol,
    ω::T,
    q::Real,
    qp,
    tp,
    K_coeffs;
    interaction_spec=nothing,
    eta::Float64,
    real_axis_mode::Symbol,
) where {T<:Real}
    Π = _polarization_components(meson, ω, q, qp, tp; eta=eta, real_axis_mode=real_axis_mode)
    if interaction_spec === nothing
        D = meson_propagator_simple(meson, K_coeffs, Π)
        return real(D), imag(D)
    end
    interaction = interaction_spec === nothing ?
        _legacy_phase_shift_interaction(meson, K_coeffs) : interaction_spec
    K = interaction.coupling
    TΠ = promote_type(typeof(real(Π)), typeof(K))
    denom = one(Π) - TΠ(interaction.denominator_factor) * TΠ(K) * Π
    if !(isfinite(real(denom)) && isfinite(imag(denom)))
        return 0.0, 0.0
    end
    if abs(denom) < TΠ(_PHASE_SHIFT_PROPAGATOR_DENOM_EPS)
        denom += Complex{TΠ}(zero(TΠ), TΠ(_PHASE_SHIFT_PROPAGATOR_DENOM_EPS))
    end
    D = (TΠ(interaction.numerator_factor) * TΠ(K)) / denom
    return real(D), imag(D)
end

function _inverse_propagator_components(
    meson::Symbol,
    ω::T,
    q::Real,
    qp,
    tp,
    K_coeffs;
    interaction_spec=nothing,
    eta::Float64,
    real_axis_mode::Symbol,
) where {T<:Real}
    Π = _polarization_components(meson, ω, q, qp, tp; eta=eta, real_axis_mode=real_axis_mode)
    if interaction_spec === nothing
        K = _simple_meson_coupling(meson, K_coeffs)
        TΠ = promote_type(typeof(real(Π)), typeof(K))
        denom = one(Π) - TΠ(4) * TΠ(K) * Π
        return real(denom), imag(denom)
    end
    interaction = interaction_spec === nothing ?
        _legacy_phase_shift_interaction(meson, K_coeffs) : interaction_spec
    K = interaction.coupling
    TΠ = promote_type(typeof(real(Π)), typeof(K))
    denom = one(Π) - TΠ(interaction.denominator_factor) * TΠ(K) * Π
    return real(denom), imag(denom)
end

function _propagator_phase(
    meson::Symbol,
    ω::T,
    q::Real,
    qp,
    tp,
    K_coeffs;
    interaction_spec=nothing,
    eta::Float64,
    real_axis_mode::Symbol,
    phase_convention::Symbol,
) where {T<:Real}
    convention = _phase_convention_symbol(phase_convention)
    if convention === :arg_inverse_propagator
        reI, imI = _inverse_propagator_components(
            meson, ω, q, qp, tp, K_coeffs;
            interaction_spec=interaction_spec,
            eta=eta,
            real_axis_mode=real_axis_mode,
        )
        return -atan(imI, reI)
    end
    reD, imD = _propagator_components(
        meson, ω, q, qp, tp, K_coeffs;
        interaction_spec=interaction_spec,
        eta=eta,
        real_axis_mode=real_axis_mode,
    )
    return atan(imD, reD)
end

function phase_shift_point_diagnostic(
    meson::Symbol,
    ω::Float64,
    q::Float64,
    quark_params,
    thermo_params;
    scheme::Symbol=:current,
    eta::Float64=DEFAULT_PHASE_SHIFT_ETA,
    real_axis_mode::Symbol=DEFAULT_PHASE_SHIFT_REAL_AXIS_MODE,
    phase_convention::Symbol=DEFAULT_PHASE_SHIFT_PHASE_CONVENTION,
    fd_step::Float64=1e-5,
)
    fd_step > 0.0 || throw(ArgumentError("fd_step must be positive, got $(fd_step)"))
    qp = ensure_quark_params_has_A(quark_params, thermo_params)
    tp = thermo_params
    K_coeffs = _build_k_coeffs(qp)
    scheme_sym = _phase_shift_scheme_symbol(scheme)
    axis = _resolve_real_axis_config(real_axis_mode, eta)
    convention = _phase_convention_symbol(phase_convention)

    re0, im0 = _propagator_components(meson, ω, q, qp, tp, K_coeffs; eta=axis.eta, real_axis_mode=axis.mode)
    phase0 = _propagator_phase(
        meson, ω, q, qp, tp, K_coeffs;
        eta=axis.eta,
        real_axis_mode=axis.mode,
        phase_convention=convention,
    )
    weighted0 = _phase_shift_weighted_phase(phase0, scheme_sym)

    re_fun(x) = first(_propagator_components(meson, x, q, qp, tp, K_coeffs; eta=axis.eta, real_axis_mode=axis.mode))
    im_fun(x) = last(_propagator_components(meson, x, q, qp, tp, K_coeffs; eta=axis.eta, real_axis_mode=axis.mode))
    phase_fun(x) = _propagator_phase(
        meson, x, q, qp, tp, K_coeffs;
        eta=axis.eta,
        real_axis_mode=axis.mode,
        phase_convention=convention,
    )
    weighted_fun(x) = _phase_shift_weighted_phase(phase_fun(x), scheme_sym)

    dre = ForwardDiff.derivative(re_fun, ω)
    dim = ForwardDiff.derivative(im_fun, ω)
    dphase_ad = ForwardDiff.derivative(phase_fun, ω)
    dphase_formula = _phase_derivative_from_components(re0, im0, dre, dim)
    dweighted_ad = ForwardDiff.derivative(weighted_fun, ω)

    dre_fd = (re_fun(ω + fd_step) - re_fun(ω - fd_step)) / (2fd_step)
    dim_fd = (im_fun(ω + fd_step) - im_fun(ω - fd_step)) / (2fd_step)
    dphase_fd = _phase_derivative_from_components(re0, im0, dre_fd, dim_fd)
    dphase_raw_fd = (phase_fun(ω + fd_step) - phase_fun(ω - fd_step)) / (2fd_step)
    dweighted_fd = (weighted_fun(ω + fd_step) - weighted_fun(ω - fd_step)) / (2fd_step)

    return (
        meson=meson,
        omega=ω,
        q=q,
        xi=Float64(tp.ξ),
        temperature=Float64(tp.T),
        eta=axis.eta,
        real_axis_mode=axis.mode,
        polarization_backend=axis.polarization_backend,
        phase_convention=convention,
        fd_step=fd_step,
        scheme=scheme_sym,
        reD=Float64(re0),
        imD=Float64(im0),
        phase=Float64(phase0),
        weighted_phase=Float64(weighted0),
        dReD_domega=Float64(dre),
        dImD_domega=Float64(dim),
        dReD_fd=Float64(dre_fd),
        dImD_fd=Float64(dim_fd),
        dphase_ad=Float64(dphase_ad),
        dphase_formula=Float64(dphase_formula),
        dphase_fd=Float64(dphase_fd),
        dphase_raw_fd=Float64(dphase_raw_fd),
        dphase_abs_diff=abs(Float64(dphase_ad) - Float64(dphase_fd)),
        dphase_formula_abs_diff=abs(Float64(dphase_formula) - Float64(dphase_ad)),
        dphase_raw_fd_abs_diff=abs(Float64(dphase_ad) - Float64(dphase_raw_fd)),
        dweighted_ad=Float64(dweighted_ad),
        dweighted_fd=Float64(dweighted_fd),
        dweighted_abs_diff=abs(Float64(dweighted_ad) - Float64(dweighted_fd)),
    )
end

function phase_shift_meson_number_density_derivative_reference(
    meson::Symbol,
    quark_params,
    thermo_params;
    degeneracy::Integer=meson_degeneracy(meson),
    μ::Float64=0.0,
    scheme::Symbol=:current,
    qmax::Float64=DEFAULT_PHASE_SHIFT_Q_MAX,
    q_nodes::Int=DEFAULT_PHASE_SHIFT_Q_NODES,
    omega_min::Float64=0.05,
    omega_max::Float64=DEFAULT_PHASE_SHIFT_OMEGA_MAX,
    omega_nodes::Int=DEFAULT_PHASE_SHIFT_OMEGA_NODES,
    eta::Float64=DEFAULT_PHASE_SHIFT_ETA,
    real_axis_mode::Symbol=DEFAULT_PHASE_SHIFT_REAL_AXIS_MODE,
    omega_measure::Symbol=DEFAULT_PHASE_SHIFT_OMEGA_MEASURE,
)
    degeneracy > 0 || throw(ArgumentError("degeneracy must be positive, got $(degeneracy)"))
    _require_positive_node_count("q_nodes", q_nodes)
    _require_positive_node_count("omega_nodes", omega_nodes)
    qmax > 0.0 || throw(ArgumentError("qmax must be positive, got $(qmax)"))
    omega_lower = _phase_shift_omega_lower_bound(omega_min, μ)
    omega_max > omega_lower || throw(ArgumentError("omega_max must exceed effective omega_min=$(omega_lower)"))
    scheme_sym = _phase_shift_scheme_symbol(scheme)
    axis = _resolve_real_axis_config(real_axis_mode, eta)
    measure = bu_omega_measure(omega_measure)
    measure_factor = bu_omega_measure_factor(measure)

    tp = thermo_params
    _require_nonnegative("temperature T", Float64(tp.T))
    _require_phase_shift_isotropic_xi(Float64(tp.ξ))
    Float64(tp.T) > 0.0 || return (
        meson=meson,
        density=0.0,
        q_integral_estimate=0.0,
        omega_shell_at_qmax=0.0,
        qmax=qmax,
        q_nodes=q_nodes,
        omega_min=omega_min,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        degeneracy=Int(degeneracy),
        scheme=scheme_sym,
        eta=axis.eta,
        real_axis_mode=axis.mode,
        polarization_backend=axis.polarization_backend,
        omega_measure=measure,
        omega_measure_factor=measure_factor,
        derivative_backend=:forwarddiff,
        max_formula_abs_diff=0.0,
    )

    qp = ensure_quark_params_has_A(quark_params, tp)
    K_coeffs = _build_k_coeffs(qp)
    q_grid, q_w = gauleg(0.0, qmax, q_nodes)
    omega_grid, omega_w = gauleg(omega_lower, omega_max, omega_nodes)

    function q_shell_from_q(q::Float64)
        omega_val = 0.0
        for iω in eachindex(omega_grid, omega_w)
            ω = Float64(omega_grid[iω])
            gω = bose_distribution(ω, μ, Float64(tp.T))
            re0, im0 = _propagator_components(meson, ω, q, qp, tp, K_coeffs; eta=axis.eta, real_axis_mode=axis.mode)
            phase0 = atan(im0, re0)
            weight_factor = _phase_shift_weight_derivative_factor(phase0, scheme_sym)

            re_fun(x) = first(_propagator_components(meson, x, q, qp, tp, K_coeffs; eta=axis.eta, real_axis_mode=axis.mode))
            im_fun(x) = last(_propagator_components(meson, x, q, qp, tp, K_coeffs; eta=axis.eta, real_axis_mode=axis.mode))
            weighted_fun(x) = _phase_shift_weighted_phase(
                _propagator_phase(
                    meson, x, q, qp, tp, K_coeffs;
                    eta=axis.eta,
                    real_axis_mode=axis.mode,
                    phase_convention=DEFAULT_PHASE_SHIFT_PHASE_CONVENTION,
                ),
                scheme_sym,
            )

            dre = ForwardDiff.derivative(re_fun, ω)
            dim = ForwardDiff.derivative(im_fun, ω)
            dphase_formula = _phase_derivative_from_components(re0, im0, dre, dim)
            dweighted_formula = weight_factor * dphase_formula
            dweighted_ad = ForwardDiff.derivative(weighted_fun, ω)
            max_formula_abs_diff = max(max_formula_abs_diff, abs(Float64(dweighted_ad) - Float64(dweighted_formula)))

            omega_val += omega_w[iω] * gω * dweighted_ad
        end
        omega_val *= measure_factor
        return (q^2 / (2.0 * π^2)) * omega_val
    end

    q_shell_weighted_sum = 0.0
    q_shell_at_qmax = 0.0
    max_formula_abs_diff = 0.0
    @inbounds for iq in eachindex(q_grid, q_w)
        q = q_grid[iq]
        q_shell = q_shell_from_q(q)
        q_shell_weighted_sum += q_w[iq] * q_shell
    end
    q_shell_at_qmax = q_shell_from_q(qmax)

    density = Float64(degeneracy) * q_shell_weighted_sum
    return (
        meson=meson,
        density=density,
        q_integral_estimate=q_shell_weighted_sum,
        omega_shell_at_qmax=q_shell_at_qmax,
        qmax=qmax,
        q_nodes=q_nodes,
        omega_min=omega_lower,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        eta=axis.eta,
        real_axis_mode=axis.mode,
        polarization_backend=axis.polarization_backend,
        omega_measure=measure,
        omega_measure_factor=measure_factor,
        degeneracy=Int(degeneracy),
        scheme=scheme_sym,
        derivative_backend=:forwarddiff,
        max_formula_abs_diff=max_formula_abs_diff,
    )
end

function phase_shift_meson_density_derivative_reference_summary(
    quark_params,
    thermo_params;
    pi_channel::Symbol=:pi,
    k_channel::Symbol=:K,
    μ_pi::Float64=0.0,
    μ_K::Float64=0.0,
    d_pi::Integer=meson_degeneracy(:pi),
    d_K::Integer=meson_degeneracy(:K),
    scheme::Symbol=:current,
    qmax::Float64=DEFAULT_PHASE_SHIFT_Q_MAX,
    q_nodes::Int=DEFAULT_PHASE_SHIFT_Q_NODES,
    omega_min::Float64=0.05,
    omega_max::Float64=DEFAULT_PHASE_SHIFT_OMEGA_MAX,
    omega_nodes::Int=DEFAULT_PHASE_SHIFT_OMEGA_NODES,
    eta::Float64=DEFAULT_PHASE_SHIFT_ETA,
    real_axis_mode::Symbol=DEFAULT_PHASE_SHIFT_REAL_AXIS_MODE,
    omega_measure::Symbol=DEFAULT_PHASE_SHIFT_OMEGA_MEASURE,
)
    pi_density = phase_shift_meson_number_density_derivative_reference(
        pi_channel, quark_params, thermo_params;
        μ=μ_pi,
        degeneracy=Int(d_pi), scheme=scheme, qmax=qmax, q_nodes=q_nodes,
        omega_min=omega_min, omega_max=omega_max, omega_nodes=omega_nodes,
        eta=eta, real_axis_mode=real_axis_mode, omega_measure=omega_measure,
    )
    k_density = phase_shift_meson_number_density_derivative_reference(
        k_channel, quark_params, thermo_params;
        μ=μ_K,
        degeneracy=Int(d_K), scheme=scheme, qmax=qmax, q_nodes=q_nodes,
        omega_min=omega_min, omega_max=omega_max, omega_nodes=omega_nodes,
        eta=eta, real_axis_mode=real_axis_mode, omega_measure=omega_measure,
    )
    n_pi = Float64(pi_density.density)
    n_K = Float64(k_density.density)
    return (
        T_fm=Float64(thermo_params.T),
        xi=Float64(thermo_params.ξ),
        pi_channel=pi_channel,
        k_channel=k_channel,
        d_pi=Int(d_pi),
        d_K=Int(d_K),
        n_pi=n_pi,
        n_K=n_K,
        kpi_ratio=iszero(n_pi) ? NaN : n_K / n_pi,
        qmax=qmax,
        q_nodes=q_nodes,
        omega_min=omega_min,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        eta=pi_density.eta,
        real_axis_mode=pi_density.real_axis_mode,
        polarization_backend=pi_density.polarization_backend,
        omega_measure=pi_density.omega_measure,
        omega_measure_factor=pi_density.omega_measure_factor,
        scheme=_phase_shift_scheme_symbol(scheme),
        derivative_backend=:forwarddiff,
        max_formula_abs_diff=max(pi_density.max_formula_abs_diff, k_density.max_formula_abs_diff),
        pi_density=pi_density,
        k_density=k_density,
    )
end

"""
    phase_shift_meson_number_density(meson, quark_params, thermo_params; kwargs...) -> NamedTuple

当前最小 Phase-E3 口径下的单通道相移介子数密度辅助函数。

约束：
- 仅支持 `xi = 0`
- 支持 `:pi` / `:K` 聚合通道以及 `:pi_plus` / `:pi_minus` / `:K_plus` / `:K_minus`
- 数值积分固定采用 GL + 硬截断
"""
function phase_shift_meson_number_density(
    meson::Symbol,
    quark_params,
    thermo_params;
    degeneracy::Integer=meson_degeneracy(meson),
    μ::Float64=0.0,
    scheme::Symbol=:current,
    qmax::Float64=DEFAULT_PHASE_SHIFT_Q_MAX,
    q_nodes::Int=DEFAULT_PHASE_SHIFT_Q_NODES,
    omega_min::Float64=0.05,
    omega_max::Float64=DEFAULT_PHASE_SHIFT_OMEGA_MAX,
    omega_nodes::Int=DEFAULT_PHASE_SHIFT_OMEGA_NODES,
    eta::Float64=DEFAULT_PHASE_SHIFT_ETA,
    real_axis_mode::Symbol=DEFAULT_PHASE_SHIFT_REAL_AXIS_MODE,
    phase_convention::Symbol=DEFAULT_PHASE_SHIFT_PHASE_CONVENTION,
    phase_display::Symbol=:unwrapped,
    phase_anchor::Symbol=DEFAULT_PHASE_SHIFT_PHASE_ANCHOR,
    omega_measure::Symbol=DEFAULT_PHASE_SHIFT_OMEGA_MEASURE,
    density_policy::Symbol=DEFAULT_PHASE_SHIFT_DENSITY_POLICY,
    bose_x_min::Float64=0.0,
    noanom_policy::Symbol=DEFAULT_PHASE_SHIFT_NOANOM_POLICY,
    interaction=nothing,
)
    degeneracy > 0 || throw(ArgumentError("degeneracy must be positive, got $(degeneracy)"))
    _require_positive_node_count("q_nodes", q_nodes)
    _require_positive_node_count("omega_nodes", omega_nodes)
    qmax > 0.0 || throw(ArgumentError("qmax must be positive, got $(qmax)"))
    scheme_sym = _phase_shift_scheme_symbol(scheme)
    axis = _resolve_real_axis_config(real_axis_mode, eta)
    convention = _phase_convention_symbol(phase_convention)
    display = _phase_display_symbol(phase_display)
    anchor = _phase_anchor_symbol(phase_anchor)
    measure = bu_omega_measure(omega_measure)
    measure_factor = bu_omega_measure_factor(measure)
    noanom_diag_empty = _empty_noanom_diag(noanom_policy)
    interaction_meta = _phase_shift_interaction_metadata(interaction)

    tp = thermo_params
    T_fm = Float64(tp.T)
    _require_nonnegative("temperature T", T_fm)
    _require_phase_shift_isotropic_xi(Float64(tp.ξ))
    domain = _phase_shift_energy_domain(
        omega_min,
        omega_max,
        omega_nodes,
        μ,
        T_fm;
        density_policy=density_policy,
        bose_x_min=bose_x_min,
    )

    if T_fm <= 0.0
        return (
            meson=meson,
            density=0.0,
            q_integral_estimate=0.0,
            omega_shell_at_qmax=0.0,
            qmax=qmax,
            q_nodes=q_nodes,
            omega_min=omega_min,
            omega_min_effective=omega_min,
            omega_max=omega_max,
            omega_nodes=omega_nodes,
            degeneracy=Int(degeneracy),
            scheme=scheme_sym,
            eta=axis.eta,
            real_axis_mode=axis.mode,
            polarization_backend=axis.polarization_backend,
            phase_convention=convention,
            phase_display=display,
            phase_anchor=anchor,
            omega_measure=measure,
            omega_measure_factor=measure_factor,
            max_abs_high_energy_phase_before_anchor=NaN,
            max_abs_phase_anchor_shift=NaN,
            max_high_energy_tail_span=NaN,
            density_policy=domain.policy,
            noanom_diag_empty...,
            interaction_backend=interaction_meta.backend,
            interaction_pair=interaction_meta.pair,
            interaction_channel=interaction_meta.channel,
            interaction_coupling=interaction_meta.coupling,
            interaction_numerator_factor=interaction_meta.numerator_factor,
            interaction_denominator_factor=interaction_meta.denominator_factor,
            unsafe_bose_count=0,
            min_E_minus_mu=omega_min - μ,
            bose_x_min=domain.bose_x_min,
            status=:ok,
            message="",
        )
    end

    if domain.unsafe || domain.no_support
        density_val = domain.no_support ? 0.0 : NaN
        return (
        meson=meson,
        density=density_val,
        q_integral_estimate=density_val,
        omega_shell_at_qmax=density_val,
        qmax=qmax,
        q_nodes=q_nodes,
        omega_min=omega_min,
        omega_min_effective=domain.omega_lower,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        degeneracy=Int(degeneracy),
        scheme=scheme_sym,
        eta=axis.eta,
        real_axis_mode=axis.mode,
        polarization_backend=axis.polarization_backend,
        phase_convention=convention,
        phase_display=display,
        phase_anchor=anchor,
        omega_measure=measure,
        omega_measure_factor=measure_factor,
        max_abs_high_energy_phase_before_anchor=NaN,
        max_abs_phase_anchor_shift=NaN,
        max_high_energy_tail_span=NaN,
        density_policy=domain.policy,
        noanom_diag_empty...,
        interaction_backend=interaction_meta.backend,
        interaction_pair=interaction_meta.pair,
        interaction_channel=interaction_meta.channel,
        interaction_coupling=interaction_meta.coupling,
        interaction_numerator_factor=interaction_meta.numerator_factor,
        interaction_denominator_factor=interaction_meta.denominator_factor,
        unsafe_bose_count=domain.unsafe_bose_count,
        min_E_minus_mu=domain.min_E_minus_mu,
        bose_x_min=domain.bose_x_min,
        status=domain.status,
        message=domain.message,
        )
    end

    qp = ensure_quark_params_has_A(quark_params, tp)
    K_coeffs = _build_k_coeffs(qp)
    resolved_interaction = _resolve_phase_shift_interaction(meson, K_coeffs, interaction)
    interaction_meta = _phase_shift_interaction_metadata(resolved_interaction)
    kernel_interaction = interaction === nothing ? nothing : resolved_interaction
    q_grid, q_w = gauleg(0.0, qmax, q_nodes)
    omega_grid, omega_w = gauleg(domain.omega_lower, omega_max, omega_nodes)

    q_shell_weighted_sum = 0.0
    q_shell_at_qmax = NaN
    noanom_removed_component_count = 0
    noanom_removed_omega_min = Inf
    noanom_removed_omega_max = -Inf
    noanom_landau_omega_min = Inf
    noanom_landau_omega_max = -Inf
    noanom_applied = false
    max_abs_high_energy_phase_before_anchor = 0.0
    max_abs_phase_anchor_shift = 0.0
    max_high_energy_tail_span = 0.0
    @inbounds for iq in eachindex(q_grid, q_w)
        q = q_grid[iq]
        phases = [
            _propagator_phase(
                meson, ω, q, qp, tp, K_coeffs;
                interaction_spec=kernel_interaction,
                eta=axis.eta,
                real_axis_mode=axis.mode,
                phase_convention=convention,
            ) for ω in omega_grid
        ]
        phase_unwrapped = if anchor === :high_energy_zero
            endpoint_phase = _propagator_phase(
                meson, omega_max, q, qp, tp, K_coeffs;
                interaction_spec=kernel_interaction,
                eta=axis.eta,
                real_axis_mode=axis.mode,
                phase_convention=convention,
            )
            profile = anchor_phase_high_energy(
                vcat(Float64.(omega_grid), omega_max),
                vcat(Float64.(phases), Float64(endpoint_phase));
                target=0.0,
            )
            max_abs_high_energy_phase_before_anchor = max(
                max_abs_high_energy_phase_before_anchor,
                abs(profile.high_energy_phase_before_anchor),
            )
            max_abs_phase_anchor_shift = max(
                max_abs_phase_anchor_shift,
                abs(profile.applied_shift),
            )
            max_high_energy_tail_span = max(max_high_energy_tail_span, profile.tail_span)
            profile.anchored_phase[1:end-1]
        else
            _unwrap_phases(phases)
        end
        effective_phases, noanom_diag = _apply_noanom_policy(
            meson,
            omega_grid,
            phase_unwrapped,
            qp;
            noanom_policy=noanom_policy,
            phase_display=display,
        )
        noanom_applied |= Bool(noanom_diag.noanom_applied)
        noanom_removed_component_count += Int(noanom_diag.noanom_removed_component_count)
        if isfinite(noanom_diag.noanom_removed_omega_min)
            noanom_removed_omega_min = min(noanom_removed_omega_min, noanom_diag.noanom_removed_omega_min)
            noanom_removed_omega_max = max(noanom_removed_omega_max, noanom_diag.noanom_removed_omega_max)
        end
        if isfinite(noanom_diag.noanom_landau_omega_min)
            noanom_landau_omega_min = min(noanom_landau_omega_min, noanom_diag.noanom_landau_omega_min)
            noanom_landau_omega_max = max(noanom_landau_omega_max, noanom_diag.noanom_landau_omega_max)
        end
        omega_val = 0.0
        for iω in eachindex(omega_grid, omega_w, effective_phases)
            gω = bose_distribution(Float64(omega_grid[iω]), μ, T_fm)
            omega_val += omega_w[iω] * gω * (1.0 + gω) * _phase_shift_weighted_phase(effective_phases[iω], scheme_sym)
        end
        omega_val *= measure_factor
        q_shell = (q^2 / (2.0 * π^2)) * omega_val
        q_shell_weighted_sum += q_w[iq] * q_shell
        if iq == length(q_grid)
            q_shell_at_qmax = q_shell
        end
    end

    density = (Float64(degeneracy) / T_fm) * q_shell_weighted_sum
    return (
        meson=meson,
        density=density,
        q_integral_estimate=q_shell_weighted_sum,
        omega_shell_at_qmax=q_shell_at_qmax,
        qmax=qmax,
        q_nodes=q_nodes,
        omega_min=domain.omega_lower,
        omega_min_effective=domain.omega_lower,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        degeneracy=Int(degeneracy),
        scheme=scheme_sym,
        eta=axis.eta,
        real_axis_mode=axis.mode,
        polarization_backend=axis.polarization_backend,
        phase_convention=convention,
        phase_display=_noanom_policy_symbol(noanom_policy) === :none ? display : :fold_0_pi,
        phase_anchor=anchor,
        omega_measure=measure,
        omega_measure_factor=measure_factor,
        max_abs_high_energy_phase_before_anchor=anchor === :none ? NaN : max_abs_high_energy_phase_before_anchor,
        max_abs_phase_anchor_shift=anchor === :none ? NaN : max_abs_phase_anchor_shift,
        max_high_energy_tail_span=anchor === :none ? NaN : max_high_energy_tail_span,
        density_policy=domain.policy,
        noanom_policy=_noanom_policy_symbol(noanom_policy),
        noanom_applied=noanom_applied,
        noanom_removed_component_count=noanom_removed_component_count,
        noanom_removed_omega_min=noanom_removed_component_count == 0 ? NaN : noanom_removed_omega_min,
        noanom_removed_omega_max=noanom_removed_component_count == 0 ? NaN : noanom_removed_omega_max,
        noanom_landau_omega_min=isfinite(noanom_landau_omega_min) ? noanom_landau_omega_min : NaN,
        noanom_landau_omega_max=isfinite(noanom_landau_omega_max) ? noanom_landau_omega_max : NaN,
        interaction_backend=resolved_interaction.backend,
        interaction_pair=resolved_interaction.pair,
        interaction_channel=resolved_interaction.channel,
        interaction_coupling=resolved_interaction.coupling,
        interaction_numerator_factor=resolved_interaction.numerator_factor,
        interaction_denominator_factor=resolved_interaction.denominator_factor,
        unsafe_bose_count=domain.unsafe_bose_count,
        min_E_minus_mu=domain.min_E_minus_mu,
        bose_x_min=domain.bose_x_min,
        status=domain.status,
        message=domain.message,
    )
end

"""
    phase_shift_meson_density_summary(quark_params, thermo_params; kwargs...) -> NamedTuple

当前最小 Phase-E3 口径下的 `π/K` 聚合通道相移介子数密度总结。
"""
function phase_shift_meson_density_summary(
    quark_params,
    thermo_params;
    pi_channel::Symbol=:pi,
    k_channel::Symbol=:K,
    μ_pi::Float64=0.0,
    μ_K::Float64=0.0,
    d_pi::Integer=meson_degeneracy(:pi),
    d_K::Integer=meson_degeneracy(:K),
    scheme::Symbol=:current,
    qmax::Float64=DEFAULT_PHASE_SHIFT_Q_MAX,
    q_nodes::Int=DEFAULT_PHASE_SHIFT_Q_NODES,
    omega_min::Float64=0.05,
    omega_max::Float64=DEFAULT_PHASE_SHIFT_OMEGA_MAX,
    omega_nodes::Int=DEFAULT_PHASE_SHIFT_OMEGA_NODES,
    eta::Float64=DEFAULT_PHASE_SHIFT_ETA,
    real_axis_mode::Symbol=DEFAULT_PHASE_SHIFT_REAL_AXIS_MODE,
    phase_convention::Symbol=DEFAULT_PHASE_SHIFT_PHASE_CONVENTION,
    phase_display::Symbol=:unwrapped,
    phase_anchor::Symbol=DEFAULT_PHASE_SHIFT_PHASE_ANCHOR,
    omega_measure::Symbol=DEFAULT_PHASE_SHIFT_OMEGA_MEASURE,
    density_policy::Symbol=DEFAULT_PHASE_SHIFT_DENSITY_POLICY,
    bose_x_min::Float64=0.0,
    noanom_policy::Symbol=DEFAULT_PHASE_SHIFT_NOANOM_POLICY,
)
    pi_density = phase_shift_meson_number_density(
        pi_channel, quark_params, thermo_params;
        μ=μ_pi,
        degeneracy=Int(d_pi),
        scheme=scheme,
        qmax=qmax,
        q_nodes=q_nodes,
        omega_min=omega_min,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        eta=eta,
        real_axis_mode=real_axis_mode,
        phase_convention=phase_convention,
        phase_display=phase_display,
        phase_anchor=phase_anchor,
        omega_measure=omega_measure,
        density_policy=density_policy,
        bose_x_min=bose_x_min,
        noanom_policy=noanom_policy,
    )
    k_density = phase_shift_meson_number_density(
        k_channel, quark_params, thermo_params;
        μ=μ_K,
        degeneracy=Int(d_K),
        scheme=scheme,
        qmax=qmax,
        q_nodes=q_nodes,
        omega_min=omega_min,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        eta=eta,
        real_axis_mode=real_axis_mode,
        phase_convention=phase_convention,
        phase_display=phase_display,
        phase_anchor=phase_anchor,
        omega_measure=omega_measure,
        density_policy=density_policy,
        bose_x_min=bose_x_min,
        noanom_policy=noanom_policy,
    )

    n_pi = Float64(pi_density.density)
    n_K = Float64(k_density.density)
    status = if pi_density.status === :ok && k_density.status === :ok
        :ok
    elseif pi_density.status === :unsafe_bose_domain || k_density.status === :unsafe_bose_domain
        :unsafe_bose_domain
    elseif pi_density.status === :no_bose_safe_support || k_density.status === :no_bose_safe_support
        :no_bose_safe_support
    else
        :non_ok
    end
    message = join(filter(!isempty, (String(pi_density.message), String(k_density.message))), " | ")
    removed_mins = filter(isfinite, (pi_density.noanom_removed_omega_min, k_density.noanom_removed_omega_min))
    removed_maxs = filter(isfinite, (pi_density.noanom_removed_omega_max, k_density.noanom_removed_omega_max))
    landau_mins = filter(isfinite, (pi_density.noanom_landau_omega_min, k_density.noanom_landau_omega_min))
    landau_maxs = filter(isfinite, (pi_density.noanom_landau_omega_max, k_density.noanom_landau_omega_max))
    return (
        T_fm=Float64(thermo_params.T),
        xi=Float64(thermo_params.ξ),
        pi_channel=pi_channel,
        k_channel=k_channel,
        d_pi=Int(d_pi),
        d_K=Int(d_K),
        n_pi=n_pi,
        n_K=n_K,
        kpi_ratio=iszero(n_pi) ? NaN : n_K / n_pi,
        qmax=qmax,
        q_nodes=q_nodes,
        omega_min=omega_min,
        omega_max=omega_max,
        omega_nodes=omega_nodes,
        eta=pi_density.eta,
        real_axis_mode=pi_density.real_axis_mode,
        polarization_backend=pi_density.polarization_backend,
        phase_convention=pi_density.phase_convention,
        phase_display=pi_density.phase_display,
        phase_anchor=pi_density.phase_anchor,
        omega_measure=pi_density.omega_measure,
        omega_measure_factor=pi_density.omega_measure_factor,
        max_abs_high_energy_phase_before_anchor=max(
            pi_density.max_abs_high_energy_phase_before_anchor,
            k_density.max_abs_high_energy_phase_before_anchor,
        ),
        max_abs_phase_anchor_shift=max(
            pi_density.max_abs_phase_anchor_shift,
            k_density.max_abs_phase_anchor_shift,
        ),
        max_high_energy_tail_span=max(
            pi_density.max_high_energy_tail_span,
            k_density.max_high_energy_tail_span,
        ),
        density_policy=pi_density.density_policy,
        noanom_policy=pi_density.noanom_policy,
        noanom_applied=pi_density.noanom_applied || k_density.noanom_applied,
        noanom_removed_component_count=pi_density.noanom_removed_component_count + k_density.noanom_removed_component_count,
        noanom_removed_omega_min=isempty(removed_mins) ? NaN : minimum(removed_mins),
        noanom_removed_omega_max=isempty(removed_maxs) ? NaN : maximum(removed_maxs),
        noanom_landau_omega_min=isempty(landau_mins) ? NaN : minimum(landau_mins),
        noanom_landau_omega_max=isempty(landau_maxs) ? NaN : maximum(landau_maxs),
        unsafe_bose_count=pi_density.unsafe_bose_count + k_density.unsafe_bose_count,
        min_E_minus_mu=min(pi_density.min_E_minus_mu, k_density.min_E_minus_mu),
        bose_x_min=max(pi_density.bose_x_min, k_density.bose_x_min),
        status=status,
        message=message,
        scheme=_phase_shift_scheme_symbol(scheme),
        pi_density=pi_density,
        k_density=k_density,
    )
end

end # module MesonDensity
