module GapTransportScanCLI

if !isdefined(Main, :TransportSamplingScanConfig)
    Base.include(Main, joinpath(@__DIR__, "transport_sampling_scan_config.jl"))
end

export ScanOptions
export parse_args
export print_usage

struct ScanOptions
    output::String
    channel_diagnostics_output::Union{Nothing, String}
    failed_points_output::Union{Nothing, String}
    provenance_dir::Union{Nothing, String}
    xi_values::Vector{Float64}
    tmin_mev::Float64
    tmax_mev::Float64
    tstep_mev::Float64
    mubmin_mev::Float64
    mubmax_mev::Float64
    mubstep_mev::Float64
    overwrite::Bool
    resume::Bool
    compute_bulk::Bool
    p_num::Int
    t_num::Int
    max_iter::Int
    tau_p_nodes::Int
    tau_angle_nodes::Int
    tau_phi_nodes::Int
    tau_n_sigma_points::Int
    propagator_xi_policy::Symbol
    sigma_cache_policy::Symbol
    integration_mode::Symbol
    gc_every_n::Int
    tr_p_nodes::Int
    tr_p_max_fm::Float64
    phase_reference_root::Union{Nothing,String}
    phase_reference_layer::Symbol
    phase_reference_mode::Symbol
    sampling_profile::Union{Nothing,String}
end

function print_usage()
    println("Usage: julia --project=. scripts/relaxtime/run_gap_transport_scan.jl [options]\n")
    println("Options:")
    println("  --sampling-profile <name|path>  绑定背景、A、热权重缓存及末端积分（default thermal_weighted_v1）")
    println("  --output <path>             输出 CSV (default data/outputs/results/relaxtime/scan/gap_transport_scan.csv)")
    println("  --channel-diagnostics-output <path>  可选：输出每点每通道的 τ^-1 贡献明细 CSV")
    println("  --failed-points-output <path>        可选：输出跳过失败点 sidecar CSV")
    println("  --provenance-dir <path>              可选：写入 run_manifest/effective_config 的目录（默认 output 同目录）")
    println("  --xi <value>                追加一个 ξ 值（可多次传入）")
    println("  --xi-list v1,v2,...         用逗号分隔的 ξ 列表替换")
    println("  --tmin/--tmax/--tstep <MeV> 温度范围与步长")
    println("  --mubmin/--mubmax/--mubstep <MeV> 重子化学势 μ_B 范围与步长")
    println("  --mumin/--mumax/--mustep <MeV> (兼容旧参数) 夸克化学势 μ_q 范围与步长")
    println("  --overwrite                 覆盖输出文件")
    println("  --no-resume                 禁用跳过逻辑，强制重算")
    println("  --compute-bulk              显式开启体粘滞 ζ 计算（默认开启）")
    println("  --no-compute-bulk           显式关闭体粘滞 ζ 计算")
    println("  --p-num <int>               能隙/密度的动量节点数 (default profile p96)")
    println("  --t-num <int>               能隙/密度的角度节点数 (default profile cos24)")
    println("  --max-iter <int>            NLsolve iterations 上限 (default 40)")
    println("  --tau-p-nodes <int>         τ 平均散射率动量节点 (default $(Main.MODULE_DEFAULT_P_NODES))")
    println("  --tau-angle-nodes <int>     τ 平均散射率 cosθ 节点 (default $(Main.MODULE_DEFAULT_ANGLE_NODES))")
    println("  --tau-phi-nodes <int>       τ 平均散射率 φ 节点 (default $(Main.MODULE_DEFAULT_PHI_NODES))")
    println("  --tau-n-sigma <int>         σ(s) 的 t 积分点数 (default $(Main.RT_ASR.DEFAULT_N_SIGMA_POINTS))")
    println("  --propagator-xi-policy <match_thermo|isotropic>  σ(s)/propagator 的 ξ 口径；isotropic 表示传播子用 ξ=0，外层分布仍用真实 ξ (default match_thermo)")
    println("  --sigma-cache-policy <thermal_weighted>  唯一支持的热权重缓存策略")
    println("  --mode <semi_infinite>      生产配置使用半无穷动量积分")
    println("  --gc-every-n <int>          每 N 个点触发一次 GC (default 5; 0 表示关闭)")
    println("  --tr-p-nodes <int>          输运积分动量节点（须与 profile 一致，default 32）")
    println("  --phase-reference-root <dir>  Issue #130 candidate root（默认使用仓库内 candidate）")
    println("  --phase-reference-layer <accepted|strict|render>  candidate layer (default accepted)")
    println("  --phase-reference-mode <runtime|strict|diagnostic>  accepted runtime (default), explicit strict, or diagnostic view")
    println("  -h, --help                  显示帮助")
end

function parse_args(args::Vector{String})
    Main.TransportSamplingScanConfig.reject_retired_sampling_flags(args)
    opts = Dict{Symbol,Any}(
        :output => joinpath("data", "outputs", "results", "relaxtime", "scan", "gap_transport_scan.csv"),
        :channel_diagnostics_output => nothing,
        :failed_points_output => nothing,
        :provenance_dir => nothing,
        :xi_values => Float64[0.0],
        :tmin => 50.0,
        :tmax => 200.0,
        :tstep => 10.0,
        :mubmin => 0.0,
        :mubmax => 1200.0,
        :mubstep => 60.0,
        :overwrite => false,
        :resume => true,
        :compute_bulk => true,
        :p_num => 12,
        :t_num => 6,
        :max_iter => 40,
        :tau_p_nodes => Main.MODULE_DEFAULT_P_NODES,
        :tau_angle_nodes => Main.MODULE_DEFAULT_ANGLE_NODES,
        :tau_phi_nodes => Main.MODULE_DEFAULT_PHI_NODES,
        :tau_n_sigma => Main.RT_ASR.DEFAULT_N_SIGMA_POINTS,
        :propagator_xi_policy => :match_thermo,
        :sigma_cache_policy => :thermal_weighted,
        :sampling_profile => "thermal_weighted_v1",
        :integration_mode => :semi_infinite,
        :gc_every_n => 5,
        :tr_p_nodes => 24,
        :tr_p_max => 8.0,
        :phase_reference_root => nothing,
        :phase_reference_layer => :accepted,
        :phase_reference_mode => :runtime,
    )

    i = 1
    while i <= length(args)
        arg = args[i]
        function require_value()
            i == length(args) && error("missing value for $arg")
            val = args[i + 1]
            i += 1
            return val
        end
        if arg == "--output"
            opts[:output] = require_value()
        elseif arg == "--channel-diagnostics-output"
            opts[:channel_diagnostics_output] = require_value()
        elseif arg == "--failed-points-output"
            opts[:failed_points_output] = require_value()
        elseif arg == "--provenance-dir"
            opts[:provenance_dir] = require_value()
        elseif arg == "--xi"
            val = parse(Float64, require_value())
            if opts[:xi_values] == Float64[0.0]
                opts[:xi_values] = Float64[]
            end
            push!(opts[:xi_values], val)
        elseif arg == "--xi-list"
            raw = split(require_value(), ',')
            vals = Float64[parse(Float64, strip(v)) for v in raw if !isempty(strip(v))]
            opts[:xi_values] = vals
        elseif arg == "--tmin"
            opts[:tmin] = parse(Float64, require_value())
        elseif arg == "--tmax"
            opts[:tmax] = parse(Float64, require_value())
        elseif arg == "--tstep"
            opts[:tstep] = parse(Float64, require_value())
        elseif arg == "--mubmin"
            opts[:mubmin] = parse(Float64, require_value())
        elseif arg == "--mubmax"
            opts[:mubmax] = parse(Float64, require_value())
        elseif arg == "--mubstep"
            opts[:mubstep] = parse(Float64, require_value())
        elseif arg == "--mumin"
            opts[:mubmin] = 3.0 * parse(Float64, require_value())
        elseif arg == "--mumax"
            opts[:mubmax] = 3.0 * parse(Float64, require_value())
        elseif arg == "--mustep"
            opts[:mubstep] = 3.0 * parse(Float64, require_value())
        elseif arg == "--overwrite"
            opts[:overwrite] = true
        elseif arg == "--no-resume"
            opts[:resume] = false
        elseif arg == "--compute-bulk"
            opts[:compute_bulk] = true
        elseif arg == "--no-compute-bulk"
            opts[:compute_bulk] = false
        elseif arg == "--p-num"
            opts[:p_num] = parse(Int, require_value())
        elseif arg == "--t-num"
            opts[:t_num] = parse(Int, require_value())
        elseif arg == "--max-iter"
            opts[:max_iter] = parse(Int, require_value())
        elseif arg == "--tau-p-nodes"
            opts[:tau_p_nodes] = parse(Int, require_value())
        elseif arg == "--tau-angle-nodes"
            opts[:tau_angle_nodes] = parse(Int, require_value())
        elseif arg == "--tau-phi-nodes"
            opts[:tau_phi_nodes] = parse(Int, require_value())
        elseif arg == "--tau-n-sigma"
            opts[:tau_n_sigma] = parse(Int, require_value())
        elseif arg == "--propagator-xi-policy"
            policy = Symbol(require_value())
            policy in (:match_thermo, :isotropic) || error("unknown propagator xi policy: $(policy) (expected: match_thermo|isotropic)")
            opts[:propagator_xi_policy] = policy
        elseif arg == "--sampling-profile"
            opts[:sampling_profile] = require_value()
        elseif arg == "--sigma-cache-policy"
            policy = Symbol(require_value())
            policy === :thermal_weighted || throw(ArgumentError("only thermal_weighted sampling is supported"))
            opts[:sigma_cache_policy] = policy
        elseif arg == "--mode"
            mode_str = require_value()
            mode_sym = Symbol(mode_str)
            mode_sym in (:semi_infinite, :finite_15, :finite_lambda) || error("unknown mode: $mode_str (expected: semi_infinite, finite_15, finite_lambda)")
            opts[:integration_mode] = mode_sym
        elseif arg == "--gc-every-n"
            opts[:gc_every_n] = parse(Int, require_value())
        elseif arg == "--tr-p-nodes"
            opts[:tr_p_nodes] = parse(Int, require_value())
        elseif arg == "--phase-reference-root"
            opts[:phase_reference_root] = require_value()
        elseif arg == "--phase-reference-layer"
            layer = Symbol(require_value())
            layer in (:accepted, :strict, :render) || error("unknown phase reference layer: $(layer)")
            opts[:phase_reference_layer] = layer
        elseif arg == "--phase-reference-mode"
            mode = Symbol(require_value())
            mode in (:runtime, :strict, :diagnostic) || error("unknown phase reference mode: $(mode)")
            opts[:phase_reference_mode] = mode
        elseif arg in ("-h", "--help")
            print_usage()
            exit(0)
        else
            error("unknown option: $arg")
        end
        i += 1
    end

    Main.TransportSamplingScanConfig.configure_profile!(opts,args;phase_guided=false)

    xi_vals = opts[:xi_values]
    isempty(xi_vals) && (xi_vals = Float64[0.0])
    xi_vals = unique(sort(Float64.(xi_vals)))

    tstep = Float64(opts[:tstep])
    tstep > 0 || error("tstep must be positive")
    mubstep = Float64(opts[:mubstep])
    mubstep > 0 || error("mubstep must be positive")
    opts[:max_iter] > 0 || throw(ArgumentError("--max-iter must be positive"))

    return ScanOptions(
        String(opts[:output]),
        isnothing(opts[:channel_diagnostics_output]) ? nothing : String(opts[:channel_diagnostics_output]),
        isnothing(opts[:failed_points_output]) ? nothing : String(opts[:failed_points_output]),
        isnothing(opts[:provenance_dir]) ? nothing : String(opts[:provenance_dir]),
        xi_vals,
        Float64(opts[:tmin]),
        Float64(opts[:tmax]),
        tstep,
        Float64(opts[:mubmin]),
        Float64(opts[:mubmax]),
        mubstep,
        Bool(opts[:overwrite]),
        Bool(opts[:resume]),
        Bool(opts[:compute_bulk]),
        Int(opts[:p_num]),
        Int(opts[:t_num]),
        Int(opts[:max_iter]),
        Int(opts[:tau_p_nodes]),
        Int(opts[:tau_angle_nodes]),
        Int(opts[:tau_phi_nodes]),
        Int(opts[:tau_n_sigma]),
        Symbol(opts[:propagator_xi_policy]),
        Symbol(opts[:sigma_cache_policy]),
        Symbol(opts[:integration_mode]),
        Int(opts[:gc_every_n]),
        Int(opts[:tr_p_nodes]),
        Float64(opts[:tr_p_max]),
        isnothing(opts[:phase_reference_root]) ? nothing : String(opts[:phase_reference_root]),
        Symbol(opts[:phase_reference_layer]),
        Symbol(opts[:phase_reference_mode]),
        opts[:sampling_profile],
    )
end

end # module GapTransportScanCLI
