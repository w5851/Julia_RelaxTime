"""
# OneLoopIntegrals.jl

有限温度-密度单圈积分实现，包含 B0 (two-line integral) 的数值计算。

公式参考 `doc/formula/B0.md`。
"""
module OneLoopIntegrals

import ..GaussLegendre  # needed by IntervalQuadratureStrategies (bare `GaussLegendre.gauleg`)
include("../integration/IntervalQuadratureStrategies.jl")
using ..GaussLegendre: gauleg
using ForwardDiff
using Main.PNJLQuarkDistributions: quark_distribution, antiquark_distribution,
    quark_distribution_integral, antiquark_distribution_integral
using Main.Constants_PNJL: Λ_inv_fm

export B0, B0_pv_cut, B0_retarded, B0_spectral_cut, A

# ----------------------------------------------------------------------------
# 基础工具函数
const EPS_K = 1.0e-9 # 三动量k大小为零的判定阈值
const EPS_SEGMENT = 1.0e-12 # 分母的最小值判定阈值

# hybrid 求积默认节点数（热点路径：优先性能）
const HYBRID_N_SMOOTH = 16
const HYBRID_N_SING = 32

"""k=0 主值积分在端点贴近极点时挖掉的对称 gap（相对区间长度的比例）。

默认 PV 实部使用“奇点减法 + 解析对数项”，不依赖 quadgk。
仅当极点数值上贴近积分端点，导致对数项不稳定时，回退到“挖掉小 gap + 分段策略积分”。
"""
const PV_GAP_REL = 1e-6
"""计算给定质量下的能量截断值"""
@inline @fastmath function energy_cutoff(m::Real)
    m_pos = max(m, 0.0)
    return sqrt(m_pos * m_pos + Λ_inv_fm * Λ_inv_fm)
end

"""计算给定能量和质量对应的动量"""
@inline @fastmath function internal_momentum(E::T, m::Real) where {T<:Real}
    m_pos = max(m, 0.0)
    return sqrt(E * E - m_pos * m_pos)
end

@inline _primal_value(x::Float64) = x
@inline _primal_value(x::ForwardDiff.Dual) = ForwardDiff.value(x)

"""计算夸克有效分布函数的值（供 A 积分使用：分别用夸克/反夸克分布）"""
@inline function distribution_value(mode::Symbol, sign_flag::Symbol, E::Real, μ::Real,
    T::Real, Φ::Real, Φbar::Real)
    @assert sign_flag === :plus || sign_flag === :minus "sign_flag must be :plus or :minus"
    if mode === :pnjl
        if sign_flag === :plus
            return quark_distribution(E, μ, T, Φ, Φbar)
        else
            return antiquark_distribution(E, μ, T, Φ, Φbar)
        end
    else
        throw(ArgumentError("暂不支持的 distribution: $mode"))
    end
end

"""B0 中使用的“±”分布（只在正能量 E 上评估，避免负能量导致溢出）。

等价目标：与参考实现的 `fd(pm*E, mu)` 一致。

注意：当前 PNJL 分布的实现形式在 E<0 时会出现 exp_term^2 溢出，
因此这里必须使用稳定恒等式把 `fd(-E,mu)` 映射回正能量表达。
"""
@inline function distribution_value_b0(sign_flag::Symbol, E::Real, μ::Real, T::Real, Φ::Real, Φbar::Real)
    @assert sign_flag === :plus || sign_flag === :minus "sign_flag must be :plus or :minus"

    # 重要：这里的 μ 具有“真实物理含义”，允许为负；不能用 μ 的正负来暗示粒子/反粒子。
    # B0 文档约定：
    # - :plus  => f^+(+E, μ)
    # - :minus => f^+(-E, μ) = 1 - f^-(+E, μ)
    # 且只在正能量 E 上评估以避免 E<0 时的指数溢出。
    if sign_flag === :plus
        return quark_distribution(E, μ, T, Φ, Φbar)
    else
        return 1.0 - antiquark_distribution(E, μ, T, Φ, Φbar)
    end
end

@inline function distribution_integral_b0(sign_flag::Symbol, E_min::Real, E_max::Real,
    μ::Real, T::Real, Φ::Real, Φbar::Real)
    @assert sign_flag === :plus || sign_flag === :minus "sign_flag must be :plus or :minus"

    # 与 distribution_value_b0 保持一致：
    # :plus  -> ∫ f^+(E, μ) dE
    # :minus -> ∫ f^+(-E, μ) dE = ∫ (1 - f^-(E, μ)) dE = (E_max-E_min) - ∫ f^-(E, μ) dE
    if sign_flag === :plus
        return quark_distribution_integral(E_min, E_max, μ, T, Φ, Φbar)
    else
        interval_len = E_max - E_min
        return interval_len - antiquark_distribution_integral(E_min, E_max, μ, T, Φ, Φbar)
    end
end

"""计算夸克有效分布函数在给定能量区间的积分"""
@inline function distribution_integral(mode::Symbol, sign_flag::Symbol, E_min::Real, E_max::Real,
    μ::Real, T::Real, Φ::Real, Φbar::Real)
    @assert sign_flag === :plus || sign_flag === :minus "sign_flag must be :plus or :minus"
    if mode === :pnjl
        if sign_flag === :plus
            return quark_distribution_integral(E_min, E_max, μ, T, Φ, Φbar)
        else
            return antiquark_distribution_integral(E_min, E_max, μ, T, Φ, Φbar)
        end
    else
        throw(ArgumentError("暂不支持的 distribution: $mode"))
    end
end
# -----------------------------------------------------------------------------
# k=0 时的积分计算相关函数
"""k=0时的积分实部被积函数"""
@inline function real_integrand_k_zero(sign_flag::Symbol, λ::T, m::Real, denominator_term::T,
    μ::Real, T0::Real, Φ::Real, Φbar::Real, E::Real) where {T<:Real}
    p = internal_momentum(E, m)
    dist = distribution_value_b0(sign_flag, E, μ, T0, Φ, Φbar)
    denominator = λ * E + denominator_term
    if !isfinite(p) || !isfinite(dist) || !isfinite(denominator)
        return zero(denominator)
    end
    if abs(denominator) < EPS_SEGMENT
        # PV 附近直接返回 0，避免 1/0 -> Inf/NaN
        return zero(denominator)
    end
    val = p * dist / denominator
    return isfinite(val) ? val : zero(val)
end

"""k=0时的奇点计算函数
返回位于 (Emin, Emax) 内的 E 奇点值列表；若无奇点则返回空列表"""
@inline function singularity_k_zero(λ::T, Emin::Float64, Emax::Float64, denominator_term::T)::Vector{Float64} where {T<:Real}
    λ0 = _primal_value(λ)
    denominator0 = _primal_value(denominator_term)
    E0 = -denominator0 / λ0
    if !isfinite(E0)
        return Float64[]
    end

    # 允许 E0 贴近端点（数值误差内）也被识别出来
    tol = 1e-8 * max(1.0, abs(E0))
    if (E0 > Emin - tol) && (E0 < Emax + tol)
        return [E0]
    else
        return Float64[]
    end
end

"""三动量大小k=0(小于EPS_K)时的 B0分量 积分计算"""
@inline function tilde_B0_k_zero(sign_flag::Symbol, λ::T, m::Real, m_prime::Real, μ::Real, T0::Real,
    Φ::Real, Φbar::Real) where {T<:Real}
    Tout = promote_type(T, typeof(T0), typeof(Φ), typeof(Φbar))
    m_pos = max(m, 0.0)
    m_prime_pos = max(m_prime, 0.0)
    Emin = m_pos
    Emax = energy_cutoff(m_pos)
    denominator_term = (λ ^ 2 + m_pos ^ 2 - m_prime_pos ^ 2) / T(2)
    singularity = singularity_k_zero(λ, Emin, Emax, denominator_term)
    integrand_fun(E) = real_integrand_k_zero(sign_flag, λ, m_pos, denominator_term,
        μ, T0, Φ, Φbar, E) # 闭包被积函数

    imag_part = zero(Tout)
    if isempty(singularity) # 无奇点
        real_part = integrate_hybrid_interval(integrand_fun, Emin, Emax, SING_NONE; n=HYBRID_N_SMOOTH)
        return real_part * Tout(2), imag_part / λ
    end

    # 有奇点：主值积分（PV）。
    # 默认使用“奇点减法 + 解析对数项”，避免在 JIT 路径中引入 quadgk。
    E0 = singularity[1]

    @inline function numer(E::Float64)
        p = internal_momentum(E, m_pos)
        dist = distribution_value_b0(sign_flag, E, μ, T0, Φ, Φbar)
        if !isfinite(p) || !isfinite(dist)
            return 0.0
        end
        val = p * dist
        return isfinite(val) ? val : 0.0
    end

    f0 = numer(E0)

    # 若极点贴近端点，解析对数项会引入 log(0) 的不稳定；此时回退到挖 gap 的分段策略积分。
    endpoint_tol = 1e-10 * max(1.0, Emax - Emin)
    if abs(E0 - Emin) <= endpoint_tol || abs(Emax - E0) <= endpoint_tol
        gap = max(PV_GAP_REL * (Emax - Emin), 64 * eps(E0))
        left_end = max(Emin, E0 - gap)
        right_start = min(Emax, E0 + gap)
        pv_integral = 0.0
        if left_end > Emin
            pv_integral += integrate_hybrid_interval(integrand_fun, Emin, left_end, SING_NONE; n=HYBRID_N_SMOOTH)
        end
        if right_start < Emax
            pv_integral += integrate_hybrid_interval(integrand_fun, right_start, Emax, SING_NONE; n=HYBRID_N_SMOOTH)
        end
    else
        @inline function regular_integrand(E::Float64)
            d = E - E0
            if abs(d) < 64 * eps(E0)
                δ = max(1e-7 * (Emax - Emin), 64 * eps(E0))
                El = max(Emin, E0 - δ)
                Er = min(Emax, E0 + δ)
                if Er > El
                    return (numer(Er) - numer(El)) / (Er - El)
                else
                    return 0.0
                end
            end
            return (numer(E) - f0) / d
        end

        regular = integrate_hybrid_interval(regular_integrand, Emin, Emax, SING_NONE; n=HYBRID_N_SING)
        logterm = f0 * (log(abs(Emax - E0)) - log(abs(Emin - E0)))
        pv_integral = (regular + logterm) / λ
    end

    # 解析虚部（残数项）
    p0 = internal_momentum(E0, m_pos)
    imag_part = Tout(2π) * p0 * distribution_value_b0(sign_flag, E0, μ, T0, Φ, Φbar)

    # 与无奇点分支保持相同归一化：返回 2×(PV 积分结果)
    return pv_integral * Tout(2), imag_part / λ
end
# ----------------------------------------------------------------------------
# k>0 时的积分计算相关函数
"""k>0 时的积分实部被积函数"""
@inline @fastmath function real_integrand_k_positive(sign_flag::Symbol, λ::T, k::Real, m::Real, m_prime::Real,
    μ::Real, T0::Real, Φ::Real, Φbar::Real, E::Real) where {T<:Real}
    p = internal_momentum(E, m)
    dist = distribution_value_b0(sign_flag, E, μ, T0, Φ, Φbar)
    common_part = (λ + E)^2 - m_prime^2
    numerator = common_part - (p - k)^2
    denominator = common_part - (p + k)^2
    if !isfinite(p) || !isfinite(dist) || !isfinite(numerator) || !isfinite(denominator)
        return zero(common_part)
    end

    # 避免 0/0 -> NaN（这是你看到 quadgk 报 NaN 的典型触发点）
    if abs(numerator) < EPS_SEGMENT && abs(denominator) < EPS_SEGMENT
        return zero(common_part)
    end

    # 避免除以 0 造成 Inf/NaN
    if abs(denominator) < EPS_SEGMENT
        denominator = (denominator == zero(T)) ? T(EPS_SEGMENT) : sign(denominator) * T(EPS_SEGMENT)
    end

    ratio = abs(numerator / denominator)
    if !isfinite(ratio)
        return zero(ratio)
    end
    ratio = max(ratio, T(1e-300))
    log_term = log(ratio)
    if !isfinite(log_term)
        return zero(log_term)
    end
    val = dist * log_term
    return isfinite(val) ? val : zero(val)
end

"""
k>0 时的奇点计算函数
根据二次项系数 a = λ² - k² 的符号，返回虚部积分区间的元组 (intervals, sign_type)
- intervals: Vector{Tuple{Float64, Float64}} 虚部积分区间列表
- sign_type: Symbol, 表示区间的类型 (:between, :outside, :none)

根据 B0_extra.md 文档:
- a > 0 (λ² > k²): 虚部积分区间为 [E1, E2]
- a < 0 (λ² < k²): 虚部积分区间为 [Emin, E1] ∪ [E2, Emax]
- a ≈ 0 (λ² ≈ k²): 退化为线性情况，特殊处理
"""
@inline function singularity_k_positive(λ::T, k::Float64, m::Float64, m_prime::Float64,
    Emin::Float64, Emax::Float64)::Tuple{Vector{Tuple{Float64, Float64}}, Symbol} where {T<:Real}
    # 解析解：
    # E_{1,2} = [λ(λ^2 - k^2 + m^2 - m'^2) ± k * sqrt((λ^2 - k^2 + m^2 - m'^2)^2 - 4 m^2 (k^2 - λ^2))] / [2 (k^2 - λ^2)]
    
    intervals = Tuple{Float64, Float64}[]
    
    λ0 = _primal_value(λ)
    a = λ0 ^ 2 - k ^ 2                # 二次项系数
    d0 = k ^ 2 - λ0 ^ 2               # 分母的一半系数 (未乘 2) = -a
    denom = 2.0 * d0                 # 实际分母 2(k^2 - λ^2) = -2a
    
    # 情况3: a ≈ 0 (λ² ≈ k²)，退化为线性情况
    if abs(a) < EPS_SEGMENT
        # 原方程退化为线性: |2λE + m² - m'²| < 2k√(E² - m²)
        # 根据 B0_extra.md 文档:
        # 有解条件: λ > 0 且 m' > m
        # 解的范围: E > (m'² - m²)/(4λ) + λm²/(m'² - m²)
        
        if λ0 > 0.0 && m_prime > m
            # 计算临界能量
            m2_diff = m_prime ^ 2 - m ^ 2
            E_crit = m2_diff / (4.0 * λ0) + λ0 * m ^ 2 / m2_diff
            
            # 虚部积分区间为 [max(E_crit, Emin), Emax]
            if E_crit < Emax
                E_start = max(E_crit, Emin)
                push!(intervals, (E_start, Emax))
            end
        end
        # 如果 λ ≤ 0 或 m' ≤ m，则无解，返回空区间
        return (intervals, :none)
    end
    
    A = λ0 ^ 2 - k ^ 2 + m ^ 2 - m_prime ^ 2
    disc = A ^ 2 + 4.0 * m ^ 2 * d0    # 判别式
    
    # 判别式为负无实根
    if disc < 0.0
        return (intervals, :none)
    end
    
    sqrt_disc = sqrt(disc)
    E1 = (λ0 * A - k * sqrt_disc) / denom
    E2 = (λ0 * A + k * sqrt_disc) / denom
    
    # 保证 E1 <= E2
    if E1 > E2
        E1, E2 = E2, E1
    end
    
    # 两根过于接近，视为无奇点
    if E2 - E1 < EPS_SEGMENT
        return (intervals, :none)
    end
    
    # 情况1: a > 0 (λ² > k², 即 d0 < 0)
    # 虚部积分区间为 [E1, E2]
    if a > 0.0
        # 检查 [E1, E2] 与 [Emin, Emax] 的交集
        if E2 > Emin && E1 < Emax
            E1_clipped = max(E1, Emin)
            E2_clipped = min(E2, Emax)
            if E2_clipped > E1_clipped
                push!(intervals, (E1_clipped, E2_clipped))
            end
        end
        return (intervals, :between)
    else
        # 情况2: a < 0 (λ² < k², 即 d0 > 0)
        # 虚部积分区间为 [Emin, E1] ∪ [E2, Emax]
        # 区间1: [Emin, E1]
        if E1 > Emin
            E1_clipped = min(E1, Emax)
            if E1_clipped > Emin
                push!(intervals, (Emin, E1_clipped))
            end
        end
        # 区间2: [E2, Emax]
        if E2 < Emax
            E2_clipped = max(E2, Emin)
            if Emax > E2_clipped
                push!(intervals, (E2_clipped, Emax))
            end
        end
        return (intervals, :outside)
    end
end

"""k>0 时的 B0分量 积分计算"""

# ---------------------------------------------------------------------------

# 固定 hybrid：按奇点分割区间并选择映射（无分配快路径）
@inline function integrate_piecewise_hybrid(integrand_fun::F, Emin::Float64, Emax::Float64,
    intervals::Vector{Tuple{Float64, Float64}}) where {F}

    if isempty(intervals)
        return integrate_hybrid_interval(integrand_fun, Emin, Emax, SING_NONE; n=HYBRID_N_SMOOTH)
    end

    # 热点优化：singularity_k_positive 只会返回 1 或 2 个区间（:between / :outside）。
    # 直接按结构分段，避免构造 pts / sort / unique 的分配。
    if length(intervals) == 1
        E1, E2 = intervals[1]
        total = 0.0
        if E1 > Emin
            total += integrate_hybrid_interval(integrand_fun, Emin, E1, SING_RIGHT; n=HYBRID_N_SING)
        end
        if E2 > E1
            total += integrate_hybrid_interval(integrand_fun, E1, E2, SING_BOTH; n=HYBRID_N_SING)
        end
        if Emax > E2
            total += integrate_hybrid_interval(integrand_fun, E2, Emax, SING_LEFT; n=HYBRID_N_SMOOTH)
        end
        return total
    elseif length(intervals) == 2
        # 期望形态： (Emin, E1) 与 (E2, Emax)
        a1, b1 = intervals[1]
        a2, b2 = intervals[2]
        tol = 1e-12 * max(1.0, Emax - Emin)

        E1 = NaN
        E2 = NaN
        if abs(a1 - Emin) <= tol
            E1 = b1
        elseif abs(a2 - Emin) <= tol
            E1 = b2
        end

        if abs(b1 - Emax) <= tol
            E2 = a1
        elseif abs(b2 - Emax) <= tol
            E2 = a2
        end

        if !(isfinite(E1) && isfinite(E2))
            # 非预期形态，回退到通用逻辑
        else
            total = 0.0
            if E1 > Emin
                total += integrate_hybrid_interval(integrand_fun, Emin, E1, SING_RIGHT; n=HYBRID_N_SING)
            end
            if E2 > E1
                total += integrate_hybrid_interval(integrand_fun, E1, E2, SING_BOTH; n=HYBRID_N_SING)
            end
            if Emax > E2
                total += integrate_hybrid_interval(integrand_fun, E2, Emax, SING_LEFT; n=HYBRID_N_SMOOTH)
            end
            return total
        end
    end

    pts = Float64[Emin]
    for (a, b) in intervals
        push!(pts, a)
        push!(pts, b)
    end
    push!(pts, Emax)
    pts = sort(unique(pts))

    nseg = length(pts) - 1
    if nseg <= 0
        return 0.0
    elseif nseg == 1
        return integrate_hybrid_interval(integrand_fun, pts[1], pts[2], SING_NONE; n=HYBRID_N_SMOOTH)
    end

    total = 0.0
    for i in 1:nseg
        a = pts[i]
        b = pts[i + 1]
        if !(isfinite(a) && isfinite(b)) || b <= a
            continue
        end

        sing_pos = (i == 1) ? SING_RIGHT : (i == nseg ? SING_LEFT : SING_BOTH)
        n_nodes = (i == nseg) ? HYBRID_N_SMOOTH : HYBRID_N_SING
        total += integrate_hybrid_interval(integrand_fun, a, b, sing_pos; n=n_nodes)
    end
    return total
end

function tilde_B0_k_positive(sign_flag::Symbol, λ::T, k::Real, m::Real, m_prime::Real, μ::Real, T0::Real,
    Φ::Real, Φbar::Real) where {T<:Real}
    Tout = promote_type(T, typeof(T0), typeof(Φ), typeof(Φbar))
    m_pos = max(m, 0.0)
    m_prime_pos = max(m_prime, 0.0)
    Emin = m_pos
    Emax = energy_cutoff(m_pos)
    integrand_fun(E) = real_integrand_k_positive(sign_flag, λ, k, m_pos, m_prime_pos, μ, T0, Φ, Φbar, E) # 闭包被积函数
    intervals, _ = singularity_k_positive(λ, k, m_pos, m_prime_pos, Emin, Emax)
    
    imag_part = zero(Tout)
    real_part = integrate_piecewise_hybrid(integrand_fun, Emin, Emax, intervals)
    
    # 根据区间类型计算虚部
    if !isempty(intervals)
        for (E1, E2) in intervals
            imag_part += distribution_integral_b0(sign_flag, E1, E2, μ, T0, Φ, Φbar)
        end
        imag_part *= Tout(π) * sign(λ)
    end
    
    return real_part / k, imag_part / k
end

"""计算单个 ̃B0 分量的函数"""
@inline function tilde_B0(sign_flag::Symbol, λ::T, k::Real, m::Real, m_prime::Real, μ::Real, T0::Real,
    Φ::Real, Φbar::Real) where {T<:Real}
    if abs(k) < EPS_K
        return tilde_B0_k_zero(sign_flag, λ, m, m_prime, μ, T0, Φ, Φbar)
    else
        return tilde_B0_k_positive(sign_flag, λ, k, m, m_prime, μ, T0, Φ, Φbar)
    end
end

"""
    B0(λ, k, m1, μ1, m2, μ2, T; Φ=0.0, Φbar=0.0)
根据文档公式组合四个 ̃B0 项得到完整的 B₀ 积分。
λ = k0 + μ1 - μ2, 其中k0是传播子能量
"""
function B0(λ::T, k::Real, m1::Real, μ1::Real, m2::Real, μ2::Real, T0::Real;
    Φ::Real=0.0, Φbar::Real=0.0) where {T<:Real}
    term1 = tilde_B0(:plus, -λ, k, m1, m2, μ1, T0, Φ, Φbar)
    term2 = tilde_B0(:minus, λ, k, m1, m2, μ1, T0, Φ, Φbar)
    term3 = tilde_B0(:plus, λ, k, m2, m1, μ2, T0, Φ, Φbar)
    term4 = tilde_B0(:minus, -λ, k, m2, m1, μ2, T0, Φ, Φbar)

    real_part = term1[1] - term2[1] + term3[1] - term4[1]
    imag_part = term1[2] - term2[2] + term3[2] - term4[2]
    return real_part, imag_part
end

"""
    _tilde_B0_retarded_cut_imag(sign_flag, w, k, m, m_prime, μ, T, Φ, Φbar,
                                 epsilon_sign)

Return the analytic `eta -> 0+` imaginary part of one logarithmic
`tilde_B0` term. `w` is the real part of the term's complex argument and
`epsilon_sign` is the sign of its infinitesimal imaginary part. The sign is
fixed pointwise by the principal-log boundary rather than by a global flip of
the historical `B0` cut.
"""
function _tilde_B0_retarded_cut_imag(
    sign_flag::Symbol,
    w::Real,
    k::Real,
    m::Real,
    m_prime::Real,
    μ::Real,
    T0::Real,
    Φ::Real,
    Φbar::Real,
    epsilon_sign::Integer,
)
    w_value = Float64(w)
    k_value = Float64(k)
    m_value = max(Float64(m), 0.0)
    m_prime_value = max(Float64(m_prime), 0.0)
    μ_value = Float64(μ)
    T_value = Float64(T0)
    Φ_value = Float64(Φ)
    Φbar_value = Float64(Φbar)
    epsilon_sign in (-1, 1) || throw(ArgumentError("epsilon_sign must be +1 or -1"))

    # At k=0, D(E)=z^2+2zE+m^2-m'^2 and the residue follows from
    # 1/(x+i0*s)=PV(1/x)-i*pi*sign(s)*delta(x).
    if abs(k_value) < EPS_K
        abs(w_value) > EPS_SEGMENT || return 0.0
        Emin = m_value
        Emax = energy_cutoff(m_value)
        denominator_term = (w_value^2 + m_value^2 - m_prime_value^2) / 2.0
        singularity = singularity_k_zero(w_value, Emin, Emax, denominator_term)
        isempty(singularity) && return 0.0
        E0 = singularity[1]
        p0 = internal_momentum(E0, m_value)
        dist0 = distribution_value_b0(sign_flag, E0, μ_value, T_value, Φ_value, Φbar_value)
        boundary_sign = sign(epsilon_sign * (w_value + E0))
        return -2.0 * π * p0 * dist0 / abs(w_value) * boundary_sign
    end

    Emin = m_value
    Emax = energy_cutoff(m_value)
    intervals, _ = singularity_k_positive(
        w_value, k_value, m_value, m_prime_value, Emin, Emax,
    )
    isempty(intervals) && return 0.0

    # The sign of Im[(w+i0+E)^2] can change at E=-w. Split there so the
    # principal-log boundary sign is constant on every subinterval.
    total = 0.0
    for (left, right) in intervals
        points = Float64[left]
        if left < -w_value < right
            push!(points, -w_value)
        end
        push!(points, right)
        sort!(points)
        for j in 1:(length(points) - 1)
            a, b = points[j], points[j + 1]
            b > a || continue
            midpoint = (a + b) / 2.0
            p = internal_momentum(midpoint, m_value)
            common = (w_value + midpoint)^2 - m_prime_value^2
            numerator = common - (p - k_value)^2
            denominator = common - (p + k_value)^2
            log_branch = (numerator < 0.0 ? 1 : 0) - (denominator < 0.0 ? 1 : 0)
            log_branch == 0 && continue
            boundary_sign = sign(epsilon_sign * (w_value + midpoint))
            total += boundary_sign * log_branch * distribution_integral_b0(
                sign_flag, a, b, μ_value, T_value, Φ_value, Φbar_value,
            )
        end
    end
    return π * total / k_value
end

raw"""
    B0_pv_cut(λ, k, m1, μ1, m2, μ2, T; Φ=0.0, Φbar=0.0)

Return the ordered real-axis PV/cut value using the repository's analytic
principal-value implementation and the `e^{-iωt}` retarded boundary value.

`B0` is retained as the historical real-axis oracle. Its PV real part is
reused, but its cut component is not related to the ordered retarded value by
one global sign. Each of the four logarithmic terms has its own argument
`w=+/-lambda` and infinitesimal sign, so the cut is recomputed term by term:

```math
B_0^{\mathrm{PV+ret}} = \operatorname{PV}B_0 + i\operatorname{Im}B_0^{R},
\qquad
\operatorname{Im}B_0^{R}=\sum_{j=1}^{4}s_j\operatorname{Im}\widetilde B_{0,j}^{R}.
```

This is not a change to `B0`'s legacy semantics and does not claim that the
finite-window regulator, endpoint fallbacks, or numerical cut partition are
production-converged.  Callers must still perform `eta`, node, and cutoff
comparisons against `B0_retarded`.

The 2026-09-05 independent spectral audit found spurious vacuum-spacelike
weight in this continuation. Agreement with B0_retarded is not physical-cut
certification. B0_spectral_cut is a separate cut-only oracle, not a replacement.
"""
function B0_pv_cut(λ::T, k::Real, m1::Real, μ1::Real, m2::Real, μ2::Real, T0::Real;
    Φ::Real=0.0, Φbar::Real=0.0) where {T<:Real}
    term1 = tilde_B0(:plus, -λ, k, m1, m2, μ1, T0, Φ, Φbar)
    term2 = tilde_B0(:minus, λ, k, m1, m2, μ1, T0, Φ, Φbar)
    term3 = tilde_B0(:plus, λ, k, m2, m1, μ2, T0, Φ, Φbar)
    term4 = tilde_B0(:minus, -λ, k, m2, m1, μ2, T0, Φ, Φbar)

    real_part = term1[1] - term2[1] + term3[1] - term4[1]
    λ_value = Float64(λ)
    if abs(λ_value) <= EPS_SEGMENT
        return ComplexF64(real_part, 0.0)
    end
    imag_part =
        _tilde_B0_retarded_cut_imag(:plus, -λ_value, k, m1, m2, μ1, T0, Φ, Φbar, -1) -
        _tilde_B0_retarded_cut_imag(:minus, λ_value, k, m1, m2, μ1, T0, Φ, Φbar, 1) +
        _tilde_B0_retarded_cut_imag(:plus, λ_value, k, m2, m1, μ2, T0, Φ, Φbar, 1) -
        _tilde_B0_retarded_cut_imag(:minus, -λ_value, k, m2, m1, μ2, T0, Φ, Φbar, -1)
    return ComplexF64(real_part, imag_part)
end

# ---------------------------------------------------------------------------
# Strict ordered retarded continuation

"""Exact energy support of the intersection of two radius-L momentum balls.

The extrema include collinear stationary points and cutoff surfaces. This is
a geometric exclusion, not a threshold on a small spectral occupation weight.
"""
function _spectral_two_line_support(q, a, b, L)
    q >= 2L && return nothing
    left, right = max(0.0,q-L), L
    p = clamp(q*a/(a+b),left,right)
    pair = (hypot(p,a)+hypot(p-q,b),hypot(L,a)+hypot(L,b))
    function maximum_difference(a,b)
        value = max(hypot(left,a)-hypot(left-q,b),hypot(right,a)-hypot(right-q,b))
        if a != b
            stationary = q*a/(a-b)
            if left <= stationary <= right
                value = max(value,hypot(stationary,a)-hypot(stationary-q,b))
            end
        end
        return value
    end
    return (pair=pair,landau=(-maximum_difference(b,a),maximum_difference(a,b)))
end

function _spectral_cut_intervals(lambda, q, m1, m2, pmax, s, t)
    lo, hi = m1, hypot(m1,pmax)
    d = lambda^2 - q^2 + m1^2 - m2^2
    a = lambda^2 - q^2
    points = [lo,hi]
    for edge in (m2,hypot(m2,pmax))
        x = s*(lambda+t*edge)
        lo < x < hi && push!(points,x)
    end
    # Angular delta support: (2*s*lambda*E-d)^2 < 4*q^2*(E^2-m1^2).
    if abs(a) <= 64eps(Float64)*max(lambda^2,q^2,1.0)
        b, c = -4s*lambda*d, d^2+4q^2*m1^2
        if b != 0
            x = -c/b
            lo < x < hi && push!(points,x)
        end
    else
        disc = d^2-4a*m1^2
        if disc >= 0
            for x in ((s*lambda*d-q*sqrt(disc))/(2a),(s*lambda*d+q*sqrt(disc))/(2a))
                lo < x < hi && push!(points,x)
            end
        end
    end
    sort!(points)
    unique!(points)
    intervals = Tuple{Float64,Float64}[]
    for i in 1:length(points)-1
        left, right = points[i],points[i+1]
        E1 = (left+right)/2
        E2 = t*(s*E1-lambda)
        E2 > m2 || continue
        E2 < hypot(m2,pmax) || continue
        p = sqrt(E1^2-m1^2)
        abs(2s*lambda*E1-d) < 2p*q || continue
        push!(intervals,(left,right))
    end
    return intervals
end

"""Independent ordered two-line spectral cut, with no inherited PV/log branches.

Uses the Matsubara residue sum
`sum(s*t*(n(t*E2,mu2)-n(s*E1,mu1))/(lambda-s*E1+t*E2+i0))`
and integrates its angular delta function analytically. Both line momenta
obey the explicit `pmax_inv_fm` cutoff. This regulator is NOT asserted equal
to the shifted one-line cutoffs used by legacy B0. The result contains only
Im B0; mixing it with a different PV real part is not an analytic completion.
All inputs use fm^-1 except Phi/PhiBar; the returned cut is dimensionless.
"""
function B0_spectral_cut(lambda::Real, q::Real, m1::Real, mu1::Real,
                         m2::Real, mu2::Real, T::Real;
                         Φ::Real=0.0, Φbar::Real=0.0,
                         pmax_inv_fm::Real=Λ_inv_fm, energy_nodes::Integer=64,
                         component::Symbol=:full)
    l,k,a,u,b,v,temp,phi,phibar,cutoff = Float64.((lambda,q,m1,mu1,m2,mu2,T,Φ,Φbar,pmax_inv_fm))
    all(isfinite,(l,k,a,u,b,v,temp,phi,phibar,cutoff)) || throw(ArgumentError("spectral cut inputs must be finite"))
    k >= 0 && a > 0 && b > 0 && temp > 0 && cutoff > 0 ||
        throw(ArgumentError("spectral cut requires q>=0, positive masses, T and pmax"))
    energy_nodes >= 4 || throw(ArgumentError("energy_nodes must be at least 4"))
    component in (:full,:vacuum,:thermal) || throw(ArgumentError("unknown spectral component $(component)"))
    function occupation(s,E,mu)
        component === :vacuum && return s == -1 ? 1.0 : 0.0
        if component === :thermal
            return s == 1 ? quark_distribution(E,mu,temp,phi,phibar) :
                           -antiquark_distribution(E,mu,temp,phi,phibar)
        end
        return distribution_value_b0(s==1 ? :plus : :minus,E,mu,temp,phi,phibar)
    end
    pair, landau = 0.0,0.0
    support = _spectral_two_line_support(k,a,b,cutoff)
    for s in (-1,1), t in (-1,1)
        support === nothing && continue
        lower,upper = s == t ? support.landau : support.pair
        # Endpoints have zero measure. Exclude them BEFORE the quadratic
        # arithmetic can turn roundoff into a spurious nonzero endpoint cell.
        lower < s*l < upper || continue
        # Exact kinematic exclusions, before nearly degenerate quadratic roots.
        if s == t
            abs(l) >= hypot(k,a-b) && continue
        else
            abs(l) <= hypot(k,a+b) && continue
            abs(l) >= hypot(a,cutoff)+hypot(b,cutoff) && continue
        end
        contribution = 0.0
        if k == 0
            l == 0 && continue # coincident static point, not a resolved delta peak
            E1 = (l^2+a^2-b^2)/(2s*l)
            E2 = t*(s*E1-l)
            if a < E1 < hypot(a,cutoff) && b < E2 < hypot(b,cutoff)
                p = sqrt(E1^2-a^2)
                contribution = -2π*p*s*t*(occupation(t,E2,v)-occupation(s,E1,u))/abs(l)
            end
        else
            for (left,right) in _spectral_cut_intervals(l,k,a,b,cutoff,s,t)
                nodes, weights = gauleg(left,right,Int(energy_nodes))
                for i in eachindex(nodes,weights)
                    E1 = nodes[i]
                    E2 = t*(s*E1-l)
                    contribution -= π/k*weights[i]*s*t*(occupation(t,E2,v)-occupation(s,E1,u))
                end
            end
        end
        if s == t
            landau += contribution
        else
            pair += contribution
        end
    end
    return (imaginary=pair+landau,pair=pair,landau=landau,
            regulator=:both_line_momenta,component=component,pmax_inv_fm=cutoff,energy_nodes=Int(energy_nodes),
            static_degeneracy_unresolved=(k==0 && l==0 && a==b),
            production_authorized=false)
end

@inline function _require_finite_real(value, label::AbstractString)
    value isa Real || throw(ArgumentError("$(label) must be real"))
    converted = Float64(value)
    isfinite(converted) || throw(ArgumentError("$(label) must be finite"))
    return converted
end

@inline function _retarded_energy_grid(m::Float64, energy_nodes::Int)
    return gauleg(m, energy_cutoff(m), energy_nodes)
end

@inline function _tilde_B0_retarded(
    sign_flag::Symbol,
    z::ComplexF64,
    q::Float64,
    m::Float64,
    m_prime::Float64,
    μ::Float64,
    T0::Float64,
    Φ::Float64,
    Φbar::Float64,
    nodes_E::AbstractVector{<:Real},
    weights_E::AbstractVector{<:Real},
)
    total = 0.0 + 0.0im
    if q < EPS_K
        @inbounds for i in eachindex(nodes_E, weights_E)
            E = nodes_E[i]
            p = internal_momentum(E, m)
            dist = distribution_value_b0(sign_flag, E, μ, T0, Φ, Φbar)
            denominator = z^2 + 2z * E + m^2 - m_prime^2
            total += weights_E[i] * (4p * dist / denominator)
        end
        return ComplexF64(total)
    end

    @inbounds for i in eachindex(nodes_E, weights_E)
        E = nodes_E[i]
        p = internal_momentum(E, m)
        dist = distribution_value_b0(sign_flag, E, μ, T0, Φ, Φbar)
        common = z^2 + 2z * E - q^2 + m^2 - m_prime^2
        total += weights_E[i] * dist * (log(common + 2p * q) - log(common - 2p * q)) / q
    end
    return ComplexF64(total)
end

"""
    B0_retarded(λ, q, m1, μ1, m2, μ2, T;
                Φ=0.0, Φbar=0.0, eta_inv_fm=1e-3, energy_nodes=128)

Evaluate the ordered two-line integral at `z = λ + i*eta_inv_fm` by direct
complex Gauss--Legendre quadrature. `λ` already includes the flavor chemical
potential shift (`k0 + μ1 - μ2`). The result is the dimensionless retarded
`B0(z,q)` for the repository Fourier convention `exp(-i*ω*t)`.

This entrypoint is intentionally separate from [`B0`](@ref). `B0` preserves
the historical real-axis principal-value/cut oracle, while `B0_retarded`
keeps the finite upper-half-plane regulator explicit. The current logarithmic
continuation fails independent vacuum-spacelike spectral checks; its name
does not certify a physical retarded correlator. Convergence in both
`eta_inv_fm` and `energy_nodes` is a caller-visible numerical requirement.
"""
function B0_retarded(
    λ::Real,
    q::Real,
    m1::Real,
    μ1::Real,
    m2::Real,
    μ2::Real,
    T0::Real;
    Φ::Real=0.0,
    Φbar::Real=0.0,
    eta_inv_fm::Real=1.0e-3,
    energy_nodes::Integer=128,
)
    λ_value = _require_finite_real(λ, "λ")
    q_value = _require_finite_real(q, "q")
    m1_value = _require_finite_real(m1, "m1")
    μ1_value = _require_finite_real(μ1, "μ1")
    m2_value = _require_finite_real(m2, "m2")
    μ2_value = _require_finite_real(μ2, "μ2")
    T_value = _require_finite_real(T0, "T")
    Φ_value = _require_finite_real(Φ, "Φ")
    Φbar_value = _require_finite_real(Φbar, "Φbar")
    eta_value = _require_finite_real(eta_inv_fm, "eta_inv_fm")

    q_value >= 0.0 || throw(ArgumentError("q must be non-negative"))
    m1_value >= 0.0 || throw(ArgumentError("m1 must be non-negative"))
    m2_value >= 0.0 || throw(ArgumentError("m2 must be non-negative"))
    T_value > 0.0 || throw(ArgumentError("T must be positive"))
    eta_value > 0.0 || throw(ArgumentError("eta_inv_fm must be positive"))
    energy_nodes >= 4 || throw(ArgumentError("energy_nodes must be at least 4"))

    nodes1, weights1 = _retarded_energy_grid(m1_value, Int(energy_nodes))
    nodes2, weights2 = _retarded_energy_grid(m2_value, Int(energy_nodes))
    z = ComplexF64(λ_value, eta_value)

    term1 = _tilde_B0_retarded(
        :plus, -z, q_value, m1_value, m2_value, μ1_value, T_value,
        Φ_value, Φbar_value, nodes1, weights1,
    )
    term2 = _tilde_B0_retarded(
        :minus, z, q_value, m1_value, m2_value, μ1_value, T_value,
        Φ_value, Φbar_value, nodes1, weights1,
    )
    term3 = _tilde_B0_retarded(
        :plus, z, q_value, m2_value, m1_value, μ2_value, T_value,
        Φ_value, Φbar_value, nodes2, weights2,
    )
    term4 = _tilde_B0_retarded(
        :minus, -z, q_value, m2_value, m1_value, μ2_value, T_value,
        Φ_value, Φbar_value, nodes2, weights2,
    )
    result = term1 - term2 + term3 - term4
    isfinite(real(result)) && isfinite(imag(result)) ||
        throw(ArgumentError("retarded B0 result is not finite"))
    return ComplexF64(result)
end

# ---------------------------------------------------------------------------
"""计算A的辅助函数,处理对常数项的积分"""
function const_integral_term_A(m::Real)
    m_pos = max(m, 0.0)
    # m -> 0 极限：term2 -> 0，term1 = Λ^2
    if m_pos < 1e-14
        return (Λ_inv_fm^2) / 2.0
    end

    term1 = Λ_inv_fm * sqrt(Λ_inv_fm^2 + m_pos^2)
    term2 = m_pos^2 * log((Λ_inv_fm + sqrt(Λ_inv_fm^2 + m_pos^2)) / m_pos)
    return (term1 - term2) / 2.0
end

"""
    A(m, μ, T, Φ, Φbar, nodes_p, weights_p)
计算单线积分函数A,需要传入预生成的动量的积分节点与权重
计算中的常数1需要截断,而分布函数的部分理论上可积分到无穷；实践中通常采用有限上限近似。
常数项的积分可以直接计算，见 const_integral_term_A 函数
因此只需计算分布函数的积分。

注意：在高温/轻质量/Φ 接近 1 的参数区，分布函数尾部贡献更显著，
积分上限 10.0 fm⁻¹ 可能不足；经验上 p ∈ [0, 20] fm⁻¹ 会更稳健。

推荐：根据精度/性能需求自行生成节点；一个常用折中是 gauleg(0.0, 20.0, 16)。
"""
function A(m::Real, μ::Real, T::Real, Φ::Real, Φbar::Real,
    nodes_p::AbstractVector{<:Real}, weights_p::AbstractVector{<:Real})
    integral = -const_integral_term_A(m) # 计算常数项积分部分
    @inbounds @simd for i in eachindex(nodes_p)
        node_p = nodes_p[i]
        weight_p = weights_p[i]
        E = sqrt(node_p^2 + m^2)
        dist_quark = distribution_value(:pnjl, :plus, E, μ, T, Φ, Φbar)
        dist_antiquark = distribution_value(:pnjl, :minus, E, μ, T, Φ, Φbar)
        integral += weight_p * node_p^2 / E * (dist_quark + dist_antiquark)
    end
    return 4.0 * integral
end

end # module OneLoopIntegrals
