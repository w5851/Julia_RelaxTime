"""Review real full-RS scans and the retained xi=0 Fortran comparison on W."""
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import zipfile

WORK = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-production-replay-20261025-v2')
SOURCE = Path(r'D:\CodexCompute\Julia_RelaxTime\full-rs-layer-validation-20261025-v2')
PROJECT = SOURCE / 'project'
SOURCE_SHA = '789c20ef317b0327692772cb256a408cf0a7ed84b5ad3fa9637ca1ea266888e5'


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(line for line in stream if line.strip() and not line.startswith('#')))


def helper(relative, name):
    spec = importlib.util.spec_from_file_location(name, PROJECT / relative)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def same(a, b):
    return math.isclose(a, b, rel_tol=1e-10, abs_tol=1e-14)


package = read_json(SOURCE / 'package_manifest.json')
assert digest(SOURCE / 'source.zip') == package['zip_sha256'] == SOURCE_SHA
for name, checksum in package['source_files'].items():
    assert digest(PROJECT / name) == checksum, name
verification = read_json(WORK / 'verification.json')
assert verification['source_verified_before_and_after']
assert {r['stage'] for r in verification['stages']} == {'production', 'fortran'}
assert all(r['process_exit_code'] == 0 for r in verification['stages'])
inputs = helper('scripts/analysis/relaxtime/prepare_transport_production_inputs.py', 'inputs')
artifacts = helper('scripts/relaxtime/check_transport_production_artifact.py', 'artifacts')
baseline = helper('scripts/dev/export_thermal_weighted_transport_baseline.py', 'baseline')
profile = PROJECT / 'config/models/pnjl/transport_sampling/thermal_weighted_v1.toml'
snapshots = 0
for name in ('production_replay', 'fortran_alignment'):
    run = WORK / name
    manifest = read_json(run / 'manifest.json')
    assert manifest['source_archive']['sha256'] == SOURCE_SHA and manifest['head'] is None
    inputs.verified_sources(run, manifest, PROJECT.resolve())
    commit, identity = baseline.replay_artifact_commit(run, manifest)
    assert commit == 'unknown' and identity['calculation_commit'] is None
    assert manifest['parameters']['profile']['source_sha256'] == digest(profile)
    for entry in manifest['source_files']:
        relative = entry['path'].replace('\\', '/')
        assert digest(run / 'source' / relative) == entry['sha256'] == package['source_files'][relative]
        snapshots += 1
    for input_name in ('review_points.csv', 'channel_plan.csv'):
        assert digest(run / 'inputs' / input_name) == package['input_files'][input_name]

run = WORK / 'production_replay'
status = read_json(run / 'status.json')
assert status['complete'] and status['production_replay_passed'] and status['failures'] == 0
assert status['points'] == status['completed_points'] == 12 and status['comparisons'] == 108
manifest = read_json(run / 'manifest.json')
reference_hash, targets = inputs.verified_reference(run, manifest)
assert reference_hash == digest(SOURCE / 'joint_complete_summary_v1/comparisons.csv')
comparisons = rows(run / 'comparisons.csv')
seen = set()
for row in comparisons:
    inputs.verify_comparison(row)
    key = row['point_id'], row['observable']
    assert key not in seen and (float(row['qualified_candidate']), float(row['qualified_reference'])) == targets[key]
    seen.add(key)
assert seen == set(targets) and len(seen) == 108
points = {r['point_id']: r for r in rows(SOURCE / 'inputs/review_points.csv')}
qualified_channels = 0
for point in {p for p, _ in seen}:
    folder = run / 'points' / point
    checked = artifacts.check_artifact(folder, profile, 'unknown', 'production', PROJECT)
    assert checked['completed_points'] == 1 and checked['qualified_channels'] == 17
    qualified_channels += checked['qualified_channels']
    actual = rows(folder / 'phase_guided_transport_scan.csv')
    assert len(actual) == 1
    actual = actual[0]
    assert tuple(float(actual[k]) for k in ('T_MeV', 'muB_MeV', 'xi')) == tuple(float(points[point][k]) for k in ('T_MeV', 'muB_MeV', 'xi'))
    for row in (r for r in comparisons if r['point_id'] == point):
        assert float(actual[row['observable']]) == float(row['production'])

fortran = WORK / 'fortran_alignment'
status = read_json(fortran / 'status.json')
assert status['complete'] and status['comparison_complete'] and status['frozen_algebra_replay_passed']
assert status['points'] == status['completed_points'] == status['external_5pct_passed'] == 4 and status['failures'] == 0
fortran_package = read_json(SOURCE / 'fortran_package_manifest.json')
assert digest(SOURCE / 'fortran_inputs.zip') == fortran_package['zip_sha256'] == 'a00d15db35f8488b5ee7d830b44e85fe806554e880e682cdf2551a66edf8ca3d'
for name, checksum in fortran_package['files'].items():
    assert digest(WORK / 'fortran_inputs' / name) == checksum, name
retained = read_json(fortran / 'fortran_inputs.json')
assert len(retained) == 24
for entry in retained:
    assert digest(fortran / entry['snapshot']) == digest(Path(entry['source'])) == entry['sha256']
assert len(rows(fortran / 'background.csv')) == 8
observable_rows = rows(fortran / 'observables.csv')
channel_rows = rows(fortran / 'channels.csv')
assert len(observable_rows) == 4 and len(channel_rows) == 68
ids = {'eta_muB0_1', 'eta_muB0_2', 'eta_muB800_1', 'eta_muB800_2'}
assert {r['target_id'] for r in observable_rows} == ids
sampling = read_json(fortran / 'manifest.json')['parameters']['profile']['sampling']
for row in observable_rows:
    for name, denominator in (('relative_to_digitized', 'digitized_eta_over_s'), ('relative_to_fortran', 'fortran_eta_over_s')):
        change = float(row['julia_eta_over_s']) / float(row[denominator]) - 1
        assert same(change, float(row[name]))
    assert abs(float(row['relative_to_digitized'])) <= 0.05 and row['passes_external_5pct'] == 'true'
    assert all(abs(float(row[name])) <= 1e-6 for name in
               ('frozen_eta_replay_relative', 'frozen_tau_replay_max_relative', 'frozen_density_replay_max_relative'))
    selected = [r for r in channel_rows if r['target_id'] == row['target_id']]
    assert len(selected) == 17 and {r['channel'] for r in selected} == artifacts.RATE_KEYS
    for channel in selected:
        rate, old_rate, error = (float(channel[k]) for k in ('julia_rate', 'fortran_rate', 'estimated_error'))
        assert math.isfinite(rate) and rate > 0 and old_rate > 0
        assert 0 <= error <= sampling['atol'] + sampling['rtol'] * rate
        assert same(rate / old_rate - 1, float(channel['relative_change']))
review = dict(host='W', source_archive_sha256=SOURCE_SHA, source_files_verified=package['files'],
              source_snapshots_verified=snapshots, production_replay_passed=True,
              production_points=12, production_comparisons=108, qualified_channels=qualified_channels,
              maximum_candidate_replay_relative=max(abs(float(r['replay_relative_change'])) for r in comparisons),
              maximum_independent_reference_relative=max(abs(float(r['reference_relative_change'])) for r in comparisons),
              fortran_comparison_passed=True, fortran_points=4, fortran_channels=68,
              fortran_xi_scope=[0.0], maximum_external_digitized_relative=max(abs(float(r['relative_to_digitized'])) for r in observable_rows),
              calculation_commit=None, phase_revalidation_pending=True, baseline_pending=True,
              formal_production_promoted=False)
(WORK / 'reviewed_result.json').write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8')
archive = WORK / 'returned_evidence.zip'
assert not archive.exists()
files = []
for directory in ('production_replay', 'fortran_alignment', 'fortran_inputs'):
    files.extend(p for p in (WORK / directory).rglob('*') if p.is_file())
files.extend(p for p in WORK.iterdir() if p.is_file() and p.suffix in ('.json', '.log', '.ps1', '.py'))
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path in sorted(set(files)):
        output.write(path, path.relative_to(WORK).as_posix())
info = dict(sha256=digest(archive), bytes=archive.stat().st_size, files=len(set(files)))
(WORK / 'returned_archive_manifest.json').write_text(json.dumps(info, indent=2) + '\n', encoding='utf-8')
print(json.dumps(review, indent=2))
print(json.dumps(info, indent=2))
