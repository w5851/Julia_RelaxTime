# PNJL 相图 r2：PNG 接受后的矢量 PDF 交付

作者已明确回复“接受，生成同版 PDF”。原 PNG 审阅案例及其 manifest 保留不变，接受记录和已审阅 manifest 的逐字节副本见 provenance/。

使用已接受的 source_snapshot/render_phase.py、相同输入和相同绘图合同生成 PNG/PDF。本包 PNG 与已接受 PNG 字节完全一致，显示数组、密度估计、连接规则、坐标范围均一致。

图中 (a) 实心圆采用源表 CEP 坐标，(b) 空心圆采用最邻近温度处的共存密度均值估计。右图两支共存边界和 crossover 闭合至相同估计点；两图温度范围为 60–230 MeV。估计和连接只属于显示层，填色为共存区间，不是旋节不稳定区。

PDF 已通过单页、6.75×4.6 in 尺寸、4 个嵌入字体、无 Type-3 字体、无栅格图像检查。600 dpi 页面渲染经 agent 视觉复核，无裁切或非预期重叠；渲染证据在 provenance/。

公共 SOP、数值源表和论文正文均未修改。figure_mode=audit，manuscript_eligible=false，current_publication_layer=false；本次接受用于图件交付，尚未将新图替换进论文。

所有显示语义保留在 plot_manifest.json，校验结果见 validation.json。source_snapshot/finalize_vector_delivery_v2.py 只补交付与验收记录，不修改图像字节。渲染器初始 manifest 已逐字节保存在 provenance/render_stage_manifest.json。
