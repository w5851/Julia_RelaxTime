"""Retain the author's PNG acceptance and vector-delivery checks without rerendering."""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
REPO = Path(r"D:\Desktop\Julia_RelaxTime")
ROOT = REPO / "data/outputs/figures/pnjl/phase_diagram"
ACCEPTED = ROOT / "figure4_phase_diagram_prod_v1__aps_v2__png_review_20261008_r2"
CASE = ROOT / "figure4_phase_diagram_prod_v1__aps_v2__pdf_20261008_r2"
WORK = Path(r"D:\Desktop\paper\tmp\phase_sop_v2_review_20261008")
REPORT = Path(r"D:\Desktop\paper\My_Paper\pnjl_aniso_transport\writing_package\outputs\journal_en\scope_comparison_2026-10-08")
sys.path.insert(0, str(REPO))

import numpy as np
from PIL import Image
from scripts.plotting.plot_manifest import input_record, write_manifest
from scripts.plotting.validate_plot_artifact import validate_manifest


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def record(path: Path) -> dict:
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest(path)}


def read(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


acceptance = read(WORK / "png_acceptance_r2.json")
original = read(ACCEPTED / "plot_manifest.json")
manifest = read(CASE / "plot_manifest.json")
if "author_review" in manifest or (CASE / "provenance").exists():
    raise FileExistsError("Vector delivery metadata was already finalized")
assert acceptance["status"] == "author_accepted"
assert digest(ACCEPTED / "plot_manifest.json") == acceptance["reviewed_manifest"]["sha256"]
png = CASE / "phase_diagram_TmuB_Trho.png"
pdf = CASE / "phase_diagram_TmuB_Trho.pdf"
assert digest(png) == acceptance["reviewed_png"]["sha256"]
identical_fields = (
    "axes", "series", "selection_rule", "interpolation_policy", "connector_policy",
    "missing_value_policy", "derived_display_geometry", "caption_parameters", "frozen_render_signature",
)
assert all(original[field] == manifest[field] for field in identical_fields)
assert all(digest(Path(path)) == expected for path, expected in acceptance["input_sha256"].items())
assert all(digest(REPO / path) == expected for path, expected in acceptance["contract_sha256"].items())
pdf_record = next(item for item in manifest["outputs"] if item["format"] == "pdf")
inspection = pdf_record["inspection"]
assert digest(pdf) == pdf_record["sha256"]
assert inspection["page_count"] == 1 and inspection["raster_image_count"] == 0
assert inspection["fonts_embedded"] and inspection["type3_font_count"] == 0
assert inspection["physical_size_inches"] == [6.75, 4.6]

comparison = read(REPORT / "comparison.json")
assert all(digest(Path(item["path"])) == item["sha256"] for item in comparison["manuscript"]["files"])
assert digest(REPO / ".agents/skills/plotting-sop/SKILL.md") == "be15dd609b9d443b08d552d31df237d5ea55dc9135959c1b1f9d03323bb0fc4c"

render = WORK / "pdf_r2_render.png"
png_array = np.asarray(Image.open(png).convert("RGB"), dtype=np.int16)
pdf_array = np.asarray(Image.open(render).convert("RGB"), dtype=np.int16)
assert png_array.shape == pdf_array.shape == (2760, 4050, 3)
comparison_metrics = {
    "same_pixel_dimensions": True,
    "rgb_mean_absolute_difference_0_255": float(np.abs(png_array - pdf_array).mean()),
    "fraction_pixels_with_any_rgb_difference_gt_32": float((np.abs(png_array - pdf_array).max(axis=2) > 32).mean()),
    "interpretation": "descriptive renderer-difference metrics, not pixel-identity or numerical-accuracy claims",
}

provenance = CASE / "provenance"
provenance.mkdir()
shutil.copyfile(WORK / "png_acceptance_r2.json", provenance / "png_acceptance.json")
shutil.copyfile(ACCEPTED / "plot_manifest.json", provenance / "png_review_manifest.json")
shutil.copyfile(render, provenance / "pdf_render_review.png")
finalizer = CASE / "source_snapshot/finalize_vector_delivery.py"
shutil.copyfile(Path(__file__), finalizer)
manifest["inputs"].extend([
    input_record(provenance / "png_acceptance.json", role="author_png_acceptance"),
    input_record(provenance / "png_review_manifest.json", role="accepted_png_manifest_archive"),
    input_record(finalizer, role="delivery_metadata_finalizer"),
])
manifest["review_status"] = "author_accepted_png"
manifest["case_revision"]["author_acceptance"] = "author_accepted_png"
manifest["author_review"] = {
    "status": "author_accepted_png", "instruction": acceptance["author_instruction"],
    "scope": acceptance["acceptance_scope"],
    "record": record(provenance / "png_acceptance.json"),
}
manifest["vector_delivery_verification"] = {
    "status": "passed", "verified_at_utc": datetime.now(timezone.utc).isoformat(),
    "accepted_png_sha256": acceptance["reviewed_png"]["sha256"],
    "png_byte_identity": True, "identical_semantic_fields": list(identical_fields),
    "pdf_inspection": inspection, "pdf_render_review": record(provenance / "pdf_render_review.png"),
    "agent_visual_review": "passed: panel bounds, curves, markers, labels and legends match the accepted composition; no clipping",
    "renderer_comparison": comparison_metrics,
    "shared_sop_modified": False, "numerical_sources_modified": False,
    "paper_tex_pdf_bbl_modified": False,
}
write_manifest(CASE / "plot_manifest.json", manifest)
errors = validate_manifest(CASE / "plot_manifest.json", repo_root=REPO)
if errors:
    raise AssertionError(errors)

validation = read(CASE / "validation.json")
validation.update({
    "passed": True, "errors": [], "human_visual_review": "author_accepted_png",
    "agent_pdf_visual_review": "passed", "delivery_stage": "vector_delivery",
    "png_matches_accepted_bytes": True, "all_display_semantics_equal": True,
    "pdf_inspection": inspection, "pdf_render_review": record(provenance / "pdf_render_review.png"),
    "renderer_comparison": comparison_metrics,
})
(CASE / "validation.json").write_text(json.dumps(validation, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
(CASE / "README.md").write_text(
    "# PNJL 相图 r2：PNG 接受后的矢量 PDF 交付\n\n"
    "作者已明确回复“接受，生成同版 PDF”。原 PNG 审阅案例及其 manifest 保留不变，"
    "接受记录和已审阅 manifest 的逐字节副本见 provenance/。\n\n"
    "使用已接受的 source_snapshot/render_phase.py、相同输入和相同绘图合同生成 PNG/PDF。"
    "本包 PNG 与已接受 PNG 字节完全一致，显示数组、密度估计、连接规则、坐标范围均一致。\n\n"
    "图中 (a) 实心圆采用源表 CEP 坐标，(b) 空心圆采用最邻近温度处的共存密度均值估计。"
    "右图两支共存边界和 crossover 闭合至相同估计点；两图温度范围为 60–230 MeV。"
    "估计和连接只属于显示层，填色为共存区间，不是旋节不稳定区。\n\n"
    "PDF 已通过单页、6.75×4.6 in 尺寸、4 个嵌入字体、无 Type-3 字体、无栅格图像检查。"
    "600 dpi 页面渲染经 agent 视觉复核，无裁切或非预期重叠；渲染证据在 provenance/。\n\n"
    "公共 SOP、数值源表和论文正文均未修改。figure_mode=audit，manuscript_eligible=false，"
    "current_publication_layer=false；本次接受用于图件交付，尚未将新图替换进论文。\n\n"
    "所有显示语义保留在 plot_manifest.json，校验结果见 validation.json。"
    "source_snapshot/finalize_vector_delivery.py 只补交付与验收记录，不修改图像字节。\n",
    encoding="utf-8",
)

comparison["phase_figure_review"]["status"] = "author_accepted_png; vector_delivery_verified"
comparison["phase_figure_vector_delivery"] = {
    "case_path": str(CASE), "pdf_path": str(pdf), "pdf_sha256": digest(pdf),
    "png_path": str(png), "png_sha256": digest(png),
    "manifest_path": str(CASE / "plot_manifest.json"), "manifest_sha256": digest(CASE / "plot_manifest.json"),
    "validation_path": str(CASE / "validation.json"), "validation_sha256": digest(CASE / "validation.json"),
    "acceptance_record": record(provenance / "png_acceptance.json"),
    "status": "author_accepted_png; vector_delivery_verified", "inspection": inspection,
    "manuscript_modified": False, "shared_sop_modified": False,
}
(REPORT / "comparison.json").write_text(json.dumps(comparison, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"vector_delivery": "verified", "pdf_sha256": digest(pdf),
                  "manifest_sha256": digest(CASE / "plot_manifest.json"),
                  "validation_errors": errors}, ensure_ascii=False))
