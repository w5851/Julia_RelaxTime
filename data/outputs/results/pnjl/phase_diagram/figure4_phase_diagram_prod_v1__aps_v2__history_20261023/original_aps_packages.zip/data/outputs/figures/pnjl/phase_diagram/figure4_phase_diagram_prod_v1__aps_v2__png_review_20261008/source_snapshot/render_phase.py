"""Replot the manuscript's frozen PNJL phase data with the APS v2 contract.

This postprocessor never invokes a solver or modifies numerical inputs.
The density panel uses native boundary/crossover support and has no CEP
density marker: the source CEP table contains no density coordinate.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True

PARSER = argparse.ArgumentParser()
PARSER.add_argument("--repo-root", type=Path, required=True)
PARSER.add_argument("--output-dir", type=Path, required=True)
PARSER.add_argument("--stage", choices=("png_review", "vector_delivery"), default="png_review")
PARSER.add_argument("--acceptance", type=Path)
ARGS = PARSER.parse_args()
REPO = ARGS.repo_root.resolve()
OUT = ARGS.output_dir.resolve()
sys.path.insert(0, str(REPO))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator
import numpy as np

from scripts.plotting.plot_manifest import (
    build_manifest, generator_record, input_record, runtime_record,
    sha256_file, write_manifest,
)
from scripts.plotting.plot_quality import export_figure
from scripts.plotting.plot_style import (
    configure_axis_ticks, configure_matplotlib, figure_size_inches,
    load_profile, phase_style,
)
from scripts.plotting.validate_plot_artifact import validate_manifest


SOURCE = REPO / "data/outputs/results/pnjl/phase_diagram/figure4_phase_diagram_prod_v1"
TAG = "figure4_phase_diagram_prod_v1_c1_p24t8"
XI_VALUES = (-0.5, -0.25, 0.0, 0.25, 0.5)
SOURCE_FILES = {
    name: SOURCE / "reference" / f"{name}_{TAG}.csv"
    for name in ("boundary", "crossover", "cep")
}
SOURCE_MANIFEST = SOURCE / "phase_reference_source_manifest.json"
OLD_PLOT_MANIFEST = REPO / "data/outputs/figures/pnjl/phase_diagram/figure4_phase_diagram_prod_v1/plot_manifest.json"
CONTRACT_FILES = [
    REPO / "config/plotting/candidate_aps_v2.toml",
    REPO / "docs/guides/sop/workflows/figure_production.md",
    *[REPO / "scripts/plotting" / name for name in (
        "plot_style.py", "plot_manifest.py", "plot_quality.py",
        "plot_bundle.py", "plot_provenance.py", "validate_plot_artifact.py",
    )],
]


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(line for line in handle if line.strip() and not line.startswith("#")))


def selected(rows: list[dict[str, str]], xi: float, key: str) -> list[dict[str, str]]:
    result = sorted((row for row in rows if abs(float(row["xi"]) - xi) < 1e-10), key=lambda row: float(row[key]))
    if not result:
        raise ValueError(f"Missing support at xi={xi}")
    keys = [float(row[key]) for row in result]
    if len(keys) != len(set(keys)):
        raise ValueError(f"Duplicate support key at xi={xi}: {key}")
    return result


def values(rows: list[dict[str, str]], field: str) -> np.ndarray:
    data = np.array([float(row[field]) for row in rows], dtype=float)
    if not np.isfinite(data).all():
        raise ValueError(f"Nonfinite source field: {field}")
    return data


def segments(keys: np.ndarray, maximum_step: float) -> list[np.ndarray]:
    if len(keys) < 2:
        return [np.arange(len(keys))]
    breaks = np.flatnonzero(np.diff(keys) > maximum_step + 1e-7) + 1
    return list(np.split(np.arange(len(keys)), breaks))


if OUT.exists():
    raise FileExistsError(f"Refusing to overwrite case: {OUT}")
for required in [SOURCE_MANIFEST, OLD_PLOT_MANIFEST, *SOURCE_FILES.values(), *CONTRACT_FILES]:
    if not required.is_file():
        raise FileNotFoundError(f"Required frozen input or plotting contract is missing: {required}")
source_manifest = json.loads(SOURCE_MANIFEST.read_text(encoding="utf-8-sig"))
expected = {Path(item["path"]).name: item for item in source_manifest["artifacts"]}
for source in SOURCE_FILES.values():
    check = expected[source.name]
    if source.stat().st_size != check["bytes"] or sha256_file(source) != check["sha256"]:
        raise ValueError(f"Frozen input drift: {source}")
rows = {name: read_rows(path) for name, path in SOURCE_FILES.items()}
original_hashes = {str(path): sha256_file(path) for path in SOURCE_FILES.values()}
contract_hashes = {str(path.relative_to(REPO)): sha256_file(path) for path in CONTRACT_FILES}
generator_hash = sha256_file(Path(__file__))

if ARGS.stage == "vector_delivery":
    if ARGS.acceptance is None:
        raise ValueError("Vector delivery requires an explicit author-acceptance record")
    acceptance = json.loads(ARGS.acceptance.read_text(encoding="utf-8-sig"))
    if acceptance.get("status") != "author_accepted":
        raise ValueError("PNG review has not been accepted by the author")
    for field, actual in (("generator_sha256", generator_hash), ("input_sha256", original_hashes), ("contract_sha256", contract_hashes)):
        if acceptance.get(field) != actual:
            raise ValueError(f"Accepted review differs from vector delivery: {field}")

profile = load_profile("candidate_aps_v2")
font_info = configure_matplotlib(profile)
size = figure_size_inches(profile, "double_column")
figure, axes = plt.subplots(1, 2, figsize=size, sharey=True)
figure.subplots_adjust(left=0.10, right=0.98, bottom=0.30, top=0.92, wspace=0.14)
series = []
support_records = []
primitive_checks = 0


def add_line(ax_index: int, x: np.ndarray, y: np.ndarray, support: np.ndarray,
             *, xi: float, color: str, state: str, series_id: str, key: str,
             source_name: str, x_field: str, y_field: str, maximum_step: float) -> None:
    global primitive_checks
    source_segments = segments(support, maximum_step)
    style = phase_style(profile, state)
    for indices in source_segments:
        line, = axes[ax_index].plot(x[indices], y[indices], color=color,
                                   linestyle=style["linestyle"], linewidth=1.2,
                                   alpha=1.0, zorder=3)
        if not (np.array_equal(line.get_xdata(), x[indices]) and np.array_equal(line.get_ydata(), y[indices])):
            raise AssertionError("Rendered line differs from selected native source values")
        primitive_checks += 1
    series.append({
        "series_id": series_id, "state": state, "panel": ax_index,
        "xi": xi, "source": source_name, "x_field": x_field, "y_field": y_field,
        "row_count": len(x), "segment_count": len(source_segments),
        "support_rule": f"native frozen rows at exact xi, ordered by {key}; adjacent native support only",
        "mask_rule": f"reject nonfinite values; break when {key} increment exceeds {maximum_step:.12g}; no synthetic endpoint",
    })


for index, xi in enumerate(XI_VALUES):
    color = profile.colors[index]
    boundary = selected(rows["boundary"], xi, "plot_order_key")
    crossover = selected(rows["crossover"], xi, "plot_order_key")
    cep = selected(rows["cep"], xi, "T_CEP_MeV")
    if len(cep) != 1 or any(row["converged"].lower() != "true" for row in crossover):
        raise ValueError(f"Source state is not qualified at xi={xi}")
    temp = values(boundary, "T_MeV")
    mu = 3.0 * values(boundary, "mu_transition_MeV")
    low, high = values(boundary, "rho_hadron"), values(boundary, "rho_quark")
    if not np.all(low < high):
        raise ValueError("Coexistence density branches are not ordered")
    mu_c = 3.0 * values(crossover, "mu_MeV")
    temp_c, rho_c = values(crossover, "T_crossover_MeV"), values(crossover, "rho")
    endpoint_mu, endpoint_temp = float(cep[0]["muB_CEP_MeV"]), float(cep[0]["T_CEP_MeV"])
    if not np.isfinite([endpoint_mu, endpoint_temp]).all() or np.any(mu_c > endpoint_mu + 1e-6):
        raise ValueError("Crossover support extends beyond the source CEP chemical potential")
    step_c = float(np.median(np.diff(mu_c))) * 1.5
    for panel, xx, xf, sid in ((0, mu, "3*mu_transition_MeV", "first_order"),
                               (1, low, "rho_hadron", "low_density_boundary"),
                               (1, high, "rho_quark", "high_density_boundary")):
        add_line(panel, xx, temp, temp, xi=xi, color=color, state="first_order",
                 series_id=f"{sid}_xi_{xi:g}", key="T_MeV", source_name="boundary",
                 x_field=xf, y_field="T_MeV", maximum_step=5.0)
    for panel, xx, xf in ((0, mu_c, "3*mu_MeV"), (1, rho_c, "rho")):
        add_line(panel, xx, temp_c, mu_c, xi=xi, color=color, state="crossover",
                 series_id=f"crossover_panel_{panel}_xi_{xi:g}", key="muB_MeV", source_name="crossover",
                 x_field=xf, y_field="T_crossover_MeV", maximum_step=step_c)
    for indices in segments(temp, 5.0):
        axes[1].fill_betweenx(temp[indices], low[indices], high[indices],
                              color=color, alpha=0.07, linewidth=0, zorder=1)
    axes[0].scatter([endpoint_mu], [endpoint_temp], s=36, marker="o", color=color,
                    edgecolor=color, linewidth=0.7, zorder=5)
    series.append({
        "series_id": f"cep_TmuB_xi_{xi:g}", "state": "cep_confirmed", "panel": 0,
        "xi": xi, "row_count": 1, "source": "cep",
        "support_rule": "direct T_CEP_MeV and muB_CEP_MeV from retained accepted CEP table",
        "mask_rule": "reject nonfinite coordinate; density coordinate is absent and is not estimated",
    })
    support_records.append({
        "xi": xi, "native_boundary_rows": len(boundary), "native_crossover_rows": len(crossover),
        "native_cep_rows": 1, "last_boundary_temperature_MeV": float(temp[-1]),
        "cep_temperature_MeV": endpoint_temp,
        "unsampled_boundary_to_cep_interval_MeV": float(endpoint_temp-temp[-1]),
        "density_cep_drawn": False,
    })

xlabels = [r"$\mu_B\;(\mathrm{MeV})$", r"$\rho/\rho_0$"]
ylabel = r"$T\;(\mathrm{MeV})$"
for index, ax in enumerate(axes):
    ax.set_xlabel(xlabels[index])
    ax.set_ylim(50, 230)
    ax.yaxis.set_major_locator(FixedLocator([50, 100, 150, 200]))
    ax.set_xlim(0, 1250 if index == 0 else 3.15)
    ax.xaxis.set_major_locator(FixedLocator([0, 400, 800, 1200] if index == 0 else [0, 1, 2, 3]))
    configure_axis_ticks(ax, profile)
    ax.grid(False)
    ax.text(0.02, 1.025, f"({chr(97+index)})", transform=ax.transAxes,
            ha="left", va="bottom", fontsize=13, fontweight="bold")
axes[0].set_ylabel(ylabel)
parameter_handles = [Line2D([], [], color=profile.colors[i], linewidth=1.6,
                            label=rf"$\xi={xi:g}$") for i, xi in enumerate(XI_VALUES)]
figure.legend(handles=parameter_handles, loc="lower center", bbox_to_anchor=(0.53, 0.105),
              ncol=5, frameon=False, handlelength=1.5, columnspacing=0.9, handletextpad=0.45)
semantic_handles = [
    Line2D([], [], color="#252525", linewidth=1.2, linestyle="-", label="First order"),
    Line2D([], [], color="#252525", linewidth=1.2, linestyle="--", label="Crossover"),
    Line2D([], [], color="#252525", marker="o", linestyle="None", markersize=6, label="CEP in (a)"),
]
figure.legend(handles=semantic_handles, loc="lower center", bbox_to_anchor=(0.53, 0.025),
              ncol=3, frameon=False, handlelength=1.7, columnspacing=1.2)

OUT.mkdir(parents=True, exist_ok=False)
snapshot = OUT / "source_snapshot"
snapshot.mkdir()
generator_copy = snapshot / "render_phase.py"
shutil.copyfile(Path(__file__), generator_copy)
for contract in CONTRACT_FILES:
    target = snapshot / "contract" / contract.relative_to(REPO)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(contract, target)
formats = ("png",) if ARGS.stage == "png_review" else ("png", "pdf")
outputs, quality = export_figure(figure, OUT / "phase_diagram_TmuB_Trho", profile,
                                 intended_width_inches=size[0], formats=formats)
plt.close(figure)
for source in SOURCE_FILES.values():
    if original_hashes[str(source)] != sha256_file(source):
        raise AssertionError("A frozen numerical input changed during plotting")

inputs = [input_record(path, role="calculation_result", units={
    "temperature": "MeV", "chemical_potential": "MeV",
    "density_columns": "rho/rho0, already dimensionless",
}) for path in SOURCE_FILES.values()]
inputs.extend(input_record(path, role=role) for path, role in (
    (SOURCE_MANIFEST, "calculation_source_manifest"), (OLD_PLOT_MANIFEST, "historical_display_provenance"),
))
inputs.extend(input_record(path, role="plotting_contract") for path in CONTRACT_FILES)
manifest = build_manifest(
    asset_id="pnjl.aniso_transport.phase_diagram.aps_v2.review",
    figure_family="pnjl_phase_diagram", case_slug=OUT.name,
    figure_mode="audit", semantic_status="candidate_native_support_phase_diagram",
    style_profile=profile.profile_id, publication_scope="internal_review",
    generator=generator_record(generator_copy, command=" ".join(sys.argv),
                               runtime=runtime_record({"matplotlib": matplotlib.__version__, "font": font_info})),
    inputs=inputs, axes=[
        {"field": "muB_MeV", "source_unit": "MeV", "display_unit": "MeV", "label": xlabels[0],
         "transform": "muB=3*mu_transition or 3*mu_MeV; source muB_CEP_MeV is direct"},
        {"field": "rho_over_rho0", "source_unit": "dimensionless", "display_unit": "dimensionless", "label": xlabels[1],
         "transform": "identity; native rho_hadron/rho_quark/rho already use rho0=0.16 fm^-3"},
        {"field": "temperature_MeV", "source_unit": "MeV", "display_unit": "MeV", "label": ylabel, "transform": "identity"},
    ], series=series, outputs=outputs,
    selection_rule="five exact xi slices from the previously adopted frozen numerical tables",
    interpolation_policy="none", connector_policy="forbidden",
    missing_value_policy="native support only; retain gaps to CEP; no density CEP estimate or synthetic closure",
    validation={"finite": True, "duplicate_keys": True, "support": True, "strict_gate": False,
                "source_hashes_match_frozen_manifest": True, "numerical_input_hashes_unchanged": True,
                "line_primitives_equal_source_arrays": primitive_checks, "native_support": support_records},
    rendering={
        "column": "double_column", "figure_size_inches": list(size), "bbox_inches": "fixed",
        "requested_dpi": profile.dpi, "intended_insertion_width_mm": size[0]*25.4,
        "delivery_stage": ARGS.stage, "vector_delivery_pending": ARGS.stage == "png_review",
        "legend_policy": "shared_external", "legend_location": "below panels", "legend_outside": True,
        "color_route": "undecided_review", "quality": quality,
        "support_visual_policy": "candidate line-first / CEP landmark only; native counts and gaps retained in manifest",
        "parameter_encoding": "accessible palette; phase meaning uses solid/dashed lines; print route remains author choice",
        "coexistence_fill": "between native low/high density boundary pairs only, alpha=0.07; no extension to CEP",
    }, calculation_sha=source_manifest["source_head_sha"],
    source_run_id=source_manifest["source_run_url"],
)
manifest["manuscript_eligible"] = False
manifest["current_publication_layer"] = False
manifest["review_status"] = "agent_review"
manifest["frozen_render_signature"] = {
    "generator_sha256": generator_hash, "input_sha256": original_hashes, "contract_sha256": contract_hashes,
}
manifest["caption_parameters"] = {
    "panels": {"a": "T-muB", "b": "T-rho/rho0"}, "xi_values": list(XI_VALUES),
    "rho0_fm3inv": 0.16, "solid": "first-order boundary", "dashed": "crossover",
    "filled_circles": "source CEP coordinates in panel (a) only",
    "shading": "native density interval between coexistence branches",
    "support_gaps": "boundaries stop at native support, with no synthetic closure or estimated CEP density",
}
manifest["source_qualification"] = {
    "status": "inherited_without_promotion", "source_verdict": source_manifest["verdict"],
    "residual_risks": source_manifest["residual_risks"], "new_numerical_computation": False,
}
write_manifest(OUT / "plot_manifest.json", manifest)
errors = validate_manifest(OUT / "plot_manifest.json", repo_root=REPO)
(OUT / "validation.json").write_text(json.dumps({"passed": not errors, "errors": errors,
    "human_visual_review": "pending", "delivery_stage": ARGS.stage}, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
(OUT / "README.md").write_text(
    "# PNJL phase figure: APS v2 review\n\n"
    "Status: agent_review. This case reuses the manuscript's retained phase calculation.\n\n"
    "The T-muB panel uses direct source CEP coordinates. The density panel does not estimate a CEP density. "
    "Both panels retain native support gaps and omit legacy plotting-only connector rows. "
    "Shaded regions cover only the native coexistence intervals.\n\n"
    "Target insertion width: 171.45 mm. Physical canvas: 6.75 x 4.6 in. PNG: 600 dpi.\n\n"
    "No solver or new numerical scan was run. No formal source table, historical figure, manuscript, "
    "or current publication pointer was replaced.\n\n"
    "The author's PNG review must precede vector delivery. See plot_manifest.json for frozen "
    "inputs, exact support, contract snapshots, caption mapping, and measurements.\n",
    encoding="utf-8",
)
print(json.dumps({"output_dir": str(OUT), "validation_errors": errors,
    "minimum_glyph_mm": quality["minimum_capital_numeral_height_mm"],
    "clipped_text": quality["clipped_text"], "text_overlaps": quality["text_overlap_pairs"],
    "legend_axes_overlaps": quality["legend_axes_overlap_count"]}, ensure_ascii=False))
raise SystemExit(1 if errors else 0)
