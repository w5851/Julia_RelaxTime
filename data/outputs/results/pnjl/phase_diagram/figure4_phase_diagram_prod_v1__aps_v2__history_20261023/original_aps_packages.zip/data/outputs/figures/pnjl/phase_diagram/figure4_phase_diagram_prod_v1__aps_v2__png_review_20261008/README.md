# PNJL phase figure: APS v2 review

Status: agent_review. This case reuses the manuscript's retained phase calculation.

The T-muB panel uses direct source CEP coordinates. The density panel does not estimate a CEP density. Both panels retain native support gaps and omit legacy plotting-only connector rows. Shaded regions cover only the native coexistence intervals.

Target insertion width: 171.45 mm. Physical canvas: 6.75 x 4.6 in. PNG: 600 dpi.

No solver or new numerical scan was run. No formal source table, historical figure, manuscript, or current publication pointer was replaced.

The author's PNG review must precede vector delivery. See plot_manifest.json for frozen inputs, exact support, contract snapshots, caption mapping, and measurements.
